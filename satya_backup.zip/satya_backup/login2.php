<?php
include('inc/config.php');
if($_REQUEST['user'] == '' AND $_REQUEST['user'] == NULL AND $_REQUEST['id'] == '' AND $_REQUEST['id'] == NULL) {
	echo "<script>window.location.href='login.php';</script>";
}

if(@$_REQUEST['hdnCmd']=="FORMSUBMIT")
	{
		$qry=mysql_query("SELECT * FROM ".PREFIX."admin WHERE id='".$_REQUEST['id']."' and code='".clean($_REQUEST['code'])."'");
		if(mysql_num_rows($qry)==1) {
				$result=mysql_fetch_assoc($qry);
				session_regenerate_id();
				$_SESSION['SESS_ID'] = $member['id'];
				$_SESSION['SESS_NAME'] = $member['name'];
				$_SESSION['ACC_MASTER'] = $member['master'];
				$_SESSION['ACC_FRONTDESK'] = $member['frontdesk'];
				$_SESSION['ACC_STUDENT'] = $member['student'];
				$_SESSION['ACC_FEE'] = $member['fee'];
				$_SESSION['ACC_ADMISSION'] = $member['admission'];
				$_SESSION['ACC_TRANSPORT'] = $member['transport'];
				$_SESSION['ACC_CERTIFICATE'] = $member['certificate'];
				$_SESSION['ACC_SETTING'] = $member['setting'];
				$_SESSION['ACC_GROUP'] = $member['group'];
				$_SESSION['LOCATION'] = $member['location'];
				$_SESSION['SECURE_SALT'] = rand(1,1000000000);
				$_SESSION['SESSION'] = $session;
				session_write_close();
				mysql_query("INSERT INTO ".PREFIX."loghistory (user,ip,date) Values ('".$login."','".get_client_ip()."','".date("Y-m-d H:i:s")."')");
				mysql_query("UPDATE ".PREFIX."admin SET is_log='TRUE',last_login='".date("Y-m-d H:i:s")."' where id='".$member['id']."'");
				echo "<script>window.location.href='main.php';</script>";
				exit();
		}
		else {
			echo "<script>window.location.href='login2.php?user=".$_REQUEST['login']."&id=".$_REQUEST['id']."&salt=FALSE';</script>";
		}
	}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>:: ACCEVATE TECHNOLOGIES - ONLINE SCHOOL MANAGEMENT v1.2::</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
        <link rel="stylesheet" href="css/bootstrap.css">
        <style>
            body {
                padding-top: 50px;
                padding-bottom: 20px;
            }
        </style>
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/main.css">
        <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    <body style="background-color: aliceblue;">
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
    <div class="container" style="width: 30%;">
      <form class="form-signin" role="form" method="post" action="login2">
	    <input type="hidden" name="hdnCmd" value="FORMSUBMIT" />
	    <input type="hidden" name="id" value="<?php echo $_REQUEST['id']; ?>" />
	    <input type="hidden" name="salt" value="<?php echo $_REQUEST['salt']; ?>" />
        <center><img src="img/accretion+.png" style="width: 200px;"></center><br/>
        <input type="text" name="login" class="form-control"  value="<?php echo $_REQUEST['user']; ?>" readonly  /><br/>
        <input type="text" name="code" class="form-control"  placeholder="Enter Your Secret Code"   /><br/>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
      </form>
	  <hr>
	  <p><b>Warning :</b> You are seeing this page because you have not logged out properly last time. Or you are currently logged in somewhere else.<br/> Please enter your secret code to login.</p>
	  <hr>
	  <?php 
	  if(isset($_REQUEST['salt']) && $_REQUEST['salt']=='FALSE') {
	  echo "<b style='color:red;'>You have entered wrong secret code.</b><hr/>";
	  }
	  ?>
      <footer>
        <p>&copy; Accevate Technologies <?php echo date('Y'); ?></p>
      </footer>
    </div> <!-- /container -->        
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/plugins.js"></script>
    </body>
</html>
