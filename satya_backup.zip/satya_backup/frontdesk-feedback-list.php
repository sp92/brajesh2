<?php
$page='frontdesk';
require('core.php');
if($_SESSION['ACC_FRONTDESK']=='0') 
{
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">

 <div class="row">
<div class="col-md-2">
<?php print_menu($frontdesk_menu_items); ?> 
</div>
	
<div class="col-md-10">	
<h3>Feedback Listings</h3>
<form name="myForm" method="get" action="frontdesk-feedback-list">
<label>Status :</label> <select name="status" required >
<option value="">--Please Select--</option>
<option value="0" <?php if($_REQUEST['status'] == '0') { echo "selected"; } ?> >PENDING</option>
<option value="1" <?php if($_REQUEST['status'] == '1') { echo "selected"; } ?> >CLEARED</option>
</select>
<input type="submit" name="submit" value="SUBMIT" />


</form>
<hr>


<table id="testTable" class="table table-hover" style="font-size:11px;">
<thead>
<tr>
<th align="center"><strong>Ref. No.</strong></th>
<th align="center"><strong>Type</strong></th>
<th align="center"><strong>Date</strong></th>
<th align="center"><strong>Name</strong></th>
<th align="center"><strong>Mobile</strong></th>
<th align="center"><strong>Complaint / Feedback</strong></th>
<th align="center"><strong>Related To</strong></th>
<?php $status = $_REQUEST["status"]; if($status == '1' or $status == 'ALL' ) { ?>
<th align="center"><strong>Comment</strong></th>
<th align="center"><strong>Action By</strong></th>
<?php } ?>
<th align="center"><strong></strong></th>
</tr>
</thead>
<tbody>
<?php
echo $_REQUEST['order'];
if($status!=''){
	$db->where('status',$status);
}


$row_data=$db->get('feedback');

$n=1;
foreach ($row_data as $row)
{

	?>
	
<tr>
<td align="center"><?php echo $row['id']; ?></td>
<td align="center"><?php echo $row['m_type']; ?></td>
<td align="center"><?php echo date('d/m/Y', strtotime($row['date'])) ; ?></td>
<td align="center"><?php echo $row['name']; ?> </td>
<td align="center"><?php echo $row['mobile']; ?> </td>
<td align="center"><?php echo $row['message']; ?> </td>
<td align="center"><?php echo $row['related']; ?> </td>
<?php if($status == '1' or $status == 'ALL' ) { ?>
<td align="center"><?php echo $row['comment']; ?> </td>

<?php } ?>
<td>
<?php 
if($status=='0') { 
$n=1;
?>
<a href="javascript:void(0)" class="btn btn-default btn-xs" rel="popover" data-html='true' data-placement="left" data-toggle="popover" data-content="<form method='post' class='clearform' id='form<?php echo $n; $n++; ?>'>
<input type='hidden' name='id' value='<?php echo $row['id']; ?>' />
<input type='hidden' name='mobile' value='<?php echo $row['mobile']; ?>' />
<input type='hidden' name='m_type' value='<?php echo $row['m_type']; ?>' />
<input type='hidden' name='message' value='<?php echo $row['message']; ?>' />
<input type='text' name='comment' style='width:150px;'  placeholder='Comment' required />
<input type='submit' class='update_form' value='Comment'  />
</form>" data-placement="top" data-original-title="Add Comment">Comment</a>
<?php } if($status=='1') { echo "<span class='label label-danger'>".$row['user']."</span>"; } ?>

</td>
</tr>


<?php
}

?>
</tbody>
</table>

</div>
<script>


$(function () {
  $('[data-toggle="popover"]').popover()
})
$(document).on('submit','.clearform',function(){
	var element = $(this);
    $.ajax({
           type: "POST",
           url: "./function/frontdeskfunctions?feedcomment",
           data: $(this).serialize(),
           success: function(data)
           {	
				element.replaceWith("Commented.");
				//location.reload();
				console.log(data);
		   }
         });
   return false;
});
</script>

 </div>

</div> <!-- /container -->

<?php
include('footer.php');
?>