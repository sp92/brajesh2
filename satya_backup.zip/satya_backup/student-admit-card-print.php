<?php
$page='student';
require('core.php');
if($_SESSION['ACC_STUDENT']=='NO') 
{
	echo "<script>window.close();</script>";
}

ob_start();
?>
<link rel="stylesheet" href="css/bootstrap.css">
<style>
.padded td, th { padding:2px; } 
</style>
<?php
$i=1;
$class=$_REQUEST['class'];
$sec=$_REQUEST['sec'];
$examtype=clean(rawurldecode($_REQUEST['exam_type']));
$type=clean($_REQUEST['type']);

// Old way to get record
//$db->where ("is_shown", 'YES');
//$db->where ("tc_issue<>'YES'");
//$db->where ("class", $class);
//$db->where ("sec", $sec);
//$db->where ("session", $_SESSION['SESSION']);
//$db->orderBy("stu_name","asc");
//$students = $db->get('student');
$db->join("stu_sess_data sc", "sc.session=s.session", "LEFT");

$db->where ("s.is_shown", 'YES');
$db->where ("s.tc_issue<>'YES'");
$db->groupBy ("s.stu_name");
$db->where ("sc.class", $class);
$db->where ("sc.sec", $sec);
$db->where ('sc.session', $_SESSION["SESSION"]);
$students = $db->get("student s");

$cols = array("address");
$address = $db->getOne('school_info',null,$cols);
foreach($students as $s){
?>


		<table style="border: none;">
			<tbody style="border: none;">
				<tr style="border: none;">
					<td rowspan="3" style="width:127px;border: none;" >
						<p align="center">
							<img  src="assets/img/rec_logo.jpg" width="73" /></p>
					</td>
					<td style="border: none;" align="right" >
						
					</td>
				</tr>
				<tr style="border: none;">
					<td style="border: none;" align="center">
							<strong style="font-size:25px;"><?php echo SCHOOLNAME; ?></strong>
					</td>
				</tr>
				<tr style="border: none;">
					<td style="border: none;" align="center">
						<p align="center">
							<strong><?php echo $address['address']; ?></strong></p>
					</td>
				</tr>
			</tbody>
		</table>

		
		<h5 align="center">
			<u><strong>Admit Card : <?php echo $examtype; ?> (<?php echo $_SESSION['SESSION']; ?>) </strong></u> </h5>
			
		<table width="98%" style="font-size:14px;">
			<tbody>
				<tr>
					<td align="right" style="width:169px;">
						<p align="right">
							Admission No. :</p>
					</td>
					<td style="border-bottom:1px solid dotted;width:408px;">
						<p>&nbsp;
							<strong style=""><?php echo $s['adm_no']; ?></strong>
							&nbsp;&nbsp;&nbsp;&nbsp;
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class & Sec :  <strong><?php echo $class." - ".$sec; ?> </strong> 
							
							</p>
					</td>
					<td align="center" rowspan="5" style="width:110px;">
						
			     <img src='pictures/photo_stu/<?php echo ($s['photo_stu']) ? $s['photo_stu'] : 'images.jpg'?>' width='75'>
			   
					</td>
					
				</tr>
				<tr>
					<td align="right" style="width:169px;">
						<p align="right">&nbsp;</p>
					</td>
					<td ></td>
				</tr>
				<tr>
					<td align="right" style="width:169px;">
						<p align="right">
							Name of the candidate :</p>
					</td>
					<td style="border-bottom:1px solid dotted;width:408px;">
						<p>&nbsp;
							<strong><?php echo $s['stu_name']; ?></strong></p>
					</td>
				</tr>
				<tr>
					<td align="right" style="width:169px;">
						<p align="right">&nbsp;</p>
					</td>
					<td ></td>
				</tr>
				<tr>
					<td align="right" style="width:169px;">
						<p align="right">
							Father&rsquo;s Name :</p>
					</td>
					<td style="border-bottom:1px solid dotted;width:408px;">
						<p>&nbsp;
							<strong><?php echo $s['fat_name']; ?></strong></p>
					</td>
				</tr>
				<tr>
					<td align="right" style="width:169px;">
						<p align="right">&nbsp;</p>
					</td>
					<td ></td>
				</tr>
				<tr>
					<td align="right" style="width:169px;">
						<p align="right">
							Mother&rsquo;s Name :</p>
					</td>
					<td style="border-bottom:1px solid dotted;width:408px;">
						<p>&nbsp;
							<strong><?php echo $s['mot_name']; ?></strong></p>
					</td>
				</tr>
				<tr>
					<td align="right" style="width:169px;">
						<p align="right">&nbsp;</p>
					</td>
					<td ></td>
				</tr>
				<tr>
					<td align="right" style="width:169px;">
						<p align="right">
							Date of Birth :</p>
					</td>
					<td style="border-bottom:1px solid dotted;width:408px;">
						<p>&nbsp;
							<strong><?php $dob = date('d-m-Y', strtotime($s['dob'])); if($dob <> '01-01-1970') { echo $dob; } ?></strong></p>
					</td>
				</tr>
				<tr>
					<td colspan=2><p ><br><b>Note:-</b> No candidate will be allowed to sit in examination hall without duly attested ADMIT CARD.</p></td>
					
					<td align="center" ><b>Principal</b>
					</td>
				</tr>
			</tbody>
		</table>


<?php $number = $i++;  ?>
<?php
if ($number % 3 <> 0) {
  print "	<hr>
	<br>
	<br>";
}
?>
<?php
if ($number % 3 == 0) {
  print "<pagebreak />";
}
?>

<?php
}
file_put_contents('admit-card.htm', ob_get_contents());
ob_end_flush();
//echo "<script>document.location.href='admit-card-pdf.php';</script>";
?>
