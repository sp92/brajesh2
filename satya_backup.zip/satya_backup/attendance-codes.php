<?php
$page='attendance';
require('core.php');
if($_SESSION['ACC_ATTENDANCE']=='0') 
{
	header("Location: main.php");
}
if(@$_REQUEST['hdnCmd']=="ADD")
{
	$code=clean($_REQUEST['code']);
	$heading=clean($_REQUEST['heading']);
	$student=clean($_REQUEST['student']);
	$staff=clean($_REQUEST['staff']);
	
	if($student <> 1) { $student = 0; }
	if($staff <> 1) { $staff = 0; }
	
	$data = Array (
		'code' => $code,
		'heading' => $heading,
		'student' => $student,
		'staff' => $staff
	);
	$db->insert ('atten_code', $data);
	header("Location: ./attendance-codes");
}
if(@$_REQUEST['action']=="delcode")
	{
		$db->where('id', round($_REQUEST['id']));
		$db->delete('atten_code');
		header("Location: ./attendance-codes");
	}

include('header.php');
?>
<div class="container">



<div class="row">
<div class="col-md-2 hidden-xs">
<?php print_menu($atten_menu_items); ?>
</div>
	<div class="col-md-10">
	
<h3>Global Dates Setup</h3>

  <div class="form-group">
    <label for="exampleInputPassword3">Global Date for Commencing Attendance :</label>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<b><span class="text-danger">For Students : <?php echo date('d/m/Y', strtotime($global_atten_date_stu)); ?></span></b>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<b><span class="text-success">For Staff : <?php echo date('d/m/Y', strtotime($global_atten_date_staff)); ?></span></b>
  </div>

  <hr>
<h3>Attendance Heads</h3>
<form class="form-inline" action="attendance-codes" method="post">
<input type="hidden" name="hdnCmd" value="ADDHEADS">
  <div class="form-group">
    <label for="exampleInputPassword3">Attendance Heads :</label>
    <input type="text" name="heading" id="heading" class="form-control" onkeyup="slugify();" placeholder="Working, Holiday, Prep. Leave" placeholder="" required />
  </div>
  &nbsp;&nbsp;&nbsp;
  <div class="form-group">
    <label for="exampleInputEmail3">Code :</label>
    <input type="text" name="code" class="form-control" placeholder="Codes (W, HL, PL...)" required>
  </div>
    <input type="hidden" name="slug" id="slug"  class="form-control" value="" required>
<script>
function slugify() {
	var text =  $("#heading").val();
	text2 = text.toString().toLowerCase().replace("-","").replace(/\s+/g, '').replace(/[^\w\-]+/g, '').replace(/\-\-+/g, '').replace(/^-+/, '').replace(/-+$/, '');
	$("#slug").val(text2);
}
</script>

				&nbsp;&nbsp;&nbsp;

				<div class="checkbox">
				<label>
				<input type="checkbox" name="student" value="1" > For Students
				</label>
				</div>
				&nbsp;&nbsp;&nbsp;
				<div class="checkbox">
				<label>
				<input type="checkbox" name="staff" value="1" > For Staff
				</label>
				</div>

				&nbsp;&nbsp;&nbsp;
 <input  class="btn btn-primary btn-xs ladda-kill" type="submit" name="submit" value="Add Record" />
</form>
  
<hr>
<table class="table table-striped table-hover table-bordered" >
<thead>
<tr>
<th style=" width: 32px;">SR</td>
<th >Attendance Heads</td>
<th >Head Code</td>
<th >For Student</td>
<th >For Staff</td>
<th style="width: 77px;">Update</td>
</tr>
</thead>
<tbody>
				
<?php
		$n=1;
		$user = $db->get ("atten_heads");
		if ($db->count > 0) {
			foreach ($user as $u) { 
?>			
<tr>
<td><?php echo $n; $n++; ?></td>
<td align="center"><?php echo $u['heading']; ?></td>
<td align="center"><?php echo $u['code']; ?></td>

<td align="center">
<?php if($u['id']>2) { ?>
<input type="checkbox" class="student2" data-id2="<?php echo $u['id']; ?>" <?php $student = $u['student']; if($student=='1') { echo "checked"; }  ?> />
<?php } else {
	echo "<span class='label label-danger'>System Default</span>";
} ?>
</td>
<td align="center">
<?php if($u['id']>2) { ?>
<input type="checkbox" class="staff2" data-id4="<?php echo $u['id']; ?>" <?php $staff = $u['staff']; if($staff=='1') { echo "checked"; }  ?> />
<?php } else {
	echo "<span class='label label-danger'>System Default</span>";
} ?>
</td>

<td align="center">
<?php if($u['id']>2) { ?>
<a href="attendance-codes?action=delheads&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
<?php } else {
	echo "<span class='label label-danger'>System Default</span>";
} ?>
</td>
</tr>
		  <?php
			}
			}
		?>	

</table>


<hr>
<h3>Attendance Codes</h3>
<form class="form-inline" action="attendance-codes" method="post">
<input type="hidden" name="hdnCmd" value="ADD">
  <div class="form-group">
    <label for="exampleInputPassword3">Attendance Label :</label>
    <input type="text" name="heading" class="form-control" placeholder="Present, Absent" placeholder="" required />
  </div>
  &nbsp;&nbsp;&nbsp;
  <div class="form-group">
    <label for="exampleInputEmail3">Code :</label>
    <input type="text" name="code" class="form-control" placeholder="Codes (P, AB)" required>
  </div>

				&nbsp;&nbsp;&nbsp;

				<div class="checkbox">
				<label>
				<input type="checkbox" name="student" value="1" > For Students
				</label>
				</div>
				&nbsp;&nbsp;&nbsp;
				<div class="checkbox">
				<label>
				<input type="checkbox" name="staff" value="1" > For Staff
				</label>
				</div>

				&nbsp;&nbsp;&nbsp;
 <input  class="btn btn-primary btn-xs ladda-kill" type="submit" name="submit" value="Add Record" />
</form>

<hr/>
<!--<p class="text-danger">
- Add contacts for the frontdesk modules.<br>
- SMS will be delivered to these contacts (if checked).
</p>-->
<table class="table table-striped table-hover table-bordered" >
<thead>
<tr>
<th style=" width: 32px;">SR</td>
<th >Attendance Label</td>
<th >Code</td>
<th >For Student</td>
<th >For Staff</td>
<th style="width: 77px;">Update</td>
</tr>
</thead>
<tbody>
				
<?php
		$n=1;
		$user = $db->get ("atten_code");
		if ($db->count > 0) {
			foreach ($user as $u) { 
?>			
<tr>
<td><?php echo $n; $n++; ?></td>
<td align="center"><?php echo $u['heading']; ?></td>
<td  align="center"><?php echo $u['code']; ?></td>

<td align="center">
<?php if($u['id']>3) { ?>
<input type="checkbox" class="student" data-id2="<?php echo $u['id']; ?>" <?php $student = $u['student']; if($student=='1') { echo "checked"; }  ?> />
<?php } else {
	echo "<span class='label label-danger'>System Default</span>";
} ?>
</td>
<td align="center">
<?php if($u['id']>3) { ?>
<input type="checkbox" class="staff" data-id4="<?php echo $u['id']; ?>" <?php $staff = $u['staff']; if($staff=='1') { echo "checked"; }  ?> />
<?php } else {
	echo "<span class='label label-danger'>System Default</span>";
} ?>
</td>

<td align="center">
<?php if($u['id']>3) { ?>
<a href="attendance-codes?action=delcode&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
<?php } else {
	echo "<span class='label label-danger'>System Default</span>";
} ?>
</td>
</tr>
		  <?php
			}
			}
		?>	

</table>			

	
	</div>
		



</div>
</div> <!-- /container -->
<script>
$(".student2").click(function() {
	var id = $(this).data("id2");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/attendance-functions?opt2=student&val2=1&id2='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/attendance-functions?opt2=student&val2=0&id2='+id,
		});
	}
});
$(".staff2").click(function() {
	var id = $(this).data("id4");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/attendance-functions?opt2=staff&val2=1&id2='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/attendance-functions?opt2=staff&val2=0&id2='+id,
		});
	}
});


$(".student").click(function() {
	var id = $(this).data("id2");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/attendance-functions?opt=student&val=1&id='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/attendance-functions?opt=student&val=0&id='+id,
		});
	}
});
$(".staff").click(function() {
	var id = $(this).data("id4");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/attendance-functions?opt=staff&val=1&id='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/attendance-functions?opt=staff&val=0&id='+id,
		});
	}
});
</script>
<?php
include('footer.php');
?>