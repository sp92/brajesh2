<?php
$page='frontdesk';
require('core.php');
error_reporting(0);
if($_SESSION['ACC_FRONTDESK']=='0') 
{
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">

  <div class="row">
  <div class="col-md-2 hidden-xs">
<?php print_menu($frontdesk_menu_items); ?>
</div>
	<div class="col-md-10">
	<h3>Visitors Listing</h3>
<form name="myForm" method="get" action="frontdesk-visitors-list">
<label>From Date: </label> 
<input name="from_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["from_date"]; ?>" class="datepicker" style="width: 100px;" readonly />  
<label>To Date : </label> 
<input name="to_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["to_date"]; ?>" class="datepicker" style="width: 100px;" readonly /> 

<label><input type='checkbox' name='pic' value='1' <?php if($_REQUEST["pic"]=='1') { echo "checked"; } ?> > Show Pictures </label>

<input type="submit" name="submit" value="SUBMIT" />


</form>
<hr>
<?php


if($_REQUEST["from_date"]!="" AND $_REQUEST["to_date"]!=""){?>

<table id="testTable" class="table table-hover" style="font-size:11px;">
<thead>
<tr>
<th align="center"><strong>Date</strong></th>
<?php if($_REQUEST["pic"]=='1') { ?>
<th align="center"><strong>Photo</strong></th>
<?php } ?>
<th align="center"><strong>Name</strong></th>
<th align="center"><strong>Address</strong></th>
<th align="center"><strong>Mobile</strong></th>
<th align="center"><strong>Regarding</strong></th>
<th align="center"><strong>To Whom</strong></th>
<th align="center"><strong>Comment</strong></th>
<th align="center"><strong>Pass</strong></th>
</tr>
</thead>
<tbody>
<?php
$from_date = datestamp($_REQUEST["from_date"]);
$to_date = datestamp($_REQUEST["to_date"]);

/* $sql = "SELECT * FROM ".PREFIX."visits where date(date) between '".$from_date."' and '".$to_date."' and session='".$_SESSION['SESSION']."' ORDER by date asc";
$sql_result = mysql_query ($sql, $conn ); */
$data=array($from_date,$to_date,$_SESSION['SESSION']);
$row_data=$db->rawQuery("SELECT * from ".PREFIX."visits where (DATE(date) between ? and ?) AND session=? order by date ASC", $data);

$n=1;
foreach ($row_data as $row)
{

	?>
	
<tr>
<td align="center"><?php echo date('d/m/Y', strtotime($row['date'])) ; ?><br>
<?php echo date('H:i:s A', strtotime($row['date'])) ; ?>
</td>
<?php if($_REQUEST["pic"]=='1') { ?>
<td align="center"><img src="pictures/visits/<?php echo $row['pic']; ?>" class="img-thumbnail" width="200" /></td>
<?php } ?>

<td align="center"><?php echo $row['name']; ?></td>
<td align="center"><?php echo $row['address']; ?> </td>
<td align="center"><?php echo $row['mobile']; ?> </td>
<td align="center"><?php echo $row['regarding']; ?> </td>
<td align="center"><?php echo $row['towhom']; ?> </td>
<td align="center"><?php echo $row['comment']; ?> </td>
<td align="center"><a href="frontdesk-view-visitorpass?type=visit&id=<?php echo $row['id']; ?>" target="_blank" >[Print]</a> </td>
</tr>


<?php
}

?>
</tbody>
</table>
<?php }?>
	</div>


	</div>	


	
	
	
</div> <!-- /container -->





<?php
include('footer.php');
?>