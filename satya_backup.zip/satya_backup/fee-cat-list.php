<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') 
{
	header("Location: main.php");
}

include('header.php');
$session = $_SESSION['SESSION'];
?>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row">
		<h3>Fee Category Listing</h3>
		<form id="form1" name="form1" method="get" action="fee-cat-list">
			<label>Fee Category :</label>
			<select name="fee_cat"  class="required">
				<option value="">--</option>
				<?php
				$db->groupBy('fee_cat');
				$db->orderBy('id');
				$sql = $db->get("fee_cat");
				foreach($sql as $row) {
					echo "<option value='".$row["fee_cat"]."''".($row["fee_cat"]==$_REQUEST["fee_cat"] ? " selected" : "").">".$row["fee_cat"]."</option>";
				} ?>
			</select>
			<label>Order By :</label>
			<select name="order">
				<option value="">--</option>
				<option value="adm_no" <?php if($_REQUEST["order"]=='adm_no') { echo "selected"; } ?>>Admission No.</option>
				<option value="stu_name" <?php if($_REQUEST["order"]=='stu_name') { echo "selected"; } ?>>Student Name</option>
			</select>
			<input type="submit" name="button" id="button1" value="Filter" />
			<a href="fee-cal-list.php">reset</a>
			<input type="button" onclick="tableToExcel('searchable', 'Student')" value="Export to Excel" style="float:right;padding: 2px;" />
			<input type="text" id="searchTerm" class="search_box" onkeyup="doSearch()" style="float:right;padding: 2px;" placeholder="Search Here....." />
		</form>
		<table id="searchable" class="table" style="font-size:11px;">
			<thead>
				<tr>
					<th align="center"><strong>SR</strong></th>
					<th align="center"><strong>Adm No.</strong></th>
					<th align="center"><strong>Student Name</strong></th>
					<th align="center"><strong>Father's Name</strong></th>
					<th align="center"><strong>Mother's Name</strong></th>
					<th align="center"><strong>Address</strong></th>
					<th align="center"><strong>Mobile</strong></th>
					<th align="center" style="width:80px;"><strong>DOB</strong></th>
					<th align="center"><strong>G</strong></th>
					<th align="center"><strong>Class</strong></th>
					<th align="center"><strong>Sec</strong></th>
				</tr>
			</thead>
			<tbody>
				<?php
				if ($_REQUEST["fee_cat"]<>'') {
					$fee_cat = " and fee_cat ='".$_REQUEST['fee_cat']."' and session='".$session."'";
				}
				if ($_REQUEST["order"]<>'') {
					$order = " order by '".$_REQUEST['order']."' ASC";
				}
				$sql = $db->rawQuery("select * from ".PREFIX."student where is_shown = 'YES' and class<>'OUT' and tc_issue<>'YES' ".$fee_cat.$order);
				$n=1;
				foreach($sql as $rows){
					if($rows['new_old']=='NEW'){ ?>
						<tr style="background-color:lightyellow;">
							<td align="center"><?php echo $n++; ?></td>
							<td align="center"><a href="fee?adm_no=<?php echo $rows['adm_no']; ?>"><?php echo $rows['adm_no']; ?></a></td>
							<td align="center"><a href="fee?adm_no=<?php echo $rows['adm_no']; ?>" class="stu_name_hover_details" alt="<?php echo $rows['adm_no']; ?>"><?php echo $rows['stu_name']; ?></a></td>
							<td align="center"><?php echo $rows['fat_name']; ?></td>
							<td align="center"><?php echo $rows['mot_name']; ?></td>
							<td align="center"><?php echo $rows['address']; ?></td>
							<td align="center"><?php echo $rows['mobile']; ?></td>
							<td align="center"><?php $dob = date('d-m-Y', strtotime($rows['dob'])); if($dob <> '01-01-1970') { echo $dob; } ?></td>
							<td align="center"><?php echo $rows['gender']; ?></td>
							<td align="center"><?php echo $rows['class']; ?></td>
							<td align="center"><?php echo $rows['sec']; ?></td>
						</tr>
					<?php }
					else { ?>
						<tr>
							<td align="center" bgcolor="#FFFFFF"><?php echo $n++; ?></td>
							<td align="center"><a href="fee.php?adm_no=<?php echo $rows['adm_no']; ?>"><?php echo $rows['adm_no']; ?></a></td>
							<td align="center"><a href="fee.php?adm_no=<?php echo $rows['adm_no']; ?>" class="stu_name_hover_details" alt="<?php echo $rows['adm_no']; ?>"><?php echo $rows['stu_name']; ?></a></td>
							<td align="center" bgcolor="#FFFFFF"><?php echo $rows['fat_name']; ?></td>
							<td align="center" bgcolor="#FFFFFF"><?php echo $rows['mot_name']; ?></td>
							<td align="center" bgcolor="#FFFFFF"><?php echo $rows['address']; ?></td>
							<td align="center" bgcolor="#FFFFFF"><?php echo $rows['mobile']; ?></td>
							<td align="center" bgcolor="#FFFFFF"><?php $dob = date('d-m-Y', strtotime($rows['dob'])); if($dob <> '01-01-1970') { echo $dob; } ?></td>
							<td align="center" bgcolor="#FFFFFF"><?php echo $rows['gender']; ?></td>
							<td align="center" bgcolor="#FFFFFF"><?php echo $rows['class']; ?></td>
							<td align="center" bgcolor="#FFFFFF"><?php echo $rows['sec']; ?></td>
						</tr>
					<?php }
				}?>
			</tbody>
		</table>
	</div>
</div>
<?php
include('footer.php');
?>       