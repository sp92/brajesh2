<?php
$page='student';
require('core.php');
if($_SESSION['ACC_STUDENT']=='0') {
	header("Location: main.php");
}

include('header.php');

?>
<div class="container">
	<?php print_menu($student_menu_items); ?>
	<div class="row">
	<h3>Search Student</h3>
		<form id="form1" name="form1" method="get" action="student-search">
		<label>Universal Search (Search for anything like Student Name, Father's Name, Class, Sec, etc. ) :</label><br/><br/>
		<input type="text" name="search" class="" id="search" style="width:500px;" value="<?php echo $_REQUEST['search']; ?>" />
		<input type="submit" name="button" id="button1" value="Submit" />
		</form>
		<br /><p>You searched for : <b><?php echo $_REQUEST['search']; ?></b> <hr size='1'>
		<?php ob_start(); ?>
		<table id="searchable" class="table" style="font-size:11px;">
			<thead>
				<tr>
					<th align="center"><strong>SR</strong></th>
					<th align="center"><strong>Status</strong></th>
					<th align="center"><strong>Adm No.</strong></th>
					<th align="center"><strong>Student Name</strong></th>
					<th align="center"><strong>Father's Name</strong></th>
					<th align="center"><strong>Class</strong></th>
					<th align="center"><strong>Section</strong></th>
				</tr>
			</thead>
			<tbody>
				<?php
				if(!empty($_REQUEST['search'])){

					// Old way to get record
					//$db->where ('stu_name LIKE "%'.$_REQUEST['search'].'%"');
					//$db->orWhere (' fat_name LIKE "%' .$_REQUEST['search'].'%"');
					//$db->orWhere ('adm_no', $_REQUEST['search']);
					//$students = $db->get('student');
					
					$db->join("stu_sess_data sc", "sc.stu_id=s.adm_no", "LEFT");
					$db->where ('sc.session', $_SESSION["SESSION"]);
					$db->where ('s.stu_name LIKE "%'.$_REQUEST['search'].'%"');
					$db->orWhere ('s.fat_name LIKE "%' .$_REQUEST['search'].'%"');
					$db->orWhere ('s.adm_no', $_REQUEST["search"]);
					$students = $db->get("student s");
				}
				if(isset($students)){$n=1;
					foreach($students as $s){ ?>
					<tr>
						<td align="center"><?php echo $n++; ?></td>
						<td align="center">
							<?php 
							if($s['is_shown']=='NO' && $s['tc_issue']=='YES') { echo "<span class='label label-danger'>TC ISSUED</span>"; }
							elseif($s['is_shown']=='NO') { echo "<span class='label label-info'>NSO</span>"; }
							elseif($s['is_shown']=='CANCEL') { echo "<span class='label label-warning'>CANCELLED</span>"; }
							elseif($s['class'] == 'OUT') {echo "<span class='label label-danger'>OUT</span>"; }
							else { echo "<span class='label label-success'>REGULAR</span>"; }?>
						</td>
						<td align="center"><?php echo $s['adm_no']; ?></td>
						<td align="center"><?php echo $s['stu_name']; ?></td>
						<td align="center"><?php echo $s['fat_name']; ?></td>
						<td align="center"><?php echo $s['class']; ?></td>
						<td align="center"><?php echo $s['sec']; ?></td>
					</tr>
				<?php  } 
				} ?>
				
			</tbody>
		</table>	
		
	</div>
</div>

<?php
include('footer.php');
?>       