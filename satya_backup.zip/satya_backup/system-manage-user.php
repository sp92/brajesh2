<?php
$page='system';
require('core.php');
if($_SESSION['ACC_GROUP']<>'root') 
{
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">
<?php print_menu($settings_menu_items); ?>
<div class="row">
<h3>Manage Users</h3>
<div class="row">
<div class="col-md-12">
<form class="form-inline" action="system-manage-user" method="post">
<input type="hidden" name="hdnCmd" value="ADD">
  <div class="form-group">
    <label for="exampleInputEmail3">Name :</label>
    <input type="text" name="title" class="form-control" id="exampleInputEmail3" placeholder="Name" style="width:100px;" required>
  </div>
  &nbsp;&nbsp;&nbsp;
  <div class="form-group">
    <label for="exampleInputEmail3">Username : </label>
    <input type="text" name="username" class="form-control" id="exampleInputEmail3" placeholder="Username" style="width:100px;" required>
  </div>
  &nbsp;&nbsp;&nbsp;
    <div class="form-group">
    <label for="exampleInputEmail3">Password :</label>
    <input type="password" name="password" class="form-control" id="exampleInputEmail3" placeholder="Password" style="width:100px;" required>
  </div>
  &nbsp;&nbsp;&nbsp;
  <div class="form-group">
    <label for="exampleInputEmail3">Secret Code :</label>
    <input type="password" name="password" class="form-control numonly" maxlenth="4" placeholder="Secret Code" style="width:100px;" required>
  </div>
  &nbsp;&nbsp;&nbsp;
  <div class="form-group">
    <label for="exampleInputEmail3">Location :</label>
    <select class="form-control" name="location">
		<?php
			$cols = Array ("location");
			$db->orderBy("location","desc");
			$location = $db->get ("location", null, $cols);
			foreach ($location as $sess) { 
			?>
		<option value="<?php echo $sess['id']; ?>"><?php echo $sess['location']; ?></option>
		<?php
			}
		?>	
		</select>
  </div>
  <br>
  <br>
<strong>Module Access : </strong>  
    &nbsp;&nbsp;&nbsp;
  <div class="checkbox">
    <label>
      <input type="checkbox" name="master" value="1" > Master
    </label>
  </div>
  &nbsp;&nbsp;&nbsp;
    <div class="checkbox">
    <label>
      <input type="checkbox" name="frontdesk" value="1" > Frontdesk
    </label>
  </div>
  &nbsp;&nbsp;&nbsp;
    <div class="checkbox">
    <label>
      <input type="checkbox" name="student" value="1" > Students
    </label>
  </div>
    &nbsp;&nbsp;&nbsp;
    <div class="checkbox">
    <label>
      <input type="checkbox" name="fee" value="1" > Fee
    </label>
  </div>
    &nbsp;&nbsp;&nbsp;
    <div class="checkbox">
    <label>
      <input type="checkbox" name="admin" value="1" > Administration
    </label>
  </div>
    &nbsp;&nbsp;&nbsp;
    <div class="checkbox">
    <label>
      <input type="checkbox" name="transport" value="1" > Transport
    </label>
  </div>
    &nbsp;&nbsp;&nbsp;
    <div class="checkbox">
    <label>
      <input type="checkbox" name="certificate" value="1" > Certificate
    </label>
  </div>
    &nbsp;&nbsp;&nbsp;
    <div class="checkbox">
    <label>
      <input type="checkbox" name="setting" value="1" > Settings
    </label>
  </div>
    &nbsp;&nbsp;&nbsp;
  <input  class="btn btn-primary ladda-kill" type="submit" name="submit" value="Add User" />
</form>

<hr/>
<p class="text-danger">
- Add contacts for the frontdesk modules.<br>
- SMS will be delivered to these contacts (if checked).
</p>
<table class="table table-striped table-hover table-bordered" >
<thead>
<tr>
<th style=" width: 32px;">SR</td>
<th >Name</td>
<th >Username</td>
<th >Master</td>
<th >Frontdesk</td>
<th >Students</td>
<th >Fee</td>
<th >Administration</td>
<th >Transport</td>
<th >Certificate</td>
<th >Settings</td>
<th style="width: 77px;">Update</td>
</tr>
</thead>
<tbody>
				
<?php
		$n=1;
		$user = $db->get ("admin");
		if ($db->count > 0) {
			foreach ($user as $u) { 
?>			
<tr>
<td><?php echo $n; $n++; ?></td>
<td align="center"><?php echo $u['name']; ?></td>
<td align="center"><?php echo $u['username']; ?></td>

<td align="center">
<input type="checkbox" class="master" data-id2="<?php echo $u['master']; ?>" <?php $visit = $u['master']; if($visit=='1') { echo "checked"; }  ?> />
</td>

<td align="center">
<input type="checkbox" class="frontdesk" data-id3="<?php echo $u['frontdesk']; ?>" <?php $visit = $u['frontdesk']; if($visit=='1') { echo "checked"; }  ?> />
</td>

<td align="center">
<input type="checkbox" class="student" data-id2="<?php echo $u['student']; ?>" <?php $visit = $u['student']; if($visit=='1') { echo "checked"; }  ?> />
</td>

<td align="center">
<input type="checkbox" class="fee" data-id2="<?php echo $u['fee']; ?>" <?php $visit = $u['fee']; if($visit=='1') { echo "checked"; }  ?> />
</td>

<td align="center">
<input type="checkbox" class="master" data-id2="<?php echo $u['master']; ?>" <?php $visit = $u['master']; if($visit=='1') { echo "checked"; }  ?> />
</td>

<td align="center">
<input type="checkbox" class="master" data-id2="<?php echo $u['master']; ?>" <?php $visit = $u['master']; if($visit=='1') { echo "checked"; }  ?> />
</td>

<td align="center">
<input type="checkbox" class="master" data-id2="<?php echo $u['master']; ?>" <?php $visit = $u['master']; if($visit=='1') { echo "checked"; }  ?> />
</td>

<td align="center">
<input type="checkbox" class="master" data-id2="<?php echo $u['master']; ?>" <?php $visit = $u['master']; if($visit=='1') { echo "checked"; }  ?> />
</td>
<td align="center"><a href="frontdesk-setup?action=del&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
</td>
</tr>
		  <?php
			}
			}
		?>	

</table>			

	
	</div>
		



</div>
</div> <!-- /container -->
<script>
$(".visitor").click(function() {
	var id = $(this).data("id2");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=visit&val=1&id='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=visit&val=0&id='+id,
		});
	}
});
$(".halfday_tr").click(function() {
	var id = $(this).data("id3");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=halfday_tr&val=1&id='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=halfday_tr&val=0&id='+id,
		});
	}
});
$(".halfday_stu").click(function() {
	var id = $(this).data("id3");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=halfday_stu&val=1&id='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=halfday_stu&val=0&id='+id,
		});
	}
});
$(".complain").click(function() {
	var id = $(this).data("id4");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=complain&val=1&id='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=complain&val=0&id='+id,
		});
	}
});
</script>

</div>
</div> <!-- /container -->
<?php
include('footer.php');
?>