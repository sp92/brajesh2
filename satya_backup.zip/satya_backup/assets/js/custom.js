$( document ).ready(function() {
	
	Ladda.bind( '.kill-evo', { timeout: 1000 } );
	Ladda.bind( '.kill' );
	
	$(".numonly").keydown(function (e) {
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            (e.keyCode == 65 && e.ctrlKey === true) || 
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 return;
        }
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
    $('input').attr('autocomplete', 'off');
});

(function($) {
  var defaults = {
    center:      "screen", //true, screen || parent || undefined, null, "", false
    createNew:   false,
    height:      screen.height,
    left:        0,
    location:    false,
    menubar:     false,
    name:        null,
    onUnload:    null,
    resizable:   false,
    scrollbars:  false, // os x always adds scrollbars
    status:      false,
    toolbar:     false,
    top:         0,
    width:       screen.width
  };

  $.popupWindow = function(url, opts) {
    var options = $.extend({}, defaults, opts);

    // center the window
    if (options.center === "parent") {
      options.top = window.screenY + Math.round(($(window).height() - options.height) / 2);
      options.left = window.screenX + Math.round(($(window).width() - options.width) / 2);
    } else if (options.center === true || options.center === "screen") {
      var screenLeft = (typeof window.screenLeft !== 'undefined') ? window.screenLeft : screen.left;
      
      options.top = ((screen.height - options.height) / 2) - 50;
      options.left = screenLeft + (screen.width - options.width) / 2;
    }

    // params
    var params = [];
    params.push('location=' + (options.location ? 'yes' : 'no'));
    params.push('menubar=' + (options.menubar ? 'yes' : 'no'));
    params.push('toolbar=' + (options.toolbar ? 'yes' : 'no'));
    params.push('scrollbars=' + (options.scrollbars ? 'yes' : 'no'));
    params.push('status=' + (options.status ? 'yes' : 'no'));
    params.push('resizable=' + (options.resizable ? 'yes' : 'no'));
    params.push('height=' + options.height);
    params.push('width=' + options.width);
    params.push('left=' + options.left);
    params.push('top=' + options.top);

    // open window
    var random = new Date().getTime();
    var name = options.name || (options.createNew ? 'popup_window_' + random : 'popup_window');
    var win = window.open(url, name, params.join(','));

    // unload handler
    if (options.onUnload && typeof options.onUnload === 'function') {
      var unloadInterval = setInterval(function() {
        if (!win || win.closed) {
          clearInterval(unloadInterval);
          options.onUnload();
        }
      }, 50);
    }

    // focus window
    if (win && win.focus) {
      win.focus();
    }

    // return handle to window
    return win;
  };
})(jQuery);

function popUpClosed() {
    window.location.reload();
}

$('#loginForm').submit(function(event) {
	event.preventDefault();
	$.ajax({
		type: 'POST',
		url: 'function/login-exec',
		data: $(this).serialize(),
		success: function (data) {
			if(data=='success') {
				$("#msg2").text('Logged in successfully. Please wait.....');
				$("#msg").text('');
				window.location.href='./main';
			} else {
				$("#user").css('border-color','#FF0000');
				$("#pass").css('border-color','#FF0000');
				$("#vercode").css('border-color','#FF0000');
				$("#msg").text('Please check your credentials. Otherwise contact the Administrator.');
				$("#msg2").text('');
			}
		}
	});
});

function doSearch() {
    var searchText = document.getElementById('searchTerm').value;
    var targetTable = document.getElementById('searchable');
    var targetTableColCount;
            
    //Loop through table rows
    for (var rowIndex = 0; rowIndex < targetTable.rows.length; rowIndex++) {
        var rowData = '';
        
        //Get column count from header row
        if (rowIndex == 0) {
           targetTableColCount = targetTable.rows.item(rowIndex).cells.length;
           continue; //do not execute further code for header row.
        }
                
        //Process data rows. (rowIndex >= 1)
        for (var colIndex = 0; colIndex < targetTableColCount; colIndex++) {
            rowData += targetTable.rows.item(rowIndex).cells.item(colIndex).textContent.toLowerCase();
        }

        //If search term is not found in row data
        //then hide the row, else show
        if (rowData.indexOf(searchText) == -1)
            targetTable.rows.item(rowIndex).style.display = 'none';
        else
            targetTable.rows.item(rowIndex).style.display = 'table-row';
    }
}

$('.datepicker').datepicker({
    format: "dd/mm/yyyy",
	endDate: 'd',
	orientation: "bottom center"
});

$('.datepicker2').datepicker({
    format: "dd/mm/yyyy",
	startDate: 'd',
	orientation: "bottom center"
});

$('.datepicker3').datepicker({
    format: "dd/mm/yyyy",
	daysOfWeekDisabled: [0],
	endDate: 'd',
	orientation: "bottom center"
});

