<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') 
{
	header("Location: main.php");
}

$head_defineSession1 =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'fee_amount');
if(!empty($head_defineSession1)){
	foreach($head_defineSession1 as $key=>$value){
		if (strpos($value['Field'], 'head') !== false && strpos($value["Field"],'_method') === false) {
			$feeNameArry[] = $value['Field'];
		}
	}
}
$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
if(!empty($head_defineSession)){
	foreach($head_defineSession as $key=>$value){
		if (strpos($value['Field'], 'head') !== false) {
			$headNameArry[] = $value['Field'];
		}
	}
}
include('header.php');
$session = $_SESSION['SESSION'];
?>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row">
		<h3>Discount List</h3>
		<input type="button" onclick="tableToExcel('testTable', 'Student')" value="Export to Excel" style="float:right;" />
		<table id="testTable" class="table table-bordered table-stripped" style="width: 200%;font-size: 12px;">
			<thead>
				<tr>
					<th align="center"><strong>SR</strong></th>
					<th align="center"><strong>Adm No.</strong></th>
					<th align="center"><strong>Student Name</strong></th>
					<th align="center"><strong>Class</strong></th>
					<th align="center"><strong>Father's Name</strong></th>
					<th>Actual Fee</th>
					<th>Edited Fee</th>
					<th>Total Discount</th>
					<?php
					$sql2 = $db->getOne("head_define");
					foreach($sql2 as $row2=>$val){
						if(strpos($row2, 'head') !== false){
							if($val<>'' AND $val<>NULL)  { ?>
								<th class="tg-na43"><?php echo $val;?></th>
							<?php }
						}
					} ?>
					<th align="center"><strong>Remark</strong></th>
				</tr>
			</thead>
			<tbody>
				<?php
				$db->where("class <> 'OUT'");
				$db->where("session",$_SESSION"SESSION");
				$db->orderBy("stu_name","asc");
				$sql = $db->get("student");
				$i = 1;
				foreach($sql as $rows){
					$newold = $rows['new_old']; 
					$class = $rows['class']; 
					foreach($m_array as $m){
						foreach($headNameArry as $hea){
							$sum."_".$m = '';
							$edited[] = $sum."_".$m + $rows{$sum."_".$m};
						}
						
					}
					foreach($headNameArry as $hea){
						foreach($m_array as $m){
							$edited1[] = $sum."_".$m + $rows{$sum."_".$m};
						}
					}
					$db->where("class",'".$class."');
					$db->where("type",$rows["type"]);
					$db->where("new_old",, $newold);
					$db->where("session",$_SESSION["SESSION"]);
					
			$q_june = mysql_query("SELECT * FROM ".PREFIX."fee_head2 WHERE class='".$class."' and type='".$rows['type']."' and old_new='".$newold."' and session='".$_SESSION['SESSION']."'") or die(mysql_error());
			$fh_sum_jun = mysql_fetch_array($q_june);
			
			$actual_apr=$fh_sum_jun['head1_apr']+$fh_sum_jun['head2_apr']+$fh_sum_jun['head3_apr']+$fh_sum_jun['head4_apr']+$fh_sum_jun['head5_apr']+$fh_sum_jun['head6_apr']+$fh_sum_jun['head7_apr']+$fh_sum_jun['head8_apr']+$fh_sum_jun['head9_apr'];
			
			$actual_may=$fh_sum_jun['head10_apr']+$fh_sum_jun['head1_may']+$fh_sum_jun['head2_may']+$fh_sum_jun['head3_may']+$fh_sum_jun['head4_may']+$fh_sum_jun['head5_may']+$fh_sum_jun['head6_may']+$fh_sum_jun['head7_may']+$fh_sum_jun['head8_may']+$fh_sum_jun['head9_may']+$fh_sum_jun['head10_may'];
			
			$actual_jun=$fh_sum_jun['head1_jun']+$fh_sum_jun['head2_jun']+$fh_sum_jun['head3_jun']+$fh_sum_jun['head4_jun']+$fh_sum_jun['head5_jun']+$fh_sum_jun['head6_jun']+$fh_sum_jun['head7_jun']+$fh_sum_jun['head8_jun']+$fh_sum_jun['head9_jun']+$fh_sum_jun['head10_jun'];
			
			$actual_jul=$fh_sum_jun['head1_jul']+$fh_sum_jun['head2_jul']+$fh_sum_jun['head3_jul']+$fh_sum_jun['head4_jul']+$fh_sum_jun['head5_jul']+$fh_sum_jun['head6_jul']+$fh_sum_jun['head7_jul']+$fh_sum_jun['head8_jul']+$fh_sum_jun['head9_jul']+$fh_sum_jun['head10_jul'];
			
			$actual_aug=$fh_sum_jun['head1_aug']+$fh_sum_jun['head2_aug']+$fh_sum_jun['head3_aug']+$fh_sum_jun['head4_aug']+$fh_sum_jun['head5_aug']+$fh_sum_jun['head6_aug']+$fh_sum_jun['head7_aug']+$fh_sum_jun['head8_aug']+$fh_sum_jun['head9_aug']+$fh_sum_jun['head10_aug'];
			
			$actual_sep=$fh_sum_jun['head1_sep']+$fh_sum_jun['head2_sep']+$fh_sum_jun['head3_sep']+$fh_sum_jun['head4_sep']+$fh_sum_jun['head5_sep']+$fh_sum_jun['head6_sep']+$fh_sum_jun['head7_sep']+$fh_sum_jun['head8_sep']+$fh_sum_jun['head9_sep']+$fh_sum_jun['head10_sep'];
			
			$actual_oct=$fh_sum_jun['head1_oct']+$fh_sum_jun['head2_oct']+$fh_sum_jun['head3_oct']+$fh_sum_jun['head4_oct']+$fh_sum_jun['head5_oct']+$fh_sum_jun['head6_oct']+$fh_sum_jun['head7_oct']+$fh_sum_jun['head8_oct']+$fh_sum_jun['head9_oct']+$fh_sum_jun['head10_oct'];
			
			$actual_nov=$fh_sum_jun['head1_nov']+$fh_sum_jun['head2_nov']+$fh_sum_jun['head3_nov']+$fh_sum_jun['head4_nov']+$fh_sum_jun['head5_nov']+$fh_sum_jun['head6_nov']+$fh_sum_jun['head7_nov']+$fh_sum_jun['head8_nov']+$fh_sum_jun['head9_nov']+$fh_sum_jun['head10_nov'];
			
			$actual_dec=$fh_sum_jun['head1_dec']+$fh_sum_jun['head2_dec']+$fh_sum_jun['head3_dec']+$fh_sum_jun['head4_dec']+$fh_sum_jun['head5_dec']+$fh_sum_jun['head6_dec']+$fh_sum_jun['head7_dec']+$fh_sum_jun['head8_dec']+$fh_sum_jun['head9_dec']+$fh_sum_jun['head10_dec'];
			
			$actual_jan=$fh_sum_jun['head1_jan']+$fh_sum_jun['head2_jan']+$fh_sum_jun['head3_jan']+$fh_sum_jun['head4_jan']+$fh_sum_jun['head5_jan']+$fh_sum_jun['head6_jan']+$fh_sum_jun['head7_jan']+$fh_sum_jun['head8_jan']+$fh_sum_jun['head9_jan']+$fh_sum_jun['head10_jan'];
			
			$actual_feb=$fh_sum_jun['head1_feb']+$fh_sum_jun['head2_feb']+$fh_sum_jun['head3_feb']+$fh_sum_jun['head4_feb']+$fh_sum_jun['head5_feb']+$fh_sum_jun['head6_feb']+$fh_sum_jun['head7_feb']+$fh_sum_jun['head8_feb']+$fh_sum_jun['head9_feb']+$fh_sum_jun['head10_feb'];
			
			$actual_mar=$fh_sum_jun['head1_mar']+$fh_sum_jun['head2_mar']+$fh_sum_jun['head3_mar']+$fh_sum_jun['head4_mar']+$fh_sum_jun['head5_mar']+$fh_sum_jun['head6_mar']+$fh_sum_jun['head7_mar']+$fh_sum_jun['head8_mar']+$fh_sum_jun['head9_mar']+$fh_sum_jun['head10_mar'];
			
			$actual = $actual_apr + $actual_may + $actual_jun + $actual_aug + $actual_sep + $actual_oct + $actual_nov + $actual_dec + $actual_jan + $actual_feb + $actual_mar + $actual_jul;
			
	$change = $actual-$edited;
	
	$head1_actual = $fh_sum_jun['head1_apr']+$fh_sum_jun['head1_may']+$fh_sum_jun['head1_jun']+$fh_sum_jun['head1_jul']+$fh_sum_jun['head1_aug']+$fh_sum_jun['head1_sep']+$fh_sum_jun['head1_oct']+$fh_sum_jun['head1_nov']+$fh_sum_jun['head1_dec']+$fh_sum_jun['head1_jan']+$fh_sum_jun['head1_feb']+$fh_sum_jun['head1_mar'];
$head2_actual = $fh_sum_jun['head2_apr']+$fh_sum_jun['head2_may']+$fh_sum_jun['head2_jun']+$fh_sum_jun['head2_jul']+$fh_sum_jun['head2_aug']+$fh_sum_jun['head2_sep']+$fh_sum_jun['head2_oct']+$fh_sum_jun['head2_nov']+$fh_sum_jun['head2_dec']+$fh_sum_jun['head2_jan']+$fh_sum_jun['head2_feb']+$fh_sum_jun['head2_mar'];
$head3_actual = $fh_sum_jun['head3_apr']+$fh_sum_jun['head3_may']+$fh_sum_jun['head3_jun']+$fh_sum_jun['head3_jul']+$fh_sum_jun['head3_aug']+$fh_sum_jun['head3_sep']+$fh_sum_jun['head3_oct']+$fh_sum_jun['head3_nov']+$fh_sum_jun['head3_dec']+$fh_sum_jun['head3_jan']+$fh_sum_jun['head3_feb']+$fh_sum_jun['head3_mar'];
$head4_actual = $fh_sum_jun['head4_apr']+$fh_sum_jun['head4_may']+$fh_sum_jun['head4_jun']+$fh_sum_jun['head4_jul']+$fh_sum_jun['head4_aug']+$fh_sum_jun['head4_sep']+$fh_sum_jun['head4_oct']+$fh_sum_jun['head4_nov']+$fh_sum_jun['head4_dec']+$fh_sum_jun['head4_jan']+$fh_sum_jun['head4_feb']+$fh_sum_jun['head4_mar'];

$head5_actual = $fh_sum_jun['head5_apr']+$fh_sum_jun['head5_may']+$fh_sum_jun['head5_jun']+$fh_sum_jun['head5_jul']+$fh_sum_jun['head5_aug']+$fh_sum_jun['head5_sep']+$fh_sum_jun['head5_oct']+$fh_sum_jun['head5_nov']+$fh_sum_jun['head5_dec']+$fh_sum_jun['head5_jan']+$fh_sum_jun['head5_feb']+$fh_sum_jun['head5_mar'];
$head6_actual = $fh_sum_jun['head6_apr']+$fh_sum_jun['head6_may']+$fh_sum_jun['head6_jun']+$fh_sum_jun['head6_jul']+$fh_sum_jun['head6_aug']+$fh_sum_jun['head6_sep']+$fh_sum_jun['head6_oct']+$fh_sum_jun['head6_nov']+$fh_sum_jun['head6_dec']+$fh_sum_jun['head6_jan']+$fh_sum_jun['head6_feb']+$fh_sum_jun['head6_mar'];
$head7_actual = $fh_sum_jun['head7_apr']+$fh_sum_jun['head7_may']+$fh_sum_jun['head7_jun']+$fh_sum_jun['head7_jul']+$fh_sum_jun['head7_aug']+$fh_sum_jun['head7_sep']+$fh_sum_jun['head7_oct']+$fh_sum_jun['head7_nov']+$fh_sum_jun['head7_dec']+$fh_sum_jun['head7_jan']+$fh_sum_jun['head7_feb']+$fh_sum_jun['head7_mar'];
$head8_actual = $fh_sum_jun['head8_apr']+$fh_sum_jun['head8_may']+$fh_sum_jun['head8_jun']+$fh_sum_jun['head8_jul']+$fh_sum_jun['head8_aug']+$fh_sum_jun['head8_sep']+$fh_sum_jun['head8_oct']+$fh_sum_jun['head8_nov']+$fh_sum_jun['head8_dec']+$fh_sum_jun['head8_jan']+$fh_sum_jun['head8_feb']+$fh_sum_jun['head8_mar'];
$head9_actual = $fh_sum_jun['head9_apr']+$fh_sum_jun['head9_may']+$fh_sum_jun['head9_jun']+$fh_sum_jun['head9_jul']+$fh_sum_jun['head9_aug']+$fh_sum_jun['head9_sep']+$fh_sum_jun['head9_oct']+$fh_sum_jun['head9_nov']+$fh_sum_jun['head9_dec']+$fh_sum_jun['head9_jan']+$fh_sum_jun['head9_feb']+$fh_sum_jun['head9_mar'];
	$head10_actual = $fh_sum_jun['head10_apr']+$fh_sum_jun['head10_may']+$fh_sum_jun['head10_jun']+$fh_sum_jun['head10_jul']+$fh_sum_jun['head10_aug']+$fh_sum_jun['head10_sep']+$fh_sum_jun['head10_oct']+$fh_sum_jun['head10_nov']+$fh_sum_jun['head10_dec']+$fh_sum_jun['head10_jan']+$fh_sum_jun['head10_feb']+$fh_sum_jun['head10_mar'];
	
if($change>0) {	
?>


<tr >
<td align="center"><?php echo $n; $n++; ?></td>
<td align="center"><?php echo $rows['adm_no']; ?></td>
<td align="center"><?php echo $rows['stu_name']; ?></td>
<td align="center"><?php echo $rows['class']."-".$rows['sec']; ?></td>
<td align="center"><?php echo $rows['fat_name']; ?></td>
<td align="center"><?php echo $a[] = $actual; ?> </td>
<td  align="center"><?php echo $b[] = $edited; ?> </td>
<td align="center"  style="background-color:lightyellow;"><?php echo $c[] = $actual-$edited; ?> </td>


<?php
  $headis=mysql_query("SELECT * FROM ".PREFIX."head_define");
  $headis2 = mysql_fetch_assoc($headis);
  if($headis2['head1']<>'' AND $headis2['head1']<>NULL)
  {
  ?>
<td  align="center"><?php echo $d[] = $head1_actual-$head1_sum; ?> </td>
  <?php
  }
  ?>
  <?php
  if($headis2['head2']<>'' AND $headis2['head2']<>NULL)
  {
  ?>
<td  align="center"><?php echo $e[] = $head2_actual-$head2_sum; ?> </td>
  <?php
  }
  ?>
  <?php
  if($headis2['head3']<>'' AND $headis2['head3']<>NULL)
  {
  ?>
<td  align="center"><?php echo $f[] = $head3_actual-$head3_sum; ?> </td>
  <?php
  }
  ?>
  <?php
  if($headis2['head4']<>'' AND $headis2['head4']<>NULL)
  {
  ?>
<td  align="center"><?php echo $g[] = $head4_actual-$head4_sum; ?> </td>
  <?php
  }
  ?>
  
 
  <?php
  if($headis2['head7']<>'' AND $headis2['head7']<>NULL)
  {
  ?>
  <td  align="center"><?php echo $j[] = $head7_actual-$head7_sum; ?> </td>
  <?php
  }
  ?>
  <?php
  if($headis2['head8']<>'' AND $headis2['head8']<>NULL)
  {
  ?>
  <td  align="center"><?php echo $k[] = $head8_actual-$head8_sum; ?> </td>
  <?php
  }
  ?>
  <?php
  if($headis2['head9']<>'' AND $headis2['head9']<>NULL)
  {
  ?>
  <td  align="center"><?php echo $l[] = $head9_actual-$head9_sum; ?> </td>
  <?php
  }
  ?>
  <?php
  if($headis2['head10']<>'' AND $headis2['head10']<>NULL)
  {
  ?>
  <td  align="center"><?php echo $m[] = $head10_actual-$head10_sum; ?> </td>
  <?php
  }
  ?>




<td><?php echo $rows['disc_remark']; ?></td>
</tr>

<?php
}
}
?>
<tr style="font-weight:bold">
<td></td><td></td><td></td><td></td><td></td>
<td align="center"><?php echo moneyFormatIndia(array_sum($a)); ?> </td>
<td align="center"><?php echo moneyFormatIndia(array_sum($b)); ?> </td>
<td align="center" style="background-color:lightyellow;"><?php echo moneyFormatIndia(array_sum($c)); ?> </td>

<?php
  $headis=mysql_query("SELECT * FROM ".PREFIX."head_define");
  $headis2 = mysql_fetch_assoc($headis);
  if($headis2['head1']<>'' AND $headis2['head1']<>NULL)
  {
  ?>
<td align="center"><?php echo moneyFormatIndia(array_sum($d)); ?> </td>
  <?php
  }
  ?>
  <?php
  if($headis2['head2']<>'' AND $headis2['head2']<>NULL)
  {
  ?>
<td align="center"><?php echo moneyFormatIndia(array_sum($e)); ?> </td>
  <?php
  }
  ?>
  <?php
  if($headis2['head3']<>'' AND $headis2['head3']<>NULL)
  {
  ?>
<td align="center"><?php echo moneyFormatIndia(array_sum($f)); ?> </td>
  <?php
  }
  ?>
  <?php
  if($headis2['head4']<>'' AND $headis2['head4']<>NULL)
  {
  ?>
<td align="center"><?php echo moneyFormatIndia(array_sum($g)); ?> </td>
  <?php
  }
  ?>
 
  
  <?php
  if($headis2['head7']<>'' AND $headis2['head7']<>NULL)
  {
  ?>
<td align="center"><?php echo moneyFormatIndia(array_sum($j)); ?> </td>
  <?php
  }
  ?>
  <?php
  if($headis2['head8']<>'' AND $headis2['head8']<>NULL)
  {
  ?>
<td align="center"><?php echo moneyFormatIndia(array_sum($k)); ?> </td>
  <?php
  }
  ?>
  <?php
  if($headis2['head9']<>'' AND $headis2['head9']<>NULL)
  {
  ?>
<td align="center"><?php echo moneyFormatIndia(array_sum($l)); ?> </td>
  <?php
  }
  ?>
  <?php
  if($headis2['head10']<>'' AND $headis2['head10']<>NULL)
  {
  ?>
<td align="center"><?php echo moneyFormatIndia(array_sum($m)); ?> </td>
  <?php
  }
  ?>


<td></td>
</tr>
</tbody>
</table>
</div>
</div>
<script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
<script src="js/plugins.js"></script>