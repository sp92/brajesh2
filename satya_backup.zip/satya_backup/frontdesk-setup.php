<?php
$page='frontdesk';
require('core.php');
if($_SESSION['ACC_FRONTDESK']=='0') 
{
	header("Location: main.php");
}
if(@$_REQUEST['hdnCmd']=="ADD")
{
	$title=clean($_REQUEST['title']);
	$mobile=clean($_REQUEST['mobile']);
	$visit=clean($_REQUEST['visit']);
	$halfday_tr=clean($_REQUEST['halfday_tr']);
	$halfday_stu=clean($_REQUEST['halfday_stu']);
	$complain=clean($_REQUEST['complain']);
	$counseller=clean($_REQUEST['counseller']);
	$interview=clean($_REQUEST['interview']);
	
	if($visit <> 1) { $visit = 0; }
	if($halfday_tr <> 1) { $halfday_tr = 0; }
	if($halfday_stu <> 1) { $halfday_stu = 0; }
	if($complain <> 1) { $complain = 0; }
	if($counseller <> 1) { $counseller = 0; }
	if($interview <> 1) { $interview = 0; }
	
	$data = Array (
		'title' => $title,
		'mobile' => $mobile,
		'visit' => $visit,
		'halfday_tr' => $halfday_tr,
		'halfday_stu' => $halfday_stu,
		'complain' => $complain,
		'counseller' => $counseller,
		'interview' => $interview
	);
	$db->insert ('fd_master', $data);
	header("Location: ./frontdesk-setup");
}
if(@$_REQUEST['action']=="del")
	{
		$db->where('id', round($_REQUEST['id']));
		$db->delete('fd_master');
		header("Location: ./frontdesk-setup");
	}

include('header.php');
?>
<div class="container">



<div class="row">
<div class="col-md-2 hidden-xs">
<?php print_menu($frontdesk_menu_items); ?>
</div>
	<div class="col-md-10">
	
<h3>Frontdesk Setup</h3>


<form class="form-inline" action="frontdesk-setup" method="post">
<input type="hidden" name="hdnCmd" value="ADD">
  <div class="form-group">
    <label for="exampleInputEmail3">Name/Desig</label>
    <input type="text" name="title" class="form-control" id="exampleInputEmail3" placeholder="Name/Desig" required>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword3">Mobile No.</label>
    <input type="text" name="mobile" class="form-control numonly" min='10' maxlength='10' id="exampleInputPassword3" placeholder="" required />
  </div>
<br>
<br>

				<div class="checkbox">
				<label>
				<input type="checkbox" name="visit" value="1" > Visitors
				</label>
				</div>
				&nbsp;&nbsp;&nbsp;
				<div class="checkbox">
				<label>
				<input type="checkbox" name="counseller" value="1" > Counselling
				</label>
				</div>
								&nbsp;&nbsp;&nbsp;
				<div class="checkbox">
				<label>
				<input type="checkbox" name="interview" value="1" > Interview
				</label>
				</div>
				&nbsp;&nbsp;&nbsp;
				<div class="checkbox">
				<label>
				<input type="checkbox" name="complain" value="1" > Complaints
				</label>
				</div>
				&nbsp;&nbsp;&nbsp;
  <code> <b>Halfdays :</b>
    <div class="checkbox">
    <label>
     <input type="checkbox" name="halfday_tr" value="1" > Staff
    </label>
  </div>
  
  <div class="checkbox">
    <label>
    <input type="checkbox" name="halfday_stu" value="1" > Student
    </label>
  </div>
  </code>
  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;
 <input  class="btn btn-primary btn-xs ladda-kill" type="submit" name="submit" value="Add Record" />
</form>

<hr/>
<p class="text-danger">
- Add contacts for the frontdesk modules.<br>
- SMS will be delivered to these contacts (if checked).
</p>
<table class="table table-striped table-hover table-bordered" >
<thead>
<tr>
<th style=" width: 32px;">SR</td>
<th >Title</td>
<th >Mobile No.</td>

<th >Visitors</td>
<th width=250 >Halfday</td>
<th >Complaints</td>
<th >Counselling</td>
<th >Interview</td>
<th style="width: 77px;">Update</td>
</tr>
</thead>
<tbody>
				
<?php
		$n=1;
		$user = $db->get ("fd_master");
		if ($db->count > 0) {
			foreach ($user as $u) { 
?>			
<tr>
<td><?php echo $n; $n++; ?></td>
<td align="center"><?php echo $u['title']; ?></td>
<td  align="center"><?php echo $u['mobile']; ?></td>

<td align="center">
<input type="checkbox" class="visitor" data-id2="<?php echo $u['id']; ?>" <?php $visit = $u['visit']; if($visit=='1') { echo "checked"; }  ?> />
</td>
<td align="center">
<label>
<code><input type="checkbox" class="halfday_tr" data-id3="<?php echo $u['id']; ?>" <?php $halfday_tr = $u['halfday_tr']; if($halfday_tr=='1') { echo "checked"; }  ?> />&nbsp; Staff</code>
</label>
&nbsp;&nbsp;&nbsp;&nbsp;
<code>
<label>
<input type="checkbox" class="halfday_stu" data-id3="<?php echo $u['id']; ?>" <?php $halfday_stu = $u['halfday_stu']; if($halfday_stu=='1') { echo "checked"; }  ?> />&nbsp; Student
</label></code>
</td>
<td align="center">
<input type="checkbox" class="complain" data-id4="<?php echo $u['id']; ?>" <?php $complain = $u['complain']; if($complain=='1') { echo "checked"; }  ?> />
</td>
<td align="center">
<input type="checkbox" class="counseller" data-id0="<?php echo $u['id']; ?>" <?php $counseller = $u['counseller']; if($counseller=='1') { echo "checked"; }  ?> />
</td>
<td align="center">
<input type="checkbox" class="interview" data-id1="<?php echo $u['id']; ?>" <?php $interview = $u['interview']; if($interview=='1') { echo "checked"; }  ?> />
</td>
<td align="center"><a href="frontdesk-setup?action=del&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
</td>
</tr>
		  <?php
			}
			}
		?>	

</table>			

	
	</div>
		



</div>
</div> <!-- /container -->
<script>
$(".visitor").click(function() {
	var id = $(this).data("id2");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=visit&val=1&id='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=visit&val=0&id='+id,
		});
	}
});
$(".halfday_tr").click(function() {
	var id = $(this).data("id3");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=halfday_tr&val=1&id='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=halfday_tr&val=0&id='+id,
		});
	}
});
$(".halfday_stu").click(function() {
	var id = $(this).data("id3");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=halfday_stu&val=1&id='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=halfday_stu&val=0&id='+id,
		});
	}
});
$(".complain").click(function() {
	var id = $(this).data("id4");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=complain&val=1&id='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=complain&val=0&id='+id,
		});
	}
});
$(".counseller").click(function() {
	var id = $(this).data("id0");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=counseller&val=1&id='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=counseller&val=0&id='+id,
		});
	}
});
$(".interview").click(function() {
	var id = $(this).data("id1");
	if($(this).is(':checked')) {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=interview&val=1&id='+id,
		});
	} else {
		$.ajax({
		type: 'POST',
		url: 'function/frontdeskfunctions?opt=interview&val=0&id='+id,
		});
	}
});
</script>
<?php
include('footer.php');
?>