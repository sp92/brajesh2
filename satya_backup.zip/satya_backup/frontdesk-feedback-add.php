<?php
$page='frontdesk';
require('core.php');
if($_SESSION['ACC_FRONTDESK']=='0') 
{
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">

  <div class="row">



<div class="col-md-2">
<?php print_menu($frontdesk_menu_items); ?>

</div>	
		<div class="col-md-10"><br>
<h3>Add Feedbacks / Suggestions</h3>		
	
  	<form id="add-feedback" method="post">
		<input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
		<input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>">
		<table class="table table-striped">
			<tr>
				<td colspan=2 align='center'>
					<label><input type='radio' name="m_type" value="Complaints" required />&nbsp;Complaints</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<label><input type='radio' name="m_type" value="Suggestion" required />&nbsp;Suggestion</label>
				</td>
				<td align=right>Date:</td>
				<td><input type="text" name="date" value="<?php echo date('d/m/Y'); ?>" style="width: 100px;" readonly /></td>
			</tr>
				
			
			<tr>
				<td align=right>Name :</td>
				<td><input type="text" name="name" id="name" style="width:100%" required /></td>
				<td align=right>Mobile No. :</td>
				<td><input type="text" name="mobile" class="numonly" maxlength="10" required /></td>
			</tr>
			
			
			<tr>
				<td align=right>Message :</td>
				<td colspan=3><textarea name="message" style="width:100%;" rows="10" required ></textarea></td>
			</tr>
			
			<tr>
				<td align=right>Related to Student :</td>
				<td colspan=3><input type="text" id="stu_name" style="width:100%;" /></td>
			</tr>
			<tr>
				<td align=right>Selected Student : <b><a title="Remove selected student." class="text-danger" onclick="clearthis();" style="cursor:pointer">[x]</a></b></td>
				<td colspan=3><input type="text" name="related" id="related" style="width:100%;" readonly /></td>
			</tr>
			
			<tr>
				<td colspan=2 align=right><button class="btn btn-success ladda-button kill-evo" type='submit' data-style="zoom-out"><span class="ladda-label">Add Record</span></button></td>
				<td colspan=2 align=left><input type="reset" class="btn btn-primary" value="Reset"></td>
			</tr>
			</table>
			</form>
	<span class="text-danger">- If any student is selected, complaint/feedback will be registered by
  </div>


	</div>	

</div> <!-- /container -->

<script>
$('#add-feedback').submit(function(event) {
	if(confirm('Confirm?' )) {
		event.preventDefault();
			$.ajax({
					type: 'POST',
					url: 'function/frontdeskfunctions',
					data: $(this).serialize(),
					success: function (data) {
						$.notify({message: '<strong>Successfully</strong> inserted the information.' },{type: 'success'});
						$('#add-feedback').trigger("reset");
						console.log();
					}
			});
	} else {
		event.preventDefault();
		return false;
	}
});


$(function() {
	$("#stu_name").autocomplete({
		source: "function/frontdeskfunctions?stu_details",
		minLength: 2,
		select: function(event, ui) {
			$('#stu_name').val(ui.item.value);
			$('#related').val(ui.item.value);
		},
		change: function (event, ui) {
			if (ui.item == null || ui.item == undefined) {
				$("#stu_name").val("");
				$("#stu_name").attr("disabled", false);
			} 
		}	
	});
});

function clearthis() {
	$("#related").val("");
	$("#stu_name").val("");
}
 </script>
<?php
include('footer.php');
?>