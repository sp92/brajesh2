	<footer class="footer">
      <div class="container">
		<div class="row">
			<div class="col-md-4">
				<p class="text-muted"><?php echo SCHOOLNAME; ?>&nbsp;&nbsp;|&nbsp;&nbsp; Session : <span class="label label-success"><?php echo $_SESSION['SESSION']; ?></span>
			</div>
			<div class="col-md-4" id="internetstatus">
			</div>
			<div class="col-md-4">
				<p class="text-muted pull-right">User : <span class="label label-danger"><?php echo $_SESSION['SESS_NAME']; ?></span>&nbsp;&nbsp;|&nbsp;&nbsp; Load Time : <?php echo round(microtime(true) - $start,3); ?> Sec
			</div>
		</div>
      </div>
    </footer>



<script src="assets/js/notify.min.js"></script>
<script src="assets/js/bootstrap-multiselect.js"></script>
<script src="assets/js/session.min.js"></script>
<script src="assets/js/spin.min.js"></script>
<script src="assets/js/ladda.min.js"></script>
<script src="assets/js/bootstrap-datepicker.min.js"></script>
<script src="assets/js/chosen.jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
    $('.multiple').multiselect({includeSelectAllOption: true});
	var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>
<script src="assets/js/custom.js"></script>
<script>
$.sessionTimeout({
    keepAliveUrl: 'function/session-alive',
	keepAliveInterval: 600000,
	keepAlive : true,
    logoutUrl: 'logout',
    redirUrl: 'logout'
});

</script>
</body>
</html>