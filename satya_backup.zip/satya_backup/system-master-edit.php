<?php
$page='system';
require('core.php');
if($_SESSION['ACC_GROUP']<>'root') 
{
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">
<?php print_menu($settings_menu_items); ?>
<div class="row">
<h3>Student Master Edit</h3>
<script src="assets/js/jquery.handsontable.js"></script>
<link rel="stylesheet" media="screen" href="assets/css/jquery.handsontable.css">

<button name="load">Load</button>
            <button name="save">Save</button>
            <button name="reset">Reset</button>
            <label><input type="checkbox" name="autosave" checked="checked" autocomplete="off"> Autosave</label>

<div id="exampleConsole" class="console">Click "Load" to load data from server</div>

<div id="example1"></div>
<?php
?>
<script>
            var $container = $("#example1");
            var $console = $("#exampleConsole");
            var $parent = $container.parent();
            var autosaveNotification;
            $container.handsontable({
              startRows: 8,
              startCols: 3,
              rowHeaders: true,
              colHeaders: ['Manufacturer', 'Year', 'Price'],
			  trimRows: [11, 12, 13],
              columns: [
                {readOnly: true},
                {readOnly: true},
                {}
              ],
              minSpareCols: 0,
              minSpareRows: 0,
              contextMenu: false,
              afterChange: function (change, source) {
                if (source === 'loadData') {
                  return; //don't save this change
                }
                if ($parent.find('input[name=autosave]').is(':checked')) {
                  clearTimeout(autosaveNotification);
                  $.ajax({
                    url: "php/save.php",
                    dataType: "json",
                    type: "POST",
                    data: {changes: change}, //contains changed cells' data
                    success: function () {
                      $console.text('Autosaved (' + change.length + ' cell' + (change.length > 1 ? 's' : '') + ')');
                      autosaveNotification = setTimeout(function () {
                        $console.text('Changes will be autosaved');
                      }, 1000);
                    }
                  });
                }
              }
            });
            var handsontable = $container.data('handsontable');


//$.each( gridData, function( rowKey, object) {
  //  if (!hot1.isEmptyRow(rowKey)) cleanedGridData[rowKey] = object;
//});
            $parent.find('button[name=load]').click(function () {
              $.ajax({
                url: "function/system-master-edit?load",
                dataType: 'json',
                type: 'GET',
                success: function (res) {
                  var data = [], row;
				  for (var i = 0, ilen = res.radiant_9th.length; i < ilen; i++) {
                    row = [];
                    row[0] = res.radiant_9th[i].id;
                    row[1] = res.radiant_9th[i].adm_no;
                    row[2] = res.radiant_9th[i].stu_name;
					if(row[0] != '' && row[1] != '' && row[2] != '') {
						data[res.radiant_9th[i].id - 1] = row;
					}
                  }
				  console.log(data);
                  $console.text('Data loaded');
                  handsontable.loadData(data);
                }
              });
            }).click(); //execute immediately

            $parent.find('button[name=save]').click(function () {
              $.ajax({
                url: "php/save.php",
                data: {"data": handsontable.getData()}, //returns all cells' data
                dataType: 'json',
                type: 'POST',
                success: function (res) {
                  if (res.result === 'ok') {
                    $console.text('Data saved');
                  }
                  else {
                    $console.text('Save error');
                  }
                },
                error: function () {
                  $console.text('Save error');
                }
              });
            });


            $parent.find('button[name=reset]').click(function () {
              $.ajax({
                url: "php/reset.php",
                success: function () {
                  $parent.find('button[name=load]').click();
                },
                error: function () {
                  $console.text('Data reset failed');
                }
              });
            });

            $parent.find('input[name=autosave]').click(function () {
              if ($(this).is(':checked')) {
                $console.text('Changes will be autosaved');
              }
              else {
                $console.text('Changes will not be autosaved');
              }
            });
          </script>
</div>
</div> <!-- /container -->
<?php
include('footer.php');
?>