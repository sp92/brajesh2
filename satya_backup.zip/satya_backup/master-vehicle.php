<?php
$page='master';
require('core.php');

if($_SESSION['ACC_MASTER']=='0') 
{
	header("Location: main.php");
}
if(@$_REQUEST['hdnCmd']=="ADD")
	{
		unset($_REQUEST['hdnCmd']);
	$db->insert ('vehicle_master', $_REQUEST);
	header("Location: ./master-vehicle"); 
	}
if(@$_REQUEST['action']=="del")
	{
	$db->where('id', round($_REQUEST['id']));
	$db->delete('vehicle_master');
	header("Location: ./master-vehicle");
	}
include('header.php');
?>
<div class="container">

<div class="row">
<div class="col-md-2 hidden-xs">
	<?php print_menu($master_menu_items); ?>
	</div>
	<div class="col-md-10">
	<h3>Vehicle Master</h3>
<center>
<form class="form-inline" role="form" action="master-vehicle" method="post">
<input type="hidden" name="hdnCmd" value="ADD">
  <div class="form-group">
    <label for="exampleInputEmail2"><small>Vehicle No.: </small></label>
    <input type="text" name="veh_no" required style="width: 100px;" />
	
  </div>
    <div class="form-group">
    <label for="exampleInputEmail2"><small>Bus No.: </small></label>
    <input type="text" name="bus_no" required style="width: 100px;" />
  </div>
    <div class="form-group">
    <label for="exampleInputEmail2"><small>Driver Name:</small> </label>
    <input type="text" name="driver_name" required style="width: 100px;" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword2"><small>Mobile No.:</small> </label>
    <input type="text" name="mobile_no"   required style="width: 100px;" />
  </div>
 <div class="form-group">
    <label for="exampleInputPassword2"><small>Capacity:</small> </label>
    <input type="text" name="veh_capacity"   required style="width: 100px;" />
  </div>
  <button type="submit" class="btn btn-default btn-sm">Add Vehicle</button>
</form>

<hr>


<table class="table table-striped table-hover table-bordered">
<thead>
<tr>
<th style="width:20px;">SR</th>
<th>Vehicle No.</th>
<th>Bus No.</th>
<th>Driver Name</th>
<th>Mobile No.</th>
<th>Stop</th>
<th>Capacity</th>
<th style="width:150px;">Update</th>
</tr>
</thead>
<tbody>
				
			<?php
					$n=1;
					$user = $db->get ("vehicle_master");
					
					
		foreach ($user as $u) { 
		
					?>			
<tr>
<td><?php echo $n; $n++; ?>.</td>
<td><?php echo $u['veh_no']; ?></td>
<td><?php echo $u['bus_no']; ?></td>
<td><?php echo $u['driver_name']; ?></td>
<td><?php echo $u['mobile_no']; ?></td>
<td><select data-placeholder="Choose Stops" class="form-control chosen-select"  multiple >
			<?php 
			$stop_id = explode(",", $u['stop']);
			$stop = $db->get ("stop_master");
			foreach ($stop as $uu) { 
			?>
            <option value="<?php echo $uu['id'];?>" <?php if(in_array($uu['id'], $stop_id)) { echo "selected"; } ?> ><?php echo $uu['stop'];?></option>
            <?php } ?>
      </select><button onClick="updateRoute(<?php echo $u['id'].",".$ind;?>)">update</button></td>
	  <td><?php echo $u['veh_capacity']; ?>
	  </td>
<td>
<a href="#" onclick="return windowpop('vehicle-master-edit?id=<?php echo $u['id']; ?>', 350, 500)" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit"></span> Edit</a>
<a href="master-vehicle?action=del&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
</td>
</tr>
		  <?php
			$ind++;}
			
		?>	
</table>

</center>
	</div>

</div>
</div> <!-- /container -->
<script>
function updateRoute(id,pas){
	routeid=$(".chosen-select").eq(pas).val();
	if(routeid==null){
		alert("Please Atleast One Stop!!");
	}else{
		$.ajax({
			type: 'POST',
			url: 'function/masterfunctions?mode=update_vehicle',
			data:"stop="+routeid+"&id="+id,
			success: function (data) {
				    alert("Data Updated Successfully");
				
			}
		});
	}
     /*  
	 */
	
}
</script>
<?php
include('footer.php');
?>