<?php
$page = 'frontdesk';
require('core.php');
error_reporting(E_ALL);
if ($_SESSION['ACC_FRONTDESK'] == '0') {
    header("Location: main.php");
}
include('header.php');
?>

<div class="container">

    <div class="row">
        <div class="col-md-2">
            <?php print_menu($frontdesk_menu_items); ?>
        </div>
        <div class="col-md-6"><br>
            <h3>Add Visitors</h3>	

            <form id="add-feedback" method="post">
                <input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>" />
                <input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php'); ?>" />
                <input type="hidden" name='pic' id='pic'>

                <table class="table table-striped">
                    <tr>
                        <td colspan=2 align='center'>
                            <?php
                            $n = 1;
                            $db->where("visit", '1');
                            $user = $db->get("fd_master");
                            if ($db->count > 0) {
                                foreach ($user as $u) {
                                    ?>			
                                    <label><input type='radio' name="towhom" value="<?php echo $u['title'] . ":::" . $u['mobile']; ?>" required />&nbsp;<?php echo $u['title']; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <?php
                                    }
                                }
                                ?>	

                        </td>
                        <td align=right>Date:</td>
                        <td><input type="text" name="date"  value="<?php echo date('d/m/Y'); ?>" style="width: 100px;" readonly /></td>
                    </tr>


                    <tr>
                        <td align=right>Name :</td>
                        <td colspan="3"><input type="text" name="name" id="name" style="width:100%" required /></td>
                    </tr>
                    <tr>
                        <td align=right>Mobile No. :</td>
                        <td><input type="text" name="mobile" style="width:100%" class="numonly"  maxlength='10' required /></td>
                        <td align=right>Visitor's Count :</td>
                        <td><input type="text" name="visitors_counts" class="numonly"  maxlength='2' style="width: 95px;"  required /></td>
                    </tr>
                    <tr>
                        <td align=right>Address (With Organization) :</td>
                        <td colspan=3><input type="text" name="address" style="width:100%;" /></td>
                    </tr>


                    <tr>
                        <td align=right>Regarding :</td>
                        <td colspan=2><textarea name="regarding" style="width:100%;" rows="5" required ></textarea></td>
                        <td><span id="cap_image"></span></td>
                    </tr>



                    <tr>
                        <td colspan=2 align=right><button class="btn btn-success ladda-button kill-evo" type='submit' data-style="zoom-out"><span class="ladda-label">Add Record</span></button></td>
                        <td colspan=2 align=left><input type="reset" class="btn btn-primary" value="Reset"></td>
                    </tr>
                </table>
            </form>


        </div>

        <div class="col-md-4">
            <script type="text/javascript" src="assets/js/webcam.js"></script>
            <script language="JavaScript">
                document.write(webcam.get_html(320, 240));
            </script>
            <br>
            <br>
            <form>
                <input type="button" value="Take Snapshot" class="ladda-button kill-evo btn-primary" onclick="take_snapshot()">&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://get.adobe.com/flashplayer/" target="_blank">Download Flash Player</a>
            </form>


            <div id="upload_results" style="background-color:#eee;"></div>


        </div>	
        <div class="row">
            <div class="col-md-6">
                <center>
                    <hr>
                    <br>
                    <h4>Today's Visits</h4>
                    <table class="table table-striped table-hover table-bordered" style="width:600px;">
                        <thead>
                            <tr>
                                <th >SR</th>
                                <th >Name</th>
                                <th >Address</th>
                                <th >Regarding</th>
                                <th >Visitors Count</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $data = array(date('Y-m-d'));
                            $users = $db->rawQuery("SELECT * from " . PREFIX . "visits where DATE(date)= ?", $data);
                            $sr = 0;
                            foreach ($users as $rows) {
                                $sr++;
                                ?>
                                <tr>
                                    <td><?php echo $sr; ?></td>
                                    <td><?php echo $rows['name']; ?></td>
                                    <td><?php echo $rows['address']; ?></td>
                                    <td><?php echo $rows['regarding']; ?></td>
                                    <td><?php echo $rows['visitors_counts']; ?></td>

                                </tr>

                            <?php }
                            ?>
                        </tbody>	
                    </table>	


                </center>


            </div>


        </div>	
    </div>	






</div> <!-- /container -->

<style>
    #webcam_movie { border: 3px solid; } 
</style>
<script>
    $('#add-feedback').submit(function (event) {
        if (confirm('Confirm?')) {
            event.preventDefault();
            $.ajax({
                type: 'POST',
                url: 'function/frontdeskfunctions',
                data: $(this).serialize(),
                success: function (data) {
                    //console.log(data);
                    $.notify({message: '<strong>Successfully</strong> inserted the information.'}, {type: 'success'});
                    document.location.reload();
                }
            });
        } else {
            event.preventDefault();
            return false;
        }
    });
</script>
<script language="JavaScript">
    webcam.set_api_url('function/save_image_from_webcam?visit');
    webcam.set_quality(100); // JPEG quality (1 - 100)
    webcam.set_shutter_sound(false); // play shutter click sound
    webcam.set_hook('onComplete', 'my_completion_handler');

    function take_snapshot() {
        // take snapshot and upload to server
        document.getElementById('upload_results').innerHTML = '<img src="assets/img/loader.gif">';
        webcam.snap();
    }

    function my_completion_handler(msg) {
        // extract URL out of PHP output
        if (msg.match(/jpg/gi)) {
            // show JPEG image in page
            document.getElementById('upload_results').innerHTML = '<h4>Picture Taken!</h4>';
            document.getElementById('pic').value = msg;
            document.getElementById('cap_image').innerHTML = "<img src='pictures/visits/" + msg + "' style='width: 122px;'>";
            // reset camera for another shot
            webcam.reset();
        } else {
            alert("PHP Error: " + msg);
        }
    }
</script>


<?php
include('footer.php');
?>