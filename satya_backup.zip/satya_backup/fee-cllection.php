<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') 
{
	header("Location: main.php");
}
$head_defineSession1 =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'fee_amount');
if(!empty($head_defineSession1)){
	foreach($head_defineSession1 as $key=>$value){
		if (strpos($value['Field'], 'head') !== false && strpos($value["Field"],'_method') === false) {
			$feeNameArry[] = $value['Field'];
		}
	}
}

$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
if(!empty($head_defineSession)){
	foreach($head_defineSession as $key=>$value){
		if (strpos($value['Field'], 'head') !== false) {
			$headNameArry[] = $value['Field'];
		}
	}
}
include('header.php');
$session = $_SESSION['SESSION'];
?>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row"><br>
		<h3>Classwise Fee Collection Report</h3>
		<form id="form1" name="form1" method="get" action="fee-cllection">
			<label>Class : </label>
			<select name="class">
				<option value="">--</option>
				<?php
				$db->groupBy ("id");
				$classArr = $db->get("class_master");
				foreach($classArr as $row) {
					echo "<option value='".$row["class"]."'".($row["class"]==$_REQUEST["class"] ? " selected" : "").">".$row["class"]."</option>";
				} ?>
				<option value="OUT">12TH OUT</option>
			</select>&nbsp;&nbsp;&nbsp;&nbsp;
			<label>Section : </label>
			<select name="section" >
				<option value="">--</option>
				<?php
				$db->groupBy ("sec");
				$stuArr = $db->get("student");
				foreach($stuArr as $row) {
					echo "<option value='".$row["sec"]."'".($row["sec"]==$_REQUEST["section"] ? " selected" : "").">".$row["sec"]."</option>";
				} ?>
			</select>&nbsp;&nbsp;&nbsp;&nbsp;
			<label>Order By :</label>
			<select name="order" onchange="document.form1.submit();">
				<option value="">--</option>
				<option value="adm_no" <?php if($_REQUEST["order"]=='adm_no') { echo "selected"; } ?>>Admission No.</option>
				<option value="stu_name" <?php if($_REQUEST["order"]=='stu_name') { echo "selected"; } ?>>Student Name</option>
			</select>
			<input type="checkbox" name="quarter" value="on" <?php if(isset($_REQUEST['quarter'])) { echo "checked"; } ?> >Show Quarterly Fees&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" name="button" id="button1" value="Submit" />
			<input type="button" onclick="tableToExcel('searchable', 'Student')" value="Export to Excel" style="float:right;margin-right: 28px;" />
			<input type="text" id="searchTerm" class="search_box" onkeyup="doSearch()" style="float:right;padding: 2px;" placeholder="Search Here....." /><br/><br/>
		</form>
		<table id="searchable" class="table table-bordered " style="font-size:11px;">
			<thead>
				<tr>
					<th colspan=6 style="vertical-align: middle;">Student Information</th>
					<?php if(isset($_REQUEST['quarter'])) { ?>
						<th colspan=3 style="background-color: azure;">TERM I</th>
						<th colspan=3 style="background-color: beige;">TERM II</th>
						<th colspan=3 style="background-color: seashell;">TERM III</th>
					<?php } else{ ?>
					<th colspan=3 style="background-color: lightgoldenrodyellow;">OVERALL</th>
					<?php } ?>
					<th rowspan=2 style="background-color: lightgoldenrodyellow;">MOBILE NO.</th>
				</tr>
				<tr>
					<th align="center"><strong>SR</strong></th>
					<th align="center"><strong>Adm No.</strong></th>
					<th align="center"><strong>Student Name</strong></th>
					<th align="center"><strong>Father's Name</strong></th>
					<th align="center"><strong>Class</strong></th>
					<th align="center"><strong>Sec</strong></th>
					<?php if(isset($_REQUEST['quarter'])) { ?>
						<th align="center"><strong>Total Fee</strong></th>
						<th align="center"><strong>Fee Paid</strong></th>
						<th align="center"><strong>Balance</strong></th>
						<th align="center"><strong>Total Fee</strong></th>
						<th align="center"><strong>Fee Paid</strong></th>
						<th align="center"><strong>Balance</strong></th>
						<th align="center"><strong>Total Fee</strong></th>
						<th align="center"><strong>Fee Paid</strong></th>
						<th align="center"><strong>Balance</strong></th>
					<?php }else{?>
						<th align="center"><strong>Total Fee</strong></th>
						<th align="center"><strong>Fee Paid</strong></th>
						<th align="center"><strong>Balance</strong></th>
					<?php }?>
				</tr>
			</thead>
			<tbody>
				<?php
				if ($_REQUEST["class"]<>'') {
					$db->where("class", $_REQUEST["class"]);
				}
				if ($_REQUEST["section"]<>'') {
					$db->where("sec", $_REQUEST["section"]);
				}
				if ($_REQUEST['order']<>'') {
					$db->orderBy($_REQUEST["order"], "ASC");
				}
				else {
					$db->orderBy("stu_name", "ASC");
				}
				$db->where("is_shown","YES");
				$db->where("adm_no != ''");
				$db->where("session",$_SESSION["SESSION"]);
				$studnt = $db->get("student");
				$n=1;
				foreach($studnt as $rows) {
					if($rows['custom_fee'] == 'YES'){
						$db->where("adm_no",$rows["adm_no"]);
						$feeAmount = $db->getOne("stu_custom_fee");
					}
					else{
						$db->where("class",$rows['class']);
						$db->where("new_old",$rows['new_old']);
						$db->where("type",$rows['type']);
						$db->where("fee_cat",$rows['fee_cat']);
						$feeAmount = $db->getOne("fee_amount");
					} ?>
					<tr>
						<td align="center"><?php echo $n++; ?></td>
						<td align="center"><?php echo $rows['adm_no']; ?></td>
						<td align="center"><a href="fee?adm_no=<?php echo $rows['adm_no']; ?>" class="stu_name_hover_details" alt="<?php echo $rows['adm_no']; ?>"><?php echo $rows['stu_name']; ?></a></td>
						<td align="center"><?php echo $rows['fat_name']; ?></td>
						<td align="center"><?php echo $rows['class']; ?></td>
						<td align="center"><?php echo $rows['sec']; ?></td>
						<?php if(isset($_REQUEST['quarter'])) { ?>
							<td align="center">
								<?php
								$qutr1Month = array("apr","may","jun","jul");
								foreach($qutr1Month as $q1){
									$sum1 = 0;
									foreach($feeNameArry as $fp){
										if(strpos($fp, $q1) !== false){
											$sum1 = $sum1 + $feeAmount[$fp];
											$total1[] = $sum1;
											unset($sum1);
										}
									}
								}
								$amount = $db->rawQuery("SELECT sum(amount) as sum FROM ".PREFIX."fee_paid where type='FEE' and month IN ('APRIL','MAY','JUN','JULY') and adm_no='".$rows['adm_no']."' and cancelled='0' and session='".$session."'");
								$paid1[] = $amount[0]['sum'] ? $amount[0]['sum'] : 0;
								$bal1[] =  array_sum($total1) - array_sum($paid1);
								echo array_sum($total1); ?>
								</td>
								<td align="center">
									<?php
									echo array_sum($paid1); ?>
								</td>
								<td align="center">
									<?php
									if(array_sum($bal1)>0) {
										echo "<span style='color:red;font-weight:bold;'>".array_sum($bal1)."</span>"; 
									} 
									else { 
										echo "<span style='color:green;font-weight:bold;'>Paid</span>"; 
									} ?>
								</td>
								<td align="center">
								<?php
								$qutr2Month = array("aug","sep","oct","nov");
								foreach($qutr2Month as $q2){
									$sum2 = 0;
									foreach($feeNameArry as $fp){
										if(strpos($fp, $q2) !== false){
											$sum2 = $sum2 + $feeAmount[$fp];
											$total2[] = $sum2;
											unset($sum2);
										}
									}
								}
								$amount = $db->rawQuery("SELECT sum(amount) as sum FROM ".PREFIX."fee_paid where type='FEE' and month IN ('AUGUST','SEPTEMBER','OCTOBER','NOVEMBER') and adm_no='".$rows['adm_no']."' and cancelled='0' and session='".$session."'");
								$paid2[] = $amount[0]['sum'] ? $amount[0]['sum'] : 0;
								$bal2[] =  array_sum($total2) - array_sum($paid2);
								echo array_sum($total2); ?>
								</td>
								<td align="center">
									<?php
									echo array_sum($paid2); ?>
								</td>
								<td align="center">
									<?php
									if(array_sum($bal2)>0) {
										echo "<span style='color:red;font-weight:bold;'>".array_sum($bal2)."</span>"; 
									} 
									else { 
										echo "<span style='color:green;font-weight:bold;'>Paid</span>"; 
									} ?>
								</td>
								<td align="center">
								<?php
								$qutr3Month = array("dec","jan","feb","mar");
								foreach($qutr3Month as $q3){
									$sum3 = 0;
									foreach($feeNameArry as $fp){
										if(strpos($fp, $q3) !== false){
											$sum3 = $sum3 + $feeAmount[$fp];
											$total3[] = $sum3;
											unset($sum3);
										}
									}
								}
								$amount = $db->rawQuery("SELECT sum(amount) as sum FROM ".PREFIX."fee_paid where type='FEE' and month IN ('DECEMBER','JANUARY','FEBRUARY','MARCH') and adm_no='".$rows['adm_no']."' and cancelled='0' and session='".$session."'");
								$paid3[] = $amount[0]['sum'] ? $amount[0]['sum'] : 0;
								$bal3[] =  array_sum($total3) - array_sum($paid3);
								echo array_sum($total3); ?>
								</td>
								<td align="center">
									<?php
									echo array_sum($paid3); ?>
								</td>
								<td align="center">
									<?php
									if(array_sum($bal3)>0) {
										echo "<span style='color:red;font-weight:bold;'>".array_sum($bal3)."</span>"; 
									} 
									else { 
										echo "<span style='color:green;font-weight:bold;'>Paid</span>"; 
									} ?>
								</td>
								<td align="center"><?php echo $rows['mobile']; ?></td>
								</tr>
							<?php 
							}
							if(isset($_REQUEST['quarter'])==FALSE) {
								$sum = 0;
								foreach($feeNameArry as $fp){
									$sum = $sum + $feeAmount[$fp];
									$total[] = $sum;
									unset($sum);
								}
								$amount = $db->rawQuery("SELECT sum(amount) as sum FROM ".PREFIX."fee_paid where type='FEE' and  adm_no='".$rows['adm_no']."' and cancelled='0' and session='".$session."'");
								$paid[] = $amount[0]['sum'] ? $amount[0]['sum'] : 0;
								$bal[] =  array_sum($total) - array_sum($paid); ?>
								<td align="center"><?php echo array_sum($total);	?></td>
								<td align="center"><?php echo array_sum($paid);	?></td>
								<td align="center">
									<?php if(array_sum($bal)>0) { echo "<span style='color:red;font-weight:bold;'>".array_sum($bal)."</span>"; }
									else { echo "<span style='color:green;font-weight:bold;'>Paid</span>"; }
									unset($total);
									unset($paid);
									unset($bal); ?>
								</td>
								<td align="center"><?php echo $rows['mobile']; ?></td>
								</tr>
							<?php } 
						}  ?>
			</tbody>
		</table>
	</div>
</div>
<?php
include('footer.php');
?>