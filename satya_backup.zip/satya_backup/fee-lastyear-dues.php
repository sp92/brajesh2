<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') 
{
	header("Location: main.php");
}
include('header.php');
$session = $_SESSION['SESSION'];
?>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row">
		<h3>LAST YEAR BALANCE COLLECTION REPORT</h3>
		<form name="myForm" method="get" action="fee-lastyear-dues">
			<label>Please Select : </label> 
			<select name="class" id="class">
				<?php
				$db->groupBy ("id");
				$classArr = $db->get("class_master");
				foreach($classArr as $row) {
					echo "<option value='".$row["class"]."'".($row["class"]==$_REQUEST["class"] ? " selected" : "").">".$row["class"]."</option>";
				} ?>
			</select>
			<input type="submit" name="submit" value="SUBMIT" />
			<input type="button" onclick="tableToExcel('searchable', 'Student')" value="Export To Excel" style='float:right;' />
		</form>
		<?php if($_REQUEST['class']){ ?>
			<table id="searchable" class="table" style="font-size:11px;">
				<thead>
					<tr>
						<th align="center" style="width: 66px;"><strong>Adm No.</strong></th>
						<th align="center"><strong>Student Name</strong></th>
						<th align="center"><strong>Father's Name</strong></th>
						<th align="center"><strong>Mother's Name</strong></th>
						<th align="center"><strong>Class</strong></th>
						<th align="center"><strong>Mobile</strong></th>
						<th align="center"><strong>Dues</strong></th>
						<th align="center"><strong>Paid</strong></th>
					</tr>
				</thead>
				<tbody>
					<?php
					$sql = $db->rawQuery("SELECT * FROM ".PREFIX."student WHERE class = '".$class."' and is_shown='YES' and tc_issue<>'YES' and session='".$_SESSION['SESSION']."'");
					$n=1;
					foreach($sql as $row){?>
							<tr>
								<td align="center"><?php echo $row['adm_no']; ?></td>
								<td align="center"><?php  echo $row['stu_name'];  ?></td>
								<td align="center"><?php echo $row['fat_name']; ?></td>
								<td align="center"><?php echo $row['mot_name']; ?></td>
								<td align="center"><?php echo $row['class']." - ".$row['sec']; ?></td>
								<td align="center"><?php echo $row['mobile']; ?></td>
								<td align="center"><?php echo $row['last_year_due']; $total_amount[] = $row['last_year_due'];  ?></td>
								<td align="center">
									<?php 
									$sum_aug_paid=mysql_query("SELECT sum(amount) FROM ".PREFIX."fee_paid where adm_no='".$row['adm_no']."' and type='LAST' and cancelled='NO' and session='".$_SESSION['SESSION']."'");
									$fh_sum_aug_paid = mysql_fetch_row($sum_aug_paid, MYSQL_NUM);
									echo array_sum($fh_sum_aug_paid); $amount[] = array_sum($fh_sum_aug_paid); ?>
								</td>
							</tr>
						<?php } ?>
					<tr bgcolor="#f7f6f0">
						<td colspan="6"></td>
						<td align="center"><b><?php echo array_sum($total_amount); ?></td>
						<td align="center"><b><?php echo array_sum($amount); ?></td>
					</tr>
				</tbody>
			</table>
			<link rel="stylesheet" type="text/css" href="css/print-style2.css" />
		<?php } ?>
	</div>
</div>
<?php
include('footer.php');
?>