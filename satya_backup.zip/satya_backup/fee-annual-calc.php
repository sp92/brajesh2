<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') {
	header("Location: main.php");
}
$feeSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'fee_amount');
if(!empty($feeSession)){
	foreach($feeSession as $key=>$value){
		if (strpos($value['Field'], 'head') !== false && strpos($value['Field'], 'head') !== true) {
			$feeNameArry[] = $value['Field'];
		}
	}
}
$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
if(!empty($head_defineSession)){
	foreach($head_defineSession as $key=>$value){
		if (strpos($value['Field'], 'head') !== false) {
			$headNameArry[] = $value['Field'];
		}
	}
}
include('header.php');
$session = $_SESSION['SESSION'];
?>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row">
		<h3>Annual Fee Calculation</h3>	
		<?php ob_start(); ?>
		<table class="table table-bordered table-striped" style="font-size:12px;">
			<thead>
				<tr>
					<th class="tg-zn0q"></th>
					<?php
					$sql2 = $db->getOne("head_define");
					foreach($sql2 as $row2=>$val){
						if(strpos($row2, 'head') !== false){
							if($val<>'' AND $val<>NULL)  { ?>
								<th class="tg-na43"><?php echo $val;?></th>
							<?php }
						}
					} ?>
					<th class="tg-na43">TOTAL</th>
				</tr>
				<tr>
					<td align="center"><b>Total Fee</b></td>
					<?php 
					// Old way to get record
					//$db->where("is_shown","YES");
					//$db->where("tc_issue <> 'YES'");
					//$db->where("session","$session");
					//$stuArr = $db->get("student");
					
					$db->join("seswise_class sc", "s.session = sc.session", "LEFT");
					$db->where ('s.is_shown', "YES");
					$db->where ("s.tc_issue <> 'YES'");
					$db->where ('sc.session', $_SESSION["SESSION"]);
					$stuArr = $db->get("student s");
					foreach($headNameArry as $hd){
						foreach($stuArr as $stu){
							foreach($m_array as $m){
								$query = "sum(".$hd.'_'.$m.") as total";
								if(in_array($hd.'_'.$m,$feeNameArry)){ 
									if($stu["custom_fee"] == 'NO'){
										$fee_amt = $db->rawQuery("SELECT ".$query." from ".PREFIX."fee_amount where class = '".$stu['class']."' AND new_old = '".$stu['new_old']."' AND type = '".$stu['type']."' AND fee_cat = '".$stu['fee_cat']."'");
									}
									else{
										$fee_amt = $db->rawQuery("SELECT ".$query." from ".PREFIX."stu_custom_fee where adm_no = '".$stu['adm_no']."'");
									}
								}
							}
						} ?>
						<td align="center"><?php echo $fee_amt[0]['total']?></td>
					<?php } exit; ?>
								<td align="center">
									<?php 
									$sum_may_paid=mysql_query("SELECT sum(head1_apr)+sum(head1_may)+sum(head1_jun)+sum(head1_jul)+sum(head1_aug)+sum(head1_sep)+sum(head1_oct)+sum(head1_nov)+sum(head1_dec)+sum(head1_jan)+sum(head1_feb)+sum(head1_mar) as total FROM ".PREFIX."student where is_shown='YES' and tc_issue<>'YES' and session='".$session."'");
									$fh_sum_may_paid = mysql_fetch_array($sum_may_paid);
									$total[] = $fh_sum_may_paid['total'];
									$head1_t = $fh_sum_may_paid['total'];
									echo moneyFormatIndia($fh_sum_may_paid['total']); ?>
								</td>
							<?php
						if($row2['head1']<>'' AND $row2['head1']<>NULL)  { ?>
						<td align="center">
							<?php 
							$sum_may_paid=mysql_query("SELECT sum(head1_apr)+sum(head1_may)+sum(head1_jun)+sum(head1_jul)+sum(head1_aug)+sum(head1_sep)+sum(head1_oct)+sum(head1_nov)+sum(head1_dec)+sum(head1_jan)+sum(head1_feb)+sum(head1_mar) as total FROM ".PREFIX."student where is_shown='YES' and tc_issue<>'YES' and session='".$session."'");
							$fh_sum_may_paid = mysql_fetch_array($sum_may_paid);
							$total[] = $fh_sum_may_paid['total'];
							$head1_t = $fh_sum_may_paid['total'];
							echo moneyFormatIndia($fh_sum_may_paid['total']); ?>
						</td>
					<?php }
					if($row2['head2']<>'' AND $row2['head2']<>NULL)  { ?>
						<td align="center">
							<?php 
							$sum_may_paid=mysql_query("SELECT sum(head2_apr)+sum(head2_may)+sum(head2_jun)+sum(head2_jul)+sum(head2_aug)+sum(head2_sep)+sum(head2_oct)+sum(head2_nov)+sum(head2_dec)+sum(head2_jan)+sum(head2_feb)+sum(head2_mar) as total FROM ".PREFIX."student where is_shown='YES' and tc_issue<>'YES' and session='".$session."'");
							$fh_sum_may_paid = mysql_fetch_array($sum_may_paid);
							$total[] = $fh_sum_may_paid['total'];
							$head2_t = $fh_sum_may_paid['total'];
							echo moneyFormatIndia($fh_sum_may_paid['total']); ?>
						</td>
					<?php }
					if($row2['head3']<>'' AND $row2['head3']<>NULL)  { ?>
						<td align="center">
							<?php 
							$sum_may_paid=mysql_query("SELECT sum(head3_apr)+sum(head3_may)+sum(head3_jun)+sum(head3_jul)+sum(head3_aug)+sum(head3_sep)+sum(head3_oct)+sum(head3_nov)+sum(head3_dec)+sum(head3_jan)+sum(head3_feb)+sum(head3_mar) as total FROM ".PREFIX."student where is_shown='YES' and tc_issue<>'YES' and session='".$session."'");
							$fh_sum_may_paid = mysql_fetch_array($sum_may_paid);
							$total[] = $fh_sum_may_paid['total'];
							$head3_t = $fh_sum_may_paid['total'];
							echo moneyFormatIndia($fh_sum_may_paid['total']); ?>
						</td>
					<?php }
					if($row2['head4']<>'' AND $row2['head4']<>NULL)  { ?>
						<td align="center">
							<?php 
							$sum_may_paid=mysql_query("SELECT sum(head4_apr)+sum(head4_may)+sum(head4_jun)+sum(head4_jul)+sum(head4_aug)+sum(head4_sep)+sum(head4_oct)+sum(head4_nov)+sum(head4_dec)+sum(head4_jan)+sum(head4_feb)+sum(head4_mar) as total FROM ".PREFIX."student where is_shown='YES' and tc_issue<>'YES' and session='".$session."'");
							$fh_sum_may_paid = mysql_fetch_array($sum_may_paid);
							$total[] = $fh_sum_may_paid['total'];
							$head4_t = $fh_sum_may_paid['total'];
							echo moneyFormatIndia($fh_sum_may_paid['total']); ?>
						</td>
					<?php }
					if($row2['head5']<>'' AND $row2['head5']<>NULL)  { ?>
						<td align="center">
							<?php 
							$sum_may_paid=mysql_query("SELECT sum(head5_apr)+sum(head5_may)+sum(head5_jun)+sum(head5_jul)+sum(head5_aug)+sum(head5_sep)+sum(head5_oct)+sum(head5_nov)+sum(head5_dec)+sum(head5_jan)+sum(head5_feb)+sum(head5_mar) FROM ".PREFIX."student where is_shown='YES' and tc_issue<>'YES' and session='".$session."'");
							$fh_sum_may_paid = mysql_fetch_array($sum_may_paid, MYSQL_NUM);
							$total[] = array_sum($fh_sum_may_paid);
							$head5_t = array_sum($fh_sum_may_paid);
							echo moneyFormatIndia(array_sum($fh_sum_may_paid)); ?>
						</td>
					<?php }
					if($row2['head7']<>'' AND $row2['head7']<>NULL)  { ?>
						<td align="center"><?php 
							$sum_may_paid=mysql_query("SELECT sum(head7_apr)+sum(head7_may)+sum(head7_jun)+sum(head7_jul)+sum(head7_aug)+sum(head7_sep)+sum(head7_oct)+sum(head7_nov)+sum(head7_dec)+sum(head7_jan)+sum(head7_feb)+sum(head7_mar) FROM ".PREFIX."student where is_shown='YES' and tc_issue<>'YES' and session='".$session."'");
							$fh_sum_may_paid = mysql_fetch_array($sum_may_paid, MYSQL_NUM);
							$total[] = array_sum($fh_sum_may_paid);
							$head7_t = array_sum($fh_sum_may_paid);
							echo moneyFormatIndia(array_sum($fh_sum_may_paid)); ?>
						</td>
					<?php }
					if($row2['head8']<>'' AND $row2['head8']<>NULL)  { ?>
						<td align="center"><?php 
							$sum_may_paid=mysql_query("SELECT sum(head8_apr)+sum(head8_may)+sum(head8_jun)+sum(head8_jul)+sum(head8_aug)+sum(head8_sep)+sum(head8_oct)+sum(head8_nov)+sum(head8_dec)+sum(head8_jan)+sum(head8_feb)+sum(head8_mar) FROM ".PREFIX."student where is_shown='YES' and tc_issue<>'YES' and session='".$session."'");
							$fh_sum_may_paid = mysql_fetch_array($sum_may_paid, MYSQL_NUM);
							$total[] = array_sum($fh_sum_may_paid);
							$head8_t = array_sum($fh_sum_may_paid);
							echo moneyFormatIndia(array_sum($fh_sum_may_paid));?>
						</td>
					<?php } 
					if($row2['head9']<>'' AND $row2['head9']<>NULL)  { ?>
						<td align="center">
							<?php 
							$sum_may_paid=mysql_query("SELECT sum(head9_apr)+sum(head9_may)+sum(head9_jun)+sum(head9_jul)+sum(head9_aug)+sum(head9_sep)+sum(head9_oct)+sum(head9_nov)+sum(head9_dec)+sum(head9_jan)+sum(head9_feb)+sum(head9_mar) FROM ".PREFIX."student where is_shown='YES' and tc_issue<>'YES' and session='".$session."'");
							$fh_sum_may_paid = mysql_fetch_array($sum_may_paid, MYSQL_NUM);
							$total[] = array_sum($fh_sum_may_paid);
							$head9_t = array_sum($fh_sum_may_paid);
							echo moneyFormatIndia(array_sum($fh_sum_may_paid)); ?>
						</td>
					<?php }
					if($row2['head10']<>'' AND $row2['head10']<>NULL)  { ?>
						<td align="center"><?php 
							$sum_may_paid=mysql_query("SELECT sum(head10_apr)+sum(head10_may)+sum(head10_jun)+sum(head10_jul)+sum(head10_aug)+sum(head10_sep)+sum(head10_oct)+sum(head10_nov)+sum(head10_dec)+sum(head10_jan)+sum(head10_feb)+sum(head10_mar) FROM ".PREFIX."student where is_shown='YES' and tc_issue<>'YES' and session='".$session."'");
							$fh_sum_may_paid = mysql_fetch_array($sum_may_paid, MYSQL_NUM);
							$total[] = array_sum($fh_sum_may_paid);
							$head10_t = array_sum($fh_sum_may_paid);
							echo moneyFormatIndia(array_sum($fh_sum_may_paid)); ?>
						</td>
					<?php } ?>
					<td align="center"><?php echo moneyFormatIndia(array_sum($total)); ?></td>
					<?php if(isset($_REQUEST['check'])) { ?>
						<td align="center"><?php 
							$sum_may_paid=mysql_query("SELECT sum(tp_apr)+sum(tp_may)+sum(tp_june)+sum(tp_july)+sum(tp_aug)+sum(tp_sep)+sum(tp_oct)+sum(tp_nov)+sum(tp_dec)+sum(tp_jan)+sum(tp_feb)+sum(tp_mar) FROM ".PREFIX."student where is_shown='YES' and tc_issue<>'YES' and class<>'OUT' and session='".$session."'");
							$fh_sum_may_paid = mysql_fetch_row($sum_may_paid, MYSQL_NUM);
							$total_tp[] = array_sum($fh_sum_may_paid);
							$headtp_t = array_sum($fh_sum_may_paid);
							echo moneyFormatIndia(array_sum($fh_sum_may_paid));?>
						</td>
						<td align="center"><?php echo moneyFormatIndia(array_sum($total)+array_sum($total_tp)); ?></td>
					<?php } ?>
				</tr> 
  <tr>
	<td align="center"><b>Collected Fee</b></td>
	<?php if($row2['head1']<>'' AND $row2['head1']<>NULL)  { ?>
	<td align="center"><?php 
	$sum_may_paid=mysql_query("SELECT sum(head1) FROM ".PREFIX."fee_paid where type='FEE' and adm_no in (".$adm_no.") and cancelled='NO' and session='".$session."'");
					$fh_sum_may_paid = mysql_fetch_row($sum_may_paid, MYSQL_NUM);
					$total_paid[] = array_sum($fh_sum_may_paid);
					$head1_paid = array_sum($fh_sum_may_paid);
					echo moneyFormatIndia(array_sum($fh_sum_may_paid));
 ?></td>
	

	<?php } if($row2['head2']<>'' AND $row2['head2']<>NULL)  { ?>
	<td align="center"><?php 
	$sum_may_paid=mysql_query("SELECT sum(head2) FROM ".PREFIX."fee_paid where  type='FEE' and adm_no in (".$adm_no.") and cancelled='NO' and session='".$session."'");
					$fh_sum_may_paid = mysql_fetch_row($sum_may_paid, MYSQL_NUM);
					$total_paid[] = array_sum($fh_sum_may_paid);
					$head2_paid = array_sum($fh_sum_may_paid);
					echo moneyFormatIndia(array_sum($fh_sum_may_paid));
 ?></td>
 
 <?php } if($row2['head3']<>'' AND $row2['head3']<>NULL)  { ?>
	<td align="center"><?php 
	$sum_may_paid=mysql_query("SELECT sum(head3) FROM ".PREFIX."fee_paid where type='FEE' and adm_no in (".$adm_no.") and cancelled='NO' and session='".$session."'");
					$fh_sum_may_paid = mysql_fetch_row($sum_may_paid, MYSQL_NUM);
					$total_paid[] = array_sum($fh_sum_may_paid);
					$head3_paid = array_sum($fh_sum_may_paid);
					echo moneyFormatIndia(array_sum($fh_sum_may_paid));
 ?></td>
 
 <?php } if($row2['head4']<>'' AND $row2['head4']<>NULL)  { ?>
	<td align="center"><?php 
	$sum_may_paid=mysql_query("SELECT sum(head4) FROM ".PREFIX."fee_paid where type='FEE' and adm_no in (".$adm_no.") and cancelled='NO' and session='".$session."'");
					$fh_sum_may_paid = mysql_fetch_row($sum_may_paid, MYSQL_NUM);
					$total_paid[] = array_sum($fh_sum_may_paid);
					$head4_paid = array_sum($fh_sum_may_paid);
					echo moneyFormatIndia(array_sum($fh_sum_may_paid));
 ?></td>
 
 <?php } if($row2['head5']<>'' AND $row2['head5']<>NULL)  { ?>
	<td align="center"><?php 
	$sum_may_paid=mysql_query("SELECT sum(head5) FROM ".PREFIX."fee_paid where type='FEE' and adm_no in (".$adm_no.") and cancelled='NO' and session='".$session."'");
					$fh_sum_may_paid = mysql_fetch_row($sum_may_paid, MYSQL_NUM);
					$total_paid[] = array_sum($fh_sum_may_paid);
					$head5_paid = array_sum($fh_sum_may_paid);
					echo moneyFormatIndia(array_sum($fh_sum_may_paid));
 ?></td>
 
 
 <?php } if($row2['head7']<>'' AND $row2['head7']<>NULL)  { ?>
	<td align="center"><?php 
	$sum_may_paid=mysql_query("SELECT sum(head7) FROM ".PREFIX."fee_paid where type='FEE' and adm_no in (".$adm_no.") and cancelled='NO' and session='".$session."'");
					$fh_sum_may_paid = mysql_fetch_row($sum_may_paid, MYSQL_NUM);
					$total_paid[] = array_sum($fh_sum_may_paid);
					$head7_paid = array_sum($fh_sum_may_paid);
					echo moneyFormatIndia(array_sum($fh_sum_may_paid));
 ?></td>
 
 <?php } if($row2['head8']<>'' AND $row2['head8']<>NULL)  { ?>
	<td align="center"><?php 
	$sum_may_paid=mysql_query("SELECT sum(head8) FROM ".PREFIX."fee_paid where type='FEE' and adm_no in (".$adm_no.") and cancelled='NO' and session='".$session."'");
					$fh_sum_may_paid = mysql_fetch_row($sum_may_paid, MYSQL_NUM);
					$total_paid[] = array_sum($fh_sum_may_paid);
					$head8_paid = array_sum($fh_sum_may_paid);
					echo moneyFormatIndia(array_sum($fh_sum_may_paid));
 ?></td>
 
 <?php } if($row2['head9']<>'' AND $row2['head9']<>NULL)  { ?>
	<td align="center"><?php 
	$sum_may_paid=mysql_query("SELECT sum(head9) FROM ".PREFIX."fee_paid where type='FEE' and adm_no in (".$adm_no.") and cancelled='NO' and session='".$session."'");
					$fh_sum_may_paid = mysql_fetch_row($sum_may_paid, MYSQL_NUM);
					$total_paid[] = array_sum($fh_sum_may_paid);
					$head9_paid = array_sum($fh_sum_may_paid);
					echo moneyFormatIndia(array_sum($fh_sum_may_paid));
 ?></td>
 
 <?php } if($row2['head10']<>'' AND $row2['head10']<>NULL)  { ?>
	<td align="center"><?php 
	$sum_may_paid=mysql_query("SELECT sum(head10) FROM ".PREFIX."fee_paid where type='FEE' and adm_no in (".$adm_no.") and cancelled='NO' and session='".$session."'");
					$fh_sum_may_paid = mysql_fetch_row($sum_may_paid, MYSQL_NUM);
					$total_paid[] = array_sum($fh_sum_may_paid);
					$head10_paid = array_sum($fh_sum_may_paid);
					echo moneyFormatIndia(array_sum($fh_sum_may_paid));
 ?></td>
 <?php } ?>
  <td align="center"><?php echo moneyFormatIndia(array_sum($total_paid)); ?></td>
 <?php if(isset($_REQUEST['check'])) { ?>
 <td align="center"><?php 
	$sum_may_paid=mysql_query("SELECT sum(transport) FROM ".PREFIX."fee_paid where type='FEE' and  adm_no in (".$adm_no.") and cancelled='NO' and session='".$session."'");
					$fh_sum_may_paid = mysql_fetch_row($sum_may_paid, MYSQL_NUM);
					$total_paid_tp[] = array_sum($fh_sum_may_paid);
					$headtp_paid = array_sum($fh_sum_may_paid);
					echo moneyFormatIndia(array_sum($fh_sum_may_paid));
 ?></td> 
 

 
 <td align="center"><?php $gross = array_sum($total_paid)+array_sum($total_paid_tp); 
 echo  moneyFormatIndia(array_sum($total_paid)+array_sum($total_paid_tp)); ?></td>
 <?php } ?>
 </tr>
 
  <tr>
	<td align="center"><b>Balance</b></td>
	<?php if($row2['head1']<>'' AND $row2['head1']<>NULL)  { ?>
	
	<td align="center"><?php echo moneyFormatIndia($head1_t-$head1_paid); ?></td>
	
	<?php } if($row2['head2']<>'' AND $row2['head2']<>NULL)  { ?>
	
	<td align="center"><?php echo moneyFormatIndia($head2_t-$head2_paid); ?></td>
 
 <?php } if($row2['head3']<>'' AND $row2['head3']<>NULL)  { ?>
	
	<td align="center"><?php echo moneyFormatIndia($head3_t-$head3_paid); ?></td>
 
 <?php } if($row2['head4']<>'' AND $row2['head4']<>NULL)  { ?>
	
	<td align="center"><?php echo moneyFormatIndia($head4_t-$head4_paid); ?></td>
 
 <?php } if($row2['head5']<>'' AND $row2['head5']<>NULL)  { ?>
	
	<td align="center"><?php echo moneyFormatIndia($head5_t-$head5_paid); ?></td>
 
 
 <?php } if($row2['head7']<>'' AND $row2['head7']<>NULL)  { ?>
	
	<td align="center"><?php echo moneyFormatIndia($head7_t-$head7_paid); ?></td>
 
 <?php } if($row2['head8']<>'' AND $row2['head8']<>NULL)  { ?>
	
	<td align="center"><?php echo moneyFormatIndia($head8_t-$head8_paid); ?></td>
 
 <?php } if($row2['head9']<>'' AND $row2['head9']<>NULL)  { ?>
	
	<td align="center"><?php echo moneyFormatIndia($head9_t-$head9_paid); ?></td>
 
 <?php } if($row2['head10']<>'' AND $row2['head10']<>NULL)  { ?>
	
	<td align="center"><?php echo moneyFormatIndia($head10_t-$head10_paid); ?></td>
	
 <?php } ?>
  <td align="center"><?php echo moneyFormatIndia(array_sum($total)-array_sum($total_paid)); $gross = array_sum($total_paid); ?></td>
 <?php if(isset($_REQUEST['check'])) { ?>
 <td align="center"><?php echo moneyFormatIndia($headtp_t-$headtp_paid); ?></td>

 
<td align="center"><?php echo moneyFormatIndia(array_sum($total)-array_sum($total_paid)+array_sum($total_tp)-array_sum($total_paid_tp)-array_sum($total_discount)); ?></td>
 <?php } ?>
 </tr>
 
  
</table>

<table>
<tr>
<td align=right>
<b><?php
					$sql = "SELECT extra_head FROM ".PREFIX."extra_head GROUP BY extra_head ORDER BY extra_head";
					$sql_result = mysql_query ($sql, $conn ) or die ('request "Could not execute SQL query" '.$sql);
					while ($row = mysql_fetch_assoc($sql_result)) {
						echo $row["extra_head"]." / ";
					}
				?> :</b> 
</td><td width="200">
<?php

$total_amount = array();

    $result = mysql_query("SELECT id,rec_no,rec_date,adm_no,stu_name,date_time,class,sec,month,particular, sum(transport) as transport2, sum(head1) as head1,sum(head2) as head2,sum(head3) as head3,sum(head4) as head4,sum(head5) as head5,sum(head6) as head6,sum(head7) as head7,sum(head8) as head8,sum(head9) as head9,sum(head10) as head10,sum(amount) as amount2,cancelled,location,mode,user,chq_no,chq_date,chq_bnk,cash_amt,chq_amt,chq_clr,remark,transport,sum(discount) as discount2,late_fine,session FROM ".PREFIX."fee_paid WHERE type='EXTRA' and cancelled<>'YES' and session='".$_SESSION['SESSION']."' group by rec_no ORDER by date_time desc");

    if(mysql_num_rows($result)>0){

        while($row = mysql_fetch_assoc($result)){

			$amount = $row['amount2']-$row['discount2']+$row['late_fine'];

			$total_amount[] = $amount;

        }

    }
	$pros = array_sum($total_amount);
	echo "Rs. ".moneyFormatIndia(array_sum($total_amount));
?>

 (+)</td>
</tr>
<tr>
<td align=right>
<b>Late Fine :</b> 
</td><td>
<?php

$total_amount = array();

    $result = mysql_query("SELECT late_fine,session FROM ".PREFIX."fee_paid WHERE cancelled<>'YES' and session='".$_SESSION['SESSION']."' group by rec_no ORDER by date_time desc");

    if(mysql_num_rows($result)>0){

        while($row = mysql_fetch_assoc($result)){

			$amount = $row['late_fine'];

			$total_amount[] = $amount;

        }

    }
	$late = array_sum($total_amount);
	echo "Rs. ".moneyFormatIndia(array_sum($total_amount));
?>
 (+)</td>
</tr>

<tr>
<td align=right>

<b>NSO :</b> 
</td><td>
<?php  
unset($adm_no);
				$nso = mysql_query("SELECT adm_no FROM ".PREFIX."student WHERE is_shown='NO' and tc_issue<>'YES' and session='".$_SESSION['SESSION']."'");
				while($data=mysql_fetch_assoc($nso)){
					$adm_no[] = $data['adm_no'];
				}
				$adm_no2 = implode(',', $adm_no);
				$total_amount = array();
				$result = mysql_query("SELECT id,rec_no,rec_date,adm_no,stu_name,date_time,class,sec,month,particular, sum(transport) as transport2, sum(head1) as head1,sum(head2) as head2,sum(head3) as head3,sum(head4) as head4,sum(head5) as head5,sum(head6) as head6,sum(head7) as head7,sum(head8) as head8,sum(head9) as head9,sum(head10) as head10,sum(amount) as amount2,cancelled,location,mode,user,chq_no,chq_date,chq_bnk,cash_amt,chq_amt,chq_clr,remark,transport,sum(discount) as discount2,late_fine,session FROM ".PREFIX."fee_paid WHERE adm_no in (".$adm_no2.") and cancelled<>'YES' and session='".$_SESSION['SESSION']."' group by rec_no ORDER by date_time desc");
				if(mysql_num_rows($result)>0){
					while($row = mysql_fetch_assoc($result)){
						$amount = $row['amount2']-$row['discount2']+$row['late_fine'];
						$total_amount[] = $amount;
					}
				}
				$nso = array_sum($total_amount);
				echo "Rs. ".moneyFormatIndia(array_sum($total_amount));
				unset($total_amount);
				unset($adm_no);
				?> (+)</td>
				

</tr>
<tr>
<td align=right>
				
				<b>TCs :</b> 
				</td><td>
				<?php  
				$tc = mysql_query("SELECT adm_no FROM ".PREFIX."student WHERE tc_issue='YES' and session='".$_SESSION['SESSION']."'");
				while($data=mysql_fetch_assoc($tc)){
					$adm_no[] = $data['adm_no'];
				}
				$adm_no2 = implode(',', $adm_no);
				$total_amount = array();
				$result = mysql_query("SELECT id,rec_no,rec_date,adm_no,stu_name,date_time,class,sec,month,particular, sum(transport) as transport2, sum(head1) as head1,sum(head2) as head2,sum(head3) as head3,sum(head4) as head4,sum(head5) as head5,sum(head6) as head6,sum(head7) as head7,sum(head8) as head8,sum(head9) as head9,sum(head10) as head10,sum(amount) as amount2,cancelled,location,mode,user,chq_no,chq_date,chq_bnk,cash_amt,chq_amt,chq_clr,remark,transport,sum(discount) as discount2,late_fine,session FROM ".PREFIX."fee_paid WHERE adm_no in (".$adm_no2.") and cancelled<>'YES' and session='".$_SESSION['SESSION']."' group by rec_no ORDER by date_time desc");
				if(mysql_num_rows($result)>0){
					while($row = mysql_fetch_assoc($result)){
						$amount = $row['amount2']-$row['discount2']+$row['late_fine'];
						$total_amount[] = $amount;
					}
				}
				$tc = array_sum($total_amount);
				echo "Rs. ".moneyFormatIndia(array_sum($total_amount));
				?>  (+)</td>
</tr>


<tr>
<td align=right>

<b>Discount Given :</b> 
</td>
<td><?php 
$sql2=mysql_query("SELECT adm_no FROM ".PREFIX."student where is_shown='YES' and tc_issue<>'YES' and session='".$_SESSION['SESSION']."'");
	while($row2 = mysql_fetch_assoc($sql2)) {
$adm_no_arr[] = $row2['adm_no'];
	}
	$adm_no = implode(',', $adm_no_arr);
	$sum_may_paid=mysql_query("SELECT sum(discount) FROM ".PREFIX."fee_paid where type='FEE' and adm_no in (".$adm_no.") and cancelled='NO' and session='".$session."'");
					$fh_sum_may_paid = mysql_fetch_row($sum_may_paid, MYSQL_NUM);
					$total_discount[] = array_sum($fh_sum_may_paid);
					echo "Rs. ".moneyFormatIndia(array_sum($total_discount));
 ?> (-)</td>
</tr>

<tr>
<td align=right><b>Annual Gross :</b> </td>
<td>
<?php  


				echo "Rs. ".moneyFormatIndia($gross+$pros+$late+$tc+$nso-array_sum($total_discount));
				?> </td>
</tr>
</table>

<link rel="stylesheet" type="text/css" href="css/print-style2.css" />

<?php
$xml2 = ob_get_contents();
$xml = str_replace('"','',$xml2);
$output = str_replace(array("\r\n", "\r"), "\n", $xml);
$lines = explode("\n", $output);
$new_lines = array();

foreach ($lines as $i => $line) {
    if(!empty($line))
        $new_lines[] = trim($line);
}

?>

<form name="sampleform" method="POST" action="get-pdf" onSubmit="return createTarget(this.target)" target="formtarget">
<input type="hidden" name="data" value="<center><?php echo implode($new_lines); ?></center>" />
<input type="hidden" name="orientation" value="L" />
<input type="hidden" name="type" value="Annual Fee Calculation" />
<input type="hidden" name="session" value="<?php echo $_SESSION['SESSION']; ?>" />
</form>
<script>
function print_pdf(){
	document.sampleform.submit();
}
</script>


</div>
</div> <!-- /container -->
<?php
include('footer.php');
?>