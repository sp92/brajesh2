<?php
$page='frontdesk';
require('core.php');
if($_SESSION['ACC_FRONTDESK']=='0') 
{
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">

  <div class="row">
  <div class="col-md-2 hidden-xs">
<?php print_menu($frontdesk_menu_items); ?>
</div>
	<div class="col-md-6">
	<h3>Add Halfdays</h3>

		
	
     	<ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Student</a></li>
    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Staff</a></li>
  </ul>
<div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="home">
	
  	<form id="add-half-student" method="post">
	<input type="hidden" name='pic' id='pic'>
	<input type="hidden" name="type" value="Student">
	<input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
	<input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>-student">
			<table class="table table-striped">
				<tr>
				<td align='right'>
				</td>
				<td >
				
					
				</td>
				<td align=right>Date:</td>
				<td><input type="text" name="date" value="<?php echo date('d/m/Y'); ?>" style="width: 100px;" readonly /></td>
				</tr>
				
			<tr >
				<td align=right>Student :</td>
				<td colspan=3><input type="text" name="stu_name" id="stu_name" placeholder="type student name" style="width:100%;" required /></td>
			</tr>
			<tr >
				<td align=right>Seleted Student :<a title="Remove selected student." class="text-danger" onclick="clearthis();" style="cursor:pointer">[x]</a></td>
				<td colspan=3><input type="text" name="related" id="related" style="width:100%;" readonly="" autocomplete="off"></td>
			</tr>
			
			<tr>
				<td align=right>Taken By :</td>
				<td ><input type="text" name="takenby" id="taker" style="width:100%" required /></td>
				<td align=right>Taker Mobile No. :</td>
				<td ><input type="text" name="takenmobile" class="numonly" maxlength="10" style="width:100%" required /></td>
			</tr>
			
			<tr >
				<td align=right>Relation with Taker :</td>
				<td ><input type="text" name="takenrelation" id="relation" required /></td>
				<td ></td>
				<td ></td>
			</tr>
			
			
			<tr>
				<td align=right>Reason :</td>
				<td colspan=2><textarea name="reason" style="width:100%;" rows="5" required ></textarea></td>
				<td><span id="cap_image"></span></td>
			</tr>
			<tr>
			   <td><span id="stuinfo" style="display:none;">Update in Student Record : <input type="checkbox" name="infrm" id="sti_info" value="on"></span><br>
				</td>
				<td colspan=3><span id="infob" style="display:none;"><input type="radio" name="infrm_img" value="photo_stu">&nbsp;Student &nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" value="photo_fat" name="infrm_img"> Father &nbsp;&nbsp;&nbsp;&nbsp; 
				<input type="radio" value="photo_mot" name="infrm_img">Mother&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
				<input type="radio" value="photo_guard" name="infrm_img">Guardian</span></td>
			</tr>
			
			<tr>
			   
				<td colspan=2 align=right><button class="btn btn-success ladda-button kill-evo" type='submit' data-style="zoom-out"><span class="ladda-label">Add Record</span></button></td>
				<td colspan=2 align=left><input type="reset" class="btn btn-primary" value="Reset"></td>
			</tr>
			</table>
			
			</form>
			</div>
    <div role="tabpanel" class="tab-pane" id="profile">
			
			
  	<form id="add-half-teacher" method="post">
	<input type="hidden" name="type" value="Teacher">
		<input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
	<input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>-teacher">
			<table class="table table-striped">
				<tr>
				
				<td align=right>Date:</td>
				<td><input type="text" name="date" value="<?php echo date('d/m/Y'); ?>" style="width: 100px;" readonly /></td>
				<td align='right'>
				</td>
				<td >
				
					
				</td>
				</tr>
				
			<tr >
				<td align=right>Teacher Name :</td>
				<td colspan=3><input type="text" name="name" id="teacher_name"  style="width:100%;" required /></td>
			</tr>
			
			
			
			<tr>
				<td align=right>Reason :</td>
				<td colspan=3><textarea name="reason" style="width:100%;" rows="5" required ></textarea></td>
			</tr>
			
			
			<tr>
			
				<td colspan=4 align=center><button class="btn btn-success ladda-button kill-evo" type='submit' data-style="zoom-out"><span class="ladda-label">Add Record</span></button>&nbsp;&nbsp;&nbsp;<input type="reset" class="btn btn-primary" value="Reset"></td>
			</tr>
			</table>
			
			</form>
			
			
			

	
	
  </div>
  </div>
	</div>

  

		<div  class="col-md-4" id="colmd4">
<script type="text/javascript" src="assets/js/webcam.js"></script>
<script language="JavaScript">
		document.write( webcam.get_html(320, 240) );
</script>
<br>
<form>
		<input type="button" value="Take Snapshot" class="ladda-button kill-evo btn-primary" onclick="take_snapshot()">&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://get.adobe.com/flashplayer/" target="_blank">Download Flash Player</a>
	</form>
		
		<div id="upload_results" style="background-color:#eee;"></div>
		<hr>
		<div id="divmsg"></div>
		</div>	

	</div>	
	<div class="row" id="student_image_info">
	
	</div>
	
	
	</div>	
<style>
#webcam_movie { border: 3px solid; } 
</style>
 <script>
 $("#sti_info").click(function(){
	if(document.getElementById('sti_info').checked) {
        $("#infob").show();
} else {
    $("#infob").hide();
}
 });

 $('#add-half-teacher').submit(function(event) {
	if(confirm('Confirm?' )) {
		event.preventDefault();
                $.ajax({
                        type: 'POST',
                        url: 'function/frontdeskfunctions',
                        data: $(this).serialize(),
						success: function (data) {
							$('#add-half-teacher').trigger("reset");
							//console.log(data);
							$.notify({message: '<strong>Successfully</strong> inserted the information.' },{type: 'success'});
						}
                });
	} else {
		event.preventDefault();
		return false;
	}
});
$('#add-half-student').submit(function(event) {
	if(confirm('Confirm?' )) {
		event.preventDefault();
                $.ajax({
                        type: 'POST',
                        url: 'function/frontdeskfunctions',
                        data: $(this).serialize(),
						success: function (data) {
							$('#add-half-student').trigger("reset");
							$('#divmsg').html(data);
							$.notify({message: '<strong>Successfully</strong> inserted the information.' },{type: 'success'});
							//console.log(data);
						}
                });
	} else {
		event.preventDefault();
		return false;
	}
});
$(function() {
	$("#stu_name").autocomplete({
		source: "function/frontdeskfunctions?stu_details",
		minLength: 2,
		select: function(event, ui) {
			$('#stu_name').val(ui.item.value);
			$('#related').val(ui.item.value);
			checkImage();
		},
		change: function (event, ui) {
			
			if (ui.item == null || ui.item == undefined) {
				$("#stu_name").val("");
				$("#stu_name").attr("disabled", false);
			} 
		}	
	});
});
function checkImage(){
	$('#stuinfo').show();
	   $.ajax({
		   url:"function/frontdeskfunctions?stu_info",
		   data:"stu_data="+$('#stu_name').val(),
		   success:function(data){
			  $('#student_image_info').html(data);
		   }
		   
	   });
	
	 
}
/* $(function() {
	$("#stu_name").autocomplete({
		source: "function/frontdeskfunctions?stu_details",
		minLength: 2,
		select: function(event, ui) {
			$('#stu_name').val(ui.item.value);
		}
	});
});
 */
	
function print_gatepass(id) {
	window.open('view-gatepass?id='+id);
}

$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
  var target = $(e.target).attr("href") // activated tab
  if(target == '#home') { $("#colmd4").show(); }
  if(target == '#profile') { $("#colmd4").hide(); }
});		
 </script>
 <script language="JavaScript">
    webcam.set_api_url( 'function/save_image_from_webcam?halfday');
		webcam.set_quality( 100 ); // JPEG quality (1 - 100)
		webcam.set_shutter_sound( false ); // play shutter click sound
		webcam.set_hook( 'onComplete', 'my_completion_handler' );

		function take_snapshot(){
			// take snapshot and upload to server
			document.getElementById('upload_results').innerHTML = '<img src="assets/img/update.gif">';
			webcam.snap();
		}

		function my_completion_handler(msg) {
			// extract URL out of PHP output
			if (msg.match(/jpg/gi)) {
				// show JPEG image in page
				document.getElementById('upload_results').innerHTML ='<h4>Picture Taken!</h4>';
				document.getElementById('pic').value = msg;
				document.getElementById('cap_image').innerHTML = "<img src='pictures/halfday/"+msg+"' style='width: 122px;'>";
				// reset camera for another shot
				webcam.reset();
			}
			else {alert("PHP Error: " + msg);
		}
		}
	</script>
 <script>
$(function(){
  var hash = window.location.hash;
  hash && $('ul.nav a[href="' + hash + '"]').tab('show');

  $('.nav-tabs a').click(function (e) {
    $(this).tab('show');
    var scrollmem = $('body').scrollTop();
    window.location.hash = this.hash;
    $('html,body').scrollTop(scrollmem);
  });
});
function clearthis() {
	$('#student_image_info').html("");
	$("#related").val("");
	$("#stu_name").val("");
}
</script>


<?php
include('footer.php');
?>