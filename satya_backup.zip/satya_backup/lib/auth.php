<?php
	if(!isset($_SESSION['SESS_ID']) || (trim($_SESSION['SESS_ID']) == '') AND !isset($_SESSION['SECURE_SALT']) || (trim($_SESSION['SECURE_SALT']) == '') ) {
		header("location: ./access-denied");
		exit();
	} else {
		$id = $_SESSION['SESS_ID'];
		$db->where ("id", $id);
		$cols = Array ("is_log");
		$session = $db->get ("admin", 1, $cols);
		foreach ($session as $sess) { 
			$val = $sess['is_log'];
		}	
		if($val<>'TRUE' AND $val<>'N/A') {
			header("location: ./access-denied");
			exit();
		}
	}
?>