<?php
date_default_timezone_set('Asia/Calcutta');
error_reporting(E_ALL);
ini_set('max_execution_time', 0);
define('SUPPORTEMAIL','info@accevate.com');
define('SCHOOLNAME','KRISHNA INTERNATIONAL SCHOOL');
define('SCHOOLNAME_SHORT','KIS ALIGARH');
define('fee_coll_type','MONTHLY');
define('PREFIX','kisalg_');

/* Initialize Database */
require_once ("MysqliDb.php");
$db = new Mysqlidb('localhost', 'root', '', 'erp');
//$db = new Mysqlidb('localhost', 'accretio_fee_erp', '?A4acNhHvHG4', 'accretio_fee_erp');
if(!$db) die("Database error");
$prefix = 'kisalg_';
$db->setPrefix(PREFIX);
$global_atten_date_stu = date('2017-01-01');
$global_atten_date_staff = date('2017-01-01');
// Function to prevent MySQL injection attacks
if(!function_exists('cleanInput')) {
function cleanInput($input) {
 
  $search = array(
    '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
    '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
    '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
    '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
  );
 
    $output = preg_replace($search, '', $input);
    return $output;
}
}

if(!function_exists('clean')) {
function clean($input) {
    if (is_array($input)) {
        foreach($input as $var=>$val) {
            $output[$var] = clean($val);
        }
    }
    else {
        if (get_magic_quotes_gpc()) {
            $input = stripslashes($input);
        }
        $output  = cleanInput($input);
    }
    return $output;
}
}

// Student username generate
if(!function_exists('getusername'))
{
function getusername($getname) {
$name = $getname;
$name = str_replace('.','',$name);
$username = explode(" ",$name);
$rand = rand(1000,99999);
$usernm = strtolower($username[0].$rand);
return $usernm;
}
}

// Function to convert dd/mm/yyyy to yyyy-mm-dd
if(!function_exists('datestamp'))
{
	function datestamp($uf_date) {
		$uf_date = str_replace('/', '-', $uf_date);
		$uf_date2 = date('Y-m-d', strtotime($uf_date));
		return $uf_date2;
	}
}
	
// Function to get ip
if(!function_exists('get_ip'))
{
function get_ip() {
$ipaddress = '';
if($_SERVER['REMOTE_ADDR'])
    $ipaddress = $_SERVER['REMOTE_ADDR'];
else if ($_SERVER['HTTP_CLIENT_IP'])
    $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
else
    $ipaddress = 'UNKNOWN';
return $ipaddress;
}
}

// For encryption and decryption
if(!function_exists('base64url_encode'))
{
function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}
}
if(!function_exists('base64url_decode'))
{
function base64url_decode($data) {
    return base64_decode(strtr($data, '-_', '+/'));
}
}

// Form Data Cleanup Before Insert/Update
if(!function_exists('clean_data')) {
function clean_data($unf_data) {
	unset($unf_data['secure_salt']);
	unset($unf_data['form']);
	foreach($unf_data as $key => $val) {
		$data[$key] = clean($val);
	}
	unset($data['accevate_erp']);
	$data['user'] = $_SESSION['SESS_NAME'];
	$data['date'] = date('Y-m-d H:i:s');
	$data['session'] = $_SESSION['SESSION'];
	return $data;
}
}

// Sending SMS
if(!function_exists('send_sms')) {
	function send_sms($mobile,$message) {
		global $db;
		$db->where ("id", 1);
		$user = $db->get ("smsapi",1);
		if ($db->count > 0) {
			foreach ($user as $u) { 
				$set_sms = $u['set_sms'];
				$api_url = $u['api_url'];
				$api_key = $u['api_key'];
				$sender_id = $u['sender_id'];
			}
		}
		$myvars = 'workingkey='.$api_key.'&sender='.$sender_id.'&to='.$mobile.'&message='.$message.'';
		if($set_sms == '1' and strlen($mobile)==10) {
			$ch = curl_init( $api_url );
			curl_setopt( $ch, CURLOPT_POST, 1);
			curl_setopt( $ch, CURLOPT_POSTFIELDS, $myvars);
			curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt( $ch, CURLOPT_HEADER, 0);
			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
			$response = curl_exec( $ch );
		}
		return $response;
	}
}

// Indian currency format
function moneyFormatIndia($num){
    $explrestunits = "" ;
    if(strlen($num)>3){
        $lastthree = substr($num, strlen($num)-3, strlen($num));
        $restunits = substr($num, 0, strlen($num)-3); // extracts the last three digits
        $restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
        $expunit = str_split($restunits, 2);
        for($i=0; $i<sizeof($expunit); $i++){
            // creates each of the 2's group and adds a comma to the end
            if($i==0)
            {
                $explrestunits .= (int)$expunit[$i].","; // if is first value , convert into integer
            }else{
                $explrestunits .= $expunit[$i].",";
            }
        }
        $thecash = $explrestunits.$lastthree;
    } else {
        $thecash = $num;
    }
    return $thecash; // writes the final format where $currency is the currency symbol.
}
function getdmYFormat($date){
	if($date<>'0000-00-00'){
	$originalDate = $date;
	$newDate = date("d/m/Y", strtotime($originalDate));
	return $newDate;
	}
}

if(!function_exists('towords'))
{
function towords($amount) {
	$number = $amount;
   $no = round($number);
   $point = round($number - $no, 2) * 100;
   $hundred = null;
   $digits_1 = strlen($no);
   $i = 0;
   $str = array();
   $words = array('0' => '', '1' => 'one', '2' => 'two',
    '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
    '7' => 'seven', '8' => 'eight', '9' => 'nine',
    '10' => 'ten', '11' => 'eleven', '12' => 'twelve',
    '13' => 'thirteen', '14' => 'fourteen',
    '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
    '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty',
    '30' => 'thirty', '40' => 'forty', '50' => 'fifty',
    '60' => 'sixty', '70' => 'seventy',
    '80' => 'eighty', '90' => 'ninety');
   $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
   while ($i < $digits_1) {
     $divider = ($i == 2) ? 10 : 100;
     $number = floor($no % $divider);
     $no = floor($no / $divider);
     $i += ($divider == 10) ? 1 : 2;
     if ($number) {
        $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
        $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
        $str [] = ($number < 21) ? $words[$number] .
            " " . $digits[$counter] . $plural . " " . $hundred
            :
            $words[floor($number / 10) * 10]
            . " " . $words[$number % 10] . " "
            . $digits[$counter] . $plural . " " . $hundred;
     } else $str[] = null;
  }
  $str = array_reverse($str);
  $result = implode('', $str);
  $points = ($point) ?
    "." . $words[$point / 10] . " " . 
          $words[$point = $point % 10] : '';
  //echo $result . "Rupees  " . $points . " Paise";
  return $result;
}
}

?>