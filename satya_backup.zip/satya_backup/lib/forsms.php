<script>
$("#balance").load("function/sms-functions?option=checkbal");

var sms = {};

var regx_unicode_pattern = '[^\sa-zA-Z0-9@£$¥èéùìòÇØøÅå\?_F\?ÆæßÉ\!"#¤%&\'\(\)\*\+,\-\|\.\/\:;\<\=\>\?¡\?ÖÑÜ§¿öñüàäÄ\\{\}~\[\]\^\r\n]+/u';
var chars_extended = '([£¥èéùìòÇØøÅåΔΦΓΛΩΠΨΣΘΞÆæßÉ¤¡ÄÖÑÜ§¿äöñüà\|\\{\}~\[\]\^])';

$(document).on('keyup keydown keypress focus paste change', '#ac-message', function(){
		sms.getLength();
	});

function countUtf8(string) {
    var utf8length = 0;
    var chars = chars_extended.replace('(', '');
    chars = chars.replace(')', '');
    var two = chars.split("");
    for (var n = 0; n < string.length; n++) {
        var c = string.charCodeAt(n);
        if (c < 128) {
            utf8length++;
            var cr = string.charAt(n);
            if ($.inArray(cr, two) !== -1) {
                utf8length++;
            }
        } else if ((c > 127) && (c < 2048)) {
            utf8length = utf8length + 2;
        } else {
            utf8length = utf8length + 3;
        }
    }
    return utf8length;
}

function calculatelength(str, type) {
    var patt = new RegExp(regx_unicode_pattern);
    var res = patt.test(str);
    var len = str.length;
    var udh = 153,
        sms = 160,
        unicode = false,
        credits = 1;
    if ((res || type == 'U') && type != 'N') {
        udh = 134;
        sms = 140;
        len = len * 2;
        unicode = true
    } else {
        var len = countUtf8(str);
    }
    if (len > sms) {
        credits = Math.ceil(len / udh);
    }
    var d = {
        credits: credits,
        len: len,
        unicode: unicode
    }
    return d;
}

sms.getLength = function() {

	var message   = $('#ac-message').val();
	var signature = $('input[name="signature"]').val();
	if("undefined" !== typeof signature && signature !== '') {
		message += ' '+signature;
	}

	var sms_type = $('input[name="sms_type"]:checked').val();
	if(sms_type == undefined) {
		sms_type = $('input[name="sms_type"]').val();
	}
	var result = calculatelength(message,sms_type);

	if(result.len === 0){
		$('.ac-sms-count').html('0');
		$('.ac-sms-credits').html('0');
		return;
	}

	
	$('.ac-sms-count').html(result.len);
	$('.ac-sms-credits').html(result.credits);
};

</script>

<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <section class="table-list-view">
<div style="overflow:auto;max-height:500px;overflow-x:hidden">
<div style="margin-bottom: 20px">
 <h4 align=center>Standard GSM Characters</h4>
    <div>
    <table class="table table-striped tablesaw tablesaw-stack" data-tablesaw-mode="stack">
        <thead>
            <tr>
                <th>No Of SMS</th>
                <th>No Of Characters</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td align=center>1</td>
                <td align=center>160 characters</td>
            </tr>
            <tr>
                <td align=center>2</td>
                <td align=center> (2 x 153) 306 characters</td>
            </tr>
            <tr>
                <td align=center>3</td>
                <td align=center> (3 x 153) 459 characters </td>
            </tr>
            <tr>
                <td align=center>...</td>
                <td align=center>...</td>
            </tr>
            <tr>
                <td align=center>7</td>
                <td align=center>(6 x 153) + (1 x 82) 1000 characters </td>
            </tr>
        </tbody>
    </table>
</div>
</div>

<div style="margin-bottom: 20px">
<h4 align=center>Unicode Characters</h4>
<div>
     <table class="table table-striped tablesaw tablesaw-stack" data-tablesaw-mode="stack">
        <thead>
        <tr>
            <th>No Of SMS</th>
            <th>No Of Characters</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td align=center>1</td>
            <td align=center>70 characters</td>
        </tr>
        <tr>
            <td align=center>2</td>
            <td align=center>(2 x 67) 134 characters </td>
        </tr>
        <tr>
            <td align=center>3</td>
            <td align=center>(3 x 67) 201 characters </td>
        </tr>
        <tr>
            <td align=center>...</td>
            <td align=center>...</td>
        </tr>
        <tr>
            <td align=center>8</td>
            <td align=center>(7 x 67) + (1 x 31) 500 characters </td>
        </tr>
    </tbody>
</table>
</div>
</div>
    


</div>
        </div>
    </div>
</section>
    </div>
