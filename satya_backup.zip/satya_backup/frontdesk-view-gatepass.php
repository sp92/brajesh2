<?php
$page='frontdesk';
require('core.php');
error_reporting(0);
if($_SESSION['ACC_FRONTDESK']=='NO') 
{
	header("Location: main.php");
}
?>
	<br/>
	<!-- Start Content -->
	<div class="row">
	<div class="col-md-9">
<?php
$id=$_REQUEST['id'];
$db->where('id',$id);
$row=$db->get('halfday');

/* $sql=mysql_query("SELECT * FROM ".PREFIX."halfday where id='".$id."'") or die(mysql_error());
$row = mysql_fetch_assoc($sql); */
if($db->count < 1 OR $db->count == 0)
{
echo "No Record Found.";
}
else
{
?>  
<?php
ob_start();
?>

<div class=Section1>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:1px solid;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0in 5.4pt 0in 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:13.05pt'>
  <td width=786 colspan=20 align=center valign=bottom style='width:534.15pt;border:solid windowtext 2.25pt;
  border-bottom:none;background:#D9D9D9;mso-background-themecolor:background1;
  mso-background-themeshade:217;padding:0in 5.4pt 0in 5.4pt;height:13.05pt'>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:17.0pt;mso-bidi-font-size:14.0pt'><?php echo SCHOOLNAME; ?></span><span style='font-size:14.0pt'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;height:20.25pt'>
  <td width=786 colspan=20 align=center valign=top style='width:534.15pt;border-top:none;
  border-left:solid windowtext 2.25pt;border-bottom:none;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:20.25pt'>
  <p class=MsoNormal align=center style='margin-top:12.0pt;margin-right:0in;
  margin-left:0in;text-align:center'><b style='mso-bidi-font-weight:
  normal'><u><span style='font-size:14.0pt;mso-bidi-font-size:16.0pt;
  font-family:JuniusSmallCaps'>Application for Half Day Leave</span></u></b><span
  style='font-size:14.0pt'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2;height:.3in'>
  <td width=140 valign=bottom  style='width:95.3pt;border:none;border-left:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Name of
  Student :<o:p></o:p></span></p>
  </td>
  <td width=296 colspan=9 valign=bottom style='width:201.1pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['name']; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class : <?php echo $row[0]['class']."-".$row[0]['sec']; ?><o:p></o:p></span></p>
  </td>
  <td width=91 colspan=3 valign=bottom align=right style='width:61.8pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Adm. No.:<o:p></o:p></span></p>
  </td>
  <td width=90 colspan=2 valign=bottom style='width:61.1pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:9.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['adm_no']; ?><o:p></o:p></span></p>
  </td>
  <td width=86 colspan=4 valign=bottom  style='width:58.5pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><o:p></o:p></span></p>
  </td>
  <td width=83 rowspan=2 valign=bottom align=center style='width:56.35pt;border-top:none;border-left:
  none;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <?php echo "<img src='pictures/halfday/".$row[0]['pic']."' style='width:130px;border:1px solid #000;'>"; ?>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3;height:.3in'>
  <td width=140 valign=bottom  style='width:95.3pt;border:none;border-left:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Father’s
  Name :<o:p></o:p></span></p>
  </td>
  <td width=296 colspan=9 valign=bottom style='width:201.1pt;border:none;
  border-bottom:1px solid;mso-border-top-alt:1px solid;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['fat_name']; ?>
  
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <o:p></o:p></span></p>
  </td>
  <td width=188 colspan=7 valign=bottom align=left  style='width:127.4pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Tel. No.: <u><?php 
   $db->where('adm_no',$row[0]['adm_no']);
   $db->where('session',$_SESSION['SESSION']);
  $mob_data=$db->get('student',null,'mobile');
  echo $mob_data[0]['mobile'];
  ?></u><o:p></o:p></span></p>
  </td>

 </tr>
 <tr style='mso-yfti-irow:4;height:19.3pt'>
  <td width=179 colspan=3  valign=bottom style='width:121.8pt;border:none;
  border-left:solid windowtext 2.25pt;padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Name of
  Taker:<o:p></o:p></span></p>
  </td>
  <td width=607 colspan=17 valign=bottom style='width:412.35pt;border-top:none;
  border-left:none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['takenby']; ?><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:5;height:19.3pt'>
  <td width=240 colspan=6  valign=bottom style='width:162.8pt;border:none;
  border-left:solid windowtext 2.25pt;padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Taker’s
  Relation with the Child:<o:p></o:p></span></p>
  </td>
  <td width=198 colspan=5 valign=bottom style='width:134.2pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['takenrelation']; ?><o:p></o:p></span></p>
  </td>
  <td width=186 colspan=5  valign=bottom align=right style='width:126.45pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Taker Mobile
  No. :<o:p></o:p></span></p>
  </td>
  <td width=163 colspan=4 valign=bottom style='width:110.7pt;border-top:none;
  border-left:none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['takenmobile']; ?><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:6;height:19.35pt'>
  <td width=218 colspan=4  valign=bottom style='width:147.85pt;border:none;
  border-left:solid windowtext 2.25pt;padding:0in 5.4pt 0in 5.4pt;height:19.35pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Reason for
  Half Day Leave:<o:p></o:p></span></p>
  </td>
  <td width=569 colspan=16 valign=bottom style='width:386.3pt;border-top:none;
  border-left:none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:19.35pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['message']; ?><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:7;height:17.55pt'>
  <td width=154 colspan=2  valign=bottom style='width:104.85pt;border:none;
  border-left:solid windowtext 2.25pt;padding:0in 5.4pt 0in 5.4pt;height:17.55pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Date of
  Application:<o:p></o:p></span></p>
  </td>
  <td width=144 colspan=5 valign=bottom style='width:97.5pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:17.55pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo date('d/m/Y'); ?><o:p></o:p></span></p>
  </td>
  <td width=88 colspan=2  valign=bottom style='width:59.55pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:17.55pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Time:<o:p></o:p></span></p>
  </td>
  <td width=110 colspan=3 valign=bottom style='width:74.85pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:17.55pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo date('H:i A'); ?><o:p></o:p></span></p>
  </td>
  <td width=173 colspan=6  valign=bottom style='width:117.35pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:17.55pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Signature of
  Applicant:<o:p></o:p></span></p>
  </td>
  <td width=118 colspan=2 valign=bottom style='width:80.05pt;border-top:none;
  border-left:none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:17.55pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:8;height:.25in'>
  <td width=220 colspan=5  valign=bottom style='width:149.55pt;border:none;
  border-left:solid windowtext 2.25pt;padding:0in 5.4pt 0in 5.4pt;height:.25in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Name of the
  Class Teacher:<o:p></o:p></span></p>
  </td>
  <td width=165 colspan=4 valign=bottom style='width:112.35pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:.25in'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><o:p></o:p></span></p>
  </td>
  <td width=219 colspan=5  valign=bottom style='width:148.55pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:.25in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Signature of
  Class Teacher:<o:p></o:p></span></p>
  </td>
  <td width=182 colspan=6 valign=bottom style='width:123.7pt;border-top:none;
  border-left:none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:.25in'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:9;height:18.45pt'>
  <td width=154 colspan=2  valign=bottom style='width:104.85pt;border:none;
  border-left:solid windowtext 2.25pt;padding:0in 5.4pt 0in 5.4pt;height:18.45pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Driver Name :<o:p></o:p></span></p>
  </td>
  <td width=231 colspan=7 valign=bottom style='width:157.05pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:18.45pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php 
  $db->join("stu_sess_data su", "su.bus_id=vm.id", "LEFT");
  $db->where('su.stu_id',$row[0]['adm_no']);
  $products = $db->get ("vehicle_master vm", null, "vm.driver_name,vm.veh_no,vm.mobile_no");
  foreach($products as $sql6)
{ echo $sql6['driver_name']; }
  ?><o:p></o:p></span></p>
  </td>
  <td width=219 colspan=5  align=right valign=bottom style='width:148.55pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:18.45pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Route No:<o:p></o:p></span></p>
  </td>
  <td width=182 colspan=6 valign=bottom style='width:123.7pt;border-top:none;
  border-left:none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  mso-border-top-alt:1px solid;padding:0in 5.4pt 0in 5.4pt;
  height:18.45pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php 
 echo $products[0]['veh_no'];?>
  <o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:10;height:16.2pt'>
  <td width=786 colspan=20 valign=top style='width:534.15pt;border-top:none;
  border-left:solid windowtext 2.25pt;border-bottom:none;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:16.2pt'>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:14.0pt'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:11;mso-yfti-lastrow:yes;height:22.7pt'>
  <td width=379 colspan=8 valign=bottom style='width:257.4pt;border-top:none;
  border-left:solid windowtext 2.25pt;border-bottom:solid windowtext 2.25pt;
  border-right:none;padding:0in 5.4pt 0in 5.4pt;height:22.7pt'>
  <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
  style='font-size:13.0pt;mso-bidi-font-size:13.0pt'></span></b><span
  style='font-size:14.0pt'><o:p></o:p></span></p>
  </td>
  <td width=407 colspan=12  align=right valign=bottom style='width:276.75pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 2.25pt;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:22.7pt'>
  <p class=MsoNormal  style='text-align:right'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:13.0pt;mso-bidi-font-size:13.0pt;font-family:
  "Monotype Corsiva"'>Signature of Principal</span></b><span style='font-size:
  14.0pt'><o:p></o:p></span></p>
  </td>
 </tr>
 <![if !supportMisalignedColumns]>
 <tr height=0>
  <td width=134 style='border:none'></td>
  <td width=13 style='border:none'></td>
  <td width=23 style='border:none'></td>
  <td width=35 style='border:none'></td>
  <td width=3 style='border:none'></td>
  <td width=18 style='border:none'></td>
  <td width=54 style='border:none'></td>
  <td width=77 style='border:none'></td>
  <td width=7 style='border:none'></td>
  <td width=47 style='border:none'></td>
  <td width=1 style='border:none'></td>
  <td width=56 style='border:none'></td>
  <td width=30 style='border:none'></td>
  <td width=73 style='border:none'></td>
  <td width=12 style='border:none'></td>
  <td width=6 style='border:none'></td>
  <td width=1 style='border:none'></td>
  <td width=42 style='border:none'></td>
  <td width=33 style='border:none'></td>
  <td width=80 style='border:none'></td>
 </tr>
 <![endif]>
</table>


<p class=MsoNormal>&nbsp;</p>

</div>
<?php
}
/* file_put_contents('gatepass.htm', ob_get_contents());
echo "<script>window.location.href='gp_pdf.php';</script>";
ob_end_flush(); */
?>