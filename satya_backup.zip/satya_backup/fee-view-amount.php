<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') {
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row">
		<h3>Define Fee Amount</h3>
		<form id="fee-form">
			<input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
			<input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>">
			<b>FEE TYPES :</b> 
			<select name="type" id="type" required onchange="get_fee();" >
				<option value=""> --  </option>
	  <?php
		$db->where('session', $_SESSION['SESSION']);
		$user = $db->get ("type");
		if ($db->count > 0) {
			foreach ($user as $u) { 
		?>			
		<option value='<?php echo $u['type']; ?>'><?php echo $u['type']; ?></option>
		<?php } } ?>	
    </select>
&nbsp;&nbsp;&nbsp;&nbsp;
	
<b>FEE CATEGORIES :</b> <select name="fee_cat" id="fee_cat" required onchange="get_fee();" >
      <option value="">
        --
      </option>
	  <?php
		$db->where('session', $_SESSION['SESSION']);
		$user = $db->get ("fee_cat");
		if ($db->count > 0) {
			foreach ($user as $u) { 
		?>			
		<option value='<?php echo $u['fee_cat']; ?>'><?php echo $u['fee_cat']; ?></option>
		<?php } } ?>	
    </select>

	&nbsp;&nbsp;&nbsp;&nbsp;
	<b>NEW / OLD :</b>
	<select name="new_old" id="new_old" required="" onchange="get_fee();">
      <option value="">  --</option>
	  	<option value="NEW">NEW</option>
		<option value="OLD">OLD</option>
	</select>
	
	&nbsp;&nbsp;&nbsp;&nbsp;
	<b>CLASS :</b>
	<select name="class" id="class" required onchange="get_fee();" >
      <option value="">
        --
      </option>
	  <?php
		$user = $db->get ("class_master");
		if ($db->count > 0) {
			foreach ($user as $u) { 
		?>			
		<option value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
		<?php } } ?>	
    </select>
<br>
<br>


<div id="amountdiv"></div>
<?php if(acl_check('fee_change_fee_define', $_SESSION['SESS_ID']) != false) {  ?>
<button class="btn btn-primary ladda-button kill-evo" type='submit' data-style="zoom-out" id="submitbtn" style="display:none;">
<span class="ladda-label">Update Fee</span></button>
<?php } ?>
</form>



  <script>

function get_fee() {
	var type = $('#type').val();
	var fee_cat = $('#fee_cat').val();
	var new_old = $('#new_old').val();
	var clss = $('#class').val();
	if(type != "" && fee_cat != "" && new_old != "" && clss != "") {
		$("#amountdiv").load("function/feeamountfunctions?viewamount", {var1:type, var2:fee_cat, var3:new_old, var4:clss});
		$("#submitbtn").css("display", "block");
	} else {
		$("#amountdiv").html("");
		$("#submitbtn").css("display", "none");
	}
}

$('#fee-form').submit(function(event) {
	event.preventDefault();
		$.ajax({
			type: 'POST',
			url: './function/feeamountfunctions?submitamount',
			data: $(this).serialize(),
			success: function (data) {
				//console.log(data);
				$.notify({message: '<strong>Successfully</strong> updated the information.' },{type: 'success'});
				get_fee();
			}
		});
	
});
</script>


</div>
</div> <!-- /container -->
<?php
include('footer.php');
?>