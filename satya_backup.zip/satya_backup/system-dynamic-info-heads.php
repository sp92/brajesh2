<?php
$page='system';
require('core.php');
if($_SESSION['ACC_GROUP']<>'root') 
{
	header("Location: main.php");
}

if(@$_REQUEST['hdnCmd']=="ADD")
{
	$f_label=clean($_REQUEST['f_label']);
	$field=clean($_REQUEST['field']);
	$type=clean($_REQUEST['type']);
	$length=clean($_REQUEST['length']);
	
	$data = Array (
	    'name' => $f_label,
		'field' => $field,
		'type' => $type,
		'length' => $length
		
	);
	$db->insert ('stu_custom_data', $data);
	if($type == 'DATE') {
		$query = "ALTER TABLE  `".PREFIX."student` ADD  `".$field."` DATE NOT NULL";
	} 
	else if($type == 'ENUM') {
		$query = "ALTER TABLE  `".PREFIX."student` ADD  `".$field."` ENUM NOT NULL";
	}else {
		$query = "ALTER TABLE  `".PREFIX."student` ADD  `".$field."` ".$type."( ".$length." ) NOT NULL";
	}
	$db->rawQuery($query);
	header("Location: ./system-dynamic-info-heads");
	
}
if(@$_REQUEST['action']=="del")
	{
		
	$db->where('id', round($_REQUEST['id']));
	$db->delete('stu_custom_data');
	
	$field=clean($_REQUEST['field']);
	$query = "ALTER TABLE  `".PREFIX."student` DROP  `".$field."`";
	$db->rawQuery($query);
	header("Location: ./system-dynamic-info-heads");
	}
include('header.php');
?>
<div class="container">
<?php print_menu($settings_menu_items); ?>
<div class="row">
<h3>Dynamic Information Heads</h3>

<form class="form-inline" role="form" action="system-dynamic-info-heads" method="post">
<input type="hidden" name="hdnCmd" value="ADD" autocomplete="off">
 <div class="form-group">
    <label for="exampleInputEmail2">Field Label : </label>
	<input type="text" name="f_label" required=""  autocomplete="off">
  </div>
    <div class="form-group">
    <label for="exampleInputEmail2">Field Name : </label>
	<input type="text" name="field" required="" autocomplete="off">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Field Type : </label>
    <select name="type" id="type" required="">
<option value="">--</option>
<option value="VARCHAR">Text/Number Field</option>
<option value="INT">Only Number Field</option>
<option value="DATE">Date</option>
<option value="ENUM">Option Select</option>
</select>
  </div>

  <div class="form-group">
    <label for="exampleInputPassword2">Length : </label>
    <input type="text" id="length" name="length" style="width: 75px;" >
  </div>
  <button type="submit" class="btn btn-default btn-xs">Create Field</button>
</form>
<p class="text-danger">* Fields will be created in Student Master.</p>
<center>
</center>
<hr>
<table class="table table-striped table-hover table-bordered">
<thead>
<tr>
<th style="width:20px;">SR</th>
<th >Field Label</th>
<th >Field Name</th>
<th >Field Type</th>
<th >Length</th>
<th >Option</th>
</tr>
</thead>
<tbody>
				
<?php
$n=1;

	$user = $db->get ("stu_custom_data");
		if ($db->count > 0) {
		foreach ($user as $u) { 		
?>
<tr>
<td align=center><?php echo $n; $n++; ?></td>
<td align=center><?php echo $u['name']; ?></td>
<td align=center><?php echo $u['field']; ?></td>
<td align=center><?php echo $u['type']; ?></td>
<td align=center><?php echo $u['length']; ?></td>

<td align=center>
<?php if($u['default']<>1) { ?>
<a href="system-dynamic-info-heads?action=del&id=<?php echo $u['id']; ?>&field=<?php echo $u['field']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
<?php } else { echo "Default Field"; } ?>

</td>
</tr>
		  <?php }} ?>	
</table>

<script>
 $("#type").change(function(){
	 var type = $(this).val();
	 if(type == 'VARCHAR') { $("#length").val(255); }
	 else if(type == 'INT') { $("#length").val(10); }
	 else if(type == 'DATE') { $("#length").val(""); }
	 else if(type == 'ENUM') { $("#length").val(""); }
	 else { $("#length").val(""); }
 });
</script>
</div>
</div>
<?php
include('footer.php');
?>