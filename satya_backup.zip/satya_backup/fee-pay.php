<?php
include('core.php');
error_reporting(0);
if($_SESSION['ACC_FEE']=='0') { header("Location: main"); }
$adm_no=clean($_REQUEST['adm_no']);
if($adm_no=='') { echo "<script>window.close();</script>"; }

$db->where ('adm_no', $adm_no);
$stu_data = $db->get("student",null,'id');
$student_id=$stu_data[0]['id'];
// Old way to get record
//$db->where ('adm_no', $adm_no);
//$data_stu = $db->getOne ("student");

$db->join("stu_sess_data sc", "s.id = sc.stu_id", "LEFT");
$db->where ('s.id', $student_id);
$db->where ('sc.session', $_SESSION["SESSION"]);
$data_stu = $db->getOne("student s");

if($data_stu['is_transport'] == 'YES') {
	$db->where ('session', $_SESSION['SESSION']);
	$db->where ('stu_id', $student_id);
	$tpt_stu = $db->getOne ("stu_tpt_fee");
}
if($data_stu['custom_fee'] == 'YES') {
	$db->where ('session', $_SESSION['SESSION']);
	$db->where ('stu_id', $student_id);
	$fee_stu = $db->getOne ("stu_custom_fee");
} else {
	$db->where ('session', $_SESSION['SESSION']);
	$db->where ('class', $data_stu['class']);
	$db->where ('new_old', $data_stu['new_old']);
	$db->where ('fee_cat', $data_stu['fee_cat']);
	$db->where ('type', $data_stu['type']);
	$fee_stu = $db->getOne ("fee_amount");	
}


// Get head count from head_define table.

$headCount = 0;
$query = '';
$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
if(!empty($head_defineSession)){
	foreach($head_defineSession as $key=>$value){
		//echo $value['Field'];
		if (strpos($value['Field'], 'head') !== false) {
			$query =  $query.'sum('.$value['Field'].') as h'.($headCount+1).', ';
			$headCount++;
		}
	}
}
$db->where('session', $_SESSION['SESSION']);
$head = $db->get ("head_define",1);
if ($db->count>0) {
	foreach ($head as $u) { 
		for ($i = 1; $i <= $headCount; $i++) { 
			$var = 'head'.$i;
			$heads[] = $u[$var];
		}
	}
}

$heads2 = array_filter($heads);
$heads_count = count($heads2);

foreach($m_array as $m) {
	for ($i=1; $i <= $heads_count; $i++) {
		$head_name = "head".$i."_".$m;
		$fee[] = $fee_stu[$head_name];
	}
	$total_fee[$m] = array_sum($fee);
	unset($fee);
	}
	if($data_stu['is_transport'] == 'YES') {
		foreach($m_array as $m) {
			$head_name = "tp_".$m;
			$fee = $tpt_stu[$head_name];
			$tpt_fee[$m] = intval($fee);
			unset($fee);
		}
	}
	$query = $query." sum(transport) as tp";
	foreach($mf_array as $m) {
		$tota = 0;
		$db->where ('session', $_SESSION['SESSION']);
		$db->where ('stu_id', $student_id);
		$db->where ('cancelled', '0');
		$db->where ('month', $m);
		$fee_paid = $db->getOne ("fee_paid", $query);
		$fee_m = strtolower(substr($m,0,3));
		for($i=0;$i<=$headCount;$i++){
			$tota = $tota+$fee_paid['h'.($i+1)];
		}
		$paid_fee[$fee_m] = $tota+$fee_paid['tp'];
	}
	
	
$sums = array();


foreach (array_keys($total_fee) as $key) {
     $sums[$key] = @($total_fee[$key] + $tpt_fee[$key]);
}
include("header2.php");
?>

  <div class="container">
	<div class="row">
	<center>
<form id="getmonth" class="form-inline">
<input type="hidden" name="adm_no" value="<?php echo $student_id; ?>">
  <div class="form-group">
  <label for="exampleInputName2">From  : </label>
    <select id="drop1" name="drop1" class="form-control" readonly>
	<?php
	$i=1;
	
	foreach($mf_array as $m) {
		$key = array_search($m, $mf_array);
		$fee_m = strtolower(substr($m,0,3));
		$bal = $sums[$fee_m] - $paid_fee[$fee_m];
		if($bal > 0) {
			echo "<option value='".$key."'>".$m."</option>"; $i++;
		}
	}
	?>
	</select>
  </div>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <div class="form-group">
    <label for="exampleInputEmail2">To  :</label>
    <select id="drop2" name="drop2" class="form-control" autofocus>
	<?php
	$i=1;
	foreach($mf_array as $m) {
		$key = array_search($m, $mf_array);
		$fee_m = strtolower(substr($m,0,3));
		$bal = $sums[$fee_m] - $paid_fee[$fee_m];
		if($bal > 0) {
			echo "<option value='".$key."'>".$m."</option>"; $i++;
		}
	}
	?>
	</select>
  </div>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <button class="btn btn-success ladda-button kill-evo" type="submit" data-style="zoom-out"><span class="ladda-label">GET FEE</span></button>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	
	<label><input type="radio" name="file" class="radio2" value="feefunction" checked >&nbsp;AUTO</label>
	&nbsp;&nbsp;&nbsp;
	<label><input type="radio" name="file" class="radio2" value="feefunction2">&nbsp;MANUAL</label>
	
	
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<input name="date" class="form-control datepicker" data-date-format="yyyy-mm-dd" value="<?php 
	if(isset($_SESSION['REC_DATE']) AND $_SESSION['REC_DATE']<> "" AND $_SESSION['REC_DATE']<> NULL)
	{ echo $_SESSION['REC_DATE']; }
	else { echo date('Y-m-d'); } ?>" style="width: 105px;" readonly  /> 
</form>

	</center>
  </div>
 <hr>
 
 <div id="message" style="padding:10px;">
 </div>
</div>
<footer class="footer">
  <div class="container">
	<div class="row">
		<div class="col-md-6">
			<p class="text-muted"><?php echo SCHOOLNAME; ?>&nbsp;&nbsp;|&nbsp;&nbsp; Session : <span class="label label-success"><?php echo $_SESSION['SESSION']; ?></span>
		</div>
		<div class="col-md-6">
			<p class="text-muted pull-right">User : <span class="label label-danger"><?php echo $_SESSION['SESS_NAME']; ?></span>&nbsp;&nbsp;|&nbsp;&nbsp; Load Time : <?php echo round(microtime(true) - $start,3); ?> Sec
		</div>
	</div>
  </div>
</footer>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="assets/js/session.min.js"></script>
<script src="assets/js/jquery.jstepper.min.js"></script>
<script src="assets/js/spin.min.js"></script>
<script src="assets/js/ladda.min.js"></script>
<script src="assets/js/bootstrap-datepicker.min.js"></script>
<script src="assets/js/custom.js"></script>
<script>
$.sessionTimeout({
    keepAliveUrl: 'function/session-alive',
	keepAliveInterval: 600000,
	keepAlive : true,
    logoutUrl: 'logout',
    redirUrl: 'logout'
});
$('.datepicker').datepicker({
    format: "yyyy-mm-dd",
	endDate: 'd',
	orientation: "bottom center"
});
function radio2() {
	if ($('.radio2').is(':checked')) {
		var value = $(this).val();
	}
	return value;
}

$('#getmonth').submit(function(event) {
	event.preventDefault();
	var selectedVal = "";
	var selected = $("input[type='radio'][name='file']:checked");
	if (selected.length > 0) {
		selectedVal = selected.val();
	}
	//alert(selectedVal);
	if(selectedVal == 'feefunction') {
		$.ajax({
			type: 'POST',
			url: 'function/feefunction?mode=auto',
			data: $(this).serialize(),
			success: function (data) {
					$('#message').html(data);
			}
		});
	} 
	if(selectedVal == 'feefunction2') {
		$.ajax({
			type: 'POST',
			url: 'function/feefunction?mode=manual',
			data: $(this).serialize(),
			success: function (data) {
					$('#message').html(data);
			}
		});
	} 
});
		

</script>
</body>
</html>