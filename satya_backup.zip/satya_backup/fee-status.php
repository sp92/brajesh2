<?php
$page='fee';
require('core.php');
error_reporting(0);
if($_SESSION['ACC_FEE']=='0') { header("Location: main"); }
#####==============================================================#####
$adm_no=clean($_REQUEST['adm_no']);
$adm_no = filter_var($adm_no, FILTER_SANITIZE_NUMBER_INT);
$adm_no = intval($adm_no);

// Old way to get record
//$db->where ('adm_no', $adm_no);
//$data_stu = $db->getOne ("student");
$db->where ('s.id', $adm_no);
$data_stud = $db->get("student s",null,'s.id');
if(count($data_stud)!=0){
	$id=$data_stud[0]['id'];
	$db->join("stu_sess_data sd", "s.id=sd.stu_id", "LEFT");
	$db->where ("s.is_shown", 'YES');
	$db->where ("s.tc_issue", 'YES', '<>');
	$db->where ('sd.session', $_SESSION["SESSION"]);
	$db->where ('s.id', $id);
	$data_stu = $db->getOne("student s");
}

if ($db->count > 0) {
	if($data_stu['custom_fee'] == 'YES') {
		$db->where ('session', $_SESSION['SESSION']);
		$db->where ('stu_id', $id);
		$fee_stu = $db->getOne ("stu_custom_fee");
	} else {
		$db->where ('session', $_SESSION['SESSION']);
		$db->where ('class', $data_stu['class']);
		$db->where ('new_old', $data_stu['new_old']);
		$db->where ('fee_cat', $data_stu['fee_cat']);
		$db->where ('type', $data_stu['type']);
		$fee_stu = $db->getOne ("fee_amount");	
	}
	if($data_stu['is_transport'] == 'YES') {
		$db->where ('session', $_SESSION['SESSION']);
		$db->where ('stu_id', $id);
		$tpt_stu = $db->getOne ("stu_tpt_fee");
		if ($db->count == 0) {
			unset($tpt_stu);
			$stop_id = $data_stu['stop_id'];
			if($data_stu['start_date']<>'0000-00-00') {
				$start_month = strtolower(date('M', strtotime($data_stu['start_date'])));
				$start_key = array_search($start_month, $m_array);
			}
			if($data_stu['end_date']<>'0000-00-00') {
				$end_month = strtolower(date('M', strtotime($data_stu['end_date'])));
				$end_key = array_search($end_month, $m_array);
			}
			$db->where ('session', $_SESSION['SESSION']);
			$db->where ("id", $stop_id);
			$stop_amount = $db->getOne ("stop_master", "amount");
			$tpt_fee = $stop_amount['amount'];
			
			$db->where ("id", 1);
			$tpt_months = $db->getOne ("tpt_months");
			if(isset($start_key)==TRUE AND isset($end_key)==FALSE ) {
				foreach($m_array as $key => $val) {
					$m2 = "tp_".$val;
					if($tpt_months[$m2]==1 AND $key >= $start_key) {
						$tpt_stu[$m2] = $tpt_fee;
					}
				}
			} elseif (isset($start_key)==TRUE AND isset($end_key)==TRUE ) {
				foreach($m_array as $key => $val) {
					$m2 = "tp_".$val;
					if($tpt_months[$m2]==1 AND $key >= $start_key AND $key <= $end_key) {
						$tpt_stu[$m2] = $tpt_fee;
					}
				}
			} else {
				$tpt_stu = array();
			}
			//print_r($tpt_stu);
			
		}
	}
	
	// Get head count from head_define table.

	$headCount = 0;
	$query = '';
	$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
	if(!empty($head_defineSession)){
		foreach($head_defineSession as $key=>$value){
			//echo $value['Field'];
			if (strpos($value['Field'], 'head') !== false) {
				$query =  $query.'sum('.$value['Field'].') as h'.($headCount+1).', ';
				$headCount++;
			}
		}
	}

include('header.php');	
	?>
	<?php  
				$curr_month = strtolower(date('M'));
				$main=getCurrentDue($id,$curr_month);
			?>
	<div class="container">
		
		<div class="row">
			<h3>Deposit Fee </h3>
			<div class="row">
				<div class="col-md-6">
					<h4> Student Information</h4>
							<form method="GET" id="target">
							<input type='text' name='adm_no' id='adm_noo' value='' placeholder="Adm No." autocomplete="off" style="text-align: center;width: 100px;" />
							<input type='text' name='termid' id='termid' value='' placeholder="Stu Name" autocomplete="off" style="text-align: center;width: 200px;" />
							</form><br>
						
					<table class="table table-bordered">
						<tbody>
							<tr>
								<td class="center" style="width: 119px;">Name: </td>
								<td><b><?php echo $data_stu['stu_name']; ?> [<?php echo $data_stu['adm_no']; ?>] <span style="font-size:14px;color:red;">[<?php echo $data_stu['type']; ?>]</span></b></td>
								<td rowspan="6" style="width: 25%;text-align:center;"><img src="" style="width: 130px;"></td>
							</tr>
							<tr>
								<td class="center">Father's Name:</td>
								<td><b><?php echo $data_stu['fat_name']; ?></b></td>
							</tr>
							<tr>
								<td class="center">Class:</td>
								<td><b><?php echo $data_stu['class']." - ".$data_stu['sec']; ?></b></td>
							</tr>
							<tr>
								<td class="center">Admission Type:</td>
								<td><b><?php echo $data_stu['new_old']; ?></b></td>
							</tr>
							<tr>
								<td class="center">Transport:</td>
								<td><b><?php echo $data_stu['is_transport']; ?> [<?php echo $main['stop_name'];?>][<?php echo $main['stop_amount'];?>]</b></td>
							</tr>
							<tr>
								<td class="center">Address:</td>
								<td><b><?php echo $data_stu['address']; ?></b></td>
							</tr>
						</tbody>
					</table>
					<center>
						<button class="btn btn-success ladda-button kill-evo" onclick="$.popupWindow('student-view?adm_no=<?php echo $adm_no; ?>&menu=OFF#fee');" data-style="zoom-out"><span class="ladda-label">Edit Fee Details</span></button>
						<?php  //if($data_stu['is_shown']=='YES' AND $data_stu['tc_issue']<>'YES')	{ ?>	
							<button class="btn btn-danger" onclick="fee_dep();">PAY FEE</button>
						<?php //} ?>
					</center><br>
				</div>
				<div class="col-md-6">
					<div role="tabpanel" style="margin-top:3px;">
						<ul class="nav nav-tabs livetabs" role="tablist">
							<li class="active"><a href="#fee-feed" aria-controls="fee-feed" role="tab" data-toggle="tab">School Fee Record</a></li>
						</ul>
						<div class="tab-content">
							<div role="tabpanel" class="tab-pane active" id="fee-feed">
								<table class="table table-hover previous-transac">
									<thead>
										<tr>
											<th class="center" style="width: 80px;"><center>Rec No.</center></th>
											<th class="center" style="width: 100px;"><center>Month</center></th>
											<th style="width:90px;"><center>Date</center></th>
											<th><center>Amount</center></th>
											<th><center>Late Fine</center></th>
											<th><center>Discount</center></th>
											
										</tr>
									</thead>
									<tbody>
									<?php
									$db->where ('session', $_SESSION['SESSION']);
									$db->where ('adm_no', $adm_no);
									$db->groupBy ("rec_no");
									$rec_data = $db->get ("fee_paid");	
									foreach($rec_data as $rec) { ?>
										<tr>
											<td align=center><?php echo $rec['rec_no']; ?></td>
											<td align=center><?php echo $rec['late_fine']; ?></td>
											<td align=center><?php echo date('d/m/Y', strtotime($rec['rec_date'])); ?></td>
											<td align=center>Rs. <?php 
											
											$db->where ("rec_no", $rec['rec_no']);
											$db->where ('session', $_SESSION['SESSION']);
											$db->where ('adm_no', $adm_no);
											$stats = $db->getOne ("fee_paid", "sum(amount) as tot"); 
											
											echo $stats['tot'];
											
											
											?></td>
											<td align=center><?php echo $rec['late_fine']; ?></td>
											<td align=center><?php echo $rec['discount']; ?></td>
										</tr>
									<?php }	?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row" style="border-top:2px solid;border-bottom:2px solid;">	
				<center>
					<h4 style="margin-top:5px;margin-bottom:5px;font-size:15px;">Category : <span style="color:red;"><?php echo $data_stu['fee_cat']; ?></span> || Total Amount Deposited : <span style="color:red;">Rs. 19000</span> || Total Discounted : <span style="color:red;">Rs. 0</span> || Late Fine : <span style="color:red;">Rs. 0</span> </h4>
				</center>
			</div>
			<div class="row">	
				<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							 <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								<h4 class="modal-title" id="myModalLabel">FEE STRUCTURE FOR : <?php echo $data_stu['stu_name']; ?></h4>
							</div>
							<div class="modal-body">
								<?php
								$db->where('session', $_SESSION['SESSION']);
								$head = $db->get ("head_define",1);
								if ($db->count > 0) {
									foreach ($head as $u) { 
										for ($i = 1; $i <= $headCount; $i++) { 
											$var = 'head'.$i;
											$heads[] = $u[$var];
										}
									}
								}
								$heads2 = array_filter($heads);
								$heads_count = count($heads2);		
								echo "<table class='table table-striped table-bordered'>
								<thead>
									<tr>
										<th>Fee Head</th>";
										foreach($mf_array as $m) {
											echo "<th>".substr($m,0,3)."</th>";
										}
									echo "</tr>
								</thead>
								<tbody>";
								$i=1;
								foreach ($heads2 as $h) {
									echo "<tr><th>".$h."</th>";
									foreach($m_array as $m) {
										$head_name = "head".$i."_".$m;
										echo "<td>".$fee_stu[$head_name]."</td>";
									}
									echo "</tr>";
									$i++;
								}
								echo "</tbody></table>";?>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							</div>
						</div>
					</div>
				</div>
				<!-------------------------------cash discount---------------------------------------->
				<div class="modal fade bs-example-modal-lg-discount" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							 <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								<h4 class="modal-title" id="myModalLabel">Discount for : <?php echo $data_stu['stu_name']; ?></h4>
							</div>
							
							<div class="modal-body">
							<div class=row>
							 <form id="AddDiscountForm">
					             <div class="col-md-4">
								
								<h4>Request Cash Discount</h4>
								    <input type="hidden" name="p_by" value="<?php echo $_SESSION['SESS_NAME']; ?>">
									<input type="hidden" name="stu_id" value="<?php echo $_REQUEST['adm_no'];  ?>">
								    <input type="text" class="form-control" name="p_amount" id="p_amount" placeholder="Enter amount">
								 <br>
							
								    <textarea  cols="24" rows="4" class="form-control" name="remark_here" placeholder="Enter Remarks Here"></textarea>
									<br>
									 <button type="submit" class="btn btn-info" id="discountapply">Apply Discount</button>
								 </div>
								
								 </form>
								 <div class="col-md-8">
								<h4>Pending/Approved Cash Discount</h4>
								 <table class="table table-bordered ">
								   <tr>
								    <th>S.No.</th><th>Proposed Amount</th><th>Approved Amount</th><th>Proposed Date</th><th>Approved Date</th><th>Status</th>
									 </tr>
									 
									 <?php 
									 if($main['cashDiscount']){
									 $y=0;foreach($main['cashDiscount'] as $cash){$y++;?>
									 <tr class="<?php echo ($cash['approved']) ? 'success' : 'info';?>">
									 <td><?php echo $y;?></td><td>Rs. <?php echo $cash['p_amount'];?></td><td>Rs. <?php echo $cash['approved_amount'];?></td><td><?php
                                       echo   getdmYFormat($cash['p_date']);
                                     ?></td><td><?php
                                      echo   getdmYFormat($cash['approved_date']);?></td><td><?php echo ($cash['approved']) ? 'Approved' : 'Pending';?></td>
									 </tr>
									 <?php }}else{
										 echo "<tr><td colspan='6' align='center'>No Discount assign</td></tr>";
									 }?>
								 </table>
								 </div>
							
								 </div>
							</div>
							
							<div class="modal-footer">
								
							</div>
							
							
						</div>
						
					</div>
				</div>
				<!-------------------------------cash discount---------------------------------------->
				
				<div class="col-md-2">
				   <h4>Cash Discounts</h4>
				   <button type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".bs-example-modal-lg-discount">Apply Discount</button>
					<h4>Discounts</h4>
					<?php 
					$db->where("session",$_SESSION["SESSION"]);
					$discArr = $db->get("discount");
					?>
					<form id="addDiscount">
						<input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
						<input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>">
						<input type="hidden" name="adm_no" value="<?php echo $_REQUEST['adm_no'];  ?>">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th colspan=2>Disc Name :</th>
								</tr>
								</thead>
							<tbody>
								<?php
								if(!empty($discArr)){ 
									// Old way to get record
									//$colls = array("disc_id");
									//$db->where("adm_no",$_REQUEST["adm_no"]);
									//$stdd = $db->get("student",null,$colls);
									
									$colls = array("disc_id");
									$db->where("adm_no",$_REQUEST["adm_no"]);
									$db->where("session",$_SESSION["SESSION"]);
									$stdd = $db->get("stu_sess_data",null,$colls);
									if($stdd[0]['disc_id']){
										$discArr1 = explode(",", $stdd[0]['disc_id']);
									}
									$i = 0;
									foreach($discArr as $d){ ?>
										<?php
										if (in_array($d["id"], $discArr1) !== false && !empty($discArr1)) {
											$syle = 'background-color:#ffff7f;';
										}
										else{
											$syle = "";
										}
										?>
										<tr style="<?php echo $syle;?>">
											<?php if(in_array($d["id"], $discArr1) !== false && !empty($discArr1)){?>
												<td>Used</td><?php } 
											else{?>
												<td>
													<input type="radio" name="allotdisc[]" value="<?php echo $d['id']; ?>"/>
											</td>
											<?php } ?>
											<td><?php echo $d['disc_name']; ?></td>
										</tr>
									<?php
									$i++;
									}
								}?>
							
								<tr>
									<td colspan=2 align=center><button type="submit" value="Apply" name="Apply" class="btn btn-xs btn-success">Apply Discount</button></td>
								</tr>
							</tbody>
						</table>
					</form>
				</div>
			
				<div class="col-md-10" style="border-left: 1px solid #ccc;">
				<br/>
				<div class="col-md-2 col-xs-12">
					<h4 class="text-danger">Current Dues : </h4>
				</div>
				<div class="col-md-10 col-xs-12">
			
			<table class="table table-bordered ">
			<thead>
							<tr>
								<th width=200>School Fee</th>
								<?php 
								$head=getHeadingOfFine($id);
								foreach($head as $key => $val){
									foreach($val as $key2 => $val2) {
										echo "<th width=200>".$key2."</th>"; 
									}
								}
								?>
								<th width=200>Late Fine</th>
								<th width=200>Transport Fees</th>
								<th width=200>Total</th>
							</tr>
						</thead>
			
			<tr align="center" >
			<td ><?php echo $main['curr_total'];?></td>
			<?php foreach($head as $key => $val){ 
				foreach($val as $key2 => $val2) { ?>
			<td><?php echo $val2;?></td>
			<?php } } ?>
			<td><?php if($main['late_total']){echo $main['late_total'];}else{echo "0";}?></td>
			<td><?php if($main['transport_fees']){echo $main['transport_fees'];}else{echo "0";}?></td>
			<td class="text-danger"><b>Rs. <?php echo $main['full_total'];?></td>
			</tr>
			</table>
			<?php
			
			?>
			
			</div>
			<div class="clearfix"></div>
			<hr>
					<h4>Fee Chart <button type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".bs-example-modal-lg">Fee Structure</button></h4>
					<form id="recal-fee">
						<input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
						<input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>">
						<input type="hidden" name="adm_no" value="<?php echo $_REQUEST['adm_no'];  ?>">
						<button type="submit" value="Recalculate" name="Recalculate" class="btn btn-primary btn-xs pull-right" style="    margin-top: -27px !important;">Recalculate Fee</button>
					</form>
					<table class="table table-bordered table-primary table-condensed">
						<thead>
							<tr>
								<th class="center">Month</th>
								<?php
									foreach($mf_array as $m) { echo "<th>".substr($m,0,3)."</th>"; }
								?>
								<th>Total</th>
							</tr>
						</thead>
						<tbody style="text-align: center;">
							<tr>
								<td class="center" style="font-weight: bolder;background-color: antiquewhite;">Total Fee</td>
								<?php
									foreach($m_array as $m) { 
										for($i=1; $i<=$headCount; $i++) {
											$month = "head".$i."_".$m;
											$t_fee[] = $fee_stu[$month];
										}
										echo "<td>".array_sum($t_fee)."</td>"; 
										$total_fee[] = array_sum($t_fee);
										unset($t_fee);
									}
								?>
								<td style="background-color: greenyellow;font-weight: bold;"><?php echo array_sum($total_fee); ?></td>
							</tr>
											<tr>
							<td class="center" style="font-weight: bolder;background-color: antiquewhite;">Bus Fee</td>
							<?php  //echo $m_array[$main['start_month']-3];
							$count_x=0;
									foreach($m_array as $m) { 
										$month = "tp_".$m;
										$t_fee = $tpt_stu[$month];
										echo "<td>".$t_fee."</td>"; 
										$total_tp[] = $t_fee;
										unset($t_fee);
									}
								?>
							<td style="background-color: greenyellow;font-weight: bold;"><?php echo array_sum($total_tp); ?></td>
							</tr>
								<tr>
								<td class="center" style="font-weight: bolder;background-color: antiquewhite;">Paid Fee</td>
								<?php
								$paid_fee = array();
								
								$query = $query." sum(transport) as tp";
								foreach($mf_array as $m) {
									$tota = 0;
									$db->where ('session', $_SESSION['SESSION']);
									$db->where ('adm_no', $adm_no);
									$db->where ('cancelled', '0');
									$db->where ('month', $m);
									$fee_paid = $db->getOne ("fee_paid", $query);
									for($i=0;$i<=$headCount;$i++){
										$tota = $tota+$fee_paid['h'.($i+1)];
									}
									$tota = $tota+$fee_paid['tp'];
									//$tot = $fee_paid['h1']+$fee_paid['h2']+$fee_paid['h3']+$fee_paid['h4']+$fee_paid['h5']+$fee_paid['h6']+$fee_paid['h7']+$fee_paid['h8']+$fee_paid['h9']+$fee_paid['h10']+$fee_paid['h11']+$fee_paid['h12']+$fee_paid['h13']+$fee_paid['h14']+$fee_paid['h15']+$fee_paid['tp'];
									echo "<td>".$tota."</td>";
									$paid_fee[] = $tota;
								}
								
								?>
								<td style="background-color: gold;font-weight: bold;"><?php echo array_sum($paid_fee); ?></td>
							</tr>
							<tr>
								<td class="center" style="font-weight: bolder;background-color: antiquewhite;">Balance</td>
								<?php
								$count_xx=0;
								foreach($mf_array as $m) { 
									$tota = 0;
									$db->where ('session', $_SESSION['SESSION']);
									$db->where ('adm_no', $adm_no);
									$db->where ('cancelled', '0');
									$db->where ('month', $m);
									$fee_paid = $db->getOne ("fee_paid", $query);
									for($i=0;$i<=$headCount;$i++){
										$tota = $tota+$fee_paid['h'.($i+1)];
									}
									$tota = $tota+$fee_paid['tp'];
									
									$ms = strtolower(substr($m,0,3));
									//$paid_fee[] = $tota;
									for($i=1; $i<=$headCount; $i++) {
										$month = "head".$i."_".$ms;
										$t_fee[] = $fee_stu[$month];
									}
									$p = array_sum($t_fee);
									
									$month = "tp_".strtolower(substr($m,0,3));
									
									$balance = $p - $tota + $tpt_stu[$month];
									if($balance == 0){
										$style = 'style="color:green;font-weight:bold;"';
										$balance = 'Paid';
									}
									else{
										$style = 'style="color:red;font-weight:bold;"';
									}
									echo "<td><span ".$style.">".$balance;"</span></td>"; 
									//$total_fee[] = array_sum($t_fee);
									unset($t_fee);
									
									
								}
								?>
								<td style="background-color: violet;font-weight: bold;">
									<?php
										$to_fees = array_sum($total_fee)+array_sum($total_tp);
										$to_paid_fees = array_sum($paid_fee);
										echo $to_fees-$to_paid_fees;
									?>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div> <!-- /container -->
	<script>
	   $("#AddDiscountForm").submit(function(e){
		   e.preventDefault();
		   $.ajax({
					type: 'POST',
					url: './function/feeamountfunctions?query=AddDiscountForm',
					data: $(this).serialize(),
					success: function (data) {
						alert("Request has been sent  to Admin");
					}
				});
		   return false;
	   });
	</script>
	<script>
		var payfee;
		$(document).keypress(function(e){
			if(e.which == 115) {
			   payfee = $.popupWindow('fee-pay?adm_no=<?php echo $adm_no; ?>');
			} 
		 })
		 
		function fee_dep() {
			   payfee = $.popupWindow('fee-pay?adm_no=<?php echo $adm_no; ?>');
		}

		$(document).keypress(function(e){
			if(e.which == 102) {
			   adm_no = prompt('Please enter Admission No.','<?php echo $adm_no; ?>');
			   if(adm_no !='' && adm_no != null )
			   {
			   window.location = "fee-status/"+adm_no;
			   }
			} 
		 });
	</script>
	<script>
		$('#addDiscount').submit(function(event) {
			event.preventDefault();
				$.ajax({
					type: 'POST',
					url: './function/feeamountfunctions?query=AddDiscount',
					data: $(this).serialize(),
					success: function (data) {
						//console.log(data);
						$.notify({message: '<strong>Successfully</strong> updated the information.' },{type: 'success'});
						location.reload();
					}
				});
		});
		$('#recal-fee').submit(function(event) {
			event.preventDefault();
				$.ajax({
					type: 'POST',
					url: './function/feeamountfunctions?query=recal-fee',
					data: $(this).serialize(),
					success: function (data) {
						console.log(data);
						$.notify({message: '<strong>Successfully</strong> updated the information.' },{type: 'success'});
						//location.reload();
					}
				});
		});
	</script>
	<?php
} else{
	include('header.php');	
	?>
	
	<div class="container">
		<div class="row" align='center'>
		<h2 style="margin:15% 0% 0% 0%">No Data Found !!!</h2>
		<form method="GET" id="target">
							<input type='text' name='adm_no' id='adm_noo' value='' placeholder="Adm No." autocomplete="off" style="text-align: center;width: 100px;" />
							<input type='text' name='termid' id='termid' value='' placeholder="Stu Name" autocomplete="off" style="text-align: center;width: 200px;" />
							</form><br>
		        
		</div>
		</div>
		
	<?php
	
}

include('footer.php');
?>
	<script>
$('input#adm_noo').keypress(function(e) {
	if (e.which == '13') {
		e.preventDefault();
	   uurl=window.location.href;
	   url=uurl.split("/");
	   max=url[url.length-1].length;
	   str=uurl.substring(0, uurl.length-max);
	   window.location.href=str+this.value;
	}
});
$("#termid").focus(function() {
    $(document).off('keypress');
});
function formSubmit(){
	   uurl=window.location.href;
	   url=uurl.split("/");
	   max=url[url.length-1].length;
	   str=uurl.substring(0, uurl.length-max);
	   strg=$("#termid").val().split("-");
	   window.location.href=str+strg[0];
}

$(function() {
	$("#termid").autocomplete({
		source: "function/frontdeskfunctions?stu_details",
		minLength: 2,
		select: function(event, ui) {
			$('#termid').val(ui.item.value);
			formSubmit();
			
		},
		change: function (event, ui) {
			if (ui.item == null || ui.item == undefined) {
				$("#termid").val("");
				$("#termid").attr("disabled", false);
				
			} 
		}	
	});
});
</script>