<?php
$page='system';
require('core.php');
if($_SESSION['ACC_GROUP']<>'root') 
{
	header("Location: main.php");
}

if(@$_REQUEST['hdnCmd']=="ADD"){ 
$done=addDataWithExtraCharge($_REQUEST);
if($done==true){
	header("Location: ./system-dynamic-extra-heads");
}
}
if(@$_REQUEST['action']=="del"){
	$del=deleteExtraCharge($_REQUEST);
	if($del==true){
	header("Location: ./system-dynamic-extra-heads");
     }
	}
if(isset($_REQUEST['editForm'])){
     $update=updateExtraCharge($_REQUEST);
	 if($update==true){
	header("Location: ./system-dynamic-extra-heads");
     }
}

include('header.php');
?>
<div class="container">

<div class="row">
<h3>Dynamic Extra Charges Heads</h3>

<form class="form-inline" role="form" action="system-dynamic-extra-heads" method="post">
<input type="hidden" name="hdnCmd" value="ADD" autocomplete="off">

    <div class="form-group">
    <label for="exampleInputEmail2">Head  Label : </label>
	<input type="text" name="f_label" required="" autocomplete="off">
  </div>
    <div class="form-group">
    <label for="exampleInputEmail2">Amount : </label>
	<input type="text" name="amount" required="" autocomplete="off">
  </div>


  <button type="submit" class="btn btn-default btn-xs">Create Field</button>
</form>
<p class="text-danger"></p>
<center>
<?php 
if(@$_REQUEST['action']=="edit"){
	$editV=editExtraCharges($_REQUEST);
	
?>
<form action="system-dynamic-extra-heads" method="post" id="editValue">
<table class="table table-striped table-hover table-bordered">
		<thead>
		<tr>
		<th style="width:20px;">SR</th>
		<th >Label Name</th>
		<th >Amount</th>
		<th >Action</th>

		</tr>
		</thead>
<tbody>
<tr>
<td><input type="hidden" name="id" value="<?php echo $editV[0]['id'];?>"></td>
<td><input type="text" name="head_name" value="<?php echo $editV[0]['head_name'];?>" placeholder="Change label here"></td>
<td><input type="text" name="amount" value="<?php echo $editV[0]['amount'];?>" placeholder="Change amount here"></td>
<td><input type="submit" name="editForm" value="Update"></td>
</tr>
</table>
</form>
<?php } ?>
</center>
<hr>


<table class="table table-striped table-hover table-bordered">
		<thead>
		<tr>
		<th style="width:20px;">SR</th>
		<th >Label Name</th>
		<th >Amount</th>
		<th >Action</th>

		</tr>
		</thead>
<tbody>
<?php 
 $data=getExtaChargesData();
 $num=0;
 foreach($data as $val){$num++;
 
?>
		<tr>
			<td align=center><?php echo $num;?></td>
			<td align=center><?php echo $val['head_name'];?></td>
			<td align=center><?php echo $val['amount'];?></td>


			<td align=center>
             <?php if(($val['id']!=1) && ($val['id']!=2)){?>
			<a href="system-dynamic-extra-heads?action=del&id=<?php echo $val['id'];?>&field=<?php echo $val['ehead_id'];?>" onClick="return confirm('Are you want to sure Delete Information');"  role="button"> Delete</a>
			<?php }?>
			<a href="system-dynamic-extra-heads?action=edit&id=<?php echo $val['id'];?>" class="" role="button"><span class="glyphicon"></span> Edit</a>
			</td>
		</tr>
 <?php } ?>
</table>
</div>
</div>
<script>

</script>
<?php
include('footer.php');
?>