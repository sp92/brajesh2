<?php
$page='student';
require('core.php');
if($_SESSION['ACC_STUDENT']=='0') {
	header("Location: main.php");
}
// Old way to get record
$db->where('adm_no',$_REQUEST['adm_no']);
$db->where("session",$_SESSION["SESSION"]);
$student = $db->getOne('student');

//$db->join("seswise_class sc", "s.adm_no = sc.adm_no", "LEFT");
//$db->where ('s.adm_no', $_REQUEST['adm_no']);
//$db->where ('sc.session', $_SESSION["SESSION"]);
//$student = $db->getOne("student s");

$db->where("adm_no", $_REQUEST['adm_no']);
$db->where("session", $_SESSION["SESSION"]);
$customFee = $db->getOne('stu_custom_fee');
include('header.php');
?>
<div class="container">
	<?php //print_menu($student_menu_items); ?><br />
	<div class="row">
		<table class="table table-condensed table-striped" style="margin-bottom: 0;font-size: 15px;border-bottom:1px solid grey;">
			<tbody>
				<tr>
					<td>Adm. No. : <b><u><?php echo $student['adm_no']; ?></u></b> // Name :<b> <u><?php echo $student['stu_name']; ?></u></b> // Class : <b><u><?php echo $student['class'].'-'.$student['sec']; ?></u></b></td>
					<td><div id="message" style="width: 270px;float: right;font-size: 11px;"></div></td>
				</tr>
			</tbody>
		</table><br />
		
		<ul class="nav nav-tabs">
			<?php if($_SESSION['ACC_STUDENT']=='1') { ?><li class="active"><a href="student-view?adm_no=<?php echo $_REQUEST['adm_no']; ?>#home" data-toggle="tab">Basic Details</a></li><?php } ?>
			<?php if($_SESSION['ACC_FEE']=='1') { ?><li><a href="student-view?adm_no=<?php echo $_REQUEST['adm_no']; ?>#fee" data-toggle="tab">Fee Details</a></li><?php } ?>
			<?php if($_SESSION['ACC_TRANSPORT']=='1') { ?><li><a href="student-view?adm_no=<?php echo $_REQUEST['adm_no']; ?>#transport" data-toggle="tab">Tranport Details</a></li><?php } ?>
			<?php if($_SESSION['ACC_CERTIFICATE']=='1') { ?><li><a href="student-view?adm_no=<?php echo $_REQUEST['adm_no']; ?>#certificate" data-toggle="tab">Certificate Details</a></li><?php } ?>
			<?php if($_SESSION['ACC_STUDENT']=='1') { ?><li><a href="student-view?adm_no=<?php echo $_REQUEST['adm_no']; ?>#photo" data-toggle="tab">Photos</a></li><?php } ?>
		</ul>
		<script>
			$(function(){
				var hash = window.location.hash;
				hash && $('ul.nav a[href="' + hash + '"]').tab('show');
				$('.applybtn').hide();
				
				$('.nav-tabs a').click(function (e) {
					if(this.hash == '#fee'){
						$('.applybtn').show();
					}
					else{
						$('.applybtn').hide();
					}
					$(this).tab('show');
					var scrollmem = $('body').scrollTop();
					window.location.hash = this.hash;
					$('html,body').scrollTop(scrollmem);
				});
				
				$('.applybtn').click(function (e) {
					document.getElementById('finalmesg1').style.display = 'block';
					document.getElementById('applybtn').style.display = 'none';
					var inputs=document.getElementsByClassName('feeData');
					for(i=0;i<inputs.length;i++){
						inputs[i].disabled=false;
					}  
				});
				
				var inputs=document.getElementsByClassName('feeData');
				for(i=0;i<inputs.length;i++){
					inputs[i].disabled=true;
				}
				var inputs=document.getElementsByClassName('DisInput');
				for(i=0;i<inputs.length;i++){
					inputs[i].disabled=true;
				}  
			});
		</script>
		<div class="well">
			<div class="tab-content">
				<div Class="tab-pane active" id="home">
					<form id="student-basic-form">
						<input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
						<input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>">
						<input type="hidden" name="new_old" value="NEW">
						<table class="table table-condensed table-striped">
							<tr>
								<td  align="right">Adm. No. : </td>
								<td><input type="text" name="adm_no" value="<?php echo $_REQUEST['adm_no']; ?>" id="adm_no"  style="width: 45px;" readonly />
								</td>
								<td align="right">Class :</td>
								<td>
									<select name="class" id="class" required >
										<option value="">--</option>
										<?php
										$user = $db->get ("class_master");
										if ($db->count > 0) {
											foreach ($user as $u) { 
										?>			
										<option <?php if($u['class'] == $student['class']){ echo 'selected'; } ?> value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
										<?php } } ?>	
									</select>&nbsp;&nbsp;&nbsp;
									Section : 
									<select name="sec" id="sec" required >
										<option value="">--</option>
										<?php
										$user = $db->get ("sec_master");
										if ($db->count > 0) {
											foreach ($user as $u) { 
										?>			
										<option <?php if($u['sec'] == $student['sec']){ echo 'selected'; } ?> value='<?php echo $u['sec']; ?>'><?php echo $u['sec']; ?></option>
										<?php } } ?>
									</select>    
								</td>
								<td align="right">Form No. :</td>
								<td>
									<input type="text" name="form_no" value="<?php echo $student['form_no']; ?>"  style="width: 100px;" />&nbsp;&nbsp;&nbsp;Adm Class :
									<span><b> <?php echo $student['adm_class']; ?> </b></span>
								</td>
							</tr>
							<tr>
								<td colspan=6><strong>STUDENT PROFILE:</strong></td>
							</tr>
							<tr>
								<td align="right">Stu. Name : </td>
								<td><input type="text" name="stu_name" id="stu_name" value="<?php echo $student['stu_name']; ?>" style="width: 100%;" required  /></td>
								<td align="right">Gender : 	</td>
								<td>
									<select name="gender"   style="width: 100%;">
										<option value="">--</option>
										<option <?php if($student['gender'] == 'M'){ echo 'selected'; }?> value="M">MALE</option>
										<option <?php if($student['gender'] == 'F'){ echo 'selected'; }?> value="F">FEMALE</option>
									</select>
								</td>
								<td align="right">Date of Birth :</td>
								<td>
									<input type="text" name="dob" id="dob" value="<?php echo date("d/m/Y", strtotime($student['dob']) );?>" class="datepicker" data-date-format="dd/mm/yyyy" style="width: 100px;" readonly />
									<span id="age" style="font-weight:bold;color:red;" ></span>
									<script>
										$( "#dob" ).change(function( event ) {
											$( "#age" ).html('Calculating');
											var date = $(this).val();
											event.preventDefault();
											$.ajax({
												type: 'POST',
												url: 'function/calc-age?dob='+date,
												success: function (data) {
													$('#age').html(data);
												}
											});
										});
									</script>
								</td>
							</tr>
							<tr>
								<td align="right">Stu. Name (Hindi):</td>
								<td>
									<input type="text" name="stu_name_hindi" value="<?php echo $student['stu_name_hindi']; ?>"  id="stu_name_hindi"  style="width: 80%;" />
									<a onclick="windowpop('html/hindi.htm', +screen.width, +screen.height)" class="btn-succes" style="cursor:pointer;">&nbsp;???</a>
								</td>
								<td align="right">House : </td>
								<td>
									<select name="house"   style="width: 100%;">
										<option value=""> --</option>
									</select>
								</td>
								<td align="right"> Stream :  </td>
								<td>
									<select name="stream"   style="width: 100%;">
										<option value=""> --</option>
										<?php
										$user = $db->get ("stream");
										if ($db->count > 0) {
											foreach ($user as $u) { 
										?>			
										<option <?php if($u['stream'] == $student['stream']){ echo 'selected'; } ?> value='<?php echo $u['stream']; ?>'><?php echo $u['stream']; ?></option>
										<?php } } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td align="right"> Physically Challenged : </td>
								<td> <input type="text" name="phy_chal" id="phy_chal" value="<?php echo $student['phy_chal']; ?>"  style="width: 100%;" /></td>
								<td align="right"> Blood Group : </td>
								<td>
									<select name="bg">
										<option value=""> -- Group --</option>
										<option <?php if($student['bg'] == 'A+'){ echo 'selected'; }?> value="A+">  A+</option>
										<option <?php if($student['bg'] == 'A-'){ echo 'selected'; }?> value="A-"> A- </option>
										<option <?php if($student['bg'] == 'B+'){ echo 'selected'; }?> value="B+"> B+</option>
										<option <?php if($student['bg'] == 'B-'){ echo 'selected'; }?> value="B-"> B- </option>
										<option <?php if($student['bg'] == 'AB+'){ echo 'selected'; }?> value="AB+">AB+</option>
										<option <?php if($student['bg'] == 'AB-'){ echo 'selected'; }?>value="AB-"> AB- </option>
										<option <?php if($student['bg'] == 'O+'){ echo 'selected'; }?>value="O+">  O+ </option>
										<option <?php if($student['bg'] == 'O-'){ echo 'selected'; }?> value="O-">  O-</option>
									</select>
								</td>
								<td align="right"> Mother Tongue :</td>
								<td>
									<input type="text" name="lang" value="<?php echo $student['lang']; ?>"  style="width: 100px;"  />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								  <input type="checkbox" <?php if($student['only_child'] == 'YES'){ echo 'checked'; }?> name='only_child' value="YES">&nbsp;Only Child
								</td>
							</tr>  
							<tr>
								<td colspan=6><strong>FAMILY PROFILE:</strong></td>
							</tr>
							<tr>
								<td align="right">Father Name :</td>
								<td><input type="text" name="fat_name" id="fat_name"  value="<?php echo $student['fat_name']; ?>" style="width: 100%;" /></td>
								<td align="right">Mother Name :</td>
								<td><input type="text" name="mot_name" id="mot_name"  value="<?php echo $student['mot_name']; ?>" style="width: 100%;" /></td>
								<td align="right">Admission Date : 	</td>
								<td><input type="text" name="do_adm" class="datepicker" value="<?php echo date("d/m/Y", strtotime($student['do_adm']) );?>"  style="width: 100px;" readonly /></td>
							</tr>
							<tr>
								<td align="right">Father Occupation :</td>
								<td><input type="text" name="fat_occ" id="fat_occ" value="<?php echo $student['fat_occ']; ?>" style="width: 100%;" /></td>
								<td align="right">Mother Occupation :</td>
								<td><input type="text" name="mot_occ" id="mot_occ" value="<?php echo $student['mot_occ']; ?>" style="width: 100%;"  /></td>
								<td align="right">Religion :</td>
								<td>
									<select name="religion" id="religion"  style="width: 100%;">
										<option value="">  --</option>
										<option <?php if($student['religion'] == 'HINDU'){ echo 'selected'; }?> value="HINDU">HINDU</option>
										<option <?php if($student['religion'] == 'MUSLIM'){ echo 'selected'; }?> value="MUSLIM">MUSLIM</option>
										<option <?php if($student['religion'] == 'SIKH'){ echo 'selected'; }?> value="SIKH">SIKH</option>
										<option <?php if($student['religion'] == 'CHRISTIAN'){ echo 'selected'; }?> value="CHRISTIAN">CHRISTIAN</option>
									 </select>
								</td>
							</tr>
							<tr>
								<td align="right">Father Qualification :</td>
								<td><input type="text" name="fat_qual" value="<?php echo $student['fat_qual']; ?>" id="fat_qual" style="width: 100%;" /></td>
								<td align="right">Mother Qualification : </td>
								<td><input type="text" name="mot_qual" value="<?php echo $student['mot_qual']; ?>" id="mot_qual" style="width: 100%;"  /></td>
								<td align="right">Category :</td>
								<td>
									<select name="category"  id="category" style="width: 100%;" >
										<option value="">--</option>
										<option <?php if($student['category'] == 'GENERAL'){ echo 'selected'; }?> value="GENERAL">GENERAL</option>
										<option <?php if($student['category'] == 'OBC'){ echo 'selected'; }?> value="OBC">OBC</option>
										<option <?php if($student['category'] == 'SC'){ echo 'selected'; }?> value="SC">SC</option>
										<option <?php if($student['category'] == 'ST'){ echo 'selected'; }?> value="ST">ST</option>
										<option <?php if($student['category'] == 'OTHERS'){ echo 'selected'; }?> value="OTHERS"> OTHERS</option>
									</select>
								</td>
							</tr>
							<tr>
								<td colspan=6> <strong>FINANCIAL PROFILE: </strong></td>
							</tr>
							<tr>
								<td align="right">Father's Income :</td>
								<td><input type="text" name="fat_income" id="fat_income" value="<?php echo $student['fat_income']; ?>" style="width: 100%;" /></td>
								<td align="right">Mother's Income  : </td>
								<td><input type="text" name="mot_income" id="mot_income" value="<?php echo $student['mot_income']; ?>" style="width: 100%;" /></td>
								<td align="right">Caste Cert. No. : </td>
								<td>
									<input type="text" name="cast_cert_no"  id="cast_cert_no" value="<?php echo $student['cast_cert_no']; ?>" style="width: 100px;" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Issue Date :
									<input type="text" name="cast_cert_issue" class="datepicker" data-date-format="dd/mm/yyyy"  style="width: 100px;" readonly />
								</td>
							</tr>
							<tr>
								<td align="right">PAN Card No. :</td>
								<td>
									<input type="text" name="pan" id="pan" value="<?php echo $student['pan']; ?>" style="width: 100%;" />
									<td align="right">UID / Aadhar No. : </td>
									<td><input type="text" name="aadhar" id="aadhar"  value="<?php echo $student['aadhar']; ?>" style="width: 100%;" /></td>
									<td align="right">Ward No. : </td>
									<td>
										<input type="text" name="ward_no" id="ward_no"  value="<?php echo $student['ward_no']; ?>"style="width: 100px;" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSSM ID :
										<input type="text" name="sssn" value="<?php echo $student['sssn']; ?>"  style="width: 100px;" />
									</td>
								</td>
							</tr>
							<tr>
								<td colspan=6><strong>GUARDIAN PROFILE:</strong></td>
							</tr>
							<tr>
								<td align="right">  Guardian Name :  </td>
								<td> <input type="text" name="guard_name" id="guard_name" value="<?php echo $student['guard_name']; ?>"   style="width: 100%;" /> </td>
								<td align="right">Guardian Mob. No. : </td>
								<td><input type="text" name="guard_no" id="guard_no" value="<?php echo $student['guard_no']; ?>"  style="width: 100%;" /></td>
								<td align="right">Guardian Relation : 	</td>
								<td><input type="text" name="guard_relation" value="<?php echo $student['guard_relation']; ?>"  id="guard_relation" style="width: 100%;" /></td>
							</tr>
							<tr>
								<td colspan=6><strong>PERMANENT ADDRESS:</strong></td>
							</tr>
							<tr>
								<td align="right">Address : </td>
								<td colspan="3"><input type="text" name="address" id="address" value="<?php echo $student['address']; ?>"  style="width:100%;" /></td>
								<td align="right">Mobile No. : 	</td>
								<td>
									<input type="text" name="mobile" id="mobile" value="<?php echo $student['mobile']; ?>" class="numonly bg-success" maxlength="10" placeholder="SMS No." style="width: 100px;"   />&nbsp;&nbsp;&nbsp;
									<input type="text" class="numonly bg-success" placeholder="Alt SMS No." value="<?php echo $student['alt_sms']; ?>" maxlength="10" id="alt_sms" name="alt_sms" style="width: 100px;" />
								</td>
							</tr>
							<tr>
								<td colspan=6><strong>CORRESPONDANCE ADDRESS:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									<input type="checkbox" id="same_address">Same As Above</td>
							</tr>
							<tr>
								<td align="right">Address : </td>
								<td colspan="3"><input type="text" value="<?php echo $student['address_co']; ?>" name="address_co" id="address_co" style="width:100%;" /></td>
								<td align="right">Mobile No. : 	</td>
								<td>
									<input type="text" name="mobile_co" id="mobile_co" value="<?php echo $student['mobile_co']; ?>" onkeyup="this.value=this.value.replace(/[^\d]/,'')"  style="width: 100px;" />&nbsp;&nbsp;&nbsp;
									<input type="text" id="mobile2_co" name="mobile2_co" value="<?php echo $student['mobile2_co']; ?>" style="width: 100px;"  onkeyup="this.value=this.value.replace(/[^\d]/,'')" />
								</td>
							</tr>
						</table>
						<div class="row">
							<div class="col-md-12">
								<table class="table table-striped" style="color: black;">
									<tr>
										<td colspan="6"><strong>PREVIOUS SCHOOLING: </strong></td>
									</tr>
									<tr style="font-size: 15px;font-weight:bold;">
										<td style="width: 15px;"><center></center></td>
										<td style="width: 200px;"><center>School Name</center></td>
										<td style="width: 50px;"><center> Class</center> </td>
										<td style="width: 50px;"><center> Session</center></td>
										<td style="width: 50px;" ><center> Curriculum </center> </td>
									</tr>
									<tr>
										<td></td>
										<td><input type="text" value="<?php echo $student['school_name']; ?>" name="school_name" id="school1_name" style="width: 95%;" /></td>
										<td>
											<select name="school_class">
												<?php
												$user = $db->get ("class_master");
												if ($db->count > 0) {
													foreach ($user as $u) { 
												?>			
												<option <?php if($u['class'] == $student['school_class']){ echo 'selected'; } ?> value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
												<?php } } ?>	
											</select>
										</td>
										<td><input type="text" name="school_session" value="<?php echo $student['school_session']; ?>" id="school1_session" style="width: 95%;" /></td>
										<td>
											<center>
												<select name="school_curri">
													<option value="">--</option>
													<option <?php if($student['school_curri'] == 'CBSE'){ echo 'selected'; }?> value="CBSE"> CBSE BOARD</option>
													<option <?php if($student['school_curri'] == 'ICSE/ISC'){ echo 'selected'; }?> value="ICSE/ISC"> ICSE/ISC BOARD</option>
													<option <?php if($student['school_curri'] == 'STATE BOARD'){ echo 'selected'; }?> value="STATE BOARD">STATE BOARD</option>
													<option <?php if($student['school_curri'] == 'OTHERS'){ echo 'selected'; }?> value="OTHERS">OTHERS</option>
												</select>
											</center>
										</td>
									</tr>	
								</table>
							</div>
						</div>
						<table class="table">
							<tr>
								<td align="center" id="finalmesg">
									<button class="btn btn-primary ladda-button kill-evo" type='submit' data-style="zoom-out"><span class="ladda-label">Update Student</span></button>&nbsp;
								</td>
							</tr>
						</table>
					</form>
				</div>
				<div class="tab-pane " id="fee">
					<form id="student-fee-form">
						<?php 
						if($student['custom_fee'] == 'NO' && empty($customFee)){?>
							<button type="submit" class="btn-success applybtn" id="applybtn" style="float: right; display:block;" >Custom Fee</button>
						<?php } ?>
						<?php
						$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'fee_amount');
						if(!empty($head_defineSession)){
							foreach($head_defineSession as $key=>$value){
								if (strpos($value['Field'], 'head') !== false) {
									$headNameArry[] = $value['Field'];
								}
							}
						}
						
						$type = $student['type'];
						$fee_cat = $student['fee_cat'];
						$new_old = $student['new_old'];
						$class = $student['class'];
						$db->where('session', $_SESSION['SESSION']);
						$head = $db->get ("head_define");
						if ($db->count > 0) {
							foreach ($head as $u) { 
								for ($i = 1; $i <= count($headNameArry); $i++) { 
									$var = 'head'.$i;
									$heads[] = $u[$var];
								}
							}
						}
						$heads = array_filter($heads);
						$heads_count = count($heads); ?>
						<table class='table table-striped table-bordered'>
							<thead>
								<tr>
									<th>Fee Head</th>
									<?php foreach($mf_array as $m) {
										echo "<th>".$m."</th>";
									}?>
									<th>Total</th>
								</tr>
							</thead>
							<tbody>
								<?php 
								$i=1;
								$rowTotalapr = $rowTotalmay = $rowTotaljun = $rowTotaljul = $rowTotalaug = $rowTotalsep = $rowTotaloct = $rowTotalnov = $rowTotaldec = $rowTotaljan = $rowTotalfeb = $rowTotalmar = 0;
								$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'fee_amount');
								if(!empty($head_defineSession)){
									foreach($head_defineSession as $key=>$value){
										if (strpos($value['Field'], 'head') !== false) {
											$headNameArry[] = $value['Field'];
										}
									}
								}
								
								foreach ($heads as $h) {
									$head_name = "head".$i."_method";
									if(empty($customFee)){
										$db->where('session', $_SESSION['SESSION']);
										$db->where('type', $type);
										$db->where('fee_cat', $fee_cat);
										$db->where('new_old', $new_old);
										$db->where('class', $class);
										$head_method = $db->getOne ("fee_amount", $head_name);
									}
									else{
										$head_method = $customFee;
									}
									?>		
									<tr>
										<th><?php echo $h; ?></th>
										<?php $mothTotal = 0; 
										foreach($mf_array as $mf) {  
											$class1Dis = '';
											$m = strtolower(substr($mf,0,3));
											$head_name1 = "head".$i."_".$m;
											$feePaid = $db->rawQuery("SELECT sum(head".$i.") as ".$head_name1." FROM ".PREFIX."fee_paid WHERE adm_no =".$_REQUEST['adm_no']." AND month='".$mf."' and session='".$_SESSION['SESSION']."'");
											if($feePaid[0][$head_name1] != 0){
												$class1Dis = 'DisInput';
											}
											else{
												$class1Dis = 'feeData';
											}
											
											if(empty($customFee)){
												$db->where('session', $_SESSION['SESSION']);
												$db->where('type', $type);
												$db->where('fee_cat', $fee_cat);
												$db->where('new_old', $new_old);
												$db->where('class', $class);
											}
											if(in_array($head_name1,$headNameArry)){ 
												if(empty($customFee)){
													$head_amt = $db->getOne ("fee_amount", $head_name1);
												}
												else{
													$head_amt = $customFee;
												} ?>
													<td><input type='text' class='form-control numonly' <?php if($class1Dis == 'DisInput') { echo ""; } ?>  name="<?php echo $head_name1; ?>" value="<?php echo $head_amt[$head_name1]?>" /></td>
												<?php
												//echo $head_name1;
												
												if (strpos($head_name1, 'head'.$i) !== false) {
													$mothTotal =  $mothTotal+$head_amt[$head_name1];
												}
												if (strpos($head_name1, '_apr') !== false) {
													$rowTotalapr =  $rowTotalapr+$head_amt[$head_name1];
												}
												if (strpos($head_name1, '_may') !== false) {
													$rowTotalmay =  $rowTotalmay+$head_amt[$head_name1];
												}
												if (strpos($head_name1, '_jun') !== false) {
													$rowTotaljun =  $rowTotaljun+$head_amt[$head_name1];
												}
												if (strpos($head_name1, '_jul') !== false) {
													$rowTotaljul =  $rowTotaljul+$head_amt[$head_name1];
												}
												if (strpos($head_name1, '_aug') !== false) {
													$rowTotalaug =  $rowTotalaug+$head_amt[$head_name1];
												}
												if (strpos($head_name1, '_sep') !== false) {
													$rowTotalsep =  $rowTotalsep+$head_amt[$head_name1];
												}
												if (strpos($head_name1, '_oct') !== false) {
													$rowTotaloct =  $rowTotaloct+$head_amt[$head_name1];
												}
												if (strpos($head_name1, '_nov') !== false) {
													$rowTotalnov =  $rowTotalnov+$head_amt[$head_name1];
												}
												if (strpos($head_name1, '_dec') !== false) {
													$rowTotaldec =  $rowTotaldec+$head_amt[$head_name1];
												}
												if (strpos($head_name1, '_jan') !== false) {
													$rowTotaljan =  $rowTotaljan+$head_amt[$head_name1];
												}
												if (strpos($head_name1, '_feb') !== false) {
													$rowTotalfeb =  $rowTotalfeb+$head_amt[$head_name1];
												}
												if (strpos($head_name1, '_mar') !== false) {
													$rowTotalmar =  $rowTotalmar+$head_amt[$head_name1];
												}
											} 
											else {
												echo "<td></td>";
											}
											
										}
										echo "<td>".$mothTotal."</td>";
									echo "</tr>";
									$i++;
								}echo "<tr><td>Total</td><td>".$rowTotalapr."</td><td>".$rowTotalmay."</td><td>".$rowTotaljun."</td><td>".$rowTotaljul."</td><td>".$rowTotalaug."</td><td>".$rowTotalsep."</td><td>".$rowTotaloct."</td><td>".$rowTotalnov."</td><td>".$rowTotaldec."</td><td>".$rowTotaljan."</td><td>".$rowTotalfeb."</td><td>".$rowTotalmar."</td><td></td></tr>";?>
							</tbody>
						</table>
						<?php 
						if($student['custom_fee'] == 'YES' && !empty($customFee)){?>
							<table class="table">
								<tr>
									<td align="center" id="finalmesg1">
										<button class="btn btn-primary ladda-button kill-evo" type='submit' data-style="zoom-out"><span class="ladda-label">Update Fee</span></button>&nbsp;
									</td>
								</tr>
							</table>
						<?php } ?>
						<input type="hidden" value="<?php echo $_REQUEST['adm_no']; ?>" name="adm_no" />
					</form>
				</div>
				<div class="tab-pane " id="transport">
				                   <?php $db->where('stu_id',$_REQUEST['adm_no']);
								         $transport_info=$db->get('stu_sess_data',null,'is_transport,stop_id,bus_id,start_date,end_date');
										
								   ?>
								<form id="update-transport">
								<input type="hidden" name="adm_no" value="<?php echo $_REQUEST['adm_no']; ?>">
							    <table class="table" style="color: black; padding: 0px;">
								<tbody><tr>
								<td>Transport Facility: <select name="is_transport" id="is_transport">
								
								<option value="YES" <?php echo ($transport_info[0]['is_transport']=="YES") ? 'selected' :''?>>YES</option>
								<option value="NO" <?php echo ($transport_info[0]['is_transport']=="NO") ? 'selected' :''?>>NO</option>
								</select></td>
								

								<td>Stoppage : 
								<select name="stop" id="stop"  <?php echo ($transport_info[0]['is_transport']=="YES") ? '' :'disabled'?>>
								<option value="">--Select Stop--</option>
								<?php $stop=$db->get('stop_master');
								  foreach($stop as $val){
									  ?>
									  <option <?php echo ($transport_info[0]['stop_id']==$val['id']) ? 'selected' : '';?> value="<?php echo $val['id'];?>" ><?php echo $val['stop'];?></option>
							    <?php		  
								  }
								?>
								
								</select>
								
								</td>

								<td>Bus No.: <select name="bus_no"  id="bus_no" <?php echo ($transport_info[0]['is_transport']=="YES") ? '' :'disabled'?>>
								<option>Select Bus</option>
								
								</select></td>
								<td>Capacity:<span id="capacity"></span></td>
								<td>Availibilty:<span id="avail"></span></td>
								</tr>

								<tr>
								<td>Start Date :<input type="text" name="strt_date_tp" style="width:100px;" class="input_date datepicker2" data-date-format="dd/mm/yyyy" value="<?php echo getdmYFormat($transport_info[0]['start_date']);?>"></td>
								<td>End Date : <input type="text" name="end_date_tp" style="width:100px;" class="input_date datepicker2" data-date-format="dd/mm/yyyy" value="<?php echo getdmYFormat($transport_info[0]['end_date']);?>"></td>
								<td></td>
								</tr>

								</tbody></table>
								<table class="table" style="padding: 0px;">
								<tbody>
								<tr>
								<td colspan="6"><center><input class="btn-success" type="submit" name="submit" value="Update Transport Information"></center></td>
								
								<td colspan="4"></td>
								</tr>
										</tbody></table>


								</form>
</div>
				<div class="tab-pane " id="certificate">certificate</div>
				<div class="tab-pane " id="photo">photo</div>
			</div>
		</div>
	</div>
</div>
<script>
id="<?php echo $transport_info[0]['bus_id']?>";
if(id!=0){
$.ajax({
			type: 'POST',
			url: './function/studentadd?getTransportCapacity=getTransportCapacity',
			data: "capacity="+id+"&option=1",
			success: function (data) {
				console.log(data);
				$str=data.split("-");
				$("#capacity").html($str[0]);
				$("#avail").html($str[1]);
				$("#bus_no").html($str[2]);
				
				
			}
		});
}
$("#stop").change(function(){
$.ajax({
			type: 'POST',
			url: './function/studentadd?updateTransportInfo=updateTransportInfo',
			data: "id="+this.value,
			success: function (data) {
				//console.log(data);
				$("#bus_no").html("<option>Select Bus</option>"+data);
				
			}
		});
});
$("#bus_no").change(function(){
	$.ajax({
			type: 'POST',
			url: './function/studentadd?getTransportCapacity=getTransportCapacity',
			data: "capacity="+this.value,
			success: function (data) {
				console.log(data);
				$str=data.split("-");
				$("#capacity").html($str[0]);
				$("#avail").html($str[1]);
				
				
			}
		});
});
$("#is_transport").change(function(){
	if(this.value=="YES"){
		$("#stop").attr('disabled',false);
		$("#bus_no").attr('disabled',false);
	}else if(this.value=="NO"){
		$("#stop").attr('disabled',true);
		$("#bus_no").attr('disabled',true);
	}
});
	$('#student-basic-form').submit(function(event) {
		event.preventDefault();
		$.ajax({
			type: 'POST',
			url: './function/studentadd?updatebasicinfo=updatebasicinfo',
			data: $(this).serialize(),
			success: function (data) {
				//console.log(data);
				$('#student-view-form').trigger("reset");
				$.notify({message: '<strong>Successfully</strong> updated the information.' },{type: 'success'});
				var adm_no = $('#adm_no').val();
				var new_adm = parseInt(adm_no)+1;
				 $('#adm_no').val(new_adm);
				$('#finalmesg').html(data);
			}
		});
	});
	$("#update-transport").submit(function(e){
		e.preventDefault();
		$.ajax({
			type: 'POST',
			url: './function/studentadd?updateTransportData=updateTransportData',
			data: $(this).serialize(),
			success: function (data) {
				console.log(data);
				
			}
		});
	});
	$('#student-fee-form').submit(function(event) {
		event.preventDefault();
		$.ajax({
			type: 'POST',
			url: './function/studentadd?updatefeeinfo=updatefeeinfo',
			data: $(this).serialize(),
			success: function (data) {
				console.log(data);
				$('#student-view-form').trigger("reset");
				$.notify({message: '<strong>Successfully</strong> updated the information.' },{type: 'success'});
				var adm_no = $('#adm_no').val();
				var new_adm = parseInt(adm_no)+1;
				$('#adm_no').val(new_adm);
				$('#finalmesg').html(data);
				location.reload();
			}
		});
	});
	
</script>
<?php
include('footer.php');
?>