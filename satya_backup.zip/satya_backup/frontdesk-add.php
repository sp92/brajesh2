<?php
$page='frontdesk';
require('core.php');
if($_SESSION['ACC_FRONTDESK']=='0') {
	header("Location: main.php");
}

include('header.php');
?>
<div class="container">
	<?php print_menu($counselling_menu_items); ?>
	
	<div class="row">
	 <div class="col-md-2 hidden-xs">
<?php print_menu($frontdesk_menu_items); ?>
</div>
		<div class="col-md-10">
		<h3>Frontdesk Setup</h3>
		<style>
			.table > tr {height:40px;}
		</style>
		<div id="hummm"></div>
		<div class="col-md-12"><br>
			<form id="add-query" method="post">
				<table class="table table-striped">
					<tr>
						<td align='right'>Enquiry No. : </td>
						<td>
							<input type="text" name="enq_no" id="enq_no" required onkeyup="lookItUp2();" autocomplete=off class="form-control" style="width:70%" />
							<a href="javascript:void(0)" onclick="get_enquiry_no()" >Get Enquiries</a>
							<script>
								function get_enquiry_no() {
									
									payfee = $.popupWindow('frontdesk-enquiry?adm_status=Enquiry',{height:600,width:900});
									
								}
							</script>
						</td>
						<td align='right'> Picture Captured: </td>
						<td align=center style="height:112px;"><span id="pic"></span></td>
					</tr>
					<tr>
						<td align='right'>Type of Inquiry : </td>
						<td><input type="text" name="type_enq" id="type_enq" class="form-control" value="Enquiry" readonly required /></td>
						<td align='right'>Is campus visited : </td>
						<td>
							<label class="radio-inline" for="radios-0">
								<input type="radio" name="campus_visit" id="radios-0" value="YES" checked="checked">YES
							</label> 
							<label class="radio-inline" for="radios-1">
								<input type="radio" name="campus_visit" id="radios-1" value="NO">NO
							</label> 
						</td>
					</tr>
					<tr>
						<td align='right'>Academic Year : </td>
						<td><?php echo $_SESSION['SESSION']; ?></td>
						<td align=right>Date: </td>
						<td>
							<input type="text" name="date" class="form-control" value="<?php echo date('d/m/Y'); ?>" style="width: 100px;" readonly required />
						</td>				
					</tr>
					<tr>
						<td align=right>Name of the Child: </td>
						<td><input type="text" name="stu_name" id="stu_name" class="form-control"  required /></td>
						<td align='right'>Gender : </td>
						<td>
							<select name="gender" id="gender" class="form-control">
								<option value="MALE">MALE</option>
								<option value="FEMALE">FEMALE</option>
							</select>
						</td>
					</tr>
					<tr>
						<td align=right>Date of birth: </td>
						<td valign="middle">
							<input type="text" name="dob" id="dob" class="datepicker form-control " data-date-format="dd/mm/yyyy"  style="width: 100px;" onchange="getage();" readonly required />
						</td>
						<td align=right>Age as on current date: </td>
						<td><input type="text" id="age" class="form-control" readonly /></td>
					</tr>			
					<tr>
						<td align=right>Father's Name: </td>
						<td>
						<input type="text" id="fat_name" name="fat_name" class="form-control"  required />
						</td>
							<td align=right>Father's Contact No.: </td>
						<td>
						<input type="number" id="mobile" name="mobile" class="form-control"  required />
						</td>
					</tr>
					<tr>
						<td align=right>Occupation: </td>
						<td><input type="text" name="fat_occ" id="fat_occ" class="form-control"   /></td>
						<td align=right>Alternate Contact No.: </td>
						<td><input type="number" name="mobile2" id="mobile2" class="form-control"   /></td>
					</tr>		
					<tr>
						<td align=right>Mother's Name: </td>
						<td><input type="text" name="mot_name" id="mot_name" class="form-control"  required /></td>
						<td align=right>Mother's Contact No.: </td>
						<td><input type="number" name="mobile3" id="mobile3" class="form-control"   /></td>
					</tr>
					<tr></tr>
					<tr>
						<td align=right>Occupation: </td>
						<td><input type="text" name="mot_occu" id="mot_occu" class="form-control"   /></td>
						<td align=right>Date of marriage anniversary of parents: </td>
						<td valign="middle">
							<input type="text" name="anniversary" id="anniversary" class="input_date2 form-control " data-date-format="dd/mm/yyyy"  style="width: 100px;"  readonly />
						</td>
					</tr>			
					<tr>
						<td align=right>Guardian Name: </td>
						<td><input type="text" name="guard_name" id="guard_name" class="form-control"   /></td>
						<td align=right>Guardian Contact No.: </td>
						<td><input type="number" name="guard_no" id="guard_no" class="form-control"   /></td>
					</tr>			
					<tr>
						<td align='right'>Location : </td>
						<td><input type="text" name="location" id="location" class="form-control"   /></td>
						<td align=right>Present Address: </td>
						<td><input type="text" id="address" name="address" class="form-control"  required /></td>
					</tr>
					<tr>
						<td align='right'>Current Class : </td>
						<td>
							<select name="current_class" id="current_class"  class="form-control">
								<option value="">--</option>
								<?php
								$user = $db->get ("class_master");
								if ($db->count > 0) {
									foreach ($user as $u) { 
								?>			
								<option value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
								<?php } } ?>	
							</select>
						</td>
						<td align='right'>Current School Name : </td>
						<td>
							<input type="text" name="last_school" id="last_school"  class="form-control">
						</td>
					</tr>
					<tr>
						<td align='right'>Board : </td>
						<td><input type="text" name="school_board" id="school_board" readonly class="form-control"></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td align='right'>Class to be admitted: </td>
						<td>
							<select name="class" id="class"  class="form-control" onchange="get_datesheet()">
								<option value="">--</option>
								<?php
								$user = $db->get ("class_master");
								if ($db->count > 0) {
									foreach ($user as $u) { 
								?>			
								<option value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
								<?php } } ?>	
							</select>
							<!-- Large modal -->
							<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#fee_struc">Fee Structure</button>
							<div class="modal fade" id="fee_struc" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-dialog modal-lg">
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
										</div>
										<div class="modal-body">
											<div id="myDiv"></div>
										</div>
									</div>
								</div>
							</div>
							<script>
								// form submission
								function get_datesheet() {
									var clss = $('#class').val();
									var type = 'NEW';
									var fee_type = 'DAY SCHOLAR';
									var option = 'fee';
									$("#myDiv").load("inc/fee-data?get", {fee_type:fee_type, type:type, class:clss, option:option})
								}
								get_datesheet();
							</script>
						</td>
						<td align='right'>Online Application Remarks: </td>
						<td><textarea name="online_remark" class="form-control" readonly></textarea></td>
					</tr>
					<tr>
						<td align='right'>Mode of Enquiry: </td>
						<td><input type="text" name="mode_enq" class="form-control" value="OFFLINE"  required readonly /></td>
						<td align='right'>Quality of Lead : </td>
						<td>
							<select name="quality_lead" class="form-control" require>
								<option value="HOT">HOT</option>
								<option value="COLD">COLD</option>
							</select>
						</td>
					</tr>
					<tr>
						<td align='right'>Admission Status: </td>
						<td><input type="text" name="adm_status" class="form-control" value="Enquiry"  required readonly /></td>
						<td align='right'>Lead Generated By: </td>
						<td><input type="text" id="lead_gen_name" name="lead_gen_name" class="form-control"  required readonly /></td>
					</tr>
					<tr>
						<td align='right'>Parent's / Guardian's Remark: </td>
						<td><textarea name="parent_remark" id="parent_remark"  class="form-control" ></textarea></td>
						<td align='right'>Counselor's Remark: </td>
						<td><textarea name="counselor_remark"  class="form-control" ></textarea></td>
					</tr>
					<tr>
						<td align='right'>Reference: </td>
						<td colspan=3>
							<div class="form-group">
								<div class="col-md-6">
									<div class="checkbox">
										<label for="checkboxes-1"><input type="checkbox" name="refer[]" value="TV">TV</label>
									</div>
									<div class="checkbox">
										<label for="checkboxes-1"><input type="checkbox" name="refer[]" value="Staff of NWS">Staff of NWS</label>
									</div>
									<div class="checkbox">
										<label for="checkboxes-1"><input type="checkbox" name="refer[]" value="Parents/Students of NWS">Parents/Students of NWS</label>
									</div>
									<div class="checkbox">
										<label for="checkboxes-1"><input type="checkbox" name="refer[]" value="Others">Others</label>
									</div>
								</div>
								<div class="col-md-6">
									<div class="checkbox">
										<label for="checkboxes-0"><input type="checkbox" name="refer[]" value="News Paper">News Paper</label>
									</div>
									<div class="checkbox">
										<label for="checkboxes-1"><input type="checkbox" name="refer[]" value="Hoarding">Hoarding</label>
									</div>
									<div class="checkbox">
										<label for="checkboxes-1"><input type="checkbox" name="refer[]" value="Reference">Reference</label>
									</div>
									<div class="checkbox">
										<label for="checkboxes-1"><input type="checkbox" name="refer[]" value="Radio">Radio</label>
									</div>
								</div>
							</div>
						</td>
					</tr>
					<tr><td align=center colspan=4><h4>Sibling's Details:</h4></td></tr>
					<tr>
						<td align=center colspan=4>
							<table class="table" style="color: black;">
								<tr style="font-size: 15px;font-weight:bold;">
									<td style="width: 15px;"><center>Sr</center></td>
									<td style="width: 50px;"><center>Name</center></td>
									<td style="width: 50px;"><center>Class</center></td>
									<td style="width: 200px;"><center>School Name & Address</center></td>
								</tr>
								<tr>
									<td>1. </td>
									<td><input type="text" name="sib1_name" id="sib1_name" class="form-control" /></td>
									<td>
										<select name="sib1_class" class="form-control">
											<option value="">--</option>
											<?php
											$user = $db->get ("class_master");
											if ($db->count > 0) {
												foreach ($user as $u) { 
											?>			
											<option value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
											<?php } } ?>	
										</select>
									</td>
									<td><input type="text" name="sib1_school" id="sib1_school" class="form-control" /></td>
								</tr>
								<tr>
									<td>2. </td>
									<td><input type="text" name="sib2_name" id="sib2_name" class="form-control" /></td>
									<td>
										<select name="sib2_class" class="form-control">
											<option value="">--</option>
											<?php
											$user = $db->get ("class_master");
											if ($db->count > 0) {
												foreach ($user as $u) { 
											?>			
											<option value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
											<?php } } ?>	
										</select>							
									</td>
									<td><input type="text" name="sib2_school" id="sib2_school" class="form-control" /></td>
								</tr>
								<tr>
									<td>3. </td>
									<td><input type="text" name="sib3_name" id="sib3_name" class="form-control" /></td>
									<td>
										<select name="sib3_class" class="form-control">
											<option value="">--</option>
											<?php
											$user = $db->get ("class_master");
											if ($db->count > 0) {
												foreach ($user as $u) { 
											?>			
											<option value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
											<?php } } ?>	
										</select>
									</td>
									<td><input type="text" name="sib3_school" id="sib3_school" class="form-control" /></td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td colspan=2 align=right><input class="btn btn-success" id="submit" type="submit" name="submit" /></td>
						<td colspan=2 align=left><input type="reset" class="btn btn-primary" value="Reset"></td>
					</tr>
				</table>
			</form>
		</div>	
		</div>
	
	</div>
</div> <!-- /container -->
<script>
    $('#add-query').submit(function(event) {
	if(confirm('Confirm?' )) {
		event.preventDefault();
                $.ajax({
                        type: 'POST',
                        url: 'function/frontdeskfunctions?page=frontdesk-add',
                        data: $(this).serialize(),
						success: function (data) {
							
							$.notify({message: '<strong>Successfully</strong> updated the information.' },{type: 'success'});
						}
                });
	} else {
		event.preventDefault();
		return false;
	}
});
	function HandlePopupResult(result) {
		
	data=result.split("^");
	$("#enq_no").val(data[0]);
	$("#stu_name").val(data[1]);
	$("#fat_name").val(data[2]);
	$("#mot_name").val(data[3]);
	$("#class").val(data[4]);
	$("#last_school").val(data[5]);
	document.getElementById('pic').innerHTML = "<img src='pictures/enquiry/"+data[11]+"' style='width: 122px;'>";
//	$("#type_enq").val("Enquiry");
	
	}
</script>
<?php
include('footer.php');
?>