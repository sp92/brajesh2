<?php $page='fee';
require('core.php');
error_reporting(0);
if($_SESSION['ACC_FEE']=='0') { header("Location: main"); }
include('header.php');
?>
<div class="container">
<div class="row">
	<h3>Bank Payslip</h3>
	<form name="myForm" method="get" action="fee-bank-payslip">
		<?php if(isset($_REQUEST['menu']) && $_REQUEST['menu']=='OFF') {
			echo "<input type='hidden' name='menu' value='OFF' />";
		} ?>
		<table style="font-size: 14px;width:100%;">
			<tr>
				<td style="border-bottom: none!important;">
					From : <input name="from_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["from_date"]; ?>" class="datepicker" style="width: 100px;" readonly />  
				</td>
				<td style="border-bottom: none!important;">
					To : <input name="to_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["to_date"]; ?>" class="datepicker" style="width: 100px;" readonly /> 
				</td>
				
				<td style="border-bottom: none!important;">
					<input type="submit" name="submit" value="SUBMIT" />
					<input type="button" onclick="tableToExcel('testTable', 'Student')" value="Export"  />
					<input type="button" onclick="return windowpop('bob-pdf', 1000, 600)" value="Print PDF "  />
				</td>
			</tr>
		</table>	
	</form><hr/>

	

	
	<?php 
	
	?>
		
	<h4>Collection Date : <?php echo $_REQUEST['to_date']; ?></h4>
	<table id="testTable" class="table" style="font-size:12px;">
<thead>
<tr>
<th align="center" width="11%"><strong>Sr.</strong></th>

<th align="center" width="17%"><strong>Chq. No.</strong></th>
<th align="center" width="17%"><strong>Chq. Date</strong></th>
<th align="center" width="17%"><strong>Bank Name</strong></th>
<th align="center" width="17%"><strong>Branch</strong></th>
<th align="center" width="17%"><strong>Amount Received</strong></th>
</tr>
</thead>
<tbody>
 <?php 
if(isset($_REQUEST["from_date"]) and isset($_REQUEST["to_date"])) { 
 $from_date = datestamp($_REQUEST["from_date"]);
 $to_date = datestamp($_REQUEST["to_date"]);
 $date=array($from_date,$to_date);
 $db->join("bank_detail u", "p.micr_code=u.micrcode", "LEFT");
 $db->where('p.rec_date',$date,'between');
 $db->groupBy('p.chq_no');
 $data_f=$db->get('fee_paid p',null,'u.branch_name,u.bank_name,p.chq_date,p.chq_no,sum(p.chq_amt) as chq_amt');

 $n=0;
 $sum=0;
foreach($data_f as $bank){$n++;
$sum=$sum+$bank['chq_amt'];
?>
	<tr align="center">
	<td><?php echo $n;?></td>
	
	<td><?php echo $bank['chq_no'];?></td>
	<td><?php echo getdmYFormat($bank['chq_date']);?></td>
	<td><?php echo $bank['bank_name'];?></td>
	<td><?php echo $bank['branch_name'];?></td>
	<td><?php echo $bank['chq_amt'];?></td>
	</tr>
<?php	} }
 
 ?>
 <tr>
		<th colspan=5 align="right">GRAND TOTAL</td>
		<th align="center">Rs. <?php echo $sum;?></td>
	</tr>
</tbody>
</table>
	<h4>In Words : <small><?php 
echo strtoupper(towords($sum)); 
?> ONLY</small></h4>


		
	<?php
	
file_put_contents('bob.htm', ob_get_contents());
// end buffering and displaying page
ob_end_flush();
?>
	</div>
</div>
<?php
include('footer.php');
?>