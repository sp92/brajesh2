<?php
$page='system';
require('core.php');
if($_SESSION['ACC_GROUP']<>'root') 
{
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">
<?php print_menu($settings_menu_items); ?>
<div class="row">
<h3>Manage Permissions</h3>


</div>
</div> <!-- /container -->
<?php
include('footer.php');
?>