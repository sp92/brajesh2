<?php
  include("core.php");
    include("lib/template.class.php");
	$school_info=$db->get('school_info',null,'school_name,address,phone,email,website');
	$rec_no = 17;
	$stu_id = 3;
	$student_type="GENERAL";
	$student_type_old="NEW";
	
	$db->join("student st", "st.id=sess.stu_id", "LEFT");
	$db->where('sess.stu_id',$stu_id);
	$db->where('sess.session',$_SESSION['SESSION']);
	$fee_details=$db->get('stu_sess_data sess',null,'st.stu_name,st.fat_name,st.adm_no,sess.class,sess.sec');
	$fee_value="OCT";
	
	$headCount = 0;
	$query = '';
	$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
	if(!empty($head_defineSession)){
		foreach($head_defineSession as $key=>$value){
			//echo $value['Field'];
			if (strpos($value['Field'], 'head') !== false) {
				$query_method .=$value['Field']."_method,";
				$query =  $query.'sum('.$value['Field'].') as h'.($headCount+1).', ';
				$headCount++;
			}
		}
	}
	$method_db=trim($query_method,",");
	
	$query = $query." sum(transport) as tp, sum(late_fine) as fine, sum(discount) as discount";
	foreach($mf_array as $m) {
		$db->where ('session', $_SESSION['SESSION']);
		$db->where ('rec_no', $rec_no);
		$db->where ('stu_id', $stu_id);
		$db->where ('cancelled', '0');
		$fee_paid = $db->getOne ("fee_paid", $query);
		for($i=0;$i<=$headCount;$i++){
			$tota = $tota+$fee_paid['h'.($i+1)];
		}
		$fee_paid['tp'];
		$paid_fee[] = $tota;
	}
	/*dynamic method*/
	$db->where('type',$student_type);
	  $db->where('new_old',$student_type_old);
	  $db->where('class',$fee_details[0]['class']);
	  $method=$db->get('fee_amount',null,$method_db);
	 
	//echo "<pre>"; print_r($method);,null,'head1_method,head2_method,head3_method,head4_method,head5_method'
	
	/*--------------------*/
	$arr=array();
	$head_d=$db->get('head_define');
	 foreach($head_d as $val){
		foreach($val as $key=>$value){
		   $str=explode("ead",$key);
		  if(count($str)==2){
			  $arr_method[$value]=$method[0][$key."_method"];
			  $arr[$value]=$fee_paid['h'.($str[1])];
		  }elseif($key=="transport"){
			 $arr[$value]=$fee_paid['tp'];
		  }
		    
	}
	} 
	
	/**************************method and fees**********************************/
	$extra_head=$db->get('extra_heads',null,'ehead_id,head_name');
	foreach($extra_head as $head){
		$field[]=$head['ehead_id'];
		$label[$head['ehead_id']]=$head['head_name'];
	}
	$head_c=0;
	foreach($field as $fld){
		$myQuery .='sum('.$fld.') as '.($fld).',';
	$head_c++;}
	
	   $myQuery=rtrim($myQuery,",");
	
	    $db->where ('session', $_SESSION['SESSION']);
		$db->where ('rec_no', $rec_no);
		$db->where ('stu_id', $stu_id);
		$db->where ('cancelled', '0');
	  $ehead = $db->getOne("fee_paid",$myQuery);
	  foreach($label as $key=>$value){
		 foreach($ehead as $ke=>$val){
		  if($key==$ke){
			  $main_ext[$value]=$val;
		  }
	  } 
	  }

	  /************************************Extra Charges With Name****************************************/
	  
	$layout = new Template("lib/layout_receipt.tpl");
	$layout->set("school_name", $school_info[0]['school_name']);
	$layout->set("school_address", $school_info[0]['address']);
	$layout->set("phone", $school_info[0]['phone']);
	$layout->set("website", $school_info[0]['website']);
	$layout->set("fees_month", $fee_value);
	$layout->set("admission_no", $fee_details[0]['adm_no']);
	$layout->set("stu_name", $fee_details[0]['stu_name']);
	$layout->set("fat_name", $fee_details[0]['fat_name']);
	$layout->set("class", $fee_details[0]['class']);
	$layout->set("section", $fee_details[0]['sec']);
	$layout->set("rec_no", $rec_no);
	$layout->set("rec_date", getdmYFormat("2016-12-26"));
	$layout->set("session", $_SESSION['SESSION']);
	$layout->set("title", "User profile");
	echo $layout->output();
	/*file_put_contents('rawhtml/yourpage.html', ob_get_contents());
	$myFile = "rawhtml/yourpage.html";
	$fh = fopen($myFile, 'w') or die("can't open file");
	$stringData = $layout->output();
	fwrite($fh, $stringData);
	fclose($fh);
	echo shell_exec("C:\wkhtmltopdf\bin\wkhtmltopdf.exe rawhtml/yourpage.html a.pdf");
	header("Location: a.pdf");*/
?>