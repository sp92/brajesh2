<?php
require_once('core.php'); 
error_reporting(0);
$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
if(!empty($head_defineSession)){
	foreach($head_defineSession as $key=>$value){
		if (strpos($value['Field'], 'head') !== false) {
			$headNameArry[] = $value['Field'];
		}
	}
}

$_REQUEST["type"] = "FEE";
$_REQUEST["rec_date"] = date("Y-m-d");
$_REQUEST["chq_amt"] = $_REQUEST["total"];
if(isset($_REQUEST["micr_code"])){
	$db->where('micrcode',$_REQUEST["micr_code"]);
	$db->get('bank_detail');
	if($db->count<1){
		$micr=array(
		'micrcode'=>$_REQUEST["micr_code"],
		'bank_name'=>$_REQUEST["chq_bnk"],
		'branch_name'=>$_REQUEST["chq_branch"],
		'created'=>date('Y-m-d')
		);
		$db->insert("bank_detail",$micr);
	}
	
}

unset($_REQUEST["class"]);
unset($_REQUEST["sec"]);
unset($_REQUEST["left"]);
unset($_REQUEST["total"]);
unset($_REQUEST["chq_branch"]);



$i = 0;

// make multiple array 

foreach($mf_array as $mf){
	$m = strtolower(substr($mf,0,3));
	if(array_key_exists($m, $_REQUEST) !== false){
		$insertArry[$i] = $_REQUEST;
		$insertArry[$i]["month"] = $mf;	$i++;
	}

}

for($a = 0; $a <= count($insertArry); $a++){
	// Remove apr may etc keys in new array
	foreach($m_array as $m){
		if(array_key_exists($m, $insertArry[$a]) !== false){
			unset($insertArry[$a][$m]);	
		}
	}
	// Remove _total suffix fields
	foreach($headNameArry as $h){
		if(array_key_exists($h.'_total',$insertArry[$a]) !== false){
				unset($insertArry[$a][$h.'_total']);	
		}
	}
}

for($a = 0; $a <= count($insertArry); $a++){
	foreach($mf_array as $mf){
		$m = strtolower(substr($mf,0,3));
		foreach($headNameArry as $h){
			if($insertArry[$a]['month'] == $mf){
				$insertArry[$a][$h] = $insertArry[$a][$h."_".$m];
				$insertArry[$a]['amount'] += $insertArry[$a][$h."_".$m];
			}
			unset($insertArry[$a][$h."_".$m]);
		}
		if (array_key_exists('tp_'.$m, $insertArry[$a]) !== false) {
			unset($insertArry[$a]['tp_'.$m]);
		}
	}
}
        $db->where ('adm_no', $_REQUEST['adm_no']);
		$stu_id_id = $db->getOne ("student", 'id');
		
    $cols = array("max(rec_no) as max_rec");
	$max_rec = $db->get("fee_paid", null, $cols);
	if($max_rec[0]['max_rec'] == null){
		$rec_no = 1;
	}
	else{
		$rec_no = $max_rec[0]['max_rec']+1;
		
	}
$extra_head=getHeadingOfFine($stu_id_id['id']);
$count_month=count($insertArry);
for($b=0;$b<count($insertArry); $b++){
	 if($b>0){
		foreach($extra_head['ehead_name'] as $can){
			unset($insertArry[$b][$can]);
		}
		unset($insertArry[$b]['chq_amt']);
	 }
	if($insertArry[$b]['mode'] == 'CASH'){
		unset($insertArry[$b]['chq_amt']);
	}else{
		$insertArry[$b]['mode']=$insertArry[$b]['mode'];
	}
	
	
	if($b == 0){
		$insertArry[$b]['late_fine'] = $insertArry[$b]['late_fine'];
		$insertArry[$b]['discount'] = $insertArry[$b]['discount'];
	}else{
		$insertArry[$b]['late_fine'] = 0;
		$insertArry[$b]['discount'] = 0;
	}
	 if($insertArry[$b]['discount']!=0){
	if($b<1){
		$str=explode("*",$insertArry[$b]['discount']);
		$insertArry[$b]['discount']=$str[1];
		$data=array(
		'used'=>"1",
		'used_date'=>date('Y-m-d')
		);
		$db->where('id',$str[0]);
		$db->update("cash_discount_master",$data);
		
	}else{
		unset($insertArry[$b]['discount']);
	}
	} 
	
	$insertArry[$b]['transport']=($insertArry[$b]['transport']/$count_month);
	$insertArry[$b]['stu_id'] = $stu_id_id['id'];
	$insertArry[$b]['session'] = $_SESSION['SESSION'];
	$insertArry[$b]['ip'] = get_ip();
	$insertArry[$b]['date_time'] = date("Y-m-d h:i:s");
	$insertArry[$b]['user'] = $_SESSION['SESS_NAME'];
	$insertArry[$b]['location'] = $_SESSION['LOCATION'];
	$insertArry[$b]['amount'] += $insertArry[$b]['transport'];
	$insertArry[$b]['cancelled'] = '0';
	$insertArry[$b]['rec_no'] = $rec_no;
	
	$db->insert("fee_paid",$insertArry[$b]);
}

exit;
?>