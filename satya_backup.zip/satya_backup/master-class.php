<?php
$page='master';
include('core.php');
if($_SESSION['ACC_MASTER']=='0') 
{
	header("Location: main.php");
}
//Code to Add & Delete Class
if(@$_REQUEST['hdnCmd']=="ADD")
	{
		$class=clean($_REQUEST['class']);
		$data = Array (
			'class' => $class
		);
		if($class!=''){
		$db->insert ('class_master', $data);
		}else{
		header("Location: ./master-class");
		}
	}
if(@$_REQUEST['action']=="del")
	{
		$db->where('id', round($_REQUEST['id']));
		$db->delete('class_master');
		header("Location: ./master-class");
	}
//Code to Add & Delete Section
if(@$_REQUEST['hdnCmd']=="ADDSEC")
	{
	$section=clean($_REQUEST['section']);
		$data = Array (
			'sec' => $section
		);
		if($section!=''){
		$db->insert ('sec_master', $data);
		}else{
		header("Location: ./master-class");
		}
	}
if(@$_REQUEST['action']=="delsec")
	{
		$db->where('id', round($_REQUEST['id']));
		$db->delete('sec_master');
		header("Location: ./master-class");
	}
include('header.php');
?>
<div class="container">

<div class="row">
	<div class="col-md-2 hidden-xs">
	<?php print_menu($master_menu_items); ?>
	</div>
	
	<div class="col-md-5">
<h3>Class Master</h3>
<table class="table table-striped table-hover">
<thead>
<tr>
<th style=" width: 32px;">SR</td>
<th >Classes</td>
<th style="width: 77px;">Update</td>
</tr>
</thead>
<tbody>
				
			<?php
					$n=1;
					$user = $db->get ("class_master");
					if ($db->count > 0) {
						foreach ($user as $u) { 
					?>			
<tr>
<td><?php echo $n; $n++; ?></td>
<td><?php echo $u['class']; ?></td>
<td><a href="master-class?action=del&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a></td>
</tr>
		  <?php } } ?>	
<tr>				
<td></td>
<td colspan=2><form action="master-class" method="post"><input type="text" name="class" required />
<input type="hidden" name="hdnCmd" value="ADD"><input  class="btn btn-default btn-sm" type="submit" name="submit" value="Add Class" /></form>
</td>
</tr>	
<tr>			
<td colspan=3 style='color:red;'>Note:- <br>1.Classes should be in increasing order.<br>
2.Class Names MUST NOT contain hyphens (-) or any special character other than SPACE.
</td>
</tr>			
</table>			
	</div>
	
	<div class="col-md-5">
<h3>Section Master</h3>
<table class="table table-striped table-hover" >
<thead>
<tr>
<th style=" width: 32px;">SR</td>
<th >Section</th>
<th style="width: 77px;">Update</td>
</tr>
</thead>
<tbody>
				
			<?php
					$n=1;
					$user = $db->get ("sec_master");
					if ($db->count > 0) {
						foreach ($user as $u) { 
					?>			
<tr>
<td><?php echo $n; $n++; ?></td>
<td><?php echo $u['sec']; ?></td>
<td><a href="master-class?action=delsec&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a></td>
</tr>
		  <?php }} ?>	

<tr>				
<td></td>
<td colspan=2><form action="master-class" method="post"><input type="text" name="section" required />
<input type="hidden" name="hdnCmd" value="ADDSEC"><input class="btn btn-default  btn-sm" type="submit" name="submit" value="Add Section" /></form>
</td>
</tr>	
		  <tr>			
<td colspan=3 style='color:red;'>Note:- <br>1. Section should be in increasing order.<br>
2. Section Names MUST NOT contain hyphens (-) or any special character other than SPACE.
</td>
</tr>			
</table>	

	
	</div>
	
	
    </div>
</div> <!-- /container -->
	
<?php
include('footer.php');
?>