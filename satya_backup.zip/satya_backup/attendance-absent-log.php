<?php
$page='attendance';
require('core.php');
if($_SESSION['ACC_ATTENDANCE']=='0') 
{
	header("Location: main.php");
}


include('header.php');
?>
<div class="container">
<div class="row">
<div class="col-md-2 hidden-xs">
<?php print_menu($atten_menu_items); ?>
</div>
<div class="col-md-10">
<h3>Attendance Logs</h3>
<div class="row">
<div class="col-md-12">
<label>Date :</label>
<input name="date" id="date" data-date-format="dd/mm/yyyy" value="<?php echo date("d/m/Y"); ?>" class="datepicker3" onchange="get_classes()" style="width: 100px;" readonly />  
&nbsp;&nbsp;&nbsp;&nbsp;
<label>Class :</label>

<select name="class" id="class" class="multiple" multiple>
	<?php 
	$class = $db->get ("class_master");
	$section = $db->get ("sec_master");
	foreach ($class as $key => $val) { 
		foreach($section as $key2 => $val2) {
			$db->join("stu_sess_data sd", "s.id=sd.stu_id", "LEFT");
			$db->where ("s.is_shown", 'YES');
			$db->where ("s.tc_issue", 'YES', '<>');
			$db->where ('sd.session', $_SESSION["SESSION"]);
			$db->where ('sd.class', $val['class']);
			$db->where ('sd.sec', $val2['sec']);
			$user = $db->get("student s",null,"s.id");
			if ($db->count > 0) {
				$data = $db->count;
				$class_arr[] = $val['class']." - ".$val2['sec'];
			}
		}
	}
	foreach($class_arr as $class) { ?>
		<option value='<?php echo $class; ?>'><?php echo $class; ?></option>
	<?php } ?>
</select>
&nbsp;&nbsp;&nbsp;&nbsp;
<label>Status :</label>
<select name="code" id="code" >
	<option value="">- All Status -</option>
	<?php 
	$db->where ('student', '1');
	$codes = $db->get ("atten_code");
	foreach($codes as $code) { ?>
		<option value='<?php echo $code['code']; ?>'><?php echo $code['heading']; ?></option>
	<?php } ?>
</select>
&nbsp;&nbsp;&nbsp;&nbsp;
<button class="btn btn-xs btn-danger ladda-button kill-evo" id='for_holiday' data-style="zoom-out" onclick="get_log();" ><span class="ladda-label">Get Attendance</span></button>
&nbsp;&nbsp;&nbsp;&nbsp;
<b><span id="text_loading" class="text-danger"></span></b>
</div>
</div>
<hr/>
<div class="row">
<div class="col-md-2">
<h4 style="margin:1px ;">Marked Classes:</h4>
</div>
<div id="doneclasses" class="col-md-10">

</div>
</div>
<hr/>
<div id="myDiv"></div>
	
	
	

	</div>
<script>
function get_classes() {
	var date = $('#date').val();
	$('#class').find('option').remove();
	$('#class2').find('option').remove();
	$('#class2').multiselect('rebuild');
	$('#doneclasses').html('');
	$('#allclass').val("");
	$('#text_loading').text("Loading...");
	$.ajax({
		type: 'POST',
		url: 'function/attendance-functions?get-classes&date='+date,
		success: function (data) {
			var arr = new Array();
			var data2 = new Array();
			var data = jQuery.parseJSON(data);
			$.each(data, function(key, value) {   
				if(value == 1) {
					$('#class').append($("<option></option>").attr("value",key).text(key)); 
					arr.push(key);
				}
			});
			$('#class').multiselect('rebuild');
			var undoneclasses = arr.join();
			$('#allclass').val(undoneclasses);
			$.each(data, function(key, value) {   
				if(value == 1) {
					test = "<span class='label label-success'>"+key+"</span>";
				} else {
					test = "<span class='label label-danger'>"+key+"</span>";
				}
				$('#doneclasses').append(""+test+" / "); 
			});
		}
	});
	$('#text_loading').text("");
}

function get_log() {
	$('#text_loading').text("Loading...");
	var date = $('#date').val();
	var clss = $('#class').val();
	var code = $('#code').val();
	$.ajax({
		type: 'POST',
		url: 'function/attendance-functions?get-log&date='+date+'&code='+code+'&class='+clss,
		success: function (data) {
			$("#myDiv").html(data);
			console.log(data);
			
		}
	});
	$('#text_loading').text("");
}
</script>
</div>
</div> <!-- /container -->

<?php
include('footer.php');
?>