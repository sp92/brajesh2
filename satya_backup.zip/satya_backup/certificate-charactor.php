<?php $page='certificate';
require('core.php');
error_reporting(0);
if($_SESSION['ACC_FEE']=='0') { header("Location: main"); }

if(isset($_REQUEST['hdnCmd']) && $_REQUEST['hdnCmd']=="ADD"){
	
  $db->orderBy('id','DESC');
	$s_no=$db->get('charactor_certificate',1,'cc_id');
	if($s_no){
		$_REQUEST['cc_id']=$s_no[0]['cc_id']+1;
	}else{
		$_REQUEST['cc_id']=1;
	} 
	$_REQUEST['stu_id']=$_REQUEST['adm_no'];
	$_REQUEST['cancelled']='1';
	$_REQUEST['date_issue']=datestamp($_REQUEST['date_issue']);
	unset($_REQUEST['hdnCmd']);
	unset($_REQUEST['adm_no']);
	unset($_REQUEST['stu_name']);
	unset($_REQUEST['fat_name']);
	
	$db->insert('charactor_certificate',$_REQUEST);
	
	

	
	header("Location: ./certificate-charactor");
	
}







include('header.php');
?>

<div class="container">        <br>

    <div class="row">
       	
		<div class="col-md-12">
			<h3 class="glyphicons adress_book"><i></i> Enter Admission No.:</h3>
		</div>
		
		<div class="col-md-3">
			<form method="get" action="certificate-charactor" id="form1" role="form">
				<input type="text" name="adm_no" class="form-control" style="background-color: beige;">
		</form></div>	

		<div class="col-md-3">
				<button type="submit" class="btn btn-success" onclick="$('#form1').submit();">Submit</button>
			
		</div>	
	</div>	
	<div class="row">
<?php if(isset($_REQUEST['adm_no'])){?>
<h3>Issue Character Certificate</h3>

<form method="post" action="certificate-charactor">

<input type="hidden" name="hdnCmd" value="ADD">

<table class="table">
<?php 
   $db->join("stu_sess_data s", "s.adm_no=ss.adm_no", "LEFT");
	$db->where('ss.adm_no',$_REQUEST['adm_no']);
	$user=$db->get('student ss',null,'ss.*,s.type,s.fee_cat,s.class as cl');
?>
    

    <tbody><tr>


	  <td>

          Admission No.: <input type="text" name="adm_no" value="<?php echo $user[0]['adm_no']?>" style="width: 50%;" readonly="">

      </td>

    </tr>

    

  </tbody></table>

  <br>

  <table class="table">

    <tbody><tr>

		<td>1.</td>

		<td>Name of the Pupil:</td>

		<td><input type="text" name="stu_name" value="<?php echo $user[0]['stu_name']?>" style="width: 100%;"></td>

    </tr>

    

    <tr>

      <td>2.</td>

      <td>Father's Name:</td>

      <td><input type="text" name="fat_name" value="<?php echo $user[0]['fat_name']?>" style="width: 100%;"></td>

    </tr>

    

    <tr>

      <td>3.</td>

      <td>Class:</td>

      <td>

	  <select name="class">

<option value="">--</option>
<?php $class_sess=$db->get('class_master');
	    foreach($class_sess as $class){
	 ?>
	      <option <?php echo ($class['class']==$user[0]['cl']) ? 'selected' : '';?> value="<?php echo $class['class'];?>"><?php echo $class['class'];?></option>
		<?php } ?>
</select>

	  

	  </td>

    </tr>

    

    <tr>

      <td>4.</td>

      <td>For Session:</td>

      <td><select name="session">
     <?php $session=$db->get('session');
	    foreach($session as $sess){
	 ?>
	      <option value="<?php echo $sess['session'];?>"><?php echo $sess['session'];?></option>
		<?php } ?>
	 </select>

	  

	  </td>

    </tr>

    

	<tr>

      <td>5.</td>

      <td>Nature of Candidate:</td>

      <td><input type="text" name="nature" value="Good" style="width: 100%;"></td>

    </tr>

	

    <tr>

      <td>6.</td>

      <td>Date of Issue:</td>

      <td><input type="text" name="date_issue" value="<?php echo date('d-m-Y')?>" class="datepicker2" style="width: 100%;" readonly=""></td>

    </tr>

	

	<tr>

	<td colspan="3">

	<center>

		<input class="btn" onclick="this.disabled=true;this.value='Submitting, Please Wait...';this.form.submit();" type="submit" value="Submit"> &nbsp;&nbsp;&nbsp;&nbsp;

	</center>

	</td>

	</tr>

</tbody></table>

<span class="label" style="color:red; font-size:11px;">* Note: Class is here for reference only. To change this information, please close this window and then change the information in the student profile.</span>

  

  

  

</form>  
<?php }else{
	$db->join("student ss", "ss.adm_no=cc.stu_id", "LEFT");
	$db->where('cancelled','1');
	$user12=$db->get('charactor_certificate cc',null,'cc.*,ss.stu_name,ss.fat_name');
    if($db->count>0){
	?>
	
	<br><br>
	<table class="table" id="testTable" style="padding: 0px;">
			<thead class="tableFloatingHeaderOriginal">
				<tr>
					<th class="center">S.R.</th>
					<th class="center">Cert. No.</th>
					<th class="center">Adm. No.</th>
					<th class="center">Student Name</th>
					<th class="center">Father Name</th>
					<th class="center">Date of Issue</th>
					<th class="center">Option</th>
				</tr>
			</thead><thead class="tableFloatingHeader" style="display: none; opacity: 0;">
				<tr>
					<th class="center">S.R.</th>
					<th class="center">Cert. No.</th>
					<th class="center">Adm. No.</th>
					<th class="center">Student Name</th>
					<th class="center">Father Name</th>
					<th class="center">Date of Issue</th>
					<th class="center">Option</th>
				</tr>
			</thead>
			<tbody>
			<?php $x=0;foreach($user12 as $use){$x++;?>
							<tr>
							<td align="center"><?php echo $x;?></td>
							<td align="center">CC/<?php echo $use['cc_id']?></td>
							<td align="center"><?php echo $use['stu_id']?></td>
							<td align="center"><?php echo $use['stu_name'];?></td>
							<td align="center"><?php echo $use['fat_name'];?></td>
							<td align="center"><?php echo getdmYFormat($use['date_issue']);?></td>
							<td align="center">
							<a href="./certificate-charactor-edit?id=<?php echo $use['id'];?>">[Edit]</a>
							<a onclick="get_tc(<?php echo $use['stu_id'];?>)" style="cursor:pointer;">[View / Print]</a>
							<a href="javascript:void(0);" onclick="cancelForm(<?php echo $use['id'];?>)">[Cancel]</a>

							</td>

							</tr>
			<?php } ?>
				
				</table>
<?php	
} }?>
     </div>		

</div>
	  <script>
function get_tc(id) {

payfee = $.popupWindow('certificate-view-cc?adm_no='+id,{height:600,width:900});

}
</script>
<script>
function cancelForm(id){
 $.ajax({
           type: "POST",
           url: "function/certificateFunction?cancelCC",
           data: "id="+id,
           success: function(data)
           {	
		     location.reload();
		   }
         });
}
</script>
<?php
include('footer.php');
?>