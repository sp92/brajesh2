// function that creates BytescoutPDF instance (defined in BytescoutPDF.js script which have to be included into the same page)
// then calls API methods and properties to create PDF document
// and returns created BytescoutPDF object instance
// this CreatePDF() function is called from Sample.html
// IsInternetExplorer8OrLower parameter indicates if we use IE8 or lower so we CAN'T use images (as it requires HTML5 Canvas available in IE9 or higher). Other browsers should be working fine

// IMPORTANT ABOUT IMAGES: 
// When using Firefox or IE, pdf generation may fail because images are not accessible when pdf generation works
// the solution for this issue is to preload images in main HTML document before running PDF generation
// to preload images, put them into hidden div block "pdfreportimages" - you can see it in the sample.html right after <body> opening tag


function CreatePDF(IsInternetExplorer8OrLower) {

    // create BytescoutPDF object instance
    var pdf = new BytescoutPDF();

    // set document properties: Title, subject, keywords, author name and creator name
    pdf.propertiesSet("Sample document title", "Sample subject", "keyword1, keyword 2, keyword3", "Document Author Name", "Document Creator Name");

    // set page size
    pdf.pageSetSize(BytescoutPDF.A4);

    // set page orientation (BytescoutPDF.PORTRAIT = portrait, BytescoutPDF.LANDSCAPE = landscape)
    pdf.pageSetOrientation(BytescoutPDF.PORTRAIT);

    // add new page
    pdf.pageAdd();

    // set font color in RGB format to 0,0,0 - black color
    pdf.fontSetColor(0, 0, 0);

    // set font size
    pdf.fontSetSize(14);

    // BytescoutPDF.js provides support for built-in PDF fonts
    // which are demonstrated in this sample

    // trying Times-Roman
    pdf.fontSetName('Times-Roman');
    // draw text
    pdf.textAdd(20, 20, 'Hello Times Roman!');

    // trying Helvetica
    pdf.fontSetName('Helvetica');
    // draw text
    pdf.textAdd(20, 60, 'Hello Helvetica!');

    // trying Courier-Bold
    pdf.fontSetName('Courier');
    // draw text
    pdf.textAdd(20, 100, 'Hello Courier!');
    

    // return BytescoutPDF object instance
    return pdf;
}

