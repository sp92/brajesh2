// function that creates BytescoutPDF instance (defined in BytescoutPDF.js script which have to be included into the same page)
// then calls API methods and properties to create PDF document
// and returns created BytescoutPDF object instance
// this CreatePDF() function is called from Sample.html
// IsInternetExplorer8OrLower parameter indicates if we use IE8 or lower so we CAN'T use images (as it requires HTML5 Canvas available in IE9 or higher). Other browsers should be working fine

// IMPORTANT ABOUT IMAGES: 
// When using Firefox or IE, pdf generation may fail because images are not accessible when pdf generation works
// the solution for this issue is to preload images in main HTML document before running PDF generation
// to preload images, put them into hidden div block "pdfreportimages" - you can see it in the sample.html right after <body> opening tag


function CreatePDF(IsInternetExplorer8OrLower) {

    // create BytescoutPDF object instance
    var pdf = new BytescoutPDF();
    // set document properties: Title, subject, keywords, author name and creator name
    pdf.propertiesSet("Sample document title", "Sample subject", "keyword1, keyword 2, keyword3", "Document Author Name", "Document Creator Name");
    
    pdf.pageAdd();

	// draw transparent star
    
    pdf.graphicsSetColor("ffff00");
	pdf.graphicsSetAlpha(125);
	
	var rad=200;
	var cx=300; var cy=300;
	
	pdf.graphicsSetLineWidth(10);
	
	for (var an = 0.0; an < Math.PI; an += Math.PI / 20) 
	{
		var x = rad * Math.sin(an);
		var y = rad * Math.cos(an);
		pdf.graphicsDrawLine(cx + x, cy + y, cx - x, cy - y);
	}
	
    // return BytescoutPDF object instance
    return pdf;
}

