// function that creates BytescoutPDF instance (defined in BytescoutPDF.js script which have to be included into the same page)
// then calls API methods and properties to create PDF document
// and returns created BytescoutPDF object instance
// this CreatePDF() function is called from Sample.html
// IsInternetExplorer8OrLower parameter indicates if we use IE8 or lower so we CAN'T use images (as it requires HTML5 Canvas available in IE9 or higher). Other browsers should be working fine

// IMPORTANT ABOUT IMAGES: 
// When using Firefox or IE, pdf generation may fail because images are not accessible when pdf generation works
// the solution for this issue is to preload images in main HTML document before running PDF generation
// to preload images, put them into hidden div block "pdfreportimages" - you can see it in the sample.html right after <body> opening tag


function CreatePDF(IsInternetExplorer8OrLower) {

    // create BytescoutPDF object instance
    var pdf = new BytescoutPDF();

    // set document properties: Title, subject, keywords, author name and creator name
    pdf.propertiesSet("Sample document title", "Sample subject", "keyword1, keyword 2, keyword3", "Document Author Name", "Document Creator Name");

    // add new page
    pdf.pageAdd();

    // set font size
    pdf.fontSetSize(48);

    // set Symbol symbolic font
    pdf.fontSetName('Symbol');

	// info: char table of Symbol font http://en.wikipedia.org/wiki/Symbol_font
    pdf.textAdd(100, 50, '\u0041');
    pdf.textAdd(200, 50, '\u0022');

    // set ZapfDingbats symbolic font
    pdf.fontSetName('ZapfDingbats');

	// info: char table of ZapfDingbats font http://www.unicode.org/charts/PDF/U2700.pdf
    pdf.textAdd(100, 150, "\u2780");
    pdf.textAdd(200, 150, "\u2776");

    // return BytescoutPDF object instance
    return pdf;
}

