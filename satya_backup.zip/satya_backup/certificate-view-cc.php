<?php
include('lib/config.php');
$db->join("student ss", "ss.adm_no=cc.stu_id", "LEFT");
	$db->where('stu_id',$_REQUEST['adm_no']);
	$user=$db->get('charactor_certificate cc',null,'cc.*,ss.stu_name,ss.fat_name,ss.gender');
	
?>
<html>

<head>

</head>

<body>

<div>

<br/>

<br/>

<br/>

<br/>

<br/>

<br/>

<br/>

<br/>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h2 style="text-align:center;">CHARACTER CERTIFICATE</h2>

<br/> 

<div align=center>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=679

 style='width:509.4pt;border-collapse:collapse;border:none;mso-yfti-tbllook:

 1184;mso-padding-alt:0in 5.4pt 0in 5.4pt;mso-border-insideh:none;mso-border-insidev:

 none'>

 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>

  <td width=128 valign=top style='width:95.75pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal align=right style='margin-bottom:0in;margin-bottom:.0001pt;

  text-align:right;line-height:normal'><span style='font-size:12.0pt;

  mso-bidi-font-size:11.0pt;font-family:"Cambria","serif";mso-ascii-theme-font:

  major-latin;mso-hansi-theme-font:major-latin'>C. C. SR No.<b

  style='mso-bidi-font-weight:normal'><u><o:p></o:p></u></b></span></p>

  </td>

  <td width=162 valign=top style='width:121.15pt;border-bottom:1px dotted;'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:12.0pt;

  mso-bidi-font-size:11.0pt;font-family:"Cambria","serif";mso-ascii-theme-font:

  major-latin;mso-hansi-theme-font:major-latin'><?php echo "CC/".$user[0]['cc_id']; ?><o:p></o:p></span></b></p>

  </td>

  <td width=126 valign=top style='width:94.5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

  <td width=128 valign=top style='width:95.75pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'>Admission

  No.<o:p></o:p></span></p>

  </td>

  <td width=136 valign=top style='width:102.25pt;border-bottom:1px dotted;

  mso-border-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;

  text-align:center;line-height:normal'><b style='mso-bidi-font-weight:normal'><span

  style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:"Cambria","serif";

  mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><?php echo $user[0]['stu_id']; ?><o:p></o:p></span></b></p>

  </td>

 </tr>

</table>



</div>



<p class=MsoNormal><span style='font-family:"Cambria","serif";mso-ascii-theme-font:

major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>



<div align=center>



<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0

 style='margin-left:.2in;border-collapse:collapse;border:1px solid;mso-border-alt:

 solid windowtext .5pt;mso-yfti-tbllook:1184;mso-padding-alt:0in 5.4pt 0in 5.4pt;

 mso-border-insideh:none;mso-border-insidev:none'>

 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>

  <td width=265 valign=top style='width:198.9pt;border-top:solid windowtext 1.0pt;

  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:none;

  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;

  padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

  <td width=402 colspan=2 valign=top style='width:301.5pt;border:solid windowtext 1.0pt;

  mso-border-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

 </tr>

 <tr style='mso-yfti-irow:1'>

  <td width=265 valign=top style='width:198.9pt;border:none;border-left:solid windowtext 1.0pt;

  mso-border-left-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'>This

  is to certify that Mr. / Ms.<o:p></o:p></span></p>

  </td>

  <td width=402 colspan=2 valign=top style='width:301.5pt;border-bottom:1px dotted;;

  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;

  padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:12.0pt;

  mso-bidi-font-size:11.0pt;font-family:"Cambria","serif";mso-ascii-theme-font:

  major-latin;mso-hansi-theme-font:major-latin'><?php echo $user[0]['stu_name']; ?><o:p></o:p></span></b></p>

  </td>

 </tr>

 <tr style='mso-yfti-irow:2'>

  <td width=265 valign=top style='width:198.9pt;border:none;border-left:solid windowtext 1.0pt;

  mso-border-left-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

  <td width=402 colspan=2 valign=top style='width:301.5pt;border:solid windowtext 1.0pt;

  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;

  padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

 </tr>

 <tr style='mso-yfti-irow:3'>

  <td width=265 valign=top style='width:198.9pt;border:none;border-left:solid windowtext 1.0pt;

  mso-border-left-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'>
Son / Daughter of
  <o:p></o:p></span></p>

  </td>

  <td width=402 colspan=2 valign=top style='width:301.5pt;border-bottom:1px dotted;;

  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;

  padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:12.0pt;

  mso-bidi-font-size:11.0pt;font-family:"Cambria","serif";mso-ascii-theme-font:

  major-latin;mso-hansi-theme-font:major-latin'><?php echo $user[0]['fat_name']; ?><o:p></o:p></span></b></p>

  </td>

 </tr>

 <tr style='mso-yfti-irow:4'>

  <td width=265 valign=top style='width:198.9pt;border:none;border-left:solid windowtext 1.0pt;

  mso-border-left-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

  <td width=402 colspan=2 valign=top style='width:301.5pt;border:solid windowtext 1.0pt;

  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;

  padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

 </tr>

 <tr style='mso-yfti-irow:5'>

  <td width=265 valign=top style='width:198.9pt;border:none;border-left:solid windowtext 1.0pt;

  mso-border-left-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'>Was

  a <span class=SpellE>bonafide</span> student of class<o:p></o:p></span></p>

  </td>

  <td width=402 colspan=2 valign=top style='width:301.5pt;border-bottom:1px dotted;;

  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;

  padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:12.0pt;

  mso-bidi-font-size:11.0pt;font-family:"Cambria","serif";mso-ascii-theme-font:

  major-latin;mso-hansi-theme-font:major-latin'><?php echo $user[0]['class']; ?><o:p></o:p></span></b></p>

  </td>

 </tr>

 <tr style='mso-yfti-irow:6'>

  <td width=265 valign=top style='width:198.9pt;border:none;border-left:solid windowtext 1.0pt;

  mso-border-left-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

  <td width=402 colspan=2 valign=top style='width:301.5pt;border:solid windowtext 1.0pt;

  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;

  padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

 </tr>

 <tr style='mso-yfti-irow:7'>

  <td width=265 valign=top style='width:198.9pt;border:none;border-left:solid windowtext 1.0pt;

  mso-border-left-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'>During

  <span class=SpellE>sesssion</span><o:p></o:p></span></p>

  </td>

  <td width=180 valign=top style='width:135.0pt;border:solid windowtext 1.0pt;

  border-bottom:1px dotted;

  padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:12.0pt;

  mso-bidi-font-size:11.0pt;font-family:"Cambria","serif";mso-ascii-theme-font:

  major-latin;mso-hansi-theme-font:major-latin'><?php echo $user[0]['session']; ?><o:p></o:p></span></b></p>

  </td>

  <td width=222 valign=top style='width:166.5pt;border:none;border-right:solid windowtext 1.0pt;

  mso-border-right-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span class=GramE><span style='font-size:12.0pt;mso-bidi-font-size:

  11.0pt;font-family:"Cambria","serif";mso-ascii-theme-font:major-latin;

  mso-hansi-theme-font:major-latin'>in</span></span><span style='font-size:

  12.0pt;mso-bidi-font-size:11.0pt;font-family:"Cambria","serif";mso-ascii-theme-font:

  major-latin;mso-hansi-theme-font:major-latin'> this institute.<o:p></o:p></span></p>

  </td>

 </tr>

 <tr style='mso-yfti-irow:8'>

  <td width=265 valign=top style='width:198.9pt;border:none;border-left:solid windowtext 1.0pt;

  mso-border-left-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

  <td width=402 colspan=2 valign=top style='width:301.5pt;border:solid windowtext 1.0pt;

  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;

  padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

 </tr>

 <tr style='mso-yfti-irow:9'>

  <td width=667 colspan=3 valign=top style='width:6.95in;border-top:none;

  border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid windowtext 1.0pt;

  mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;

  padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><?php

	if($user[0]['gender']=='M')

	{ echo "He"; }

	if($user[0]['gender']=='F')

	{ echo "She"; }



?>  was an obedient student having <?php echo $user[0]['nature']; ?> moral character.<o:p></o:p></span></p>

  </td>

 </tr>

 <tr style='mso-yfti-irow:10;mso-yfti-lastrow:yes'>

  <td width=265 valign=top style='width:198.9pt;border-top:none;border-left:

  solid windowtext 1.0pt;border-bottom:solid windowtext 1.0pt;border-right:

  none;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;

  padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

  <td width=402 colspan=2 valign=top style='width:301.5pt;border:solid windowtext 1.0pt;

  mso-border-alt:solid windowtext .5pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:

  "Cambria","serif";mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

 </tr>

</table>



</div>



<p class=MsoNormal><span style='font-family:"Cambria","serif";mso-ascii-theme-font:

major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>



<p class=MsoNormal><span style='font-family:"Cambria","serif";mso-ascii-theme-font:

major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>



<p class=MsoNormal><span style='font-family:"Cambria","serif";mso-ascii-theme-font:

major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>



<p class=MsoNormal><span style='font-family:"Cambria","serif";mso-ascii-theme-font:

major-latin;mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>



<div align=center>



<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0

 style='margin-left:.2in;border-collapse:collapse;border:none;mso-yfti-tbllook:

 1184;mso-padding-alt:0in 5.4pt 0in 5.4pt;mso-border-insideh:none;mso-border-insidev:

 none'>

 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>

  <td width=91 valign=top style='width:.95in;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal align=right style='margin-bottom:0in;margin-bottom:.0001pt;

  text-align:right;line-height:normal'><span style='font-family:"Cambria","serif";

  mso-ascii-theme-font:major-latin;mso-hansi-theme-font:major-latin'>Date :<o:p></o:p></span></p>

  </td>

  <td width=119 valign=top style='width:89.0pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-family:"Cambria","serif";mso-ascii-theme-font:major-latin;

  mso-hansi-theme-font:major-latin'><?php echo getdmYFormat($user[0]['date_issue']);?><o:p></o:p></span></p>

  </td>

  <td width=119 valign=top style='width:89.0pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-family:"Cambria","serif";mso-ascii-theme-font:major-latin;

  mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

  <td width=119 valign=top style='width:89.05pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-family:"Cambria","serif";mso-ascii-theme-font:major-latin;

  mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

  <td width=119 valign=top style='width:89.05pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-family:"Cambria","serif";mso-ascii-theme-font:major-latin;

  mso-hansi-theme-font:major-latin'><o:p>&nbsp;</o:p></span></p>

  </td>

  <td width=119 valign=top style='width:89.05pt;padding:0in 5.4pt 0in 5.4pt'>

  <p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:

  normal'><span style='font-family:"Cambria","serif";mso-ascii-theme-font:major-latin;

  mso-hansi-theme-font:major-latin'>(PRINCIPAL)<o:p></o:p></span></p>

  </td>

 </tr>

</table>



</div>





</div>

</body>

</html>

<?php

/* file_put_contents('character_certificate.htm', ob_get_contents());

echo "<script>window.location.href='cc_pdf.php';</script>";

ob_end_flush(); */

?>