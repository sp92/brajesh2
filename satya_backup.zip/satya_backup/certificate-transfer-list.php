<?php $page='certificate';
require('core.php');
error_reporting(0);
if($_SESSION['ACC_FEE']=='0') { header("Location: main"); }

include('header.php');
?>
<div class="container">  
<div class="row">
<h3>Issued Transfer Certificates
</h3>
<!---
<a class='btn btn-success' href='transfer-certificate-enter?edit=ON'>Update Issue Date</a>
-->
<input type="button" onclick="tableToExcel('testTable', 'Student')" value="Export to Excel" style="float:right;margin-right: 28px;">
  <input type="text" id="searchTerm" class="search_box" onkeyup="doSearch()" style="float:right;padding: 2px;" placeholder="Search Here....."><br><br>
		<div id="contain" style="overflow: hidden; width: auto; height: 500px;">

	
					
			<table class="table" id="testTable" >
			<thead>
				<tr>
					<th class="center">S.R.</th>
					<th class="center">Cert. No.</th>
					<th class="center">Adm. No.</th>
					<th class="center">Student Name</th>
					<th class="center">Class</th>
					<th class="center">Father Name</th>
					<th class="center">Date of Issue</th>
					<th class="center">Option</th>
				</tr>
			</thead>
			<tbody>
			<?php 
			
	
		
	$db->join("student s", "s.adm_no=ts.adm_no", "LEFT");
	$db->where('ts.cancel','YES');
	$user=$db->get('transfer_certificate ts');
	
	if($db->count>0){
		$x=0;
		foreach($user as $val){$x++;
			?>
			
			<tr>
					<td align="center"><?php echo $x;?></td>
					<td align="center"><?php echo $val['s_no'];?></td>
					<td align="center">KIS10<?php echo $val['adm_no'];?></td>
					<td align="center"><?php echo $val['stu_name'];?></td>
					<td align="center"><?php echo $val['last_class'];?></td>
					<td align="center"><?php echo $val['fat_name'];?></td>
					<td align="center">
					
					<?php echo getdmYFormat($val['date_issue']);?>			
					</td>
	<td align="center">
	<a href="./certificate-transfer-edit?adm_no=<?php echo $val['id'];?>">[Edit]</a>
	
	<a onclick="get_tc(<?php echo $val['adm_no'];?>)" style="cursor:pointer;">[View / Print]</a>
	<a href="javascript:void(0);" onclick="cancelForm(<?php echo $val['id'];?>)">[Cancel]</a>
	
	
	</td>
					
				</tr>
				
		<?php } } ?>	
			</tbody>
		</table>
	
		

</div>
</div>    

</div>
<script>
function get_tc(id) {

payfee = $.popupWindow('certificate-view-tc?adm_no='+id,{height:600,width:900});

}
</script>
<script>
function cancelForm(id){
 $.ajax({
           type: "POST",
           url: "function/certificateFunction?cancelTC",
           data: "id="+id,
           success: function(data)
           {	
		     location.reload();
		   }
         });
}
</script>
<?php
include('footer.php');
?>