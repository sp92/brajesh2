<?php
$page='master';
require('core.php');
if($_SESSION['ACC_MASTER']=='0') 
{
	header("Location: ./main");
}
require_once('header.php');
?>
<div class="container">
	
	<div class="row">
	<div class="col-md-2 hidden-xs">
	<?php print_menu($master_menu_items); ?>
	</div>
	<div class="col-md-10">
	<h3>Certificate Information</h3>
				<?php
					$db->where ("id", 1);
					$cert = $db->get ("certificate",1);
					if ($db->count > 0) {
						foreach ($cert as $c) { 
							$cert1 = $c['cert1'];
							$cert2 = $c['cert2'];
							$cert3 = $c['cert3'];
							$cert4 = $c['cert4'];
							$cert5 = $c['cert5'];
							$cert6 = $c['cert6'];
							$cert7 = $c['cert7'];
							$cert8 = $c['cert8'];
							$cert9 = $c['cert9'];
							$cert10 = $c['cert10'];
						}
					}
					?>	
			<div class='row'>
			<div class='col-md-6 col-sm-6 col-xs-12'>
				<form id="master-form">
                      <input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
                      <input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>">
                     
                        <label for="street">Certificate 1 : </label> 
                        <input type="text" name="cert1" class="form-control" value="<?php echo $cert1; ?>" />
                        <br>
                        <label for="city">Certificate 2 : </label>
                        <input type="text" name="cert2" class="form-control" value="<?php echo $cert2; ?>" />
                        <br>
                        <label for="country">Certificate 3 : </label> 
                        <input name="cert3" type="text" class="form-control" value="<?php echo $cert3; ?>" />
                        <br>
						<label for="country">Certificate 4 : </label> 
                        <input type="text" name="cert4"  class="form-control" value="<?php echo $cert4; ?>" />
                        <br>
						<label for="country">Certificate 5 : </label> 
                        <input type="text" name="cert5" class="form-control" value="<?php echo $cert5; ?>" />
                        <br>
						</div>
						<div  class='col-md-6  col-sm-6 col-xs-12'>
						<label for="country">Certificate 6 : </label> 
                        <input type="text" name="cert6" class="form-control" value="<?php echo $cert6; ?>" />
                        <br>
                        <label for="state">Certificate 7 : </label>
                        <input name="cert7" type="text" class="form-control" value="<?php echo $cert7; ?>"  />
                        <br>
                        <label for="zip">Certificate 8 : </label>
                        <input name="cert8" type="text" class="form-control" value="<?php echo $cert8; ?>"  />
                        <br>
                        <label for="tel">Certificate 9 : </label>
                        <input type="text" name="cert9" class="form-control" value="<?php echo $cert9; ?>" />
						<br>
                        <label for="tel">Certificate 10 : </label>
                        <input type="text" name="cert10" class="form-control" value="<?php echo $cert10; ?>" />
                      </div>
                      </div>
                      
                      <div align="center">
					  <br>
					  <?php if(acl_check('master_update_school_info', $_SESSION['SESS_ID']) != false) {  ?>
                      <button class="btn btn-primary ladda-button kill-evo" type='submit' data-style="zoom-out"><span class="ladda-label">Update Information</span></button>
					  <?php } ?>
                      </div>
                    </form>
					
	</div>
				

    </div>
    </div> 
<script>
	$('#master-form').submit(function(event) {
	event.preventDefault();
		$.ajax({
			type: 'POST',
			url: './function/masterfunctions',
			data: $(this).serialize(),
			success: function (data) {
				if(data=='0') {
					$.notify({message: 'Failed to update information.' },{type: 'danger'});
				} else {
					$.notify({message: '<strong>Successfully</strong> updated the information.' },{type: 'success'});
				}
			}
		});
	});
</script>
<?php
require_once('footer.php');
?>