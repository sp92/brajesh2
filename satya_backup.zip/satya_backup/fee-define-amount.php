<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') 
{
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">
<?php print_menu($fee_menu_items); ?>
<div class="row">
<h3>Define Fee Amount</h3>

<form id="fee-form">
<input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
<input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>">
<b>FEE TYPES :</b> <select name="type" id="type" required onchange="get_fee();" >
      <option value="">
        --
      </option>
	  <?php
		$db->where('session', $_SESSION['SESSION']);
		$user = $db->get ("type");
		if ($db->count > 0) {
			foreach ($user as $u) { 
		?>			
		<option value='<?php echo $u['type']; ?>'><?php echo $u['type']; ?></option>
		<?php } } ?>	
    </select>
&nbsp;&nbsp;&nbsp;&nbsp;
	
<b>FEE CATEGORIES :</b> <select name="fee_cat" id="fee_cat" required onchange="get_fee();" >
      <option value="">
        --
      </option>
	  <?php
		$db->where('session', $_SESSION['SESSION']);
		$user = $db->get ("fee_cat");
		if ($db->count > 0) {
			foreach ($user as $u) { 
		?>			
		<option value='<?php echo $u['fee_cat']; ?>'><?php echo $u['fee_cat']; ?></option>
		<?php } } ?>	
    </select>

	&nbsp;&nbsp;&nbsp;&nbsp;
	<b>NEW / OLD :</b>
	<select name="new_old" id="new_old" required="" onchange="get_fee();">
      <option value="">  --</option>
	  	<option value="NEW">NEW</option>
		<option value="OLD">OLD</option>
	</select>
<br>
<br>


<div id="amountdiv"></div>

<button class="btn btn-primary ladda-button kill-evo" type='submit' data-style="zoom-out" id="submitbtn" style="display:none;"><span class="ladda-label">Add Fee Slab</span></button>

</form>



  <script>
    $('select#fee_category').change(function(event) {
		if(category=='SPECIAL') {
			$("#updatefee input[name^='head1_']").val(0);
			$("#updatefee input[name^='head2_']").val(0);
			$("#updatefee input[name^='head3_']").val(0);
			$("#updatefee input[name^='head4_']").val(0);
			$("#updatefee input[name^='head5_']").val(0);
			$("#updatefee input[name^='head6_']").val(0);
		}
	});
	
function get_fee() {
	var type = $('#type').val();
	var fee_cat = $('#fee_cat').val();
	var new_old = $('#new_old').val();
	$("#amountdiv").addClass("loading");
	if(type != "" && fee_cat != "" && new_old != "") {
		$("#amountdiv").removeClass("loading");
		$("#amountdiv").load("function/feeamountfunctions?getamount", {var1:type, var2:fee_cat, var3:new_old});
		$("#submitbtn").css("display", "block");
	} else {
		$("#amountdiv").removeClass("loading");
		$("#amountdiv").html("");
		$("#submitbtn").css("display", "none");
	}
}

$('#fee-form').submit(function(event) {
	event.preventDefault();
	var checkedAtLeastOne = false;
	$('input[type="checkbox"]').each(function() {
		if ($(this).is(":checked")) {
			checkedAtLeastOne = true;
		}
	});
	if(checkedAtLeastOne == true) {
		$.ajax({
			type: 'POST',
			url: './function/feeamountfunctions?submitamount',
			data: $(this).serialize(),
			success: function (data) {
				//console.log(data);
				$.notify({message: '<strong>Successfully</strong> updated the information.' },{type: 'success'});
				get_fee();
			}
		});
	} else {
		$.notify({message: '<strong>Select at least one class</strong>.' },{type: 'danger'});
	}
});
</script>


</div>
</div> <!-- /container -->
<?php
include('footer.php');
?>