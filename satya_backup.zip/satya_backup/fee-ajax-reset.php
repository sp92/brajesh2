<?php

require('core.php');

if($_REQUEST['reset']  == 'reset'){

	$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
	if(!empty($head_defineSession)){
		foreach($head_defineSession as $key=>$value){
			
			if (strpos($value['Field'], 'head') !== false) {
				$arr[] = ' DROP '.$value['Field'];
			}
		}
		$arr2 = implode(',', $arr);
		$db->rawQuery('ALTER TABLE '.PREFIX.'head_define '.$arr2.';');
		$db->where('session', $_SESSION['SESSION']);
		$db->delete('head_define');
	}
	$fee_amountArray = $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'fee_amount');
	if(!empty($fee_amountArray)){
		foreach($fee_amountArray as $key=>$value){
			if (strpos($value['Field'], 'head') !== false) {
				$arr1[] = ' DROP '.$value['Field'];
			}
		}
		$arr3 = implode(',', $arr1);
		$db->rawQuery('ALTER TABLE '.PREFIX.'fee_amount '.$arr3.';');
	}
	$fee_paidArray = $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'fee_paid');
	if(!empty($fee_paidArray)){
		foreach($fee_paidArray as $key=>$value){
			if (strpos($value['Field'], 'head') !== false) {
				$feePaid[] = ' DROP '.$value['Field'];
			}
		}
		$feePaidArr = implode(',', $feePaid);
		$db->rawQuery('ALTER TABLE '.PREFIX.'fee_paid '.$feePaidArr.';');

	}
	$stu_custom_feeArray = $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'stu_custom_fee');
	if(!empty($stu_custom_feeArray)){
		foreach($stu_custom_feeArray as $key=>$value){
			if (strpos($value['Field'], 'head') !== false) {
				$custom_fee[] = ' DROP '.$value['Field'];
			}
		}
		$custom_feeArr = implode(',', $custom_fee);
		$db->rawQuery('ALTER TABLE '.PREFIX.'stu_custom_fee '.$custom_feeArr.';');

	}
	$stu_tpt_feeArray = $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'stu_tpt_fee');
	if(!empty($stu_tpt_feeArray)){
		foreach($stu_tpt_feeArray as $key=>$value){
			if (strpos($value['Field'], 'tp') !== false) {
				$stu_tpt_fee[] = ' DROP '.$value['Field'];
			}
		}
		$stu_tpt_feeArr = implode(',', $stu_tpt_fee);
		$db->rawQuery('ALTER TABLE '.PREFIX.'stu_tpt_fee '.$stu_tpt_feeArr.';');

	}
	$discountArray = $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'discount');
	if(!empty($discountArray)){
		foreach($discountArray as $key=>$value){
			if (strpos($value['Field'], 'head') !== false) {
				$discount[] = ' DROP '.$value['Field'];
			}
		}
		$discountArr = implode(',', $discount);
		$db->rawQuery('ALTER TABLE '.PREFIX.'discount '.$discountArr.';');
	}
	echo 1;
}
?>