<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') 
{
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row">
		<h3>Fee Discount</h3>
		<form id="disc-form">
			<input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
			<input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>">	
			<b>Discount Name :</b>
			<input type="text" name="disc_name" value="" />&nbsp;&nbsp;&nbsp;&nbsp;
			<b>Remark :</b> 
			<input type="text" name="remark" value="" />&nbsp;&nbsp;&nbsp;&nbsp;
			<b>Revoke :</b>
			<input type="checkbox" name="revoke" value="YES" />&nbsp;&nbsp;&nbsp;&nbsp;<br /><br />
			<table class="table table-striped table-bordered" style="width:50%">
				<thead>
					<tr>
						<th>Fee Head</th>
						<th>Percentage</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$db->where("session",$_SESSION["SESSION"]);
					$headDefine = $db->getOne("head_define");
					foreach($headDefine as $h=>$bs){
						if (strpos($h, 'head') !== false) { ?>
							<tr>
								<th><?php echo $bs; ?></th>
								<td align="center	">
									<select name="<?php echo $h; ?>">
										<option value="">--</option>
										<option value="10%">10%</option>
										<option value="20%">20%</option>
										<option value="30%">30%</option>
										<option value="40%">40%</option>
										<option value="50%">50%</option>
										<option value="60%">60%</option>
										<option value="70%">70%</option>
										<option value="80%">80%</option>
										<option value="90%">90%</option>
										<option value="100%">100%</option>
									</select>
								</td>
							</tr>
						<?php }
					} ?>
				</tbody>
			</table>
			<button class="btn btn-primary ladda-button kill-evo" type='submit' data-style="zoom-out">
				<span class="ladda-label">Submit</span>
			</button>
		</form>
		<script>
			$('#disc-form').submit(function(event) {
				event.preventDefault();
				var n =  $("input[name=disc_name]").val();
				if(n != ''){
					$.ajax({
						type: 'POST',
						url: './function/feeamountfunctions',
						data: $(this).serialize(),
						success: function (data) {
							//console.log(data);
							$.notify({message: '<strong>Successfully</strong> updated the information.' },{type: 'success'});
							location.reload();
						}
					});
				}
				else{
					$.notify({message: 'Please enter discount name.' },{type: 'danger'});
				}
			});
		</script>
	</div>
</div> <!-- /container -->
<?php
include('footer.php');
?>