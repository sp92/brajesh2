<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') {
	header("Location: main.php");
}

include('header.php');
$session = $_SESSION['SESSION'];
?>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row">
		<h3>Fee Receivable Before Discount</h3>
		<input type="button" onclick="tableToExcel('testTable', 'Student')" value="Export"  />
		<table id="testTable" class="table" style="font-size:11px;">
			<thead>
				<tr>
					<th align="center"><strong>S.No.</strong></th>
					<th align="center" style="width: 66px;"><strong>Adm No.</strong></th>
					<th align="center"><strong>Class</strong></th>
					<th align="center"><strong>Stu. Name</strong></th>
					<th align="center"><strong>Adm. Date</strong></th>
					<th align="center"><strong>Fee Type</strong></th>
					<th align="center"><strong>Prospectus</strong></th>
					<?php
					$sql2 = $db->getOne("head_define");
					foreach($sql2 as $row2=>$val){
						if(strpos($row2, 'head') !== false){
							if($val<>'' AND $val<>NULL)  { ?>
								<th class="tg-na43"><?php echo $val;?></th>
							<?php }
						}
					} ?>
					<th align="center"><strong>Total</strong></th>
					<th align="center"><strong>Remark</strong></th>
				</tr>
			</thead>
			<tbody>
				<?php
				$db->join("seswise_class sc", "s.adm_no = sc.adm_no", "LEFT");
				$db->where ("s.adm_no != ''");
				$db->where ('sc.session', $_SESSION["SESSION"]);
				$stu = $db->get("student s");
				// Old way to get record
				//$db->where("adm_no != ''");
				//$stu = $db->get('student');
				$n=1;
				foreach($stu as $rows){?>
					<tr>
						<td align="center" ><?php echo $n; $n++; ?></td>
						<td align="center"><?php echo $rows['adm_no']; ?></td>
						<td align="center" ><?php echo substr($rows['class'],0,3)."-".$rows['sec']; ?></td>
						<td align="center"><?php echo $rows['stu_name']; ?></td>
						<td align="center" bgcolor="#FFFFFF">
							<?php
							$do_adm = date('d-m-Y', strtotime($rows['do_adm'])); 
							if($do_adm <> '01-01-1970') { 
								echo $do_adm; 
							} ?>
						</td>
						<td align="center"><?php echo $rows['new_old']; ?></td>
						<td align="center">
							<?php if($rows['new_old']=='NEW') { 
								echo 500; 
								$pros[] = 500; 
								$pros = 500; 
							} 
							else { 
								echo 0;
								$pros = 0; 
							} ?>
						</td>
						<td align="center">
							<?php
							foreach($sql2 as $row2=>$val){
								if(strpos($row2, 'head') !== false){
									if($val<>'' AND $val<>NULL)  { ?>
										<th class="tg-na43"><?php echo $val;?></th>
									<?php }
								}
							}
							$head_method2 = mysql_query("SELECT head1_apr, head2_apr, head3_apr, head3_jul, head4_apr, head4_jul, head4_oct FROM ".PREFIX."fee_head2 where class='".$rows['class']."' and old_new='".$rows['new_old']."' and session='".$_SESSION['SESSION']."'") or die(mysql_error());
							$method = mysql_fetch_assoc($head_method2);
							echo $method['head1_apr'];
							$head1_apr[] = $method['head1_apr'];?>
						</td>
						<td align="center"><?php echo $method['head2_apr']; $head2_apr[] = $method['head2_apr']; ?></td>
						<td align="center"><?php echo $method['head3_apr']; $head3_apr[] = $method['head3_apr']; ?></td>
						<td align="center"><?php echo $method['head3_jul']; $head3_jul[] = $method['head3_jul']; ?></td>
						<td align="center"><?php echo $method['head4_apr']; $head4_apr[] = $method['head4_apr']; ?></td>
						<td align="center"><?php echo $method['head4_jul']; $head4_jul[] = $method['head4_jul']; ?></td>
						<td align="center"><?php echo $method['head4_oct']; $head4_oct[] = $method['head4_oct']; ?></td>
						<td align="center"><?php echo $pros+$method['head1_apr']+$method['head2_apr']+$method['head3_apr']+$method['head3_jul']+$method['head4_apr']+$method['head4_jul']+$method['head4_oct']; ?></td>
						<td align="center"></td>
					</tr>
				<?php }
				?>
			</tbody>
			<thead>
				<tr>
					<th align="center"><strong></strong></th>
					<th align="center"><strong></strong></th>
					<th align="center"><strong></strong></th>
					<th align="center"><strong></strong></th>
					<th align="center"><strong></strong></th>
					<th align="center"><strong></strong></th>
					<th align="center"><strong><?php echo moneyFormatIndia(array_sum($pros)); ?></strong></th>
					<th align="center"><strong><?php echo moneyFormatIndia(array_sum($head1_apr)); ?></strong></th>
					<th align="center"><strong><?php echo moneyFormatIndia(array_sum($head2_apr)); ?></strong></th>
					<th align="center"><strong><?php echo moneyFormatIndia(array_sum($head3_apr)); ?></strong></th>
					<th align="center"><strong><?php echo moneyFormatIndia(array_sum($head3_jul)); ?></strong></th>
					<th align="center"><strong><?php echo moneyFormatIndia(array_sum($head4_apr)); ?></strong></th>
					<th align="center"><strong><?php echo moneyFormatIndia(array_sum($head4_jul)); ?></strong></th>
					<th align="center"><strong><?php echo moneyFormatIndia(array_sum($head4_oct)); ?></strong></th>
					<th align="center"><strong><?php echo moneyFormatIndia(array_sum($pros)+array_sum($head1_apr)+array_sum($head2_apr)+array_sum($head3_apr)+array_sum($head3_jul)+array_sum($head4_apr)+array_sum($head4_jul)+array_sum($head4_oct));  ?></strong></th>
					<th align="center"><strong></strong></th>
				</tr>
			</thead>
		</table>
		<link rel="stylesheet" type="text/css" href="css/print-style2.css" />
	</div>
</div>
<?php
include('footer.php');
?>