<?php
$page='student';
require('core.php');
if($_SESSION['ACC_STUDENT']=='0') {
	header("Location: main.php");
}

include('header.php');

?>
<div class="container">
	<?php print_menu($student_menu_items); ?>
	<div class="row">
		<h3>Classwise Strength</h3>	
		<?php
		$class = array();
		$section = array();
		$cols = array("class");
		$class = $db->get ("class_master",null,$cols);
		$cols = array("sec");
		$section = $db->get ("sec_master",null,$cols); ?>
		<center>
			<input type="button" onclick="tableToExcel('searchable', 'Student')" value="Export to Excel" style="float:right;padding: 2px;" />
			<?php ob_start();?>
			<table id="searchable" class="table" >
				<thead>
					<tr>
						<th>Class & Sec</th>
						<th>Total</th>
						<th>New</th>
						<th>Old</th>
						<th>Male</th>
						<th>Female</th>
						<th>SC</th>
						<th>ST</th>
						<th>OBC</th>
						<th>GEN</th>
						<th>Hindus</th>
						<th>Muslims</th>
						<th>Sikhs</th>
						<th>Christians</th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach($class as $c_class){
						foreach($section as $sec){
							$cols = array("id");
							$db->where("class<>'OUT'");
							$db->where("tc_issue<>'YES'");
							$db->where("class", $c_class['class']);
							$db->where("sec", $sec['sec']);
							$db->where("is_shown", 'YES');
							$db->where("session", $_SESSION['SESSION']);
							$db->get('student', null, $cols);
							if($db->count>0) {?>
								<tr align="center">
									<td  align="center"><?php echo $c_class['class']." - ".$sec['sec']; ?></td>
									<td align="center"><?php echo $total[] = $db->count;?></td>
									<td align="center"><?php 
										$cols = array("id");
										$db->where("class<>'OUT'");
										$db->where("tc_issue<>'YES'");
										$db->where("class", $c_class['class']);
										$db->where("sec", $sec['sec']);
										$db->where("is_shown", 'YES');
										$db->where("new_old", 'NEW');
										$db->where("session", $_SESSION['SESSION']);
										$db->get('student', null, $cols);
										echo $new[] = $db->count;?>
									</td>
									<td align="center"><?php 
										$cols = array("id");
										$db->where("class<>'OUT'");
										$db->where("tc_issue<>'YES'");
										$db->where("class", $c_class['class']);
										$db->where("sec", $sec['sec']);
										$db->where("is_shown", 'YES');
										$db->where("new_old", 'OLD');
										$db->where("session", $_SESSION['SESSION']);
										$db->get('student', null, $cols);
										echo $old[] = $db->count;?>
									</td>	
									<td align="center"><?php 
										$cols = array("id");
										$db->where("class<>'OUT'");
										$db->where("tc_issue<>'YES'");
										$db->where("class", $c_class['class']);
										$db->where("sec", $sec['sec']);
										$db->where("is_shown", 'YES');
										$db->where("gender", 'M');
										$db->where("session", $_SESSION['SESSION']);
										$db->get('student', null, $cols);
										echo $male[] = $db->count;?>
									</td>
									<td align="center"><?php 
										$cols = array("id");
										$db->where("class<>'OUT'");
										$db->where("tc_issue<>'YES'");
										$db->where("class", $c_class['class']);
										$db->where("sec", $sec['sec']);
										$db->where("is_shown", 'YES');
										$db->where("gender", 'F');
										$db->where("session", $_SESSION['SESSION']);
										$db->get('student', null, $cols);
										echo $female[] = $db->count;?>
									</td>
									<td align="center"><?php 
										$cols = array("id");
										$db->where("class<>'OUT'");
										$db->where("tc_issue<>'YES'");
										$db->where("class", $c_class['class']);
										$db->where("sec", $sec['sec']);
										$db->where("is_shown", 'YES');
										$db->where("category", 'SC');
										$db->where("session", $_SESSION['SESSION']);
										$db->get('student', null, $cols);
										echo $sc[] = $db->count;?>
									</td>
									<td align="center"><?php 
									$cols = array("id");
										$db->where("class<>'OUT'");
										$db->where("tc_issue<>'YES'");
										$db->where("class", $c_class['class']);
										$db->where("sec", $sec['sec']);
										$db->where("is_shown", 'YES');
										$db->where("category", 'ST');
										$db->where("session", $_SESSION['SESSION']);
										$db->get('student', null, $cols);
										echo $st[] = $db->count;?>
									</td>
									<td align="center"><?php 
									$cols = array("id");
										$db->where("class<>'OUT'");
										$db->where("tc_issue<>'YES'");
										$db->where("class", $c_class['class']);
										$db->where("sec", $sec['sec']);
										$db->where("is_shown", 'YES');
										$db->where("category", 'OBC');
										$db->where("session", $_SESSION['SESSION']);
										$db->get('student', null, $cols);
										echo $obc[] = $db->count;?>
									</td>
									<td align="center"><?php 
									$cols = array("id");
										$db->where("class<>'OUT'");
										$db->where("tc_issue<>'YES'");
										$db->where("class", $c_class['class']);
										$db->where("sec", $sec['sec']);
										$db->where("is_shown", 'YES');
										$db->where("category", 'GENERAL');
										$db->where("session", $_SESSION['SESSION']);
										$db->get('student', null, $cols);
										echo $gen[] = $db->count;?>
									</td>
									<td align="center"><?php 
									$cols = array("id");
										$db->where("class<>'OUT'");
										$db->where("tc_issue<>'YES'");
										$db->where("class", $c_class['class']);
										$db->where("sec", $sec['sec']);
										$db->where("is_shown", 'YES');
										$db->where("religion", 'HINDU');
										$db->where("session", $_SESSION['SESSION']);
										$db->get('student', null, $cols);
										echo $hindu[] = $db->count;?>
									</td>
									<td align="center"><?php 
									$cols = array("id");
										$db->where("class<>'OUT'");
										$db->where("tc_issue<>'YES'");
										$db->where("class", $c_class['class']);
										$db->where("sec", $sec['sec']);
										$db->where("is_shown", 'YES');
										$db->where("religion", 'MUSLIM');
										$db->where("session", $_SESSION['SESSION']);
										$db->get('student', null, $cols);
										echo $muslim[] = $db->count;?>
									</td>
									<td align="center"><?php 
									$cols = array("id");
										$db->where("class<>'OUT'");
										$db->where("tc_issue<>'YES'");
										$db->where("class", $c_class['class']);
										$db->where("sec", $sec['sec']);
										$db->where("is_shown", 'YES');
										$db->where("religion", 'SIKH');
										$db->where("session", $_SESSION['SESSION']);
										$db->get('student', null, $cols);
										echo $sikh[] = $db->count;?>
									</td>
									<td align="center"><?php 
									$cols = array("id");
										$db->where("class<>'OUT'");
										$db->where("tc_issue<>'YES'");
										$db->where("class", $c_class['class']);
										$db->where("sec", $sec['sec']);
										$db->where("is_shown", 'YES');
										$db->where("religion", 'CHRISTIAN');
										$db->where("session", $_SESSION['SESSION']);
										$db->get('student', null, $cols);
										echo $christ[] = $db->count;?>
									</td>
								</tr>
							<?php }
						}
					} ?>
					<tr align="right">
						<td><h4>Total Strength : </h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($total); ?></span></h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($new); ?></span></h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($old); ?></span></h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($male); ?></span></h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($female); ?></span></h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($sc); ?></span></h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($st); ?></span></h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($obc); ?></span></h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($gen); ?></span></h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($hindu); ?></span></h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($muslim); ?></span></h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($sikh); ?></span></h4></td>
						<td align=center><h4><span style="color:red;"><?php echo array_sum($christ); ?></span></h4></td>
					</tr>
				</tbody>
			</table>
		</center>
	</div>
</div> <!-- /container -->
<?php
include('footer.php');
?>