<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') {
	header("Location: main.php");
}
include('header.php');
$session = $_SESSION['SESSION'];
?><br>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row">
		<h3>Transactions Report</h3>
		<form name="myForm" onsubmit="return(validate());" method="get" action="fee-view-trasaction">
			<table style="font-size: 14px;width:100%;">
				<tr>
					<td style="border-bottom: none!important;"> From : 
						<input name="from_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["from_date"]; ?>" class="datepicker" style="width: 100px;" readonly />  
					</td>
					<td style="border-bottom: none!important;">To : 
						<input name="to_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["to_date"]; ?>" class="datepicker" style="width: 100px;" readonly /> 
					</td>
					<td style="border-bottom: none!important;">Record Type : 
						<select name="fee_option">
							<option value="ALL"><b>ALL</b> Transactions</option>
							<option value="FEE" <?php if($_REQUEST['fee_option']=='FEE') { echo "selected"; } ?> ><b>FEE</b> only</option>
							<option value="EXTRA" <?php if($_REQUEST['fee_option']=='EXTRA') { echo "selected"; } ?> ><b>EXTRA</b> only</option>
							<option value="LAST" <?php if($_REQUEST['fee_option']=='LAST') { echo "selected"; } ?> ><b>LAST YEAR DUES</b> only</option>
						</select>
					</td>
					<td style="border-bottom: none!important;">Order : 
						<select name="order">
							<option value="rec_no">Rec. No.</option>
							<option value="adm_no">Adm. No.</option>
						</select>
					</td>
					<td style="border-bottom: none!important;">
						<input type="submit" name="submit" value="SUBMIT" />
					</td>
				</tr>
			</table>	
		</form><hr/>
		<?php ob_start(); ?>
		<link rel="stylesheet" type="text/css" href="css/print-style2.css" />
		<table id="testTable" class="table" style="font-size:11px;width:100%;">
			<thead>
				<tr>
					<th align="center"><strong>Sr.</strong></th>
					<th align="center" style="width: 50px;"><strong>Rec.No.</strong></th>
					<th align="center" style="width: 100px;"><strong>Adm No.</strong></th>
					<th align="center" style="width: 150px;"><strong>Student Name</strong></th>
					<th align="center" style="width: 75px;"><strong>Class</strong></th>
					<th align="center" style="width: 100px;"><strong>Month</strong></th>
					<?php
					$headis2 = $db->rawQuery("SELECT * FROM ".PREFIX."head_define");
					if($_REQUEST['fee_option']<>'TRANSPORT') {
						$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
						if(!empty($head_defineSession)){
							foreach($head_defineSession as $key=>$value){
								if (strpos($value['Field'], 'head') !== false) {
									$headNameArr[] = $value['Field'];
									$v = $value['Field'];
									if($headis2[0][$v]<>'' AND $headis2[0][$v]<>NULL) { ?>
										<th align="center"><strong><?php echo substr($headis2[0][$v],0,3); ?></strong></th>
									<?php }
								}
							}
						}
					}
					if($headis2[0]['transport']<>'' AND $headis2[0]['transport']<>NULL) { ?>
						<th align="center"><strong><?php echo substr($headis2[0]['transport'],0,3); ?></strong></th>
					<?php } ?>
					<th align="center"><strong>Amount</strong></th>
					<th align="center"><strong>Disc.</strong></th>
					<th align="center"><strong>Late</strong></th>
					<th align="center"><strong>Mode</strong></th>
					<th align="center"><strong>User</strong></th>
					<th align="center"><strong>Total</strong></th>
				</tr>
			</thead>
			<tbody>
				<?php
				$from_date = datestamp($_REQUEST["from_date"]);
				$to_date = datestamp($_REQUEST["to_date"]);
				$extra = $_REQUEST["extra"];
				if(isset($_REQUEST["fee_option"]) AND $_REQUEST['fee_option']=='FEE'){ 
					$extra = " type='fee' and "; 
				}
				if(isset($_REQUEST["fee_option"]) AND $_REQUEST['fee_option']=='EXTRA'){ 
					$fee = " type='extra' and "; 
				}
				if(isset($_REQUEST["fee_option"]) AND $_REQUEST['fee_option']=='LAST'){ 
					$last = " type='LAST' and "; 
				}
				$fee_option = $_REQUEST["fee_option"];
				if($_REQUEST["order"] == ''){
					$order = 'id';
				}else{
					$order = $_REQUEST["order"];
				}
				foreach($headNameArr as $hn){
					${$hn."_t"} = array();
					${$hn."_ct"} = array();
					$query = $query."sum(".$hn.") as ".$hn.","; 
				}
				$amount_t=array();
				$headRow=array();
				$disc_t=array();
				$late_t=array();
				$rec_t=array();

				$amount_ct=array();
				$disc_ct=array();
				$late_ct=array();
				$rec_ct=array();
				$grand_t=array();
				
				function createDateRangeArray($strDateFrom,$strDateTo){
					$aryRange=array();
					$iDateFrom=mktime(1,0,0,substr($strDateFrom,5,2),     substr($strDateFrom,8,2),substr($strDateFrom,0,4));
					$iDateTo=mktime(1,0,0,substr($strDateTo,5,2),     substr($strDateTo,8,2),substr($strDateTo,0,4));
					if ($iDateTo>=$iDateFrom) {
						array_push($aryRange,date('Y-m-d',$iDateFrom)); // first entry
						while ($iDateFrom<$iDateTo) {
							$iDateFrom+=86400; // add 24 hours
							array_push($aryRange,date('Y-m-d',$iDateFrom));
						}
					}
					return $aryRange;
				}
				$date = createDateRangeArray($from_date,$to_date);
				$session = $_SESSION['SESSION'];
				foreach($date as $go){
					if($fee_option =="ALL"){
						$sql_result = $db->rawQuery("SELECT id,type,rec_no,rec_date,adm_no,month,particular, sum(transport) as transport2, ".$query." sum(amount) as amount2,cancelled,location,mode,user,chq_no,chq_date,chq_bnk,cash_amt,sum(chq_amt) as chq_amt,chq_clr,remark,transport,sum(discount) as discount2,sum(late_fine) as late_fine,session FROM ".PREFIX."fee_paid WHERE ".$extra.$fee.$last." rec_date = '" . $go . "' and session='".$session."' and type not in ('TRANSPORT','LAST-TP') group by rec_no ORDER by ".$order." asc");
					}
					else{
						$sql_result = $db->rawQuery("SELECT id,type,rec_no,rec_date,adm_no,month,particular, sum(transport) as transport2, ".$query." sum(amount) as amount2,cancelled,location,mode,user,chq_no,chq_date,chq_bnk,cash_amt,sum(chq_amt) as chq_amt,chq_clr,remark,transport,sum(discount) as discount2,sum(late_fine) as late_fine,session FROM ".PREFIX."fee_paid WHERE ".$extra.$fee.$last." rec_date = '" . $go . "' and session='".$session."' and type not in ('TRANSPORT','LAST-TP') AND location='SCHOOL OFFICE' group by rec_no  ORDER by ".$order." asc");
					}
					if($db->count == 0){ echo ""; }
					else{
						$n = 1; ?>
						<tr>
							<td colspan="6" style="font-size:14px; font-weight:bold;">Dated : <?php echo date('d F, Y', strtotime($go)); ?></td>
							<?php
							$headis2 = $db->rawQuery("SELECT * FROM ".PREFIX."head_define");
							if($_REQUEST['fee_option']<>'TRANSPORT') {
								$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
								if(!empty($head_defineSession)){
									foreach($head_defineSession as $key=>$value){
										if (strpos($value['Field'], 'head') !== false) {
											$headNameArr[] = $value['Field'];
											$v = $value['Field'];
											if($headis2[0][$v]<>'' AND $headis2[0][$v]<>NULL) { ?>
												<td></td>
											<?php }
										}
									}
								}
							}
							if($headis2[0]['transport']<>'' AND $headis2[0]['transport']<>NULL) { ?>
								<td></td>
							<?php } ?>								
							<td colspan="6"></td>
						</tr>
						<?php
						$n=1;
						foreach($sql_result as $row) {
							if($row['cancelled'] == 1) { ?>
								<tr style="background-color:lightyellow;font-weight:bold;">
									<td></td>
									<td align="center">
										<?php
										$rec_loc = $db->rawQuery("SELECT * FROM ".PREFIX."location where location='".$row['location']."'");
										foreach($rec_loc as $rec_loc2){
											echo $rec_loc2['code']."-".$row['rec_no']; 
										} ?>
									</td>
									<td align="center"><?php echo $row['adm_no']; ?></td>
									<td align="center">
										<?php
										$rec_stu = $db->rawQuery("SELECT stu_name,class,sec FROM ".PREFIX."student where adm_no='".$row['adm_no']."'");
										echo $rec_stu[0]['stu_name'] ; ?>
									</td>
									<td align="center"><?php echo $rec_stu[0]['class']."-".$rec_stu[0]['sec'] ; ?></td>
									<td align="center"><?php 
										$sql2 = $db->rawQuery("SELECT month from ".PREFIX."fee_paid where rec_no='".$row['rec_no']."' and location='SCHOOL OFFICE'");
										$month_rec = array();
										foreach($sql2 as $row2){
											$month_rec[]=$row2['month'];
										}
										if(fee_coll_type=='MONTHLY'){
											$count = $db->count;
											if($count == 1){
												$start = reset($month_rec);
												echo substr($start,0,3);
											}
											if($count > 1){
												$start = reset($month_rec);
												$end = end($month_rec);
												echo substr($start,0,3)."-".substr($end,0,3);
											}
										}
										if(fee_coll_type=='QUARTERLY'){
											$month_rec = str_replace("APRIL","I",$month_rec);
											$month_rec = str_replace("MAY","I",$month_rec);
											$month_rec = str_replace("JUNE","I",$month_rec);
											$month_rec = str_replace("JULY","II",$month_rec);
											$month_rec = str_replace("AUGUST","II",$month_rec);
											$month_rec = str_replace("SEPTEMBER","II",$month_rec);
											$month_rec = str_replace("OCTOBER","III",$month_rec);
											$month_rec = str_replace("NOVEMBER","III",$month_rec);
											$month_rec = str_replace("DECEMBER","III",$month_rec);
											$month_rec = str_replace("JANUARY","IV",$month_rec);
											$month_rec = str_replace("FEBRUARY","IV",$month_rec);
											$month_rec = str_replace("MARCH","IV",$month_rec);
											$count = count(array_unique($month_rec));
											if($count == 1){
												echo "TERM ".$month_rec[0];
											}
											if($count>1){
												echo "TERM ".$month_rec[0]." - ".end($month_rec);
											}
										}?>
									</td>
									<?php
									$headis2 = $db->rawQuery("SELECT * FROM ".PREFIX."head_define");
									if($_REQUEST['fee_option']<>'TRANSPORT') {
										$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
										if(!empty($head_defineSession)){
											foreach($head_defineSession as $key=>$value){
												if (strpos($value['Field'], 'head') !== false) {
													$headNameArr[] = $value['Field'];
													$v = $value['Field'];
													if($headis2[0][$v]<>'' AND $headis2[0][$v]<>NULL) { ?>
														<td align="center"><?php echo $row[$v]; ?></td>
													<?php }
												}
											}
										}
									}
									if($headis2[0]['transport']<>'' AND $headis2[0]['transport']<>NULL) { ?>
										<td align="center"><?php echo $row['transport2']; ?></td>
									<?php } ?>
									<td align="center"><?php echo $row['amount2']; ?></td>
									<td align="center"><?php echo $row['discount2']; ?> </td>
									<td align="center"><?php echo $row['late_fine']; ?> </td>
									<td align="center"><?php echo $row['mode']; ?> </td>
									<td align="center" style="font-size:9px;"><?php echo $row['user']; ?> </td>
									<td align="center">Cancel</td>
								</tr>
							<?php }
							else { ?>
								<tr>
									<td align="center"><?php echo $n; $n++; ?></td>
									<td align="center"><?php 
										$rec_loc = $db->rawQuery("SELECT * FROM ".PREFIX."location where location='".$row['location']."'");
										foreach($rec_loc as $rec_loc2){
												echo $rec_loc2['code']."-".$row['rec_no']; 
										} ?>
									</td>
									<td align="center"><?php echo $row['adm_no']; ?></td>
									<td align="center">
										<?php
										$rec_stu = $db->rawQuery("SELECT stu_name,class,sec FROM ".PREFIX."student where adm_no='".$row['adm_no']."'");
										echo $rec_stu[0]['stu_name'] ; ?></td>
									<td align="center"><?php echo $rec_stu[0]['class']."-".$rec_stu[0]['sec'] ; ?></td>
									<td align="center"><?php 
										$sql2 = $db->rawQuery("SELECT month from ".PREFIX."fee_paid where rec_no='".$row['rec_no']."'  and type not in ('TRANSPORT','LAST-TP') and session ='".$_SESSION['SESSION']."'");
										$month_rec = array();
										foreach($sql2 as $row2) {
											$month_rec[]=$row2['month'];
										}
										if($row['type'] == 'FEE' or $row['type'] == 'TRANSPORT' ) {
											if(fee_coll_type == 'MONTHLY'){
												$count = $db->count;
												if($count == 1){
													$start = reset($month_rec);
													echo substr($start,0,3);
												}
												if($count>1){
													$start = reset($month_rec);
													$end = end($month_rec);
													echo substr($start,0,3)."-".substr($end,0,3);
												}
											}
											if(fee_coll_type == 'QUARTERLY'){
												$month_rec = str_replace("APRIL","I",$month_rec);
												$month_rec = str_replace("MAY","I",$month_rec);
												$month_rec = str_replace("JUNE","I",$month_rec);
												$month_rec = str_replace("JULY","II",$month_rec);
												$month_rec = str_replace("AUGUST","II",$month_rec);
												$month_rec = str_replace("SEPTEMBER","II",$month_rec);
												$month_rec = str_replace("OCTOBER","III",$month_rec);
												$month_rec = str_replace("NOVEMBER","III",$month_rec);
												$month_rec = str_replace("DECEMBER","III",$month_rec);
												$month_rec = str_replace("JANUARY","IV",$month_rec);
												$month_rec = str_replace("FEBRUARY","IV",$month_rec);
												$month_rec = str_replace("MARCH","IV",$month_rec);
												$count=count(array_unique($month_rec));
												if($count == 1){
													echo "TERM ".$month_rec[0];
												}
												if($count>1){
													echo "TERM ".$month_rec[0]." - ".end($month_rec);
												}
											}
											$month_rec[]=NULL;
										}
										if($row['type'] == 'EXTRA' or $row['type'] == 'LAST') {
											echo "<span style='font-size:9px;'>".$row['particular']."</span>";
										} ?>
									</td>
									<?php
									$headis2 = $db->rawQuery("SELECT * FROM ".PREFIX."head_define");
									if($_REQUEST['fee_option']<>'TRANSPORT') {
										$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
										if(!empty($head_defineSession)){
											foreach($head_defineSession as $key=>$value){
												if (strpos($value['Field'], 'head') !== false) {
													$headNameArr[] = $value['Field'];
													$v = $value['Field'];
													if($headis2[0][$v]<>'' AND $headis2[0][$v]<>NULL) { ?>
														<td align="center">
															<?php 
															echo $row[$v]; 
															${$value["Field"]."_t"}[] = $row[$v];
															${$value["Field"]."_ct"}[] = $row[$v]; ?>
														</td>
													<?php }
												}
											}
										}
									}
									if($headis2[0]['transport']<>'' AND $headis2[0]['transport']<>NULL) { ?>
										<td align="center"><?php echo $row['transport2']; $transport_t[]=$row['transport2'];  $transport_ct[]=$row['transport2']; ?></td>
									<?php } ?>
									<td align="center"><?php 
									//echo "<pre>";
									//print_r($row);
										if($row['type']=='FEE' or  $row['type']=='TRANSPORT' ) {
											foreach($headNameArr as $hn){
												//$amount_t[] = $row["amount2"];
												//$amount_ct[] = $row["amount2"];
											}
											$amount_t[] = $row["amount2"];
											//$amount_t[] = $row['transport2'];
											$amount_ct[] = $row["amount2"];
											//$amount_ct[] = $row['transport2'];
											
											echo ($row["amount2"]);
										}
										if($row['type']=='EXTRA' or $row['type']=='LAST' ) {
											echo $row['amount2'];
											$amount_t[] = $row['amount2'];
											$amount_ct[] = $row['amount2'];
										} ?>
									</td>
									<td align="center">	
										<?php 
										echo $row['discount2']; 
										$disc_t[] = $row['discount2']; 
										$disc_ct[] = $row['discount2']; ?> 
									</td>
									<td align="center">
										<?php 
										echo $row['late_fine']; 
										$late_t[] = $row['late_fine']; 
										$late_ct[] = $row['late_fine']; ?> 
									</td>
									<td align="center"><?php echo $row['mode']; ?> </td>
									<td align="center" style="font-size:9px;"><?php echo $row['user']; ?> </td>
									<td align="center"><?php 
										if($row['type']=='FEE'  or $row['type']=='TRANSPORT' ) {
											foreach($headNameArr as $hn){
												//$recRow[] = $row[$hn];
												//$rec_t[] = $row[$hn];
												//$rec_ct[] = $row[$hn];
											}
											$recRowSum = $row["amount2"];
											$rec_tSum = $row["amount2"];
											$rec_ctSum = $row["amount2"];
											
											//$recRowSum = array_sum($recRow);
											echo $recRowSum + $row['late_fine']-$row['discount2'];
											//$rec_tSum = array_sum($rec_t);
											$rec_tSum1[] = $rec_tSum + $row['late_fine']-$row['discount2'];
											//$rec_ctSum = array_sum($rec_ct);
											$rec_ctSum1[] = $rec_ctSum + $row['late_fine']-$row['discount2'];
										}
										if($row['type'] == 'EXTRA' or $row['type'] == 'LAST' ) {
											echo $row['amount2']-$row['discount2'];
											$rec_t[] = $row['amount2']-$row['discount2'];
											$rec_ct[] = $row['amount2']-$row['discount2'];
										} ?> 
									</td>
								</tr>
							<?php }
						} ?>
						<tr style="font-weight:bold;">
							<td align="center" style="background-color:rgb(240, 255, 255);"></td>
							<td align="center" style="background-color:rgb(240, 255, 255);"></td>
							<td align="center" style="background-color:rgb(240, 255, 255);"></td>
							<td align="center" style="background-color:rgb(240, 255, 255);"></td>
							<td align="center" style="background-color:rgb(240, 255, 255);"></td>
							<td align="center" style="background-color:rgb(240, 255, 255);">Total</td>
							<?php
							//print_r($rec_tSum1);
							$headis21 = $db->rawQuery("SELECT * FROM ".PREFIX."head_define");
							if($_REQUEST['fee_option']<>'TRANSPORT') {
								$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
								if(!empty($head_defineSession)){
									foreach($head_defineSession as $key=>$value1){
										if (strpos($value1['Field'], 'head') !== false) {
											$v1 = $value1['Field']."_t";
											if($headis21[0][$value1['Field']]<>'' AND $headis21[0][$value1['Field']]<>NULL) { ?>
												<td align="center" style="background-color:rgb(240, 255, 255);"><?php echo array_sum($$v1); ?></td>
											<?php }
										}
									}
								}
							}
							if($headis2[0]['transport']<>'' AND $headis2[0]['transport']<>NULL) { ?>
								<td align="center" style="background-color:rgb(240, 255, 255);"><?php echo array_sum($transport_ct); ?></td>
							<?php } ?>
							<td align="center" style="background-color:rgb(240, 255, 255);"><?php echo array_sum($amount_ct); ?></td>
							<td align="center" style="background-color:rgb(240, 255, 255);"><?php echo array_sum($disc_ct); ?></td>
							<td align="center" style="background-color:rgb(240, 255, 255);"><?php echo array_sum($late_ct); ?></td>
							<td align="center" style="background-color:rgb(240, 255, 255);"></td>
							<td align="center" style="background-color:rgb(240, 255, 255);"></td>
							<td align="center" style="background-color:rgb(240, 255, 255);"><?php echo array_sum($rec_tSum1); ?></td>
						</tr>
						<?php
						foreach($headNameArr as $hn){
							unset(${$hn."_t"}); 
						}
						
						unset($rec_tSum1);
						unset($transport_ct);
						unset($amount_ct);
						unset($disc_ct);
						unset($late_ct);
						unset($rec_ct);
					}
				}
				$location = "SCHOOL OFFICE";
				$total = $db->rawQuery("SELECT sum(amount) FROM ".PREFIX."fee_paid WHERE rec_date BETWEEN '" . $from_date . "' AND  '" . $to_date . "' AND location='".$location."'"); ?>
				<tr style="font-weight:bold;">
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"><b>Grand Total</b></td>
					<?php
					$headis21 = $db->rawQuery("SELECT * FROM ".PREFIX."head_define");
					if($_REQUEST['fee_option']<>'TRANSPORT') {
						$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
						if(!empty($head_defineSession)){
							foreach($head_defineSession as $key=>$value1){
								if (strpos($value1['Field'], 'head') !== false) {
									$v1 = $value1['Field']."_ct";
									if($headis21[0][$value1['Field']]<>'' AND $headis21[0][$value1['Field']]<>NULL) { ?>
										<td align="center" bgcolor="#f7f6f0"><?php echo array_sum($$v1); ?></td>
									<?php }
								}
							}
						}
					}
					if($headis2[0]['transport']<>'' AND $headis2[0]['transport']<>NULL) { ?>
						<td align="center" bgcolor="#f7f6f0"><?php echo array_sum($transport_t); ?></td>
					<?php } ?>
					<td align="center" bgcolor="#f7f6f0"><?php echo array_sum($amount_t); ?></td>
					<td align="center" bgcolor="#f7f6f0"><?php echo array_sum($disc_t); ?></td>
					<td align="center" bgcolor="#f7f6f0"><?php echo array_sum($late_t); ?></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"><?php echo array_sum($rec_ctSum1); ?></td>
				</tr>
				<tr>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<?php
					$headis2 = $db->rawQuery("SELECT * FROM ".PREFIX."head_define");
					if($_REQUEST['fee_option']<>'TRANSPORT') {
						$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
						if(!empty($head_defineSession)){
							foreach($head_defineSession as $key=>$value){
								if (strpos($value['Field'], 'head') !== false) {
									$headNameArr[] = $value['Field'];
									$v = $value['Field'];
									if($headis2[0][$v]<>'' AND $headis2[0][$v]<>NULL) { ?>
										<td align="center" bgcolor="#f7f6f0"></td>
									<?php }
								}
							}
						}
					}
					if($headis2[0]['transport']<>'' AND $headis2[0]['transport']<>NULL) { ?>
						<td align="center" bgcolor="#f7f6f0"></td>
					<?php } ?>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" colspan="3" bgcolor="#f7f6f0"><b>Cheque Amount</b></td>
					<td align="center" bgcolor="#f7f6f0"><b><?php
						if($fee_option =="ALL"){
							$chq_amt = $db->rawQuery("SELECT sum(chq_amt) FROM ".PREFIX."fee_paid WHERE ".$extra.$fee.$transport."  rec_date BETWEEN '" . $from_date . "' AND  '" . $to_date . "' ".$byuser." and cancelled<>'YES' and session='".$session."'");
							echo array_sum($chq_amt);
							$chq_amt = array_sum($chq_amt);
						}
						else {
							$chq_amt = $db->rawQuery("SELECT sum(chq_amt) FROM ".PREFIX."fee_paid WHERE ".$extra.$fee.$last."  rec_date BETWEEN '" . $from_date . "' AND  '" . $to_date . "' ".$byuser." AND location='SCHOOL OFFICE' and cancelled<>'YES' and session='".$session."'");
							echo array_sum($chq_amt);
							$chq_amt = array_sum($chq_amt);
						} ?></b>
					</td>
				</tr>
				<tr>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" bgcolor="#f7f6f0"></td>
					<?php
					$headis2 = $db->rawQuery("SELECT * FROM ".PREFIX."head_define");
					if($_REQUEST['fee_option']<>'TRANSPORT') {
						$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
						if(!empty($head_defineSession)){
							foreach($head_defineSession as $key=>$value){
								if (strpos($value['Field'], 'head') !== false) {
									$headNameArr[] = $value['Field'];
									$v = $value['Field'];
									if($headis2[0][$v]<>'' AND $headis2[0][$v]<>NULL) { ?>
										<td align="center" bgcolor="#f7f6f0"></td>
									<?php }
								}
							}
						}
					}
					if($headis2[0]['transport']<>'' AND $headis2[0]['transport']<>NULL) { ?>
						<td align="center" bgcolor="#f7f6f0"></td>
					<?php } ?>
					<td align="center" bgcolor="#f7f6f0"></td>
					<td align="center" colspan="3" bgcolor="#f7f6f0"><b>Cash In Hand</b></td>
					<td align="center" bgcolor="#f7f6f0"><b><?php echo array_sum($rec_ctSum1)-$chq_amt; ?></b></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
<?php
include('footer.php');
?>