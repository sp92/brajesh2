<?php
$page='master';
include('core.php');
if($_SESSION['ACC_MASTER']=='0') 
{
	header("Location: main.php");
}
//Code to Add & Delete Route

//Code to Add & Delete Stop
if(@$_REQUEST['hdnCmd']=="ADDSTOP")
	{
	    $stop = clean($_REQUEST['stop']);  
	    $amount = clean($_REQUEST['amount']);  
		$data = Array (
			'stop' => $stop,
			'amount' => $amount,
			'session' => $_SESSION['SESSION']
		); 
		$db->insert ('stop_master', $data);
		header("Location: ./master-stop");
	}
if(@$_REQUEST['action']=="delstop")
	{
		$db->where('id', round($_REQUEST['id']));
		$db->delete('stop_master');
		header("Location: ./master-stop");
	}
include('header.php');
?>
<div class="container">
<?php print_menu($master_menu_items); ?>
<div class="row">
	<h3>Stop Master</h3>
	
	<div class="col-md-12">

	
	<form class="form-inline" role="form" action="master-stop" method="post">
<input type="hidden" name="hdnCmd" value="ADDSTOP">
  
    <div class="form-group">
    <label for="exampleInputEmail2">Stop Name : </label>
	<input type="text" name="stop"  required="">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword2">Amount : </label>
    <input type="text" name="amount" style="width: 75px;"  required />
  </div>
  <button type="submit" class="btn btn-default">Add Record</button>
</form>

<p class="text-danger">Please Enter Amount on Monthly Basis.</p>
<center>
<table class="table table-striped table-hover table-bordered">
<thead>
<tr>
<th style="width:20px;">SR</th>

<th style="width:150px;">Stop</th>
<th style="width:100px;">Amount</th>
<th style="width:100px;">Update</th>
</tr>
</thead>
<tbody>
				
<?php
$n=1;
	if(isset($_REQUEST['route'])) { 
		$db->where ('route', $_REQUEST['route']);
	}
	$user = $db->get ("stop_master");
		if ($db->count > 0) {
		foreach ($user as $u) { 
			
	
?>
<tr>
<td><?php echo $n; $n++; ?></td>

<td><?php echo $u['stop']; ?></td>
<td><?php echo $u['amount']; ?></td>
<td>
<a href="#" onclick="return windowpop('stop-master-edit?id=<?php echo $rows['id']; ?>', 400, 400)" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-edit"></span> Edit</a>
<a href="master-stop?action=delstop&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
</td>
</tr>
		  <?php
			}
		}
		?>	
</table>
</center>
	
	</div>
	
	
    </div>
</div> <!-- /container -->
	
<?php
include('footer.php');
?>