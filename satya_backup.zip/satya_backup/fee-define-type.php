<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') 
{
	header("Location: main.php");
}

error_reporting(0);
if(@$_REQUEST['hdnCmd']=="ADD")
{
	$type=clean($_REQUEST['type']);
	
	if(isset($type) && $type != ''){
		$data = Array (
			'type' => strtoupper($type),
			'session'=> $_SESSION['SESSION']
		);
		$db->insert ('type', $data);
		header("Location: ./fee-define-type");
	}
}
if(@$_REQUEST['action']=="del")
{
	$db->where('id', round($_REQUEST['id']));
	$db->delete('type');
	header("Location: ./fee-define-type");
}
include('header.php');
?>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row">
		<h3>Fee Types</h3>
		<center>
			<table class="table table-striped table-hover table-bordered" style="width:350px;">
				<thead>
					<tr>
						<th style="width:20px;">SR</th>
						<th style="width:150px;">Type</th>
						<th style="width:1px;">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$n=1;
					$fee_type = $db->get ("type");
					if ($db->count > 0) {
						foreach ($fee_type as $u) {  ?>			
							<tr>
								<td><?php echo $n; $n++; ?></td>
								<td><?php echo $u['type']; ?></td>
								<td>
									<a href="fee-define-type?action=del&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
								</td>
							</tr>
							<?php
						}
					} ?>	
					<tr>				
						<td></td>
						<td colspan=2>
							<form action="./fee-define-type" method="post">
								<input type="text" name="type" />
								<input type="hidden" name="hdnCmd" value="ADD"><input type="submit" name="submit" class="btn-primary" value="Add Type" />
							</form>
						</td>
					</tr>	
				</tbody>
			</table>
		</center>
    </div>
</div> <!-- /container -->
<?php
include('footer.php');
?>