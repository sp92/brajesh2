<?php 
$start = microtime(true);
include('lib/config.php'); 
include('function/feedues.php');
include('function/system-master-function-edit.php');
session_name("accevate_erp");
session_start();

include('lib/auth.php'); 

if(!function_exists('print_menu')){
	function print_menu($menu) {
		//echo "<div class='row'><div id='horizontal_nav'>";
		foreach($menu as $m) { echo $m; };
		//echo "</div></div>";
	}
}
if(!function_exists('logAction')){
	function logAction($adm_no, $message){
		global $db;
		$data1 = array(
						"adm_no"=>$adm_no,
						"message"=>$message,
						"user"=>$_SESSION["SESS_NAME"],
						"session"=>$_SESSION["SESSION"],
						"date_time"=> date("Y-m-d h:i:s")
		);
		$id = $db->insert("logactions",$data1);
		return $id;
	}
}
if(!function_exists('acl_check')){
	function acl_check($perm_name, $user_id) {
		global $db;
		$db->where('perm_name', $perm_name);
		$user_ids = $db->getOne ("acl", "user_id");
		$ids = explode(',', $user_ids['user_id']);
		if (in_array($user_id, $ids)) {
			return true;
		} else {
			return false;
		}
	}
}

$m_array = array( 1=> 'apr','may','jun','jul','aug','sep','oct','nov','dec','jan','feb','mar');
$mf_array = array( 1=> 'APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER','JANUARY','FEBRUARY','MARCH');
//$m_array = array( 1=> 'apr','jul','oct','jan');
//$mf_array = array( 1=> 'APRIL','JULY','OCTOBER','JANUARY');
//$label_array = array( 1=> 'QUARTER I','QUARTER II','QUARTER III','QUARTER IV');
?>