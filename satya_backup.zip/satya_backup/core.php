<?php 
$start = microtime(true);
include('lib/config.php'); 
include('function/feedues.php');
include('function/system-master-function-edit.php');
session_name("accevate_erp");
session_start();

include('lib/auth.php'); 

if(!function_exists('print_menu')){
	function print_menu($menu) {
		//echo "<div class='row'><div id='horizontal_nav'>";
		foreach($menu as $m) { echo $m; };
		//echo "</div></div>";
	}
}
if(!function_exists('logAction')){
	function logAction($adm_no, $message){
		global $db;
		$data1 = array(
						"adm_no"=>$adm_no,
						"message"=>$message,
						"user"=>$_SESSION["SESS_NAME"],
						"session"=>$_SESSION["SESSION"],
						"date_time"=> date("Y-m-d h:i:s")
		);
		$id = $db->insert("logactions",$data1);
		return $id;
	}
}
if(!function_exists('acl_check')){
	function acl_check($perm_name, $user_id) {
		global $db;
		$db->where('perm_name', $perm_name);
		$user_ids = $db->getOne ("acl", "user_id");
		$ids = explode(',', $user_ids['user_id']);
		if (in_array($user_id, $ids)) {
			return true;
		} else {
			return false;
		}
	}
}

$m_array = array( 1=> 'apr','may','jun','jul','aug','sep','oct','nov','dec','jan','feb','mar');
$mf_array = array( 1=> 'APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER','JANUARY','FEBRUARY','MARCH');
//$m_array = array( 1=> 'apr','jul','oct','jan');
//$mf_array = array( 1=> 'APRIL','JULY','OCTOBER','JANUARY');
//$label_array = array( 1=> 'QUARTER I','QUARTER II','QUARTER III','QUARTER IV');




/**********this function is create for search student data in bulk action *********/


if(!function_exists(filter_student)){
	function filter_student($search_data){

$fields_search=$search_data;
  

  
/*    for table colum use the query  student table*/

$columns = $db->rawQueryValue('SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA ="erp" AND TABLE_NAME =  "kisalg_student"');

/*******************************/
$filter_array=array();

foreach($fields_search as $search) {
    
    
    if(in_array($search, $columns))
    {

      $val=array_search($search,$columns);
        
        $filter_array[]=$columns["$val"];
        
    }

}
print_r($filter_array);

/* create array for remove the ambiguity */

$array_amb=array("adm_no","class","sec","sssn","new_old");
//print_r($array_amb);

foreach($array_amb as $search_amb) {
	
	
	if(in_array($search_amb, $filter_array))
	{

		 $val=array_search($search_amb,$filter_array);
		
		 $filter_array["$val"]="s.".$search_amb." as "."stu_".$search_amb;
		
	}

}

/****************join the filter table************************/


	$db->join("stu_sess_data sd", "s.id=sd.stu_id", "LEFT");
    $db->where("s.is_shown", 'YES');
    $db->where("s.tc_issue", 'YES', '<>');
    $db->where('sd.session', $_SESSION["SESSION"]);
    $db->where('s.stu_name', '%' . clean($_GET['term']) . '%', 'LIKE');
    $data1 = $db->get("student s", null, $filter_array);
 

/**************************************************************/

	}

}
?>