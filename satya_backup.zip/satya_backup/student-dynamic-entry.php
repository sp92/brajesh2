<?php
$page='student';
require('core.php');
if($_SESSION['ACC_STUDENT']=='0') {
	header("Location: main.php");
}


include('header.php');

?>
<div class="container">
	<?php print_menu($student_menu_items); ?>
	<div class='row'>
		<h3>Student Dynamic Entry</h3>
<form class="form-inline" role="form" action="student-dynamic-entry" method="get">
   <div class="form-group">
    <label for="exampleInputEmail2">Class : </label>
	
						<select name="class">
							<option value="">--</option>
							<?php
							$user = $db->get ("class_master");
							if ($db->count > 0) {
								foreach ($user as $u) { 
							?>			
							<option <?php if($_REQUEST['class'] == $u['class']) { echo 'selected'; }?> value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
							<?php } } ?>	
						</select>
  </div>
    <div class="form-group">
    <label for="exampleInputEmail2">Section : </label>
	<select name="sec">
							<option value="">--</option>
							<?php
							$user = $db->get ("sec_master");
							if ($db->count > 0) {
								foreach ($user as $u) { 
							?>			
							<option <?php if($_REQUEST['sec'] == $u['sec']) { echo 'selected'; }?> value='<?php echo $u['sec']; ?>'><?php echo $u['sec']; ?></option>
							<?php } } ?>	
	                     </select>
    </div>
   <div class="form-group">
    <label for="exampleInputEmail2">Dynamic Head : </label>
<select  name="field">
							<option value="">--</option>
							<?php
							       $db->where ("`default`","0");
							$user = $db->get ("stu_custom_data");
							if ($db->count > 0) {
								foreach ($user as $u) {
									$d_type = $u['type'];
									$d_field = $u['field'];
									
									$datatype[$d_field]=$d_type;
									
							?>			
							<option <?php if($_REQUEST['field'] == $u['field']) { echo 'selected'; }?> value='<?php echo $u['field']; ?>'><?php echo $u['name']; ?></option>
							<?php } } ?>	
						</select>
    </div>
  <div class="form-group">
    <label for="exampleInputEmail2">Order By : </label>
<select name="order">
					    <option value="">--</option>
						<option value="adm_no" <?php if($_REQUEST["order"]=='adm_no') { echo "selected"; } ?>>Admission No.</option>
						<option value="stu_name" <?php if($_REQUEST["order"]=='stu_name') { echo "selected"; } ?>>Student Name</option>
						</select>
    </div>
     <div class="form-group">
    <button type="submit" class="btn btn-default btn-xs">Submit</button>
	</div>
</form>             
 <hr>
<table class="table table-striped table-hover table-bordered">
<thead>
<tr>
             <th style="width:20px;">SR</th>
             <th>Adm No.</th>
             <th>Class</th>
             <th>Student Name</th>
             <th>Section</th>
			
             <th><?php
			    $db->where ("field",$_REQUEST['field']);
				$head = $db->get ("stu_custom_data",null,'name');
			 echo $head[0]['name'];?></th>

</tr>
</thead>
<tbody>
			<?php
			
			   $dyn_field = $_REQUEST['field'];
				$db->where ("class", $_REQUEST["class"]);
				$db->where ("sec", $_REQUEST['sec']);
				if(isset($_REQUEST['order'])){
				$db->orderBy ($_REQUEST['order'],'asc');
				}
				
			//$db->where ("is_shown", 'YES');
			//$db->where ("tc_issue", 'NO');
			$db->where ("session", $_SESSION['SESSION']);
			$students = $db->get('student');
           
			
			$n=1;
			foreach($students as $s){
			?>
				<tr>
					<td align="center"><?php echo $n++; ?></td>
					<td align="center"><?php echo $s['adm_no']; ?></td>
					<td align="center"><?php echo $s['class']; ?></td>
					<td align="center"><?php echo $s['stu_name']; ?></td>
					<td align="center"><?php echo $s['sec']; ?></td>
					
					<td align="center">
					<form class="update">
						<input type="hidden"  name="field" value="<?php echo $dyn_field; ?>" />
						<input type="hidden" name="adm_no" value="<?php echo $s['adm_no']; ?>" />
						<?php if($datatype[$dyn_field]=='DATE') { 
							?>
						<input type="text" readonly data-date-format="dd/mm/yyyy" class="datepicker" name="fielddate" value="<?php echo date("d/m/Y"); strtotime($s[$dyn_field]);?>">
						<?php } if($datatype[$dyn_field]=='VARCHAR') { ?>
						<input type="text" name="field_data" value="<?php echo $s[$dyn_field]; ?>">
						<?php } if($datatype[$dyn_field]=='ENUM') { ?>
						   <select name="field_data">
                            <option value="">--</option>
							<?php
							$db->where ("type", $datatype[$dyn_field]);
							$db->where ("field", $dyn_field);
							$user = $db->getOne ("stu_custom_data");
							$options = explode(",", $user['length']);
								foreach($options as $o) {
							?>			
							<option value="<?php echo $o; ?>" <?php if($o==$s['bg'] ){ echo "selected";}?>> <?php echo $o; ?></option>
						<?php } ?>
						</select>
						<?php } ?>
						<input type="submit" name='data_upd' class="data_upd" value="Update">
					</form>
					</td>
					</tr>
			<?php } ?>
		</tbody>
	</table>
</div>
</div>
<script type="text/javascript">
$(".data_upd").click(function() {
	formdata = $(this).parent(".update").serialize();

	$.ajax({
		type: "POST",
		data: formdata,
		url: "student-dynamic-entry2?dyn_upd",
		cache: false,
		success: function(html){
			console.log(html);
		}
	});
	event.preventDefault();
})   

</script>
<script>
$(function() {
    $( ".datepicker" ).datepicker({
     function() {
   
}
  
    }});
</script>
<?php
include('footer.php');
?>  
