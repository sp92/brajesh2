<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') 
{
	header("Location: main.php");
}

if(isset($_GET)){
	$month = $_GET["month"];
}
else{
	$month = '';
}
$existingADm = $db->rawQuery("SELECT id,adm_no,stu_name FROM ".PREFIX."student where new_old = 'OLD' AND adm_no!= NULL AND session = '2016-2017'");
foreach($existingADm as $existingADmarr){
	$existingADmArry[] = $existingADmarr['adm_no'];
}
$existingADmArryF = array_filter($existingADmArry);
$existingADmStr = implode(",",$existingADmArryF);

$existingADm1 = $db->rawQuery("SELECT id,adm_no,stu_name FROM ".PREFIX."student where new_old = 'NEW' AND session = '2016-2017'");
foreach($existingADm1 as $existingADmarr1){
	$existingADmArry1[] = $existingADmarr1['adm_no'];
}

$existingADmArry1F = array_filter($existingADmArry1);
$existingADmStr1 = implode(",",$existingADmArry1F);

include('header.php');
$session = $_SESSION['SESSION'];
?>

<div class="container">
	<?php print_menu($fee_menu_items); ?>
<div class="row"><br>
	<h3>Month Wise Fee Summary</h3>
	<center>
		<form action="" method="GET">
			<select name="month">
				<option> == </option>
				<option <?php if($month == 'Tsummary'){ echo 'selected'; }?> value="Tsummary"> Total Summary </option>
				<option <?php if($month == 'January'){ echo 'selected'; }?> value="January"> January </option>
				<option <?php if($month == 'february'){ echo 'selected'; }?> value="february"> february </option>
				<option <?php if($month == 'March'){ echo 'selected'; }?> value="March"> March </option>
				<option <?php if($month == 'April'){ echo 'selected'; }?> value="April"> April </option>
				<option <?php if($month == 'May'){ echo 'selected'; }?> value="May"> May </option>
				<option <?php if($month == 'June'){ echo 'selected'; }?> value="June"> June </option>
				<option <?php if($month == 'July'){ echo 'selected'; }?> value="July"> July </option>
				<option <?php if($month == 'August'){ echo 'selected'; }?> value="August"> August </option>
				<option <?php if($month == 'September'){ echo 'selected'; }?> value="September"> September </option>
				<option <?php if($month == 'October'){ echo 'selected'; }?> value="October"> October </option>
				<option <?php if($month == 'November'){ echo 'selected'; }?> value="November"> November </option>
				<option <?php if($month == 'December'){ echo 'selected'; }?> value="December"> December </option>
			</select>
			<input type="submit" name="submit" value="sumit" />
		</form>
		<button onclick="print_pdf();" style="float:right;padding: 2px;">PDF Report</button>
		<?php 
		ob_start(); 
		if($month != 'Tsummary'){ ?>
			<table class="table" style="width:100%;">
				<thead>
					<tr>
						<th>Date</th>
						<th>School fee 2015-2016</th>
						<th>School fee 2016-2017</th>
						<th>School fee Existing Students 2016-2017</th>
						<th>New Student</th>
						<th>Total Collection</th>
						<th>By Cash</th>
						<th>By Cheque</th>
						<th>Other Fees</th>
						<th>Grand Total</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$classArr = $db->rawQuery("SELECT * FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$month."' AND session='2016-2017' group by rec_date");
					foreach($classArr as $classArr1){ ?>
						<tr align="center">
							<td>
								<?php $date = date_create($classArr1["rec_date"]);
								echo date_format($date,"d-m-Y");
								?>
							</td>
							<td>
								<?php 
								$t = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$month."' AND rec_date='".$classArr1["rec_date"]."' AND session='2015-2016'");
								echo $t[0]['amt'] ? $t[0]['amt'] : 0;
								$prevsess[] = $t[0]["amt"];
								?>
							</td>
							<td>
								<?php 					
								$t1 = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$month."' AND rec_date='".$classArr1["rec_date"]."' AND session='2016-2017'");
								echo $t1[0]['amt'] ? $t1[0]['amt'] : 0;
								$currsess[] = $t1[0]["amt"];
								?>
							</td>
							<td>
								<?php 					
								if(!empty($existingADmArry)){ $admNoIN = ' AND adm_no IN ('.$existingADmStr.')'; }
								else{ $admNoIN = ''; }
								$ex1 = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$month."' ".$admNoIN." AND rec_date='".$classArr1["rec_date"]."' AND session='2016-2017'");
								echo $ex1[0]['amt'] ? $ex1[0]['amt'] : 0;
								$exArr[] = $ex1[0]["amt"];
								?>
							</td>
							<td>
								<?php 
								if(!empty($existingADmArry)){ $admNoIN = ' AND adm_no IN ('.$existingADmStr1.')'; }
								else{ $admNoIN = ''; }								
								$exq1 = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$month."' ".$admNoIN." AND rec_date='".$classArr1["rec_date"]."' AND session='2016-2017'");
								echo $exq1[0]['amt'] ? $exq1[0]['amt'] : 0;
								$n1T[] = $exq1[0]['amt'];
								?>
							</td>
							<td>
								<?php 					
								echo $ct = $t[0]['amt'] + $t1[0]['amt'];
								$ctArr[] = $ct;
								?>
							</td>
							<td>
								<?php 					
								$p = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$month."' AND mode='CASH' AND rec_date='".$classArr1["rec_date"]."' AND session='2016-2017'");
								echo $p[0]["amt"] ? $p[0]["amt"] : 0;
								$mocasT[] = $p[0]["amt"];
								?>
							</td>
							<td>
								<?php 					
								$p1 = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$month."' AND mode='CHEQUE' AND rec_date='".$classArr1["rec_date"]."' AND session='2016-2017'");
								echo $p1[0]["amt"] ? $p1[0]["amt"] : 0;
								$mocheT[] = $p1[0]["amt"];
								?>
							</td>
							<td>
								<?php 					
								$extra1 = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='EXTRA' AND MONTHNAME(rec_date) = '".$month."' AND rec_date='".$classArr1["rec_date"]."' AND session='2016-2017'");
								echo $extra1[0]['amt'] ? $extra1[0]['amt'] : 0;
								$extraT[] = $extra1[0]['amt'];
								?>
							</td>
							<td>
								<?php
								echo $ct+$extra1[0]['amt'];
								?>
							</td>
						</tr>
					<?php } ?>	
						<tr align="center">
							<th>Total</th>
							<td><?php echo '<b>'.array_sum($prevsess).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($currsess).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($exArr).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($n1T).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($ctArr).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($mocasT).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($mocheT).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($extraT).'</b>'; ?></td>
							<td><?php echo '<b>'.(array_sum($ctArr) + array_sum($extraT)).'</b>'; ?></td>
						</tr>				
				</tbody>
			</table>
		<?php } ?>
		<?php 
		ob_start(); 
		if($month == 'Tsummary'){ ?>
			<table class="table" style="width:100%;">
				<thead>
					<tr>
						<th>Month</th>
						<th>School fee 2015-2016</th>
						<th>School fee 2016-2017</th>
						<th>School fee Existing Students 2016-2017</th>
						<th>New Student</th>
						<th>Total Collection</th>
						<th>By Cash</th>
						<th>By Cheque</th>
						<th>Other Fees</th>
						<th>Grand Total</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$monthArr = array("April","May","June","July","August","September","October","November","December","January","February","March");
					foreach($monthArr as $m){ ?>
						<tr align="center">
							<td><?php echo $m; ?></td>
							<td>
								<?php 					
								$t = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$m."' AND session='2015-2016'");
								echo $t[0]['amt'] ? $t[0]['amt'] : 0;
								$prevsess[] = $t[0]["amt"];
								?>
							</td>
							<td>
								<?php 					
								$t1 = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$m."' AND session='2016-2017'");
								echo $t1[0]['amt'] ? $t1[0]['amt'] : 0;
								$currsess[] = $t1[0]["amt"];
								?>
							</td>
							<td>
								<?php
								if(!empty($existingADmArry)){ $admNoIN = ' AND adm_no IN ('.$existingADmStr.')'; }
								else{ $admNoIN = ''; }
								$ex1 = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$m."' ".$admNoIN." AND session='2016-2017'");
								echo $ex[0]['amt'] ? $ex1[0]['amt'] : 0;
								$exArr[] = $ex1[0]["amt"];
								?>
							</td>
							<td>
								<?php
								if(!empty($existingADmArry1)){ $admNoIN = ' AND adm_no IN ('.$existingADmStr1.')'; }
								else{ $admNoIN = ''; }
								$eq1 = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$m."' ".$admNoIN." AND session='2016-2017'");
								echo $eq1[0]['amt'] ? $eq1[0]['amt'] : 0;
								$nT[] = $eq1[0]["amt"];
								?>
							</td>
							<td>
								<?php 					
								echo $ct = $t[0]['amt'] + $t1[0]['amt'];
								$ctArr[] = $ct;
								?>
							</td>
							<td>
								<?php 					
								$p = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$m."' AND mode='CASH' AND session='2016-2017'");
								echo $p[0]["amt"] ? $p[0]["amt"] : 0;
								$mocasT[] = $p[0]["amt"];
								?>
							</td>
							<td>
								<?php 					
								$p1 = $db->rawQuery("SELECT id FROM ".PREFIX."fee_paid where type='FEE' AND MONTHNAME(rec_date) = '".$m."' AND mode='CHEQUE' AND session='2016-2017'");
								echo $p1[0]["amt"] ? $p1[0]["amt"] : 0;
								$mocheT[] = $p1[0]["amt"];
								?>
							</td>
							<td>
								<?php 					
								$extra1 = $db->rawQuery("SELECT sum(amount) as amt FROM ".PREFIX."fee_paid where type='EXTRA' AND MONTHNAME(rec_date) = '".$m."' AND session='2016-2017'");
								echo $extra1[0]['amt'] ? $extra1[0]['amt'] : 0;
								$extraT[] = $extra1[0]['amt'];
								?>
							</td>
							<td>
								<?php
								echo $ct+$extra1[0]['amt'];
								?>
							</td>
						</tr>
					<?php } ?>	
						<tr align="center">
							<th>Total</th>
							<td><?php echo '<b>'.array_sum($prevsess).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($currsess).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($exArr).'</b>';  ?></td>
							<td><?php echo '<b>'.array_sum($nT).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($ctArr).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($mocasT).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($mocheT).'</b>'; ?></td>
							<td><?php echo '<b>'.array_sum($extraT).'</b>'; ?></td>
							<td><?php echo '<b>'.(array_sum($ctArr) + array_sum($extraT)).'</b>'; ?></td>
						</tr>				
				</tbody>
			</table>
		<?php } ?>
	</center>
	<?php
	$xml2 = ob_get_contents();
	$xml = str_replace('"','',$xml2);
	$output = str_replace(array("\r\n", "\r"), "\n", $xml);
	$lines = explode("\n", $output);
	$new_lines = array();
	foreach ($lines as $i => $line) {
		if(!empty($line))
			$new_lines[] = trim($line);
	} ?>
	<form name="sampleform" method="POST" action="get_pdf" onsubmit="return createTarget(this.target)" target="formtarget">
		<input type="hidden" name="data" value="<center><?php echo implode($new_lines); ?></center>" />
		<input type="hidden" name="orientation" value="L" />
		<input type="hidden" name="type" value="Student Strength" />
		<input type="hidden" name="session" value="<?php echo $_SESSION['SESSION']; ?>" />
	</form>
	<script>
		function print_pdf(){
			document.sampleform.submit();
		}
	</script>
	</div>
</div> <!-- /container -->
<?php
include('footer.php');
?>