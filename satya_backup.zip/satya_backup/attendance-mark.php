<?php
$page='attendance';
require('core.php');
if($_SESSION['ACC_ATTENDANCE']=='0') 
{
	header("Location: main.php");
}


include('header.php');
?>
<div class="container">
<div class="row">
<div class="col-md-2 hidden-xs">
<?php print_menu($atten_menu_items); ?>
</div>
<div class="col-md-10">
<h3>Mark Student Attendance</h3>
<div class="row">
<div class="col-md-5">
<label>Date :</label>
<input name="date" id="date" data-date-format="dd/mm/yyyy" value="<?php echo date("d/m/Y"); ?>" class="datepicker3" onchange="get_classes()" style="width: 100px;" readonly />  
&nbsp;&nbsp;&nbsp;&nbsp;
<label>Class :</label>
<?php
	
	?>		
<select name="class" id="class" onchange="get_stu_attendance();">
	<option value="">- All Classes -</option>
	<?php /*foreach($class_arr as $class) { ?>
	<option value='<?php echo $class; ?>'><?php echo $class; ?></option>
	<?php }*/ ?>
</select>
<input type="hidden" name="allclass" id="allclass" value="" />
&nbsp;&nbsp;&nbsp;&nbsp;<b><span id="text_loading" class="text-danger"></span></b>
</div>
<div class="col-md-3" style="background-color: lightgreen; padding: 4px;">
<input type="checkbox" id="mark_holiday" onclick="mark_holiday();"> 
<select name="other_head" id="other_head">
	<option value="">- Heads -</option>
	<?php 
	$db->where ('code', 'W', '!=');
	$atten_head = $db->get('atten_heads');
	foreach($atten_head as $head) { ?>
	<option value='<?php echo $head['code']; ?>'><?php echo $head['heading']; ?></option>
	<?php } ?>
</select>
<select name="class2[]" class="multiple" id="class2" multiple>
</select>
</div>
<div class="col-md-2" style="background-color: lightgreen; padding: 2px;">
<input type="text" name="holiday_remark" id="holiday_remark" placeholder="Holiday Remark" style="display:none;" >
<input type="text" name="allholiday_remark" id="allholiday_remark" placeholder="Holiday Remark" style="display:none;" >
</div>
<div class="col-md-2" style="background-color: lightgreen; padding: 2px;">
<button class="btn btn-xs btn-danger ladda-button kill-evo" id='for_holiday' data-style="zoom-out"  style="display:none;"><span class="ladda-label">Mark Holiday</span></button>
<button class="btn btn-xs btn-danger ladda-button kill-evo" id='for_allholiday' data-style="zoom-out"  style="display:none;"><span class="ladda-label">Mark Holiday</span></button>
</div>
</div>
<p class="text-danger">
- Attendance will be marked only once for a class everyday. To change attendance, kindly use UPDATE ATTENDACE section.<br>
- If Attendance is marked for few classes, then Complete Holiday will be marked for the remaining classes only.<br>
</p>
<hr/>
<div class="row">
<div class="col-md-2">
<h4 style="margin:1px ;">Marked Classes:</h4>
</div>
<div id="doneclasses" class="col-md-10">

</div>
</div>
<hr/>
<div id="myDiv"></div>
	
	
	

	</div>
<script>
function get_classes() {
	var date = $('#date').val();
	$('#class').find('option').remove();
	$('#class2').find('option').remove();
	$('#class2').multiselect('rebuild');
	$('#doneclasses').html('');
	$('#allclass').val("");
	$('#class').append($("<option></option>").attr("value","").text("- All Classes -")); 
	get_stu_attendance();
	$('#text_loading').text("Loading...");
	$.ajax({
		type: 'POST',
		url: 'function/attendance-functions?get-classes&date='+date,
		success: function (data) {
			var arr = new Array();
			var data2 = new Array();
			var data = jQuery.parseJSON(data);
			$.each(data, function(key, value) {   
				if(value == 0) {
					$('#class').append($("<option></option>").attr("value",key).text(key)); 
					arr.push(key);
					$('#class2').append($("<option></option>").attr("value",key).text(key));
				}
			});
			$('#class2').multiselect('rebuild');
			var undoneclasses = arr.join();
			$('#allclass').val(undoneclasses);
			$.each(data, function(key, value) {   
				if(value == 1) {
					test = "<span class='label label-success'>"+key+"</span>";
				} else {
					test = "<span class='label label-danger'>"+key+"</span>";
				}
				$('#doneclasses').append(""+test+" / "); 
			});
		}
	});
	$('#text_loading').text("");
}
//get_classes();
function get_stu_attendance() {
	var clss = $('#class').val();
	var date = $('#date').val();
	 $('#text_loading').text("Loading...");
	$("#myDiv").load("function/attendance-functions?mark", {var1:clss, var2:date })
	if(clss == '') { 
		$('#holiday').css("display","none");
		$('#allholiday').css("display","block"); 
	} else {  
		$('#holiday').css("display","block"); 
		$('#allholiday').css("display","none"); 
	}
	$('#text_loading').text("");
	if($('#mark_holiday').is(':checked')) {
		$('#mark_holiday').click();
	}
	if($('#mark_allholiday').is(':checked')) {
		$('#mark_allholiday').click();
	}
}
get_stu_attendance();

function mark_holiday() {
	if($('#mark_holiday').is(':checked')) {
		$("#myDiv :input").attr("disabled", true);
		$("#myDiv :button").attr("disabled", true);
		$('#holiday_remark').css("display","block");
		$('#for_holiday').css("display","block");
	} else {
		$("#myDiv :input").attr("disabled", false);
		$("#myDiv :button").attr("disabled", false);
		$('#holiday_remark').css("display","none");
		$('#for_holiday').css("display","none");
	}
}
function mark_allholiday() {
	if($('#mark_allholiday').is(':checked')) {
		$('#allholiday_remark').css("display","block");
		$('#for_allholiday').css("display","block");
	} else {
		$('#allholiday_remark').css("display","none");
		$('#for_allholiday').css("display","none");
	}
}

$('#for_holiday').click(function(event) {
	var clss = $('#class2').val();
	var date = $('#date').val();
	var other_head = $('#other_head').val();
	var holiday_remark = $('#holiday_remark').val();
	if(holiday_remark != "") {
		$.ajax({
			type: 'POST',
			url: './function/attendance-functions?for_holiday&head='+other_head+'&class='+clss+'&date='+date+'&holiday_remark='+holiday_remark,
			data: $(this).serialize(),
			success: function (data) {
				get_classes();
				console.log(data);
				if(data=='0') {
					$.notify({message: 'Failed to update information.' },{type: 'danger'});
				} else {
					$.notify({message: '<strong>Successfully</strong> updated the information.' },{type: 'success'});
				}
			}
		});
	} else {
		$.notify({message: 'Please mention holiday remark.' },{type: 'danger'});
	}
});
</script>
</div>
</div> <!-- /container -->

<?php
include('footer.php');
?>