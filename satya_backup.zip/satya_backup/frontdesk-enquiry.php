<?php 
//error_reporting(0);
include('core.php');
include("header2.php");

?>
<div class="container">
  <h3><?php echo ($_GET['adm_status']=="Enquiry") ? 'Basic Enquiry' : (($_GET['adm_status']=="Prospectus") ? 'Scheduled Interview' : (($_GET['adm_status']=="Approved") ? 'Registration Query' : 'Admission Enquiry'));?></h3>
        
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Enquiry No</th>
        <th>Student Name</th>
        <th>Father Name</th>
		<th>Mother Name</th>
        <th>Class</th>
        <th>Current School</th>
      </tr>
    </thead>
    <tbody>
	<?php 
	if($_GET['adm_status']=="Approved"){
		$cols = Array ("*");
	}else{
		$cols = Array ("id", "stu_name", "fat_name","mot_name","class","last_school","mobile","dob","fat_occ","location","current_class","pic");
	}
	
	$db->where ('adm_status',$_GET['adm_status']);
    $stu_enq= $db->get("inquiry",null,$cols);
   if(count($stu_enq)!=0){
	   $x=0;$str="";
foreach($stu_enq as $stu_info){
	?>

				<tr >
				<td><a href="javascript:void(0)" result="<?php 
				if($_GET['adm_status']=="Approved"){
					foreach(array_values($stu_info) as $val){
						if($val==""){
							$str .="&&&^";
						}else{
							$str .=$val."^";
						}
						
					}
					echo $str;
				}else{
					 echo $stu_info['id']."^".$stu_info['stu_name']."^".$stu_info['fat_name']."^".$stu_info['mot_name']."^".$stu_info['class']."^".$stu_info['last_school']."^".$stu_info['mobile']."^".$stu_info['dob']."^".$stu_info['fat_occ']."^".$stu_info['location']."^".$stu_info['current_class']."^".$stu_info['pic'];
				}
				?>" onclick="return passData(this)"><?php echo $stu_info['id'];?></a></td>
				<td><?php echo $stu_info['stu_name'];?></td>
				<td><?php echo $stu_info['fat_name'];?></td>
				<td><?php echo $stu_info['mot_name'];?></td>
				<td><?php echo $stu_info['class'];?></td>
				<td><?php echo $stu_info['last_school'];?></td>
				</tr>
	  <?php
  $x++;  }
    }else{
		echo "<tr>";
		echo "<td colspan='6' style='text-align:center;color:red;font-size:18px;'>No Data Found</td>";
		echo "</td>";
	}
	?>
    </tbody>
  </table>
</div>

<script>
function passData(sender){
	 window.opener.HandlePopupResult(sender.getAttribute("result"));
     window.close();
    return false;
}
</script>



<?php 
include("footer.php");
?>