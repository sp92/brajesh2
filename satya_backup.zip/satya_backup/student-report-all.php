<?php
$page='student';
require('core.php');
if($_SESSION['ACC_STUDENT']=='0') {
	header("Location: main.php");
}
include('header.php');

?>
<link rel="stylesheet" href="assets/css/bootstrap-multiselect.css">
<div class="container">
<form id="getrecord">
<div class="row">
<div class="col-md-6">
<h3>Select Fields</h3>
<div style="display:inline-block">
<select id="options" multiple="multiple" style="height:325px;width:200px; display:inline-block">
<?php
$cols=array("name","field");
$data_stu = $db->get('stu_custom_data',null,$cols); 
 foreach($data_stu as $data){
 ?>
<option value="<?php echo $data['field']; ?>"><?php echo $data['name']; ?></option>
<?php } ?>
</select>
</div>
<div style="width:120px; display:inline-block; vertical-align:top;text-align:center">
<br/>
<br/>
<input onclick="moveOption('options','selected')" type="button" value="Add Field >>">
<br/>
<br/>
<input onclick="moveOption2('selected','options')" type="button" value="<< Remove">
</div>
<div style="display:inline-block">
<select id="selected" style="height:325px;width:200px;  display:inline-block" multiple></select>
<br>
<input type="hidden" id="fields" name="fields" value="" />
</div>
</div>
<div class="col-md-3" id="panel">
	<h3>Filters</h3>
	<table class="table" style="font-size:12px;">
	<tr>
		<td><label>Student Type:</label> </td>
	<td>
	<select name="stu_type" style="width:100%">
	<option value="regular">General / Regular</option>
	<option value="nso">NSO / Left</option>
<option value="tc">TC Issued</option>
<option value="all_stu">All Students</option>
</select>
</td>
</tr>

<tr>
<td><label>Adm. Type:</label> </td>
<td><select name="new_old" style="width:100%">
<option value="">-- Any --</option>
<option value="OLD">OLD Only</option>
<option value="NEW">NEW Only</option>
</select>
</td>
</tr>

<tr>
<td><label>Class:</label> </td>
<td><select name="class[]" class="multiselect" class="form-control" multiple>
<?php
$cols=array("class");
$class_stu = $db->get('class_master',null,$cols); 
foreach($class_stu as $stu){
	echo "<option value='".$stu["class"]."'".($stu["class"]==$_REQUEST["class"] ? " selected" : "").">".$stu["class"]."</option>";
}
	
?>
</select>
</td>
</tr>

<tr>
<td><label>Section:</label> </td>
<td><select name="sec[]" class="multiselect" class="form-control" multiple>
<?php
$cols=array("sec");
$db->orderBy ("sec","asc");
$class_stu = $db->get('sec_master',null,$cols); 
foreach($class_stu as $stu){
	echo "<option value='".$stu["sec"]."'".($stu["sec"]==$_REQUEST["sec"] ? " selected" : "").">".$stu["sec"]."</option>";
}


?>
</select>
</td>
</tr>

<tr>
<td><label>Fee Category:</label> </td>
<td><select name="fee_cat[]" class="multiselect" class="form-control" multiple>
<?php
				$cols=array("fee_cat");
				
				$class_stu = $db->get('fee_cat',null,$cols); 
				foreach($class_stu as $stu){
				echo "<option value='".$stu["fee_cat"]."'".($stu["fee_cat"]==$_REQUEST["fee_cat"] ? " selected" : "").">".$stu["fee_cat"]."</option>";
				}
?>
</select>
</td>
</tr>

<tr>
<td><label>Gender:</label> </td>
<td><select name="gender" style="width:100%">
<option value="">-- Any --</option>
<option value="M">BOY Only</option>
<option value="F">GIRL Only</option>
</select>
</td>
</tr>

<tr>
<td><label>Age as on :</label> </td>
<td>
<input type="text" name="ageon" data-date-format="dd/mm/yyyy" class="datepicker" value="" readonly="">
</td>
</tr>
<tr>
<td align=center colspan=2><small>For age, DOB must be selected.</small></td>
</tr>
<tr>
<td><label>Category:</label> </td>
<td><select name="category[]" class="multiselect" class="form-control" multiple>
<option value="GENERAL">General</option>
<option value="OBC">OBC</option>
<option value="SC">SC</option>
<option value="ST">ST</option>
<option value="OTHERS">Others</option>
</select>
</td>
</tr>

<tr>
<td><label>Religion:</label> </td>
<td><select name="religion[]" class="multiselect" class="form-control" multiple>
<option value="HINDU">Hindu</option>
<option value="MUSLIM">Muslim</option>
<option value="SIKH">Sikh</option>
<option value="CHRISTIAN">Christian</option>
</select>
</td>
</tr>
<tr>
<td><label>Adm. Date Between :</label> </td>
<td>
<input name="adm_from" data-date-format="dd/mm/yyyy" value="" class="datepicker"  readonly="" placeholder="From Date"><br>
<input name="adm_to" data-date-format="dd/mm/yyyy" value="" class="datepicker"  readonly="" placeholder="To Date">

</td>
</tr>

</table>
</div>
<div class="col-md-3">
<h3>Ordering & Grouping</h3>
<table class="table" style="font-size:12px">
<tr>
<td><label>Order By :</label></td>
<td><select name="order">
<option value="stu_name">Student Name</option>
<option value="adm_no">Admission No.</option>
</select></td>
<tr>
<tr>
<td><label>Display / Export :</label></td>
<td><select name="rpt_type">
<option value="display">Display</option>
<option value="export">Export</option>
</select></td>
</tr>
<tr>
<td><label>Group Sections :</label></td>
<td><input type="checkbox" name="group_sec" value="on"></td>
</tr>
<tr>
<th  colspan=2><b>FOR PDF ONLY</th>
</tr>
<tr>
<td><label>Orientation :</label></td>
<td><select name="layout">
<option value="P">Portrait</option>
<option value="L">Landscape</option>
</select></td>
</tr>
<tr>
<td><label>Report Name :</label></td>
<td><input type="text" name="rpt_name" value="" /></td>
</tr>
</table>
</div>
</div>
<hr>
<div class="row text-center">
<input class="btn btn-success" type="submit" id="submit" name="submit" value="Export Data" />
</div>
</form>


<div id="for_data"></div>

<script>
var selected = [];
function moveOption(from, to)
{
	$("#" + from + " :selected").each(function () 
    {
		$('#' + to).append('<option value="' + $(this).val() + '">' + $(this).text() + '</option>');
        $('#' + from + ' option[value="' + $(this).val() + '"]').remove();
		selected.push($(this).val());
		$("#fields").val(selected.join());
	});
}
function moveOption2(from, to)
{
	$("#" + from + " :selected").each(function () 
    {
		$('#' + to).append('<option value="' + $(this).val() + '">' + $(this).text() + '</option>');
        $('#' + from + ' option[value="' + $(this).val() + '"]').remove();
		selected.splice(selected.indexOf($(this).val()), 1);
		$("#fields").val(selected.join());
	});
}
$('#getrecord').submit(function(event) {
	if(confirm('Confirm?' )) {
		$( "#submit" ).prop('disabled',true);
		$( "#submit" ).val('Processing. Please wait......');
		event.preventDefault();
                $.ajax({
                        type: 'POST',
                        url: 'csv-export',
                        data: $(this).serialize(),
						success: function (data) {
							console.log(data);
							 $('#for_data').html(data);
							$( "#submit" ).prop('disabled',false);
							$( "#submit" ).val('Export Data'); 
						}
                });
	} else {
		event.preventDefault();
		return false;
	}
});
</script>

<script src="assets/js/bootstrap-multiselect.js"></script>
<script>
function print_pdf(){
	document.sampleform.submit();
}
var tableToExcel = (function() {
  var uri = 'data:application/vnd.ms-excel;base64,'
	, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
	, base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
	, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
  return function(table, name) {
	if (!table.nodeType) table = document.getElementById(table)
	var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
	window.location.href = uri + base64(format(template, ctx))
  }
})()
</script>
<script>
$('.input_date').datepicker();
$('.multiselect').multiselect({includeSelectAllOption: true});
</script>
</div>
<?php
include('footer.php');
?>       