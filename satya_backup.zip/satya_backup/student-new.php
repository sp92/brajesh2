<?php
$page='student';
require('core.php');
if($_SESSION['ACC_STUDENT']=='0') {
header("Location: main.php");
}
include('header.php');
?>
<div class="container">
	<?php print_menu($student_menu_items); ?>
	<div class="row">
		<h3>Register New Student</h3>
		<form id="student-add-form">
			<input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
			<input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>">
			<input type="hidden" name="new_old" value="NEW">
			<table class="table table-condensed table-striped">
				<tr>
					<td colspan="4">
						In Case of Any Brother / Sister, Please enter Admission No. : 
						<input size="7" onkeyup="lookItUp();" name="s_adm_no" id="s_adm_no" type="text">
						<span class="glyphicon glyphicon-question-sign" title="Any admission no. written here will make sibling with admission no. written below. Leave blank to add student only."></span>
						| <a href="javascript:void(0);" onclick="get_enquiry_no()">Get Enquiries</a>
						
					</td>
					<script>
				function get_enquiry_no() {
					payfee = $.popupWindow('frontdesk-enquiry?adm_status=Approved',{height:500,width:800});
				}
				</script>
					<td align=right></td>
					<td>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						Form No. : 
						<input type="text" name="form_no"   style="width: 100px;" />
                    </td>
				</tr>
				<tr class="bg-info">
          <td align="right">
	Adm. Type : 
            
          </td>
          <td>
		  <select name="std_type" onchange="admNoField()">
				<option value="confirm">Confirm</option>
				<option value="provisional">Provisional</option>
			</select>     
&nbsp;&nbsp;&nbsp;&nbsp;			
		   <span id="hideAdmNo">Adm. No. : 
            <input type="text" name="adm_no" value="12" id="adm_no"  style="width: 45px;" readonly/></span>
			 <input type="hidden" name="enq_no" value="" id="enq_no"  style="width: 45px;" readonly/></span>
  </td>
  <td align="right">
    Class : 		
  </td>
  <script>
  function admNoField(){
	  var admType = $('select[name="std_type"]').val();
	  if(admType == 'confirm'){
		  $('#hideAdmNo').show();
		}
		else if(admType == 'provisional'){
			$('#hideAdmNo').hide();
		}
  }
  </script>
  <td>
    <select name="class" id="class" required >
      <option value="">
        --
      </option>
	  <?php
		$user = $db->get ("class_master");
		if ($db->count > 0) {
			foreach ($user as $u) { 
		?>			
		<option value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
		<?php } } ?>	
    </select>
    &nbsp;&nbsp;&nbsp;
    Section : 
    <select name="sec" id="sec" required >
      <option value="">
        --
      </option>
       <?php
		$user = $db->get ("sec_master");
		if ($db->count > 0) {
			foreach ($user as $u) { 
		?>			
		<option value='<?php echo $u['sec']; ?>'><?php echo $u['sec']; ?></option>
		<?php } } ?>
    </select>
    
    
  </td>
  <td align="right">
    Fee Type :
  </td>
  <td>
    <select name="type" id="type" required >
      <option value="">
        --
      </option>
	  <?php
		$db->where('session', $_SESSION['SESSION']);
		$user = $db->get ("type");
		if ($db->count > 0) {
			foreach ($user as $u) { 
		?>			
		<option value='<?php echo $u['type']; ?>'><?php echo $u['type']; ?></option>
		<?php } } ?>	
    </select>
    
    Fee Category : <select name="fee_cat" id="fee_cat" required >
      <option value="">
        --
      </option>
	  <?php
		$db->where('session', $_SESSION['SESSION']);
		$user = $db->get ("fee_cat");
		if ($db->count > 0) {
			foreach ($user as $u) { 
		?>			
		<option value='<?php echo $u['fee_cat']; ?>'><?php echo $u['fee_cat']; ?></option>
		<?php } } ?>	
    </select>
	
  </td>
  </tr>
   <tr>
    <td colspan=6>
      <strong>
        STUDENT PROFILE:
      </strong>
    </td>
  </tr>
  <tr>
    <td align="right">
      Stu. Name : 	
    </td>
    <td>
      <input type="text" name="stu_name" id="stu_name"  style="width: 100%;" required  />
    </td>
    <td align="right">
      Gender : 	
    </td>
    <td>
      <select name="gender" id="gender"   style="width: 100%;">
        <option value=""  selected>
          --
        </option>
        <option value="MALE">
          MALE
        </option>
        <option value="FEMALE">
          FEMALE
        </option>
      </select>
    </td>
    <td align="right">
      Date of Birth : 	
    </td>
    <td>
	
<input type="text" name="dob" id="dob" class="datepicker" value="" data-date-format="dd/mm/yyyy" style="width: 100px;" readonly />
<span id="age" style="font-weight:bold;color:red;" ></span>
<script>
$( "#dob" ).change(function( event ) {
	$( "#age" ).html('Calculating');
	var date = $(this).val();
event.preventDefault();
  $.ajax({
    type: 'POST',
    url: 'function/calc-age?dob='+date,
    success: function (data) {
		$('#age').html(data);
    }
  });
});
</script>
  </td>
  </tr>
  <tr>
    <td align="right">
      Stu. Name (Hindi): 	
    </td>
    <td>
      <input type="text" name="stu_name_hindi"  id="stu_name_hindi"  style="width: 80%;" />
      <a onclick="windowpop('html/hindi.htm', +screen.width, +screen.height)" class="btn-succes" style="cursor:pointer;">
        &nbsp;???
      </a>
    </td>
    <td align="right">
      House : 	
    </td>
    <td>
      <select name="house"   style="width: 100%;">
        <option value="">
          --
        </option>
      </select>
    </td>
    <td align="right">
      Stream : 	
    </td>
    <td>
      <select name="stream"   style="width: 100%;">
        <option value="">
          --
        </option>
       <?php
		$user = $db->get ("stream");
		if ($db->count > 0) {
			foreach ($user as $u) { 
		?>			
		<option value='<?php echo $u['stream']; ?>'><?php echo $u['stream']; ?></option>
		<?php } } ?>	
      </select>
    </td>
    
  </tr>
  <tr>
    <td align="right">
      Physically Challenged : 	
    </td>
    <td>
      <input type="text" name="phy_chal" id="phy_chal"   style="width: 100%;" />
    </td>
    <td align="right">
      Blood Group : 	
    </td>
    <td>
      <select name="bg">
        <option value="">
          -- Group --
        </option>
        <option value="A+">
          A+
        </option>
        <option value="A-">
          A-
        </option>
        <option value="B+">
          B+
        </option>
        <option value="B-">
          B-
        </option>
        <option value="AB+">
          AB+
        </option>
        <option value="AB-">
          AB-
        </option>
        <option value="O+">
          O+
        </option>
        <option value="O-">
          O-
        </option>
      </select>
    </td>
    <td align="right">
      Mother Tongue : 	
    </td>
    <td>
      <input type="text" name="lang"   style="width: 100px;"  />
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="checkbox" name='only_child' value="YES">
      &nbsp;Only Child
      
    </td>
  </tr>
  
  <tr>
  <td align=right>Religion :</td>
  <td><select name="religion" id="religion"  style="width: 100%;">
        <option value="">
          --
        </option>
        <option value="HINDU">
          HINDU
        </option>
        <option value="MUSLIM">
          MUSLIM
        </option>
        <option value="SIKH">
          SIKH
        </option>
        <option value="CHRISTIAN">
          CHRISTIAN
        </option>
      </select></td>
  <td align=right>Category :</td>
  <td><select name="category"  id="category" style="width: 100%;" >
        <option value="">
          --
        </option>
        <option value="GENERAL">
          GENERAL
        </option>
        <option value="OBC">
          OBC
        </option>
        <option value="SC">
          SC
        </option>
        <option value="ST">
          ST
        </option>
        <option value="OTHERS">
          OTHERS
        </option>
      </select></td>
  <td align=right>Admission Date :</td>
  <td><input type="text" name="do_adm" class="datepicker" value="<?php echo date('d/m/Y'); ?>" style="width: 100px;" readonly /></td>
  </tr>
  
  
  <tr>
    <td colspan=6>
      <strong>
        FAMILY PROFILE:
      </strong>
    </td>
  </tr>
  
  <tr>
<td align="right">Father Name : 	</td><td><input type="text" name="fat_name" id="fat_name" value="" class="required" style="width: 100%;"></td>
<td align="right">Father Mobile No.: 	</td><td><input type="text" value="" onkeyup="this.value=this.value.replace(/[^\d]/,'')" id="mobile2" name="mobile2" style="width: 100px;"></td>
<td align="right">Father Email : 	</td><td><input type="text" name="fat_email" id="fat_email" value="" class="required" style="width: 100%;"></td>
</tr>
<tr>
<td align="right">Father Income :	</td><td><input type="text" name="fat_income" value="" id="fat_income" style="width: 100%;"></td>
<td align="right">Father Occupation : 	</td><td><input type="text" name="fat_occ" value="" id="fat_occ" style="width: 100%;"></td>
<td align="right">Father Qualification : 	</td><td><input type="text" name="fat_qual" value="" id="fat_qual" style="width: 100%;"></td>
</tr>
<tr>
<td align="right">Father Aadhar :	</td><td><input type="text" name="fat_aadhar" id="fat_aadhar" value="" style="width: 100%;"></td>
<td align="right">Father Company : 	</td><td><input type="text" name="fat_comp" value="" id="fat_occ" style="width: 100%;"></td>
<td align="right">Office Address : 	</td><td><input type="text" name="fat_office_addrs" value="" id="fat_office_addrs" style="width: 100%;"></td>
</tr>
<tr>
<td align="right">Mother Name : 	</td><td><input type="text" name="mot_name" id="mot_name" value="" class="required" style="width: 100%;"></td>
<td align="right">Mother Mobile No.: 	</td><td><input type="text" value="" onkeyup="this.value=this.value.replace(/[^\d]/,'')" id="mobile3" name="mobile3" style="width: 100px;"></td>
<td align="right">Mother Email : 	</td><td><input type="text" name="mot_email" value="" id="mot_email" class="required" style="width: 100%;"></td>
</tr>
<tr>
<td align="right">Mother Income :	</td><td><input type="text" name="mot_income" value="" id="mot_income" style="width: 100%;"></td>
<td align="right">Mother Occupation : 	</td><td><input type="text" name="mot_occ" value="" id="mot_occ" style="width: 100%;"></td>
<td align="right">Mother Qualification : 	</td><td><input type="text" name="mot_qual" value="" id="mot_qual" style="width: 100%;"></td>
</tr>
<tr>
<td align="right">Mother Aadhar :	</td><td><input type="text" name="mot_aadhar" id="mot_aadhar" value="" style="width: 100%;"></td>
<td align="right">Mother Company : 	</td><td><input type="text" name="mot_comp" value="" id="mot_comp" style="width: 100%;"></td>
<td align="right">Office Address : 	</td><td><input type="text" name="mot_office_addrs" value="" id="mot_office_addrs" style="width: 100%;"></td>
</tr>
  
  
  <tr>
    <td colspan=6>
      <strong>
        GUARDIAN PROFILE:
      </strong>
    </td>
  </tr>
  <tr>
    <td align="right">
      Guardian Name : 	
    </td>
    <td>
      <input type="text" name="guard_name" id="guard_name"   style="width: 100%;" />
    </td>
    <td align="right">
      Guardian Mob. No. : 	
    </td>
    <td>
      <input type="text" name="guard_no" id="guard_no"  style="width: 100%;" />
    </td>
    <td align="right">
      Guardian Relation : 	
    </td>
    <td>
      <input type="text" name="guard_relation" id="guard_relation" style="width: 100%;" />
    </td>
  </tr>
  <tr>
    <td colspan=6>
      <strong>
        PERMANENT ADDRESS:
      </strong>
    </td>
  </tr>
  <tr>
    <td align="right">
      Address : 	
    </td>
    <td colspan="3">
      <input type="text" name="address" id="address"   style="width:100%;" />
    </td>
    <td align="right">
      Mobile No. : 	
    </td>
    <td>
      <input type="text" name="mobile" id="mobile" class="numonly bg-success" maxlength="10" placeholder="SMS No." style="width: 100px;"   />
      &nbsp;&nbsp;&nbsp;
      <input type="text" class="numonly bg-success" placeholder="Alt SMS No." maxlength="10" id="alt_sms" name="alt_sms" style="width: 100px;" />
    </td>
  </tr>
  <tr>
    <td colspan=6>
      <strong>
        CORRESPONDANCE ADDRESS:
      </strong>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="checkbox" id="same_address" onclick="copy_address();">
      Same As Above
    </td>
  </tr>
  <tr>
    <td align="right">
      Address : 	
    </td>
    <td colspan="3">
      <input type="text" name="address_co" id="address_co"   style="width:100%;" />
    </td>
    <td align="right">
      <!--Mobile No. : 	-->
    </td>
    <td>
      <!--<input type="text" name="mobile_co" id="mobile_co"  onkeyup="this.value=this.value.replace(/[^\d]/,'')"  style="width: 100px;" />
      &nbsp;&nbsp;&nbsp;
      <input type="text" id="mobile2_co" name="mobile2_co" style="width: 100px;"  onkeyup="this.value=this.value.replace(/[^\d]/,'')" />-->
    </td>
  </tr>
  
 <tr>
	<td colspan=6><strong>SUBMISSIVE DOCUMENTS:</strong></td>
</tr>
<tr>
	<td colspan=6>
		<table class="table table-striped">				
			<tr>
				<td><center><b>SR</b></center></td>
				<td><center><b>CERTIFICATES</b></center></td>
				<td><center><b>COLLECTED</b></center></td>
				<td><center><b>REMARKS</b></center></td>
			</tr>
			<?php
			$n=1;
			$cert = $db->getOne ("certificate");
			if($cert['cert1']<>""){ ?>
				<tr>
					<td><center><?php echo $n++; ?></center></td>
					<td><center><?php echo $cert['cert1']; ?></center></td>
					<td><center>
						<input type="radio" name="cert1" value="YES" >&nbsp;YES</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert1" value="NO" checked>&nbsp;NO</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert1" value="N/A">&nbsp;N/A</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert1" value="PARTIAL">&nbsp;PARTIAL</input>
					</center></td>
					<td><center><input type="text" name="cert1_remark" value="" /></center></td>
				</tr>
			<?php } ?>
			<?php if($cert['cert2']<>""){ ?>
				<tr>
					<td><center><?php echo $n++; ?></center></td>
					<td><center><?php echo $cert['cert2']; ?></center></td>
					<td>
						<center><input type="radio" name="cert2" value="YES" >&nbsp;YES</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert2" value="NO" checked >&nbsp;NO</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert2" value="N/A" >&nbsp;N/A</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert2" value="PARTIAL" >&nbsp;PARTIAL</input>
						</center>
					</td>
					<td><center><input type="text" name="cert2_remark" value="" /></center></td>
				</tr>
			<?php } ?>
			<?php if($cert['cert3']<>""){?>
				<tr>
					<td><center><?php echo $n++; ?></center></td>
					<td><center><?php echo $cert['cert3']; ?></center></td>
					<td>
						<center><input type="radio" name="cert3" value="YES" >&nbsp;YES</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert3" value="NO" checked >&nbsp;NO</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert3" value="N/A">&nbsp;N/A</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert3" value="PARTIAL" >&nbsp;PARTIAL</input>
						</center>
					</td>
					<td><center><input type="text" name="cert3_remark" value="" /></center></td>
				</tr>
			<?php } ?>
			<?php if($cert['cert4']<>""){?>
				<tr>
					<td><center><?php echo $n++; ?></center></td>
					<td><center><?php echo $cert['cert4']; ?></center></td>
					<td>
						<center><input type="radio" name="cert4" value="YES" >&nbsp;YES</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert4" value="NO" checked >&nbsp;NO</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert4" value="N/A" >&nbsp;N/A</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert4" value="PARTIAL" >&nbsp;PARTIAL</input>
						</center>
					</td>
					<td><center><input type="text" name="cert4_remark" value="" /></center></td>
				</tr>
			<?php } ?>
			<?php if($cert['cert5']<>""){	?>
				<tr>
					<td><center><?php echo $n++; ?></center></td>
					<td><center><?php echo $cert['cert5']; ?></center></td>
					<td>
						<center><input type="radio" name="cert5" value="YES" >&nbsp;YES</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert5" value="NO" checked >&nbsp;NO</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert5" value="N/A" >&nbsp;N/A</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert5" value="PARTIAL" >&nbsp;PARTIAL</input>
						</center>
					</td>
					<td><center><input type="text" name="cert5_remark" value="" /></center></td>
				</tr>
			<?php } ?>
			<?php if($cert['cert6']<>""){?>
				<tr>
					<td><center><?php echo $n++; ?></center></td>
					<td><center><?php echo $cert['cert6']; ?></center></td>
					<td>
						<center><input type="radio" name="cert6" value="YES" >&nbsp;YES</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert6" value="NO" checked >&nbsp;NO</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert6" value="N/A">&nbsp;N/A</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert6" value="PARTIAL" >&nbsp;PARTIAL</input>
						</center>
					</td>
					<td><center><input type="text" name="cert6_remark" value="" /></center></td>
				</tr>
			<?php } ?>
			<?php if($cert['cert7']<>""){?>
				<tr>
					<td><center><?php echo $n++; ?></center></td>
					<td><center><?php echo $cert['cert7']; ?></center></td>
					<td>
						<center><input type="radio" name="cert7" value="YES" >&nbsp;YES</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert7" value="NO" checked >&nbsp;NO</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert7" value="N/A" >&nbsp;N/A</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert7" value="PARTIAL" >&nbsp;PARTIAL</input>
						</center>
					</td>
					<td><center><input type="text" name="cert7_remark" value="" /></center></td>
				</tr>
			<?php } ?>
			<?php if($cert['cert8']<>""){?>
				<tr>
					<td><center><?php echo $n++; ?></center></td>
					<td><center><?php echo $cert['cert8']; ?></center></td>
					<td>
						<center><input type="radio" name="cert8" value="YES" >&nbsp;YES</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert8" value="NO" checked >&nbsp;NO</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert8" value="N/A" >&nbsp;N/A</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert8" value="PARTIAL" >&nbsp;PARTIAL</input>
						</center>
					</td>
					<td><center><input type="text" name="cert8_remark" value="" /></center></td>
				</tr>
			<?php } ?>
			<?php if($cert['cert9']<>""){?>
				<tr>
					<td><center><?php echo $n++; ?></center></td>
					<td><center><?php echo $cert['cert9']; ?></center></td>
					<td>
						<center><input type="radio" name="cert9" value="YES">&nbsp;YES</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert9" value="NO" checked >&nbsp;NO</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert9" value="N/A" >&nbsp;N/A</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert9" value="PARTIAL" >&nbsp;PARTIAL</input>
						</center>
					</td>
					<td><center><input type="text" name="cert9_remark" value="" /></center></td>	
				</tr>
			<?php } ?>
			<?php if($cert['cert10']<>""){?>
				<tr>
					<td><center><?php echo $n++; ?></center></td>
					<td><center><?php echo $cert['cert10']; ?></center></td>
					<td>
						<center><input type="radio" name="cert10" value="YES" >&nbsp;YES</input>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert10" value="NO" checked >&nbsp;NO</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert10" value="N/A" >&nbsp;N/A</input>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="cert10" value="PARTIAL" >&nbsp;PARTIAL</input>
						</center>
					</td>
					<td><center><input type="text" name="cert10_remark" value="" /></center></td>
				</tr>
			<?php } ?>
  </table>
  </td>
  </tr>
  </table>
  <div class="row">
  

  <div class="col-md-6">
  <table class="table table-striped" style="color: black;">
    <tr>
      <td colspan="6">
        <strong>
        PREVIOUS SCHOOLING:
      </strong>
      </td>

    </tr>
    <tr style="font-size: 15px;font-weight:bold;">
      <td style="width: 15px;">
        <center>
          
        </center>
      </td>
      <td style="width: 200px;">
        <center>
          School Name
        </center>
      </td>
      <td style="width: 50px;">
        <center>
          Class
        </center>
      </td>
      <td style="width: 50px;">
        <center>
          Session
        </center>
      </td>
      <td style="width: 50px;" >
        <center>
          Curriculum
        </center>
      </td>
    </tr>
    <tr>
      <td>
       
      </td>
      <td>
        <input type="text" name="school_name" id="school1_name" style="width: 95%;" />
      </td>
      <td>
        <select name="school_class" id="class">
          <option value="" selected>
            --
          </option>
          <option value='1ST'>
            1ST
          </option>
          <option value='2ND'>
            2ND
          </option>
          <option value='3RD'>
            3RD
          </option>
          <option value='4TH'>
            4TH
          </option>
          <option value='5TH'>
            5TH
          </option>
          <option value='6TH'>
            6TH
          </option>
          <option value='7TH'>
            7TH
          </option>
          <option value='8TH'>
            8TH
          </option>
          <option value='9TH'>
            9TH
          </option>
          <option value='10TH'>
            10TH
          </option>
          <option value='11TH'>
            11TH
          </option>
          <option value='12TH'>
            12TH
          </option>
        </select>
      </td>
      <td>
        <input type="text" name="school_session" id="school1_session" style="width: 95%;" />
      </td>
      <td>
        <center>
          <select name="school_curri">
            <option value="">
              --
            </option>
            <option value="CBSE">
              CBSE BOARD
            </option>
            <option value="ICSE/ISC">
              ICSE/ISC BOARD
            </option>
            <option value="STATE BOARD">
              STATE BOARD
            </option>
            <option value="OTHERS">
              OTHERS
            </option>
          </select>
        </center>
      </td>
    </tr>

  </table>
  </div>
    <div class="col-md-6">
  
  
  <table class="table table-striped">
    <tr>
  	  <td colspan="2">
        <strong>
        TRANSPORT FACILITY:
      </strong>
      </td>
  </tr>
    <tr>
      <td align="right" valign="top">
       Bus Facility 	
      </td>
      <td>
        <input type="checkbox" name='is_transport' id='is_transport' value="YES">
        &nbsp;&nbsp;&nbsp;
        Route :
        <select name="route"  id="route" disabled required >
			<option value="">- Please Select -</option>
          <?php
			$user = $db->get ("stop_master");
			if ($db->count > 0) {
				foreach ($user as $u) { 
			?>			
			<option value='<?php echo $u['route']; ?>'><?php echo $u['route']; ?></option>
			<?php } } ?>
        </select>
		&nbsp;&nbsp;&nbsp;
        Stoppage : 
        <select name="stop" id="stop"  disabled required>
          <option value="">
            --
          </option>
          
          
        </select>
        <input type="hidden" name="bus_fee" id="amount" value="0" style="width:50px;" disabled readonly />
      </td>
    </tr>
  
  </table>
  </div>
 
  
  </div>
  
   <table class="table">
    <tr>
      <td align="center" id="finalmesg">
        <button class="btn btn-primary ladda-button kill-evo" type='submit' data-style="zoom-out"><span class="ladda-label">Add Student</span></button>
        &nbsp;
        <button class="btn btn-danger ladda-button kill-evo" type='reset' data-style="zoom-out"><span class="ladda-label">Reset Form</span></button>
      </td>
    </tr>
  </table>
  
  
</form>


</div>
</div>
<script>
	$('#student-add-form').submit(function(event) {
	 event.preventDefault();
		$.ajax({
			type: 'POST',
			url: './function/studentadd',
			data: $(this).serialize(),
			success: function (data) {
				//console.log(data);
				alert(data);
				 $('#student-add-form').trigger("reset");
				$.notify({message: '<strong>Successfully</strong> updated the information.' },{type: 'success'}); 
				 var adm_no = $('#adm_no').val();
				var new_adm = parseInt(adm_no)+1;
				 $('#adm_no').val(new_adm);
				$('#finalmesg').html(data); 
			}
		});
	});
	
	$("#is_transport").click(function() {
		if($(this).is(':checked')) {
			$("#route").attr("disabled", false);
			$("#stop").attr("disabled", false);
			$('#amount').prop('disabled', false);
		} else {
			$("#route").attr("disabled", "disabled");
			$("#stop").attr("disabled", "disabled");
			$('#amount').prop('disabled', "disabled");
		}
	});
	
	<?php
			$user = $db->get ("stop_master");
			if ($db->count > 0) {
				foreach ($user as $u) { 
			$stoplist[$u['route']] = $u['stop'].":::".$u['amount'];
			 } } ?>
	var stoplist = (<?php echo json_encode($stoplist); ?>);
	
	$("#route").change(function(event) {
			var route_choice = $("#route").val();
			
			if(route_choice != "") {  
				var option;
				option += '<option value="">-Please Select-</option>';
				n=1;
				$.each(stoplist, function(key, value) {
					if(key == route_choice) {
						var res = value.split(":::");
						option += '<option value="'+ value + '">' + res[0] + '</option>';
					}
				});
				$('#stop').prop('disabled', false);
				$('#stop').html(option);
				$("#amount").val(0);
			} else {
				$('#stop').prop('disabled', true);
				$('#stop').html("<option value=''>-Please select-</option>");
				$("#amount").val(0);
			}
		});
		
		$("#stop").change(function(event) {
			var amount = $("#stop").val();
			var res = amount.split(":::");
			$("#amount").val(res[1]);
		});
</script>
<script>
function HandlePopupResult(result) {
	
       data=result.split("^");
	   $("#enq_no").val(data[0]);
	   $("#stu_name").val(data[2]);
	   $("#fat_name").val(data[4]);
	   $("#address").val(data[3]);
	   $("#mot_name").val(data[5]);
	  
	   $("#class").val(data[7]);
	   $("#mobile").val(data[8]);
	   $("#gender").val(data[12]);
	   $date=data[13].split("-");
	   $("#dob").val($date[2]+"/"+$date[1]+"/"+$date[0]);
	  
	  
	}
	x=0;
	function copy_address(){
		
		if(x==0){
		$('input[name=\'address_co\']').val($('input[name=\'address\']').val());
		x=1;
		}else{
			$('input[name=\'address_co\']').val("");
			x=0;
		}
		
	}
	</script>
<!-- /container -->
<?php
include('footer.php');
?>