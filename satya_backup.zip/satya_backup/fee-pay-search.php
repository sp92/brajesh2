<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') { header("Location: main.php"); }
include('header.php');
?>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row">
		<h3>Enter / Search Admission No.</h3>
		<div class="col-md-2">
		<form id="form1" name="form1" action="fee-status">

		<input type="text" name="search" class="form-control" id="search" placeholder="Admission Number"/>
		</div>
		<div class="col-md-2">
		 <button class="btn btn-primary ladda-button kill-evo" type='submit' data-style="zoom-out"><span class="ladda-label">Search </span></button>
		</div>
		</form>
		
    </div>
	<div class="row">
	<h3> Search By Name</h3>
	<div class="col-md-4">
	<input type="text" name="search_name" class="form-control" id="search_name" placeholder="search by name"/>
	</div>
	    <div id="show_data"></div>
		</div>
	</div>
</div> <!-- /container -->
<script>
     $("#form1").submit(function(e){
		e.preventDefault();
		if($("#search").val()==""){
			$("#search").val("");
			$.notify({message: '<strong>Please</strong> Enter Admission Number.' },{type: 'danger'});
		}else if(isNaN($("#search").val())){
			$("#search").val("");
		$.notify({message: '<strong>Please</strong> Enter  Number Only.' },{type: 'danger'});
		}else{
			formAction = $("#form1").attr('action');
		    window.location.href="./"+formAction+"/"+$("#search").val();
		}
		
		
	 });
	 $("#search_name").keyup(function(){
		if($(this).val().length>2){
		$.ajax({
			type: 'POST',
			url: 'function/feefunction?search_name='+$(this).val(),
			success: function (data) {
					$("#show_data").html(data);
			}
		});
		}
		 
	 })
</script>
<?php
include('footer.php');
?>