<?php
$page='master';
require('core.php');
if($_SESSION['ACC_MASTER']=='0') 
{
	header("Location: main.php");
}
if(@$_REQUEST['hdnCmd']=="ADD")
	{
	$session2=clean($_REQUEST['session']);
	
	$data = Array (
		'session' => $session2
	);
	$db->insert ('session', $data);
	header("Location: ./master-session");
	}
if(@$_REQUEST['action']=="del")
	{
	$db->where('id', round($_REQUEST['id']));
	$db->delete('session');
	header("Location: ./master-session");
	}
include('header.php');
?>
<div class="container">

<div class="row">
<div class="col-md-2">
<?php print_menu($master_menu_items); ?>
</div>
<div class="col-md-8">
<h3>Session Master</h3>
<center>
<table class="table table-striped table-hover table-bordered" style="width:350px;">
<thead>
<tr>
<th style="width:20px;">SR</th>
<th style="width:150px;">Session Year</th>
<th style="width:1px;">Update</th>
</tr>
</thead>
<tbody>
				
			<?php
				$n=1;
					$user = $db->get ("session");
					if ($db->count > 0) {
						foreach ($user as $u) { 
							
					?>			
<tr>
<td><?php echo $n; $n++; ?></td>
<td><?php echo $u['session']; ?></td>
<td><a href="master-session?action=del&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a></td>
</tr>
		  <?php }} ?>	
<tr>				
<td></td>
<td colspan=2><form action="./master-session" method="post"><input type="text" name="session" />
<input type="hidden" name="hdnCmd" value="ADD"><input type="submit" name="submit" class="btn-primary" value="Add Session" /></form>
</td>
</tr>				
</table>
</center>
</div>

    </div>
    </div> <!-- /container -->
<?php
include('footer.php');
?>