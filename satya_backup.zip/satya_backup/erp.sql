-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2017 at 07:58 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_acl`
--

CREATE TABLE IF NOT EXISTS `kisalg_acl` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `perm_name` varchar(100) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `perm_name` (`perm_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `kisalg_acl`
--

INSERT INTO `kisalg_acl` (`id`, `perm_name`, `user_id`) VALUES
(1, 'master_update_school_info', '1,3'),
(2, 'master_add_session', '3'),
(3, 'fee_change_fee_define', '3'),
(4, 'export_table', '1,3'),
(5, 'approve_cash_discounts', '1');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_admin`
--

CREATE TABLE IF NOT EXISTS `kisalg_admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `master` enum('0','1') NOT NULL DEFAULT '1',
  `admin` enum('0','1') NOT NULL DEFAULT '1',
  `frontdesk` enum('0','1') NOT NULL DEFAULT '1',
  `counselling` enum('0','1') NOT NULL,
  `student` enum('0','1') NOT NULL DEFAULT '1',
  `fee` enum('0','1') NOT NULL DEFAULT '1',
  `admission` enum('0','1') NOT NULL DEFAULT '1',
  `attendance` enum('0','1') NOT NULL DEFAULT '0',
  `transport` enum('0','1') NOT NULL DEFAULT '1',
  `certificate` enum('0','1') NOT NULL DEFAULT '1',
  `comm` enum('0','1') NOT NULL DEFAULT '0',
  `setting` enum('0','1') NOT NULL DEFAULT '1',
  `group` enum('user','admin','root') NOT NULL DEFAULT 'user',
  `location` varchar(100) NOT NULL,
  `is_log` enum('TRUE','FALSE','N/A') NOT NULL DEFAULT 'FALSE',
  `code` varchar(100) NOT NULL,
  `last_login` datetime NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `kisalg_admin`
--

INSERT INTO `kisalg_admin` (`id`, `username`, `password`, `name`, `master`, `admin`, `frontdesk`, `counselling`, `student`, `fee`, `admission`, `attendance`, `transport`, `certificate`, `comm`, `setting`, `group`, `location`, `is_log`, `code`, `last_login`, `status`) VALUES
(1, 'admin', '2571933', 'ADMIN', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', 'admin', 'SCHOOL OFFICE', 'N/A', '', '2014-09-29 17:18:48', '1'),
(2, 'rahul', 'rahul!@#', 'Rahul', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '0', '1', 'user', 'SCHOOL OFFICE', 'FALSE', '562', '2016-05-13 12:25:46', '1'),
(3, 'root', 'root', 'ROOT', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 'root', 'SCHOOL OFFICE', 'N/A', '', '2014-09-29 17:18:48', '1');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_attendance_stu`
--

CREATE TABLE IF NOT EXISTS `kisalg_attendance_stu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stu_id` int(10) NOT NULL,
  `atten_code` varchar(50) NOT NULL,
  `remark` text NOT NULL,
  `date` date NOT NULL,
  `session` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=77 ;

--
-- Dumping data for table `kisalg_attendance_stu`
--

INSERT INTO `kisalg_attendance_stu` (`id`, `stu_id`, `atten_code`, `remark`, `date`, `session`) VALUES
(55, 1, 'AB', '', '2017-01-14', '2016-2017'),
(56, 15, 'LV', '', '2017-01-14', '2016-2017'),
(57, 9, 'LV', '', '2017-01-14', '2016-2017'),
(58, 19, 'AB', '', '2017-01-13', '2016-2017'),
(59, 17, 'LV', '', '2017-01-13', '2016-2017'),
(60, 16, 'ML', '', '2017-01-13', '2016-2017'),
(61, 13, 'AB', '', '2017-01-09', '2016-2017'),
(62, 1, 'AB', '', '2017-01-09', '2016-2017'),
(63, 11, 'LV', '', '2017-01-09', '2016-2017'),
(64, 12, 'AB', '', '2017-01-09', '2016-2017'),
(65, 9, 'ML', '', '2017-01-09', '2016-2017'),
(66, 19, 'AB', '', '2017-01-09', '2016-2017'),
(67, 4, 'LV', '', '2017-01-09', '2016-2017'),
(68, 17, 'AB', '', '2017-01-09', '2016-2017'),
(69, 16, 'LV', '', '2017-01-09', '2016-2017'),
(70, 10, 'AB', '', '2017-01-09', '2016-2017'),
(71, 2, 'AB', '', '2017-01-09', '2016-2017'),
(72, 8, 'LV', '', '2017-01-09', '2016-2017'),
(73, 7, 'AB', '', '2017-01-09', '2016-2017'),
(74, 6, 'LV', '', '2017-01-09', '2016-2017'),
(75, 5, 'AB', '', '2017-01-09', '2016-2017'),
(76, 3, 'ML', '', '2017-01-09', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_attendance_w_days`
--

CREATE TABLE IF NOT EXISTS `kisalg_attendance_w_days` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `class` varchar(50) NOT NULL,
  `head` varchar(50) NOT NULL,
  `remark` text NOT NULL,
  `session` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `kisalg_attendance_w_days`
--

INSERT INTO `kisalg_attendance_w_days` (`id`, `date`, `class`, `head`, `remark`, `session`) VALUES
(17, '2017-01-14', 'LKG - A', 'W', '', '2016-2017'),
(18, '2017-01-14', 'LKG - B', 'HL', 'As per dm', '2016-2017'),
(19, '2017-01-14', 'UKG - A', 'HL', 'As per dm', '2016-2017'),
(20, '2017-01-13', 'LKG - B', 'W', '', '2016-2017'),
(21, '2017-01-13', 'LKG - A', 'PL', 'for exams', '2016-2017'),
(22, '2017-01-09', 'LKG - A', 'W', '', '2016-2017'),
(23, '2017-01-09', 'LKG - B', 'W', '', '2016-2017'),
(24, '2017-01-09', 'UKG - A', 'W', '', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_atten_code`
--

CREATE TABLE IF NOT EXISTS `kisalg_atten_code` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `heading` varchar(100) NOT NULL,
  `student` enum('0','1') NOT NULL,
  `staff` enum('0','1') NOT NULL,
  `color` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `kisalg_atten_code`
--

INSERT INTO `kisalg_atten_code` (`id`, `code`, `heading`, `student`, `staff`, `color`) VALUES
(1, 'P', 'Present', '1', '1', '#fff'),
(2, 'AB', 'Absent', '1', '1', '#f78c75'),
(3, 'LV', 'Leave', '1', '1', '#ffd652'),
(4, 'ML', 'Medical', '1', '', '#3af');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_atten_heads`
--

CREATE TABLE IF NOT EXISTS `kisalg_atten_heads` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `heading` varchar(100) NOT NULL,
  `field` varchar(50) NOT NULL,
  `student` enum('0','1') NOT NULL,
  `staff` enum('0','1') NOT NULL,
  `color` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `kisalg_atten_heads`
--

INSERT INTO `kisalg_atten_heads` (`id`, `code`, `heading`, `field`, `student`, `staff`, `color`) VALUES
(1, 'W', 'Working', 'working', '1', '1', '#fff'),
(2, 'HL', 'Holiday', 'holiday', '1', '1', '#f78c75'),
(5, 'PL', 'Prep. Leave', 'prepleave', '1', '1', '#f7eafa');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_bank_detail`
--

CREATE TABLE IF NOT EXISTS `kisalg_bank_detail` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `micrcode` varchar(100) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `created` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=277 ;

--
-- Dumping data for table `kisalg_bank_detail`
--

INSERT INTO `kisalg_bank_detail` (`id`, `micrcode`, `bank_name`, `branch_name`, `created`) VALUES
(3, '110017037', 'Corporation Bank', 'vasanth vihar', '2016-07-08'),
(4, '110010029', 'allahabad bank ', 'vikas puri', '2016-07-08'),
(5, '110020043', 'Indian overseas bank', 'wast punjabi bagh', '2016-07-08'),
(6, '110036018', 'Standard Chartered Bank', 'saket', '2016-07-08'),
(7, '110025112', 'syndicate bank', 'vikas puri', '2016-07-08'),
(8, '110229108', 'Icici Bank', 'tilak nagar', '2016-07-08'),
(9, '11002181', 'State Bank Of India', 'Kesho Pur', '2016-07-08'),
(10, '110026107', 'Union Bank', 'Tilak Nagar', '2016-07-08'),
(11, '110013037', 'Bank Of India', 'Vikas Puri', '2016-07-08'),
(12, '110240012', 'HDFC Bank', 'Sector-14, Gurgaon', '2016-07-08'),
(13, '110014022', 'Bank Of Maharashtra', 'Sec 11 Rohini', '2016-07-08'),
(14, '110011013', 'Andhra Bank', 'Rajadhani Enclave', '2016-07-08'),
(15, '110019029', 'Indian Bank', 'Vikas Puri', '2016-07-08'),
(16, '110013044', 'Bank Of India', 'Keshopur Village', '2016-07-08'),
(17, '110211012', 'AXIS BANK LTD.', 'Vikas Puri', '2016-07-08'),
(18, '110024038', 'Pnb', 'Asaf Ali Road', '2016-07-08'),
(19, '110229183', 'Icici Bank', 'Vikas Puri', '2016-07-08'),
(20, '110240111', 'HDFC Bank', 'Sector-31-32, Gurgaon', '2016-07-08'),
(21, '110240066', 'HDFC Bank', 'Naraina Indl Area', '2016-07-08'),
(22, '110024091', 'Pnb', 'Tilak Nagar', '2016-07-08'),
(23, '110234028', 'Induslnd Bank', 'Naraina ', '2016-07-08'),
(24, '110037002', 'Citi Bank', 'Delhi', '2016-07-08'),
(25, '110020086', 'Indian Overseas Bank', 'Janak Puri', '2016-07-08'),
(26, '110015188', 'Canra Bank', 'Hari Nagar', '2016-07-08'),
(27, '110019014', 'Indian Bank', 'Shantiniketan', '2016-07-08'),
(28, '110024244', 'Pnb', 'Sec-10 Dwarka', '2016-07-08'),
(29, '110229020', 'Icici Bank', 'Vikas Puri', '2016-07-08'),
(30, '110036014', 'Standard Chartered Bank', 'New Friends Colony', '2016-07-08'),
(31, '110240037', 'HDFC Bank', 'Mehrauli Gurgaon Road', '2016-07-08'),
(32, '110027023', 'United Bank Of India', 'Fatehnagar Branch', '2016-07-08'),
(33, '110015073', 'Canara Bank', 'Mayapuri', '2016-07-08'),
(34, '110211075', 'AXIS BANK LTD.', 'Patel Nagar', '2016-07-08'),
(35, '110229011', 'Icici Bank', 'Janak Puri', '2016-07-08'),
(36, '110012118', 'Bank Of Baroda', 'Vikas Puri', '2016-07-08'),
(37, '110229002', 'Icici Bank', 'Cannought Place', '2016-07-08'),
(38, '110229222', 'Icici Bank', 'Dlf Phase-3, Gurgaon', '2016-07-08'),
(39, '110019006', 'Indian Bank', 'Janak Puri', '2016-07-08'),
(40, '110229149', 'Icici Bank', 'Karol Bagh 3 Branch', '2016-07-08'),
(41, '110019016', 'Indian Bank', 'Tilak Nagar', '2016-07-08'),
(42, '110012123', 'Bank Of Baroda', 'Tilak Nagar', '2016-07-08'),
(43, '110014054', 'Bank Of Maharastra', 'Vikas Puri', '2016-07-08'),
(44, '110020018', 'Indian Oversease Bank', 'Janak Puri Branch', '2016-07-08'),
(45, '110004025', 'State Bank Of Hyderabad', 'Vikas Puri', '2016-07-08'),
(46, '110002302', 'State Bank Of India', 'A G C R Building', '2016-07-08'),
(47, '110211105', 'Axis Bank', 'New Friends Colony', '2016-07-08'),
(48, '110240093', 'Hdfc Bank', 'Sec-53 Gurgaon', '2016-07-08'),
(49, '110017090', 'Corporation Bank', 'Vikas Puri', '2016-07-08'),
(50, '110485031', 'Kotak Mahindra Bank', 'A-3 Janak Puri', '2016-07-08'),
(51, '110002178', 'State Bank Of India', 'Vikas Puri', '2016-07-08'),
(52, '827002002', 'State Bank Of India', 'Bokaro', '2016-07-08'),
(53, '110018030', 'Dena Bank', 'Paschim Vihar', '2016-07-08'),
(54, '110485047', 'Kotak Mahindra Bank', 'Dlf City Ph-iv Gurgaon', '2016-07-08'),
(55, '110024047', 'Pnb', 'Hari Nagar', '2016-07-08'),
(56, '110013073', 'Bank Of India', 'Dwarka', '2016-07-08'),
(57, '110026021', 'Union Bank', 'Azadpur', '2016-07-08'),
(58, '400037003', 'Citi Bank', 'N.a. Mumbai', '2016-07-08'),
(59, '110240022', 'Hdfc Bank', 'East Patel Nagar', '2016-07-08'),
(60, '110002054', 'State Bank Of India', 'Janak Puri', '2016-07-08'),
(61, '110009003', 'State Bank Of Travancore', 'R K Puram', '2016-07-08'),
(62, '110240050', 'HDFC Bank', 'Vikas Puri', '2016-07-08'),
(63, '110064018', 'Kotak Mahindra Bank', 'Vikas Puri', '2016-07-08'),
(64, '110003037', 'State Bank Of Bikaner And Jaipur', 'Vikas Puri', '2016-07-08'),
(65, '110211023', 'Axis Bank', 'Janak Puri', '2016-07-08'),
(66, '110229027', 'Icici Bank', 'Uttam Nagar', '2016-07-08'),
(67, '110259001', 'Idbi Bank', 'K.g.marg', '2016-07-11'),
(68, '110240186', 'HDFC Bank', 'Janak Puri', '2016-07-11'),
(69, '', '', '', '2016-07-11'),
(70, '110002066', 'State Bank Of India', 'Kishanganj', '2016-07-11'),
(71, '110211020', 'Axis Bank', 'Saket', '2016-07-11'),
(72, '110024115', 'Punjab National Bank', 'Bhikhaiji Cama Place', '2016-07-11'),
(73, '110240109', 'HDFC Bank', 'Sector-23, Gurgaon', '2016-07-11'),
(74, '390240002', 'HDFC Bank', 'Baroda', '2016-07-11'),
(75, '110022057', 'O B C', 'Janak Puri', '2016-07-11'),
(76, '110023051', 'Punjab & Sindh Bank', 'Delhi Cantonement', '2016-07-11'),
(77, '110229060', 'Icici Bank', 'Sector-54, Gurgaon', '2016-07-11'),
(78, '110240011', 'HDFC Bank', 'West Punjabi Bagh', '2016-07-11'),
(79, '110211006', 'Axis Bank', 'Pitampura', '2016-07-11'),
(80, '110039002', 'H S B C', 'Barakhamba Road', '2016-07-11'),
(81, '110211022', 'Axis Bank', 'Ashok Vihar', '2016-07-11'),
(82, '1100156137', 'Central Bank Of India', 'Old Rajender Nagar', '2016-07-11'),
(83, '110002111', '', 'Parliament House', '2016-07-11'),
(84, '110024098', 'Punjab National Bank', 'Vikas Puri', '2016-07-11'),
(85, '110240228', 'HDFC Bank', 'Tagore Garden', '2016-07-11'),
(86, '110002468', 'State Bank Of India', 'Metcalfe House', '2016-07-11'),
(87, '110015105', 'Canara Bank', 'Uttam Nagar', '2016-07-11'),
(88, '110002059', 'State Bank Of India', 'Kalkaji', '2016-07-11'),
(89, '110023118', 'Punjab & Sindh Bank', 'Vikas Puri', '2016-07-11'),
(90, '110064018.', 'Ing Vysya Bank Ltd.', 'Vikaspuri', '2016-07-11'),
(91, '110259030', 'Idbi Bank', 'Vikas Puri', '2016-07-11'),
(92, '110229090', 'Icici Bank', 'Badshahpur Gurgaon', '2016-07-11'),
(93, '110229059', 'Icici Bank', 'Bahadur Shah Zafar Marg', '2016-07-11'),
(94, '110532009', 'Yes Bank Ltd. ', 'Vishal Enclave', '2016-07-11'),
(95, '110002119', 'State Bank Of India', 'South Patel Nagar', '2016-07-11'),
(96, '110211002', 'Axis Bank', 'New Delhi', '2016-07-11'),
(97, '110485032', 'Kotak Mahindra Bank', 'Okhla Indl. Area', '2016-07-11'),
(98, '110037009', 'Citi Bank', 'New Delhi', '2016-07-11'),
(99, '110240049', 'Hdfc Bank ', 'Paschim Vihar', '2016-07-11'),
(100, '110029033', 'Vijaya Bank', 'Naraina Branch', '2016-07-11'),
(101, '110059017', 'The South Indian Bank Ltd.', 'Rajouri Garden', '2016-07-11'),
(102, '110036006', 'Standard Chartered Bank', 'Sec-24, Gurgaon', '2016-07-11'),
(103, '110022150', 'O B C', 'Vikas Puri', '2016-07-11'),
(104, '110229207', 'HDFC Bank', 'Mayapuri', '2016-07-11'),
(105, '110240079', 'HDFC Bank', 'Manesar', '2016-07-11'),
(106, '110240167', 'HDFC Bank', 'Vikas Puri', '2016-07-11'),
(107, '110485022', 'Kotak Mahindra Bank', 'South Extn Part II', '2016-07-11'),
(108, '110240001', 'Hdfc Bank', 'Kg Marg', '2016-07-11'),
(109, '110240088', 'Hdfc Bank', 'Meera Bagh', '2016-07-11'),
(110, '110012018', 'Bank Of Baroda', 'Greater Kailash', '2016-07-11'),
(111, '110015134', 'Canara Bank', 'Sector-15, Rohini', '2016-07-11'),
(112, '110015114', 'Canra Bank', 'Vikas Puri', '2016-07-11'),
(113, '110240016', 'Hdfc Bank', 'Janak Puri B Block', '2016-07-11'),
(114, '110036017', 'Standard Chartered Bank', 'Mg Road Gurgaon', '2016-07-11'),
(115, '110029007', 'Vijaya Bank', 'Palam Airport', '2016-07-11'),
(116, '110020024', 'Indian Overseas Bank', 'Sadar Bazar Delhi Cantonment', '2016-07-11'),
(117, '110229005', 'Icici Bank', 'Sector 18 Noida', '2016-07-11'),
(118, '110011058', 'Andhra Bank', 'Deepali Chowk', '2016-07-11'),
(119, '110002398', 'State Bank Of India', 'Ganesh Nagar', '2016-07-11'),
(120, '110025168', 'Syndicate Bank', 'Uttam Nagar', '2016-07-11'),
(121, '110002181', 'State Bank Of India', 'Keshopur', '2016-07-11'),
(122, '110002019', 'State Bank Of India', 'Chaukhandi', '2016-07-11'),
(123, '110195010', 'The Vaish Co-operative New Bank Ltd.', 'J Block Vikas Puri', '2016-07-11'),
(124, '110018054', 'Dena Bank', 'Vikas Puri', '2016-07-11'),
(125, '110004006', 'State Bank Of Hyderabad', 'Shalimarbagh', '2016-07-11'),
(126, '110211049', 'Axis Bank', 'Tilak Nagar', '2016-07-11'),
(127, '110024407', 'Punjab National Bank', 'Vikas Puri', '2016-07-11'),
(128, '110023096', 'Punjab & Sindh Bank', 'Tilak Nagar', '2016-07-11'),
(129, '110059005', 'South Indian Bank', 'Rohini', '2016-07-11'),
(130, '110017027', 'Corporation Bank', 'Tilak Nagar', '2016-07-11'),
(131, '110211068', 'AXIS BANK LTD.', 'Rajouri Garden', '2016-07-11'),
(132, '110240017', 'HDFC Bank', 'Defence Colony', '2016-07-11'),
(133, '110016030', 'Central Bank Of India', 'Tilak Nagar', '2016-07-11'),
(134, '110328007', 'P M C Bank', 'Karol Bagh', '2016-07-11'),
(135, '000030000', 'R B S', 'Barakhamba Road', '2016-07-11'),
(136, '110240474', 'HDFC Bank', 'Janak Puri', '2016-07-11'),
(137, '110240041', 'HDFC Bank', 'Rajouri Garden', '2016-07-11'),
(138, '110229036', 'Icici Bank', '110229036', '2016-07-11'),
(139, '110002086', 'State Bank Of India', 'Nehru Place', '2016-07-11'),
(140, '110019011', 'Indian Bank', 'Rajouri Garden', '2016-07-11'),
(141, '110485090', 'Kotak Mahindra Bank', 'Peeragrahi', '2016-07-11'),
(142, '110211007', 'Axis Bank', 'Nehru Place', '2016-07-11'),
(143, '110014042', 'Bank Of Maharashtra', 'Pitam Pura', '2016-07-11'),
(144, '110027045', 'United Bank Of India', 'Vikas Puri', '2016-07-11'),
(145, '110240030', 'Hdfc Bank', 'Sec 5, Dwarka', '2016-07-11'),
(146, '110019004', 'Indian Bank', 'Desh Bandhu Gupta Road', '2016-07-11'),
(147, '110002109', 'State Bank Of India', 'Roshanara Road', '2016-07-11'),
(148, '110211070', 'Axis Bank', 'Sector-54, Gurgaon', '2016-07-11'),
(149, '110240077', 'HDFC Bank', 'Udyog Vihar, Gurgaon', '2016-07-11'),
(150, '110026063', 'United Bank Of India', 'Vikas Puri', '2016-07-11'),
(151, '110051009', 'J&k Bank', 'Phase-1, Naraina', '2016-07-11'),
(152, '110026030', 'Union Bank Of India', 'Nehru Place', '2016-07-11'),
(153, '110051035', 'J&k Bank', 'Prithvi Raj Road', '2016-07-11'),
(154, '110023020', 'Punjab & Sindh Bank', '110023020', '2016-07-11'),
(155, '110532061', 'Yes Bank', 'Vikas Puri', '2016-07-11'),
(156, '110240084', 'HDFC Bank', 'Chandni Chowk', '2016-07-11'),
(157, '110229018', 'Icici Bank', 'Rajouri Garden', '2016-07-11'),
(158, '110259021', 'Idbi  Bank ', 'Janak Puri', '2016-07-11'),
(159, '110002057', 'State Bank Of India', 'Jawalapuri', '2016-07-11'),
(160, '110240085', 'Hdfc Bank', 'Gole Market', '2016-07-11'),
(161, '110211016', 'AXIS BANK LTD.', 'Khan Market', '2016-07-11'),
(162, '110017040', 'Corporation Bank', 'Mundka', '2016-07-11'),
(163, '110229003', 'Icici Bank', 'Huda Shopping Center Gurgaon', '2016-07-11'),
(164, '110023013', 'Punjab & Sindh Bank', 'Rajouri Garden', '2016-07-11'),
(165, '000088', 'HDFC BANK', 'JANAK PURI', '2016-07-11'),
(166, '110240242', 'Hdfc Bank ', 'Katwaria Sarai', '2016-07-11'),
(167, '110019022', 'Indian Bank', 'Saket', '2016-07-11'),
(168, '110007088', 'State Bank Of Patiala', 'Vikas Puri', '2016-07-11'),
(169, '110485034', 'Kotak Mahindra Bank', 'Vikas Puri', '2016-07-11'),
(170, '110039005', 'Hsbc', 'Mg Road Gurgaon', '2016-07-11'),
(171, '110328004', 'P M C Bank', 'Uttam Nagar', '2016-07-11'),
(172, '110023090', 'Punjab & Sindh Bank', 'Meera Bagh', '2016-07-11'),
(173, '110002379', 'State Bank Of India', 'Hari Nagar', '2016-07-11'),
(174, '110022160', 'O B C', 'Paschim Vihar', '2016-07-11'),
(175, '110064013', 'Kotak Mahindra Bank', 'Kirti Nagar', '2016-07-11'),
(176, '110017072', 'Corporation Bank', 'Rajouri Garden', '2016-07-11'),
(177, '000234000', 'Induslnd Bank', 'Vikas Puri', '2016-07-11'),
(178, '110002073', 'State Bank Of India', 'Mayapuri', '2016-07-11'),
(179, '110029065', 'Vijaya Bank', 'Tilak Nagar', '2016-07-11'),
(180, '110229038', 'Icici Bank', 'Paschim Vihar', '2016-07-11'),
(181, '110053015', 'Karur Vysya Bank', 'Kamla Nagar', '2016-07-11'),
(182, '110016021', 'Central Bank Of India', 'Press Area, New Delhi', '2016-07-12'),
(183, '110015091', 'Canara Bank', 'Rohtas Nagar', '2016-07-12'),
(184, '110485002', 'Kotak Mahindra Bank', 'Kasturba Gandhi Marg', '2016-07-12'),
(185, '110015138', 'Canara Bank', 'Panjabi Bagh', '2016-07-12'),
(186, '110010040', 'Allahabad', 'Bindapur, Uttam Nagar', '2016-07-12'),
(187, '110002411', 'State Bank Of India', 'Sushant Lok, Gurgaon', '2016-07-12'),
(188, '110002125', 'State Bank Of India', 'Tilak Nagar', '2016-07-12'),
(189, '110012079', 'Bank Of Baroda', 'Janak Puri', '2016-07-12'),
(190, '110240057', 'HDFC Bank', 'Kirti Nagar', '2016-07-12'),
(191, '110240365', 'HDFC Bank', 'Sector-47, Gurgaon', '2016-07-12'),
(192, '110240086', 'HDFC Bank', 'Mayapuri', '2016-07-12'),
(193, '110240172', 'Hdfc Bank', 'Tilak Nagar', '2016-07-12'),
(194, '110015010', 'Canara Bank', 'Gole Market', '2016-07-12'),
(195, '110211091', 'Axis Bank Ltd.', 'Kashmere Gate', '2016-07-12'),
(196, '110018015', 'Dena Bank', 'Hari Nagar', '2016-07-12'),
(197, '110012024', 'Bank Of Baroda', 'Naraina', '2016-07-12'),
(198, '110234008', 'Indusind Bank', 'Janakpuri', '2016-07-12'),
(199, '110532033', 'Yes Bank', 'Sushant Lok Gurgaon', '2016-07-12'),
(200, '110012023', 'Bank Of Baroda', 'Najafgarh Road', '2016-07-12'),
(201, '110002347', 'State Bank Of India', 'Janka Puri', '2016-07-12'),
(202, '110229030', 'Icici Bank', 'Dlf City Gurgaon', '2016-07-12'),
(203, '110022037', 'Oriental Bank Of Commerce', 'Tagore Garden', '2016-07-12'),
(204, '110532099', 'Yes Bank', 'East Patel Nagar', '2016-07-12'),
(205, '110240014', 'Hdfc Bank', 'Sec 18 Noida', '2016-07-12'),
(206, '110013005', 'B O I', 'Chittaranjan Park', '2016-07-12'),
(207, '110002435', 'State Bank Of India', 'Timarpur', '2016-07-12'),
(208, '110211019', 'Axis Bank Ltd.', 'Dlf Gurgaon', '2016-07-12'),
(209, '110026070', 'Union Bank', 'Janak Puri', '2016-07-12'),
(210, '400064011', 'Kotak Mahindra Bank', 'Andheri', '2016-07-12'),
(211, '700211047', 'Axis Bank', 'Kolkata', '2016-07-12'),
(212, '110229190', 'Icici Bank', 'Sec 11 Noida', '2016-07-12'),
(213, '110240052', 'Hdfc Bank', 'Vasundhra Enclave', '2016-07-12'),
(214, '110013008', 'Bank Of India', 'East Of Kailash', '2016-07-13'),
(215, '110211087', 'Axis Bank', 'Janak Puri', '2016-07-13'),
(216, '110002179', 'State Bank Of India', 'Meera Bagh', '2016-07-13'),
(217, '700229014', 'Icici Bank', 'Kolkata', '2016-07-13'),
(218, '110184003', 'The Nanital Bank Ltd', 'Tilak Nagar', '2016-07-13'),
(219, '110014039', 'Bank Of Maharastra', 'Rajouri Garden', '2016-07-13'),
(220, '110037003', 'Citi Bank', 'New Delhi', '2016-07-13'),
(221, '110002121', 'State Bank Of India', 'Subhash Nagar', '2016-07-13'),
(222, '110240024', 'Hdfc Bank', 'Rani Bagh Pitampura', '2016-07-13'),
(223, '110023037', 'Punjab & Singh Bank', 'Tilak Nagar', '2016-07-14'),
(224, '110009020', 'State Bank Of Travancore', 'IMT Manesar Gurgaon', '2016-07-14'),
(225, '110025080', 'Syndicate Bank', 'Jail Road', '2016-07-14'),
(226, '110064003', 'Ing Vysya Bank Ltd.', 'Barakhamba Rd', '2016-07-14'),
(227, '110011007', 'Andhra Bank', 'Janakpuri', '2016-07-14'),
(228, '110029015', 'Vijaya Bank', 'New Krishna Park', '2016-07-14'),
(229, '110240087', 'HDFC BANK ', 'G K- II', '2016-07-14'),
(230, '110002380', 'State Bank Of India', 'Hastsal Vikas Puri', '2016-07-14'),
(231, '110052023', 'Karnataka Bank Ltd.', 'Vikas Puri', '2016-07-14'),
(232, '110020066', 'Indian Overseas Bank', 'Lodhi Road', '2016-07-14'),
(233, '110211027', 'Axis Bank Ltd.', 'Kirti Nagar', '2016-07-14'),
(234, '110024437', 'Punjab National Bank', 'Mandir Marg', '2016-07-14'),
(235, '10025031', 'Syndicate Bank', 'Mayapuri', '2016-07-14'),
(236, '110111007', 'Post Office Saving  Bank', 'Janak Puri', '2016-07-14'),
(237, '110234017', 'Indusind Bank', 'Karol Bagh', '2016-07-14'),
(238, '110229033', 'Icici Bank', 'Delhi University', '2016-07-14'),
(239, '110012013', 'Bank Of Baroda', 'Connaught  Place', '2016-07-14'),
(240, '110009013', 'State Bank Of Travancore', 'Tilak Nagar', '2016-07-14'),
(241, '558460', 'State Bank Of India', 'Safdurjung Airport', '2016-07-14'),
(242, '110002065', 'State Bank Of India', 'Kirti Nagar', '2016-07-15'),
(243, '110211003', 'AXIS BANK LTD.', 'Green Park', '2016-07-15'),
(244, '110059006', 'South Indian Bank', 'Janak Puri', '2016-07-15'),
(245, '110002127', 'State Bank Of India', 'Trilokpuri', '2016-07-15'),
(246, '110240055', 'HDFC Bank', 'Kashmere Gate', '2016-07-15'),
(247, '110059011', 'The South Indian Bank Ltd.', 'Vikas Puri', '2016-07-15'),
(248, '110024030', 'Punjab National Bank', 'Sadar Bazar', '2016-07-15'),
(249, '110024214', 'Punjab National Bank', 'Paschim Vihar', '2016-07-15'),
(250, '110024219', 'Punjab National Bank', 'New Custom House Igia', '2016-07-16'),
(251, '110002153', 'State Bank Of India', 'Uttam Nagar', '2016-07-16'),
(252, '110022169', 'Oriental Bank Of Commerce', 'Tilak Nagar', '2016-07-16'),
(253, '110024079', 'Punjab National Bank', 'Punjabi Bagh', '2016-07-16'),
(254, '110013028', 'Bank Of India', 'Tilak Nagar', '2016-07-16'),
(255, '110240006', 'Hdfc Bank', 'Qutub Enclave', '2016-07-16'),
(256, '000024000', 'Punjab National Bank', 'Kankar Khera, Meerut', '2016-07-18'),
(257, '110026041', 'Union Bank', 'Holumbi', '2016-07-18'),
(258, '110002156', ' Bank Of India', 'Hauz Khas', '2016-07-18'),
(259, '110229047', 'Icici Bank', 'Patel Nagar', '2016-07-18'),
(260, '110059015', 'The South Indian Bank Limited', 'Sainik Vihar', '2016-07-19'),
(261, '110022015', 'O B C', 'Kirti Nagar', '2016-07-20'),
(262, '110011057', 'Andhra Bank', 'Paschim Vihar', '2016-07-20'),
(263, '110240149', 'Hdfc Bank', 'Rajouri Garden', '2016-07-21'),
(264, '110017064', 'Corporation Bank', 'K.g.marg', '2016-07-21'),
(265, '110485019', 'Kotak Mahindra Bank', 'Karol Bagh', '2016-07-25'),
(266, '110002126', 'State Bank Of India', 'Tis Hazari', '2016-07-25'),
(267, '110029059', 'Vijaya Bank', 'Janakpuri', '2016-07-26'),
(268, '110023031', 'Punjab & Sind Bank', 'Janakpuri', '2016-07-26'),
(269, '141240002', 'Hdfc Bank', 'Ludhiana', '2016-07-27'),
(270, '110229007', 'ICICI BANK', 'NEW FRIENDS COLONY', '2016-07-27'),
(271, '110229053', 'Icici Bank', 'Manesar', '2016-07-30'),
(272, '110024081', 'Jab National Bank', 'Rajouri Garden', '2016-07-30'),
(273, '110009019', 'State Bank Of Travancore', 'Janakpuri', '2016-08-02'),
(274, '110229032', 'Icici Bank', 'Panchsheel Park', '2016-08-03'),
(275, '34252352532', 'syndicate', 'bazpur', '2017-01-03'),
(276, '124141421', 'sdfssdsg', 'sgsgwg', '2017-01-03');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_cash_discount_master`
--

CREATE TABLE IF NOT EXISTS `kisalg_cash_discount_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` int(11) NOT NULL,
  `adm_no` int(11) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `approved_remark` varchar(255) NOT NULL,
  `p_amount` int(11) NOT NULL,
  `p_by` varchar(255) NOT NULL,
  `p_date` date NOT NULL,
  `approved` enum('0','1') NOT NULL DEFAULT '0',
  `approved_amount` int(11) NOT NULL,
  `approved_date` date NOT NULL,
  `approved_by` varchar(255) NOT NULL,
  `used` enum('0','1') NOT NULL DEFAULT '0',
  `used_date` date NOT NULL,
  `rec_no` int(11) NOT NULL,
  `session` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `kisalg_cash_discount_master`
--

INSERT INTO `kisalg_cash_discount_master` (`id`, `stu_id`, `adm_no`, `remark`, `approved_remark`, `p_amount`, `p_by`, `p_date`, `approved`, `approved_amount`, `approved_date`, `approved_by`, `used`, `used_date`, `rec_no`, `session`) VALUES
(1, 3, 3, 'f', 'describes all issues', 67, 'ROOT', '2016-12-24', '1', 67, '2016-12-24', 'ROOT', '', '0000-00-00', 0, '2016-2017'),
(2, 2, 2, 'snnnn', 'dgehr ewsfgguifge wefiuifgq wqefgigfb ', 20, 'ROOT', '2016-12-24', '1', 56, '2016-12-24', 'ROOT', '1', '2016-12-24', 0, '2016-2017'),
(3, 6, 6, 'g', '', 500, 'ROOT', '2016-12-24', '0', 0, '0000-00-00', '', '0', '0000-00-00', 0, '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_certificate`
--

CREATE TABLE IF NOT EXISTS `kisalg_certificate` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cert1` varchar(1000) NOT NULL,
  `cert2` varchar(100) NOT NULL,
  `cert3` varchar(100) NOT NULL,
  `cert4` varchar(100) NOT NULL,
  `cert5` varchar(100) NOT NULL,
  `cert6` varchar(100) NOT NULL,
  `cert7` varchar(100) NOT NULL,
  `cert8` varchar(100) NOT NULL,
  `cert9` varchar(100) NOT NULL,
  `cert10` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `kisalg_certificate`
--

INSERT INTO `kisalg_certificate` (`id`, `cert1`, `cert2`, `cert3`, `cert4`, `cert5`, `cert6`, `cert7`, `cert8`, `cert9`, `cert10`) VALUES
(1, 'BIRTH CERTIFICATE', 'TRANSFER CERTIFICATE', 'PHOTOS', 'REPORT CARD', 'MEDICAL CERTIFICATE', 'BLOOD GROUP REPORT', 'OTHER CERTIFICATE', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_charactor_certificate`
--

CREATE TABLE IF NOT EXISTS `kisalg_charactor_certificate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cc_id` int(11) NOT NULL,
  `stu_id` int(11) NOT NULL,
  `class` varchar(100) NOT NULL,
  `nature` varchar(100) NOT NULL,
  `cancelled` enum('0','1') NOT NULL DEFAULT '0',
  `date_issue` date NOT NULL,
  `session` varchar(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `kisalg_charactor_certificate`
--

INSERT INTO `kisalg_charactor_certificate` (`id`, `cc_id`, `stu_id`, `class`, `nature`, `cancelled`, `date_issue`, `session`) VALUES
(1, 1, 12, 'LKG', 'Good', '1', '2017-01-06', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_chq_bounce_master`
--

CREATE TABLE IF NOT EXISTS `kisalg_chq_bounce_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rec_no` int(11) NOT NULL,
  `stu_id` int(11) NOT NULL,
  `adm_no` int(11) NOT NULL,
  `chq_no` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `bounce_date` date NOT NULL,
  `bounce_by` varchar(255) NOT NULL,
  `bounce_reason` varchar(255) NOT NULL,
  `session` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `kisalg_chq_bounce_master`
--

INSERT INTO `kisalg_chq_bounce_master` (`id`, `rec_no`, `stu_id`, `adm_no`, `chq_no`, `amount`, `bounce_date`, `bounce_by`, `bounce_reason`, `session`) VALUES
(3, 23, 9, 9, 'abc123az', 4600, '2017-01-04', 'ROOT', 'check bounce case', '2016-2017'),
(4, 24, 12, 12, 'abc123az', 5250, '2017-01-04', 'ROOT', 'check bounce case', '2016-2017'),
(5, 25, 13, 13, 'sfwqf123', 4600, '2017-01-04', 'ROOT', 'bounce ho gya', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_class_master`
--

CREATE TABLE IF NOT EXISTS `kisalg_class_master` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `class` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `kisalg_class_master`
--

INSERT INTO `kisalg_class_master` (`id`, `class`) VALUES
(17, 'NUR'),
(18, 'LKG'),
(19, 'UKG'),
(37, '1ST'),
(38, '2ND'),
(39, '3RD'),
(40, '4TH'),
(41, '5TH'),
(42, '6TH'),
(43, '7TH'),
(44, '8TH'),
(45, '9TH'),
(46, '10TH'),
(47, '11TH ARTS'),
(48, '11TH COM'),
(49, '11TH SCI'),
(50, '12TH ARTS'),
(51, '12TH COM'),
(52, '12TH SCI');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_discount`
--

CREATE TABLE IF NOT EXISTS `kisalg_discount` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `disc_name` varchar(50) NOT NULL,
  `remark` varchar(100) NOT NULL,
  `head1` int(10) NOT NULL,
  `head2` int(10) NOT NULL,
  `head3` int(10) NOT NULL,
  `head4` int(10) NOT NULL,
  `head5` int(10) NOT NULL,
  `revoke` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `session` varchar(50) NOT NULL,
  `created` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `kisalg_discount`
--

INSERT INTO `kisalg_discount` (`id`, `disc_name`, `remark`, `head1`, `head2`, `head3`, `head4`, `head5`, `revoke`, `session`, `created`) VALUES
(12, '1/2 Tuition Fee', '50% Concession Tuition Fee', 0, 0, 0, 0, 50, 'NO', '2016-2017', 0);

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_extra_charges`
--

CREATE TABLE IF NOT EXISTS `kisalg_extra_charges` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stu_id` int(10) NOT NULL,
  `adm_no` int(10) NOT NULL,
  `ehead_id` varchar(15) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `session` varchar(100) NOT NULL,
  `remark` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `kisalg_extra_charges`
--

INSERT INTO `kisalg_extra_charges` (`id`, `stu_id`, `adm_no`, `ehead_id`, `amount`, `session`, `remark`) VALUES
(1, 1, 1, 'ehead2', '300', '2016-2017', 'Charges against chq bounce no. 112233'),
(2, 1, 1, 'ehead3', '300', '2016-2017', 'awfgqgwqaeh'),
(3, 3, 3, 'ehead3', '175', '2016-2017', 'Found fighting/abusing'),
(4, 2, 2, 'ehead2', '200', '2016-2017', 'wgfqwg'),
(5, 3, 3, 'ehead2', '200', '2016-2017', 'Cheque Bounce'),
(6, 3, 3, 'ehead2', '150', '2016-2017', 'Cheque Bounce'),
(7, 8, 8, 'ehead2', '200', '2016-2017', 'check bounce'),
(8, 6, 6, 'ehead2', '200', '2016-2017', 'Check sv'),
(9, 9, 9, 'ehead2', '200', '2016-2017', 'check bounce case'),
(10, 13, 13, 'ehead2', '200', '2016-2017', 'bounce ho gya');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_extra_heads`
--

CREATE TABLE IF NOT EXISTS `kisalg_extra_heads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ehead_id` varchar(20) NOT NULL,
  `head_name` varchar(20) NOT NULL,
  `amount` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `kisalg_extra_heads`
--

INSERT INTO `kisalg_extra_heads` (`id`, `ehead_id`, `head_name`, `amount`) VALUES
(1, 'ehead1', 'Registration', 300),
(2, 'ehead2', 'Check Bounce ', 200),
(3, 'ehead3', 'Indiscipline charge', 100);

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_fd_master`
--

CREATE TABLE IF NOT EXISTS `kisalg_fd_master` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `visit` enum('0','1') NOT NULL DEFAULT '0',
  `halfday_tr` enum('0','1') NOT NULL DEFAULT '0',
  `halfday_stu` enum('0','1') NOT NULL DEFAULT '0',
  `complain` enum('0','1') NOT NULL DEFAULT '0',
  `counseller` enum('0','1') NOT NULL DEFAULT '0',
  `interview` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `kisalg_fd_master`
--

INSERT INTO `kisalg_fd_master` (`id`, `title`, `mobile`, `visit`, `halfday_tr`, `halfday_stu`, `complain`, `counseller`, `interview`) VALUES
(5, 'Director', '8475976976', '1', '1', '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_feedback`
--

CREATE TABLE IF NOT EXISTS `kisalg_feedback` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `m_type` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `message` text NOT NULL,
  `related` varchar(100) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `comment` text NOT NULL,
  `user` varchar(50) NOT NULL,
  `session` varchar(12) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `kisalg_feedback`
--

INSERT INTO `kisalg_feedback` (`id`, `m_type`, `date`, `name`, `mobile`, `message`, `related`, `status`, `comment`, `user`, `session`) VALUES
(1, 'Complaints', '2016-12-27 11:22:08', 'himanshi', '8512041363', 'awgagewagwqgeqg3', '6 - HIMANSHI - SANJAY KUMAR - UKG - A', '0', '', 'ROOT', '2016-2017'),
(2, 'Suggestion', '2016-12-27 11:46:21', 'daksh', '9999888745', 'segwehwqh', '1 - DAKSH - DHARMESH - LKG - A', '1', 'sfaf', 'ROOT', '2016-2017'),
(3, 'Complaints', '2016-12-28 10:49:42', 'Surya', '7290005481', 'Demo', '5 - JATIN RAJ - AMIT KUMAR - UKG - A', '1', 'Resolved', 'ROOT', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_fee_amount`
--

CREATE TABLE IF NOT EXISTS `kisalg_fee_amount` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `class` varchar(15) DEFAULT NULL,
  `new_old` varchar(10) DEFAULT NULL,
  `type` varchar(20) NOT NULL,
  `fee_cat` varchar(20) NOT NULL,
  `head1_apr` int(10) NOT NULL,
  `head2_apr` int(10) NOT NULL,
  `head3_apr` int(10) NOT NULL,
  `head3_oct` int(10) NOT NULL,
  `head4_apr` int(10) NOT NULL,
  `head4_may` int(10) NOT NULL,
  `head4_jun` int(10) NOT NULL,
  `head4_jul` int(10) NOT NULL,
  `head4_aug` int(10) NOT NULL,
  `head4_sep` int(10) NOT NULL,
  `head4_oct` int(10) NOT NULL,
  `head4_nov` int(10) NOT NULL,
  `head4_dec` int(10) NOT NULL,
  `head4_jan` int(10) NOT NULL,
  `head4_feb` int(10) NOT NULL,
  `head4_mar` int(10) NOT NULL,
  `head5_apr` int(10) NOT NULL,
  `head5_may` int(10) NOT NULL,
  `head5_jun` int(10) NOT NULL,
  `head5_jul` int(10) NOT NULL,
  `head5_aug` int(10) NOT NULL,
  `head5_sep` int(10) NOT NULL,
  `head5_oct` int(10) NOT NULL,
  `head5_nov` int(10) NOT NULL,
  `head5_dec` int(10) NOT NULL,
  `head5_jan` int(10) NOT NULL,
  `head5_feb` int(10) NOT NULL,
  `head5_mar` int(10) NOT NULL,
  `head1_method` varchar(50) NOT NULL,
  `head2_method` varchar(50) NOT NULL,
  `head3_method` varchar(50) NOT NULL,
  `head4_method` varchar(50) NOT NULL,
  `head5_method` varchar(50) NOT NULL,
  `session` varchar(20) NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `fee_id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `kisalg_fee_amount`
--

INSERT INTO `kisalg_fee_amount` (`id`, `class`, `new_old`, `type`, `fee_cat`, `head1_apr`, `head2_apr`, `head3_apr`, `head3_oct`, `head4_apr`, `head4_may`, `head4_jun`, `head4_jul`, `head4_aug`, `head4_sep`, `head4_oct`, `head4_nov`, `head4_dec`, `head4_jan`, `head4_feb`, `head4_mar`, `head5_apr`, `head5_may`, `head5_jun`, `head5_jul`, `head5_aug`, `head5_sep`, `head5_oct`, `head5_nov`, `head5_dec`, `head5_jan`, `head5_feb`, `head5_mar`, `head1_method`, `head2_method`, `head3_method`, `head4_method`, `head5_method`, `session`) VALUES
(14, 'UKG', 'NEW', 'GENERAL', 'GENERAL', 5000, 2000, 2000, 2000, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 'ONE TIME', 'ONE TIME', 'H-YEARLY', 'MONTHLY', 'MONTHLY', '2016-2017'),
(13, 'LKG', 'NEW', 'GENERAL', 'GENERAL', 5000, 2000, 2000, 2000, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 'ONE TIME', 'ONE TIME', 'H-YEARLY', 'MONTHLY', 'MONTHLY', '2016-2017'),
(12, 'NUR', 'NEW', 'GENERAL', 'GENERAL', 5000, 2000, 2000, 2000, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 'ONE TIME', 'ONE TIME', 'H-YEARLY', 'MONTHLY', 'MONTHLY', '2016-2017'),
(15, 'NUR', 'OLD', 'GENERAL', 'GENERAL', 0, 0, 2000, 2000, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 'MONTHLY', 'MONTHLY', 'MONTHLY', 'MONTHLY', 'MONTHLY', '2016-2017'),
(16, 'LKG', 'OLD', 'GENERAL', 'GENERAL', 0, 0, 2000, 2000, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 'MONTHLY', 'MONTHLY', 'MONTHLY', 'MONTHLY', 'MONTHLY', '2016-2017'),
(17, 'UKG', 'OLD', 'GENERAL', 'GENERAL', 0, 0, 2000, 2000, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 600, 'MONTHLY', 'MONTHLY', 'MONTHLY', 'MONTHLY', 'MONTHLY', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_fee_cat`
--

CREATE TABLE IF NOT EXISTS `kisalg_fee_cat` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fee_cat` varchar(1000) NOT NULL,
  `session` varchar(100) NOT NULL,
  UNIQUE KEY `id_2` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `kisalg_fee_cat`
--

INSERT INTO `kisalg_fee_cat` (`id`, `fee_cat`, `session`) VALUES
(1, 'GENERAL', '2016-2017'),
(2, 'FFC', '2016-2017'),
(3, 'RTE', '2016-2017'),
(4, 'STAFF WARD', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_fee_paid`
--

CREATE TABLE IF NOT EXISTS `kisalg_fee_paid` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `rec_no` int(100) DEFAULT NULL,
  `rec_date` date NOT NULL,
  `adm_no` varchar(100) DEFAULT NULL,
  `stu_id` int(11) NOT NULL,
  `month` varchar(100) DEFAULT NULL,
  `particular` varchar(100) DEFAULT NULL,
  `head1` int(10) NOT NULL,
  `head2` int(10) NOT NULL,
  `head3` int(10) NOT NULL,
  `head4` int(10) NOT NULL,
  `head5` int(10) NOT NULL,
  `transport` varchar(50) NOT NULL,
  `amount` varchar(50) DEFAULT NULL,
  `ehead3` int(10) NOT NULL,
  `ehead2` int(10) NOT NULL,
  `ehead1` int(10) NOT NULL,
  `late_fine` varchar(50) NOT NULL,
  `discount` varchar(50) NOT NULL,
  `cancelled` enum('0','1') NOT NULL DEFAULT '0',
  `location` varchar(100) DEFAULT NULL,
  `mode` varchar(10) DEFAULT NULL,
  `user` varchar(100) DEFAULT NULL,
  `cash_amt` varchar(100) DEFAULT NULL,
  `chq_amt` varchar(100) DEFAULT NULL,
  `chq_no` varchar(100) DEFAULT NULL,
  `micr_code` varchar(255) NOT NULL,
  `chq_date` date DEFAULT NULL,
  `chq_bnk` varchar(100) DEFAULT NULL,
  `chq_clr` varchar(100) NOT NULL,
  `remark` varchar(100) NOT NULL,
  `left_fee` varchar(100) NOT NULL,
  `session` varchar(100) DEFAULT NULL,
  `date_time` datetime NOT NULL,
  `ip` varchar(20) NOT NULL,
  UNIQUE KEY `id_2` (`id`),
  KEY `rec_no` (`rec_no`),
  KEY `adm_no` (`adm_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=92 ;

--
-- Dumping data for table `kisalg_fee_paid`
--

INSERT INTO `kisalg_fee_paid` (`id`, `type`, `rec_no`, `rec_date`, `adm_no`, `stu_id`, `month`, `particular`, `head1`, `head2`, `head3`, `head4`, `head5`, `transport`, `amount`, `ehead3`, `ehead2`, `ehead1`, `late_fine`, `discount`, `cancelled`, `location`, `mode`, `user`, `cash_amt`, `chq_amt`, `chq_no`, `micr_code`, `chq_date`, `chq_bnk`, `chq_clr`, `remark`, `left_fee`, `session`, `date_time`, `ip`) VALUES
(1, 'FEE', 1, '2016-12-20', '1', 1, 'APRIL', NULL, 0, 0, 2000, 50, 600, '', '2650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:07:57', '192.168.1.9'),
(2, 'FEE', 1, '2016-12-20', '1', 1, 'MAY', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:07:57', '192.168.1.9'),
(3, 'FEE', 1, '2016-12-20', '1', 1, 'JUNE', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:07:57', '192.168.1.9'),
(4, 'FEE', 1, '2016-12-20', '1', 1, 'JULY', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:07:57', '192.168.1.9'),
(5, 'FEE', 1, '2016-12-20', '1', 1, 'AUGUST', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:07:57', '192.168.1.9'),
(6, 'FEE', 1, '2016-12-20', '1', 1, 'SEPTEMBER', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:07:57', '192.168.1.9'),
(7, 'FEE', 2, '2016-12-20', '2', 2, 'APRIL', NULL, 0, 0, 2000, 50, 600, '0', '2650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:08:09', '192.168.1.9'),
(8, 'FEE', 2, '2016-12-20', '2', 2, 'MAY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:08:09', '192.168.1.9'),
(9, 'FEE', 2, '2016-12-20', '2', 2, 'JUNE', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:08:09', '192.168.1.9'),
(10, 'FEE', 2, '2016-12-20', '2', 2, 'JULY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:08:09', '192.168.1.9'),
(11, 'FEE', 2, '2016-12-20', '2', 2, 'AUGUST', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:08:09', '192.168.1.9'),
(12, 'FEE', 2, '2016-12-20', '2', 2, 'SEPTEMBER', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:08:09', '192.168.1.9'),
(13, 'FEE', 3, '2016-12-20', '6', 6, 'APRIL', NULL, 0, 0, 2000, 50, 600, '', '2650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:09:27', '192.168.1.9'),
(14, 'FEE', 3, '2016-12-20', '6', 6, 'MAY', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:09:27', '192.168.1.9'),
(15, 'FEE', 3, '2016-12-20', '6', 6, 'JUNE', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:09:27', '192.168.1.9'),
(16, 'FEE', 3, '2016-12-20', '6', 6, 'JULY', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:09:27', '192.168.1.9'),
(17, 'FEE', 3, '2016-12-20', '6', 6, 'AUGUST', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:09:27', '192.168.1.9'),
(18, 'FEE', 3, '2016-12-20', '6', 6, 'SEPTEMBER', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:09:27', '192.168.1.9'),
(19, 'FEE', 3, '2016-12-20', '6', 6, 'OCTOBER', NULL, 0, 0, 2000, 50, 600, '', '2650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:09:27', '192.168.1.9'),
(20, 'FEE', 3, '2016-12-20', '6', 6, 'NOVEMBER', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:09:27', '192.168.1.9'),
(21, 'FEE', 3, '2016-12-20', '6', 6, 'DECEMBER', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:09:27', '192.168.1.9'),
(22, 'FEE', 4, '2016-12-20', '8', 8, 'APRIL', NULL, 0, 0, 2000, 50, 600, '0', '2650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:15:49', '192.168.1.9'),
(23, 'FEE', 4, '2016-12-20', '8', 8, 'MAY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:15:49', '192.168.1.9'),
(24, 'FEE', 4, '2016-12-20', '8', 8, 'JUNE', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:15:49', '192.168.1.9'),
(25, 'FEE', 5, '2016-12-20', '7', 7, 'APRIL', NULL, 0, 0, 2000, 50, 600, '', '2650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:53:24', '192.168.1.9'),
(26, 'FEE', 5, '2016-12-20', '7', 7, 'MAY', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:53:25', '192.168.1.9'),
(27, 'FEE', 5, '2016-12-20', '7', 7, 'JUNE', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:53:25', '192.168.1.9'),
(28, 'FEE', 5, '2016-12-20', '7', 7, 'JULY', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 11:53:25', '192.168.1.9'),
(29, 'FEE', 6, '2016-12-20', '2', 2, 'OCTOBER', NULL, 0, 0, 2000, 50, 600, '0', '2650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '3950', 'afW', '', '0000-00-00', 'AWQAG', '', '', '', '2016-2017', '2016-12-20 12:24:05', '192.168.1.9'),
(30, 'FEE', 6, '2016-12-20', '2', 2, 'NOVEMBER', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '3950', 'afW', '', '0000-00-00', 'AWQAG', '', '', '', '2016-2017', '2016-12-20 12:24:05', '192.168.1.9'),
(31, 'FEE', 6, '2016-12-20', '2', 2, 'DECEMBER', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '3950', 'afW', '', '0000-00-00', 'AWQAG', '', '', '', '2016-2017', '2016-12-20 12:24:05', '192.168.1.9'),
(32, 'FEE', 7, '2016-12-20', '6', 6, 'JANUARY', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 12:28:36', '192.168.1.9'),
(33, 'FEE', 8, '2016-12-20', '6', 6, 'FEBRUARY', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 12:30:37', '192.168.1.9'),
(34, 'FEE', 9, '2016-12-20', '5', 5, 'APRIL', NULL, 0, 0, 2000, 50, 600, '0', '2650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 12:31:37', '192.168.1.9'),
(35, 'FEE', 9, '2016-12-20', '5', 5, 'MAY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 12:31:37', '192.168.1.9'),
(36, 'FEE', 9, '2016-12-20', '5', 5, 'JUNE', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 12:31:37', '192.168.1.9'),
(37, 'FEE', 9, '2016-12-20', '5', 5, 'JULY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-20 12:31:37', '192.168.1.9'),
(38, 'FEE', 10, '2016-12-20', '5', 5, 'AUGUST', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '4600', 'AEGQA', '', '0000-00-00', 'AAGA', '', '', '', '2016-2017', '2016-12-20 12:32:15', '192.168.1.9'),
(39, 'FEE', 10, '2016-12-20', '5', 5, 'SEPTEMBER', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '4600', 'AEGQA', '', '0000-00-00', 'AAGA', '', '', '', '2016-2017', '2016-12-20 12:32:15', '192.168.1.9'),
(40, 'FEE', 10, '2016-12-20', '5', 5, 'OCTOBER', NULL, 0, 0, 2000, 50, 600, '0', '2650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '4600', 'AEGQA', '', '0000-00-00', 'AAGA', '', '', '', '2016-2017', '2016-12-20 12:32:15', '192.168.1.9'),
(41, 'FEE', 10, '2016-12-20', '5', 5, 'NOVEMBER', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '4600', 'AEGQA', '', '0000-00-00', 'AAGA', '', '', '', '2016-2017', '2016-12-20 12:32:15', '192.168.1.9'),
(42, 'FEE', 11, '2016-12-21', '1', 1, 'OCTOBER', NULL, 0, 0, 2000, 50, 600, '', '2650', 0, 0, 0, '100', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-21 09:50:49', '192.168.1.9'),
(43, 'FEE', 11, '2016-12-21', '1', 1, 'NOVEMBER', NULL, 0, 0, 0, 50, 600, '', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-21 09:50:49', '192.168.1.9'),
(44, 'FEE', 12, '2016-12-22', '1', 1, 'DECEMBER', NULL, 0, 0, 0, 50, 600, '', '650', 0, 300, 0, '50', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-22 12:42:22', '192.168.1.9'),
(46, 'FEE', 13, '2016-12-22', '3', 3, 'APRIL', NULL, 0, 0, 2000, 50, 600, '0', '2650', 75, 150, 0, '50', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-22 05:07:47', '::1'),
(47, 'FEE', 14, '2016-12-22', '3', 3, 'MAY', NULL, 0, 0, 0, 50, 50, '0', '100', 100, 200, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-22 05:55:18', '::1'),
(48, 'FEE', 15, '2016-12-23', '3', 3, 'MAY', NULL, 0, 0, 0, 0, 550, '0', '550', 0, 0, 0, '50', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-23 10:10:59', '::1'),
(49, 'FEE', 16, '2016-12-24', '3', 3, 'JUNE', NULL, 0, 0, 0, 50, 600, '0', '1900', 0, 0, 0, '200', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-24 10:33:52', '192.168.0.7'),
(50, 'FEE', 16, '2016-12-24', '3', 3, 'JULY', NULL, 0, 0, 0, 50, 600, '1300', '1900', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-24 10:33:52', '192.168.0.7'),
(51, 'FEE', 16, '2016-12-24', '3', 3, 'AUGUST', NULL, 0, 0, 0, 50, 600, '1300', '1900', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-24 10:33:52', '192.168.0.7'),
(52, 'FEE', 16, '2016-12-24', '3', 3, 'SEPTEMBER', NULL, 0, 0, 0, 50, 600, '1300', '1900', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-24 10:33:52', '192.168.0.7'),
(61, 'FEE', 17, '2016-12-24', '3', 3, 'OCTOBER', NULL, 0, 0, 2000, 50, 600, '1300', '3950', 0, 0, 0, '150', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-24 12:31:56', '192.168.0.7'),
(62, 'FEE', 17, '2016-12-24', '3', 3, 'NOVEMBER', NULL, 0, 0, 0, 50, 600, '1300', '1950', 0, 0, 5, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-24 12:31:56', '192.168.0.7'),
(63, 'FEE', 17, '2016-12-24', '3', 3, 'DECEMBER', NULL, 0, 0, 0, 50, 600, '1300', '1950', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, NULL, '', NULL, NULL, '', '', '', '2016-2017', '2016-12-24 12:31:57', '192.168.0.7'),
(66, 'FEE', 18, '2016-12-24', '2', 2, 'JANUARY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 200, 0, '50', '56', '0', 'SCHOOL OFFICE', 'CASH', 'ROOT', NULL, NULL, 'acc', '', NULL, NULL, '', '', '', '2016-2017', '2016-12-24 07:17:08', '192.168.0.7'),
(70, 'FEE', 19, '2017-01-03', '4', 4, 'APRIL', NULL, 0, 0, 2000, 50, 600, '0', '2650', 0, 0, 0, '150', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '3950', 'Caca', '124141421', '0000-00-00', 'sdfssdsg', '', '', '', '2016-2017', '2017-01-03 02:06:25', '192.168.0.4'),
(71, 'FEE', 19, '2017-01-03', '4', 4, 'MAY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'Caca', '124141421', '0000-00-00', 'sdfssdsg', '', '', '', '2016-2017', '2017-01-03 02:06:25', '192.168.0.4'),
(72, 'FEE', 19, '2017-01-03', '4', 4, 'JUNE', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '0', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'Caca', '124141421', '0000-00-00', 'sdfssdsg', '', '', '', '2016-2017', '2017-01-03 02:06:25', '192.168.0.4'),
(73, 'FEE', 20, '2017-01-03', '6', 6, 'MARCH', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '50', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '650', '', '110014022', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-03 02:50:38', '192.168.0.4'),
(74, 'FEE', 21, '2017-01-03', '8', 8, 'JULY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '200', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '4600', 'bscd123', '110211012', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-03 03:56:31', '192.168.0.4'),
(75, 'FEE', 21, '2017-01-03', '8', 8, 'AUGUST', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'bscd123', '110211012', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-03 03:56:31', '192.168.0.4'),
(76, 'FEE', 21, '2017-01-03', '8', 8, 'SEPTEMBER', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'bscd123', '110211012', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-03 03:56:31', '192.168.0.4'),
(77, 'FEE', 21, '2017-01-03', '8', 8, 'OCTOBER', NULL, 0, 0, 2000, 50, 600, '0', '2650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'bscd123', '110211012', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-03 03:56:31', '192.168.0.4'),
(78, 'FEE', 22, '2017-01-03', '7', 7, 'AUGUST', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '50', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '650', 'bscd123', '110019029', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-03 04:07:45', '192.168.0.4'),
(79, 'FEE', 23, '2017-01-04', '9', 9, 'APRIL', NULL, 0, 0, 2000, 50, 600, '0', '2650', 0, 0, 0, '200', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '4600', 'abc123az', '110024038', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 10:23:17', '192.168.0.5'),
(80, 'FEE', 23, '2017-01-04', '9', 9, 'MAY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'abc123az', '110024038', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 10:23:17', '192.168.0.5'),
(81, 'FEE', 23, '2017-01-04', '9', 9, 'JUNE', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'abc123az', '110024038', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 10:23:17', '192.168.0.5'),
(82, 'FEE', 23, '2017-01-04', '9', 9, 'JULY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'abc123az', '110024038', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 10:23:17', '192.168.0.5'),
(83, 'FEE', 24, '2017-01-04', '12', 12, 'APRIL', NULL, 0, 0, 2000, 50, 600, '0', '2650', 0, 0, 0, '250', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '5250', 'abc123az', '110024038', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 10:24:11', '192.168.0.5'),
(84, 'FEE', 24, '2017-01-04', '12', 12, 'MAY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'abc123az', '110024038', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 10:24:11', '192.168.0.5'),
(85, 'FEE', 24, '2017-01-04', '12', 12, 'JUNE', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'abc123az', '110024038', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 10:24:11', '192.168.0.5'),
(86, 'FEE', 24, '2017-01-04', '12', 12, 'JULY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'abc123az', '110024038', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 10:24:11', '192.168.0.5'),
(87, 'FEE', 24, '2017-01-04', '12', 12, 'AUGUST', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'abc123az', '110024038', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 10:24:11', '192.168.0.5'),
(88, 'FEE', 25, '2017-01-04', '13', 13, 'APRIL', NULL, 0, 0, 2000, 50, 600, '0', '2650', 0, 0, 0, '200', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, '4600', 'sfwqf123', '110240111', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 11:10:30', '192.168.0.5'),
(89, 'FEE', 25, '2017-01-04', '13', 13, 'MAY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'sfwqf123', '110240111', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 11:10:30', '192.168.0.5'),
(90, 'FEE', 25, '2017-01-04', '13', 13, 'JUNE', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'sfwqf123', '110240111', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 11:10:30', '192.168.0.5'),
(91, 'FEE', 25, '2017-01-04', '13', 13, 'JULY', NULL, 0, 0, 0, 50, 600, '0', '650', 0, 0, 0, '0', '0', '1', 'SCHOOL OFFICE', 'CHEQUE', 'ROOT', NULL, NULL, 'sfwqf123', '110240111', '2017-01-29', NULL, '', '', '', '2016-2017', '2017-01-04 11:10:30', '192.168.0.5');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_fee_paid_recal`
--

CREATE TABLE IF NOT EXISTS `kisalg_fee_paid_recal` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `rec_no` int(100) DEFAULT NULL,
  `rec_date` date NOT NULL,
  `adm_no` varchar(100) DEFAULT NULL,
  `month` varchar(100) DEFAULT NULL,
  `particular` varchar(100) DEFAULT NULL,
  `head1` int(10) NOT NULL,
  `head2` int(10) NOT NULL,
  `head3` int(10) NOT NULL,
  `head4` int(10) NOT NULL,
  `head5` int(10) NOT NULL,
  `head6` int(10) NOT NULL,
  `head7` int(10) NOT NULL,
  `head8` int(10) NOT NULL,
  `head9` int(10) NOT NULL,
  `head10` int(10) NOT NULL,
  `head11` int(10) NOT NULL,
  `transport` varchar(50) NOT NULL,
  `amount` varchar(50) DEFAULT NULL,
  `late_fine` varchar(50) NOT NULL,
  `discount` varchar(50) NOT NULL,
  `cancelled` enum('0','1') NOT NULL DEFAULT '0',
  `location` varchar(100) DEFAULT NULL,
  `mode` varchar(10) DEFAULT NULL,
  `user` varchar(100) DEFAULT NULL,
  `cash_amt` varchar(100) DEFAULT NULL,
  `chq_amt` varchar(100) DEFAULT NULL,
  `chq_no` varchar(100) DEFAULT NULL,
  `chq_date` date DEFAULT NULL,
  `chq_bnk` varchar(100) DEFAULT NULL,
  `chq_clr` varchar(100) NOT NULL,
  `remark` varchar(100) NOT NULL,
  `left_fee` varchar(100) NOT NULL,
  `session` varchar(100) DEFAULT NULL,
  `date_time` datetime NOT NULL,
  `ip` varchar(20) NOT NULL,
  UNIQUE KEY `id_2` (`id`),
  KEY `rec_no` (`rec_no`),
  KEY `adm_no` (`adm_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_halfday`
--

CREATE TABLE IF NOT EXISTS `kisalg_halfday` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `date` datetime NOT NULL,
  `name` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `sec` varchar(100) NOT NULL,
  `fat_name` varchar(100) NOT NULL,
  `adm_no` varchar(100) NOT NULL,
  `reason` text NOT NULL,
  `takenby` varchar(100) NOT NULL,
  `takenmobile` varchar(100) NOT NULL,
  `takenrelation` varchar(100) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `user` varchar(50) NOT NULL,
  `session` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `kisalg_halfday`
--

INSERT INTO `kisalg_halfday` (`id`, `type`, `date`, `name`, `class`, `sec`, `fat_name`, `adm_no`, `reason`, `takenby`, `takenmobile`, `takenrelation`, `pic`, `user`, `session`) VALUES
(25, 'Student', '2015-11-19 14:50:54', ' Anuj Pandey  ', ' 8TH ', ' A', ' Ashok Pandey  ', '541 ', 'jasjdajsd', 'data', '4512', 'masjdj', '', 'ROOT', '2015-2016'),
(26, 'Student', '2015-11-19 15:02:59', ' Anuj Pandey  ', ' 8TH ', ' A', ' Ashok Pandey  ', '541 ', 'message', 'surya', '8475976976', 'test', '', 'ROOT', '2015-2016'),
(27, 'Student', '2015-11-19 15:08:50', ' Anuj Pandey  ', ' 8TH ', ' A', ' Ashok Pandey  ', '541 ', 'fever', 'surya', '8475976976', 'brother', '', 'ROOT', '2015-2016'),
(28, 'Student', '2015-11-19 15:31:11', ' Anuj Pandey  ', ' 8TH ', ' A', ' Ashok Pandey  ', '541 ', 'fever', 'Surya', '8475976976', 'Brother', '', 'ROOT', '2015-2016'),
(29, 'Teacher', '2015-11-19 15:35:33', 'Mr. Ashwani Sharma', '', '', '', '', 'Fever', '', '', '', '', 'ROOT', '2015-2016'),
(30, 'Teacher', '2015-11-19 15:42:53', 'Mr. Rahul Verma', '', '', '', '', 'High fever', '', '', '', '', 'ROOT', '2015-2016'),
(31, 'Teacher', '2015-11-19 15:43:36', 'Mr. Rahul Sharma', '', '', '', '', 'Function at home', '', '', '', '', 'ROOT', '2015-2016'),
(32, 'Student', '2016-12-27 18:52:00', ' HIMANSHI ', ' UKG ', ' A', ' SANJAY KUMAR ', '6 ', 'seewswrbwer', 'awfqwfg', '851204136', 'segwge', '', 'ROOT', '2016-2017'),
(33, 'Student', '2016-12-28 12:10:37', ' PRACHI ', ' LKG ', ' A', ' MR. DEVENDER ', '12 ', 'swewrhweh', 'saegwgw', '8512041363', 'sdgws', '20161228074006-601.jpg', 'ROOT', '2016-2017'),
(34, 'Student', '2016-12-28 16:55:55', ' DAKSH ', ' LKG ', ' A', ' DHARMESH ', '1 ', 'xcfndfnd', 'zsav', '4575', 'fcgndf', '20161228122549-914.jpg', 'ROOT', '2016-2017'),
(35, 'Student', '2016-12-28 16:56:41', ' DAKSH ', ' LKG ', ' A', ' DHARMESH ', '1 ', 'cfndnf', 'fxbdsf', '533', 'xxn xx', '20161228122627-830.jpg', 'ROOT', '2016-2017'),
(36, 'Student', '2016-12-28 16:58:49', ' PRACHI ', ' LKG ', ' A', ' MR. DEVENDER ', '12 ', 'bc x cx', 'saedae', '453735', 'b,bg,', '20161228122846-380.jpg', 'ROOT', '2016-2017'),
(37, 'Student', '2016-12-28 17:02:28', ' DAKSH ', ' LKG ', ' A', ' DHARMESH ', '1 ', 'hjhhhhhhhhhhhhh', 'c bv b', '5645454444', 'hjhjhjj', '20161228123221-860.jpg', 'ROOT', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_head_define`
--

CREATE TABLE IF NOT EXISTS `kisalg_head_define` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `head1` varchar(50) NOT NULL,
  `head2` varchar(50) NOT NULL,
  `head3` varchar(50) NOT NULL,
  `head4` varchar(50) NOT NULL,
  `head5` varchar(50) NOT NULL,
  `transport` varchar(50) NOT NULL,
  `transport_method` varchar(20) NOT NULL,
  `session` varchar(20) NOT NULL,
  UNIQUE KEY `id_2` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `kisalg_head_define`
--

INSERT INTO `kisalg_head_define` (`id`, `head1`, `head2`, `head3`, `head4`, `head5`, `transport`, `transport_method`, `session`) VALUES
(1, 'ADMISSION FEE', 'CAUTION MONEY', 'DEVELOPMENT FEE', 'SMART CLASS FEE', 'TUITION FEE', 'TRANSPORT FEE', '', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_house`
--

CREATE TABLE IF NOT EXISTS `kisalg_house` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `house` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `kisalg_house`
--

INSERT INTO `kisalg_house` (`id`, `house`) VALUES
(2, 'YAMUNA'),
(3, 'SARASWATI'),
(4, 'GANGA'),
(6, 'KAVERI');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_inquiry`
--

CREATE TABLE IF NOT EXISTS `kisalg_inquiry` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `stu_name` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `fat_name` varchar(100) NOT NULL,
  `mot_name` varchar(50) NOT NULL,
  `last_school` varchar(50) NOT NULL,
  `class` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `type_enq` varchar(20) NOT NULL,
  `campus_visit` varchar(10) NOT NULL,
  `visit_offered_by` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `mobile2` varchar(20) NOT NULL,
  `fat_occ` varchar(30) NOT NULL,
  `mobile3` varchar(20) NOT NULL,
  `mot_occu` varchar(20) NOT NULL,
  `guard_name` varchar(20) NOT NULL,
  `guard_no` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  `current_class` varchar(20) NOT NULL,
  `school_board` varchar(20) NOT NULL,
  `visitor_pass` int(10) NOT NULL,
  `pass_date` datetime NOT NULL,
  `online_remark` varchar(100) NOT NULL,
  `anniversary` date NOT NULL,
  `mode_enq` varchar(50) NOT NULL,
  `quality_lead` varchar(50) NOT NULL,
  `adm_status` varchar(50) NOT NULL DEFAULT 'Enquiry',
  `lead_gen_name` varchar(50) NOT NULL,
  `pros_sold_date` date NOT NULL,
  `approve_date` date NOT NULL,
  `do_adm` date NOT NULL,
  `parent_remark` varchar(200) NOT NULL,
  `counselor_remark` varchar(200) NOT NULL,
  `refer` varchar(200) NOT NULL,
  `head1_d` int(5) NOT NULL,
  `head2_d` int(5) NOT NULL,
  `head3_d` int(5) NOT NULL,
  `head4_d` int(5) NOT NULL,
  `head4_d2` int(10) NOT NULL,
  `sib_id` varchar(50) NOT NULL,
  `sib_id2` varchar(50) NOT NULL,
  `staff_id` varchar(50) NOT NULL,
  `disc_type` varchar(50) NOT NULL,
  `disc_remark` text NOT NULL,
  `disc_approved` varchar(10) NOT NULL,
  `disc_approvedby` varchar(100) NOT NULL,
  `sib1_name` varchar(50) NOT NULL,
  `sib1_class` varchar(50) NOT NULL,
  `sib1_school` varchar(50) NOT NULL,
  `sib2_name` varchar(50) NOT NULL,
  `sib2_class` varchar(50) NOT NULL,
  `sib2_school` varchar(50) NOT NULL,
  `sib3_name` varchar(50) NOT NULL,
  `sib3_class` varchar(50) NOT NULL,
  `sib3_school` varchar(50) NOT NULL,
  `followup_date` date NOT NULL,
  `followup_remark` varchar(200) NOT NULL,
  `followup_by` varchar(50) NOT NULL,
  `interview_date` datetime NOT NULL,
  `interview_scheduledby` varchar(50) NOT NULL,
  `scheduler_remark` varchar(250) NOT NULL,
  `principal` varchar(50) NOT NULL,
  `approvedby` varchar(50) NOT NULL,
  `approvalremark` varchar(200) NOT NULL,
  `stop` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `pic` varchar(50) NOT NULL,
  `towhom` varchar(50) NOT NULL,
  `session` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2878 ;

--
-- Dumping data for table `kisalg_inquiry`
--

INSERT INTO `kisalg_inquiry` (`id`, `date`, `stu_name`, `address`, `fat_name`, `mot_name`, `last_school`, `class`, `mobile`, `type_enq`, `campus_visit`, `visit_offered_by`, `gender`, `dob`, `mobile2`, `fat_occ`, `mobile3`, `mot_occu`, `guard_name`, `guard_no`, `location`, `current_class`, `school_board`, `visitor_pass`, `pass_date`, `online_remark`, `anniversary`, `mode_enq`, `quality_lead`, `adm_status`, `lead_gen_name`, `pros_sold_date`, `approve_date`, `do_adm`, `parent_remark`, `counselor_remark`, `refer`, `head1_d`, `head2_d`, `head3_d`, `head4_d`, `head4_d2`, `sib_id`, `sib_id2`, `staff_id`, `disc_type`, `disc_remark`, `disc_approved`, `disc_approvedby`, `sib1_name`, `sib1_class`, `sib1_school`, `sib2_name`, `sib2_class`, `sib2_school`, `sib3_name`, `sib3_class`, `sib3_school`, `followup_date`, `followup_remark`, `followup_by`, `interview_date`, `interview_scheduledby`, `scheduler_remark`, `principal`, `approvedby`, `approvalremark`, `stop`, `user`, `pic`, `towhom`, `session`) VALUES
(2872, '0000-00-00', 'BHAI jaNAN', 'scCS', 'RAm Pal Din ', 'DAS', 'ASDA', 'NUR', '69674646', 'Enquiry', 'YES', '', 'MALE', '0000-00-00', '', 'IT', '', '', '', '', 'noida', '11th', '', 0, '0000-00-00 00:00:00', '', '0000-00-00', 'OFFLINE', 'HOT', 'Enquiry', '', '0000-00-00', '0000-00-00', '0000-00-00', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', '', '2016-2017'),
(2873, '2016-05-12', 'DCSDC', 'CSDCDSCDS', 'SDCSD', 'CSDCSD', 'DCSDCSD', 'PG', 'DSCDS', '', '', '', '', '0000-00-00', '', 'Account', '', '', '', '', 'delhi', '8th', '', 0, '0000-00-00 00:00:00', '', '0000-00-00', '', '', 'Enquiry', '', '0000-00-00', '0000-00-00', '0000-00-00', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', '', '2016-2017'),
(2874, '2016-05-12', 'Shashank', 'dehradun', 'Mr. Sharma', 'Mrs Sharma', 'UIt ', 'NUR', '56756756', '', '', '', 'MALE', '2016-12-01', '', 'Managemant', '', '', '', '', 'gurgaon', '3rd', '', 0, '0000-00-00 00:00:00', '', '0000-00-00', '', '', 'Admitted', '', '0000-00-00', '0000-00-00', '2017-01-02', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', 'YES', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '0000-00-00 00:00:00', '', '', '', 'ROOT', 'afbjbjafgs', '', '', '', '', '2016-2017'),
(2875, '0000-00-00', 'Ram', 'asaq', 'shyam', 'RamPyari', 'ERHERH', 'NUR', '8512041363', 'Enquiry', 'YES', '', 'MALE', '0000-00-00', '', 'Govt Job', '', '', '', '', 'faridabad', '12TH COM', '', 0, '0000-00-00 00:00:00', '', '0000-00-00', 'OFFLINE', 'HOT', 'Admitted', '', '0000-00-00', '2016-12-26', '2016-12-26', '', 'asdqw', '', 0, 0, 0, 0, 0, '', '', '', '', '', 'YES', '', 'awfq', '12TH COM', 'asa', 'awfq', '7TH', 'asf', 'awfqwe', '5TH', 'aSa', '0000-00-00', '', '', '2016-10-12 02:10:00', '', 'vgddd', 'Dennis Augustine', 'ROOT', 'ZVDVA', '', '', '', '', '2016-2017'),
(2876, '2016-12-13', 'VIJAY SINGH', 'bazpur', 'NANDRAM SINGH', 'RAMI', 'JNV', 'UKG', '9999888745', 'Enquiry', 'YES', '', 'MALE', '2016-12-11', '', 'Famer', '', 'housewife', '', '', 'bazpur', '3RD', '', 0, '0000-00-00 00:00:00', '', '0000-00-00', 'OFFLINE', 'HOT', 'Admitted', '', '0000-00-00', '2016-12-13', '2016-12-13', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', 'YES', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '2016-12-13 04:15:00', '', 'qaehgwehwhe', 'Dennis Augustine', 'ROOT', 'fhshrsrhr', '', '', '', 'DIRECTOR', '2016-2017'),
(2877, '2016-12-28', 'VIJY', 'SDSD', 'SEFIUGFEIQ', 'SGEWSEW', 'DXFBSDFDN', 'LKG', '346464646', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', 0, '0000-00-00 00:00:00', '', '0000-00-00', '', '', 'Enquiry', '', '0000-00-00', '0000-00-00', '0000-00-00', '', '', '', 0, 0, 0, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '', '', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '20161228130744-957.JPG', 'DIRECTOR', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_location`
--

CREATE TABLE IF NOT EXISTS `kisalg_location` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `location` varchar(100) NOT NULL,
  `code` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `kisalg_location`
--

INSERT INTO `kisalg_location` (`id`, `location`, `code`) VALUES
(1, 'SCHOOL OFFICE', 'S');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_logactions`
--

CREATE TABLE IF NOT EXISTS `kisalg_logactions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `adm_no` varchar(100) NOT NULL,
  `message` varchar(2000) NOT NULL,
  `user` varchar(100) NOT NULL,
  `date_time` datetime NOT NULL,
  `session` varchar(100) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_loghistory`
--

CREATE TABLE IF NOT EXISTS `kisalg_loghistory` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(100) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_route_master`
--

CREATE TABLE IF NOT EXISTS `kisalg_route_master` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `route` varchar(100) NOT NULL,
  `stop` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `kisalg_route_master`
--

INSERT INTO `kisalg_route_master` (`id`, `route`, `stop`) VALUES
(2, 'Bhartari', '2,5'),
(3, 'Gabhana', ''),
(4, 'Dorau Mod', '2,3'),
(5, 'Chandaus', ''),
(6, 'Nagla Padam', ''),
(7, 'Andala', '1,4,6,7,8,9'),
(8, 'Khair', '3,6'),
(9, 'Kaasimpur', ''),
(10, 'KIS to Sotmil', ''),
(11, 'Aligarh City', ''),
(12, 'Navodaya School', ''),
(17, 'Bhankari', '');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_school_info`
--

CREATE TABLE IF NOT EXISTS `kisalg_school_info` (
  `id` varchar(50) NOT NULL DEFAULT '',
  `school_name` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `website` varchar(50) DEFAULT NULL,
  `cbse_aff` varchar(50) DEFAULT NULL,
  `code` varchar(100) NOT NULL,
  `principal` varchar(100) NOT NULL,
  `eschool_url` varchar(100) NOT NULL,
  `eschool_param` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kisalg_school_info`
--

INSERT INTO `kisalg_school_info` (`id`, `school_name`, `address`, `phone`, `email`, `website`, `cbse_aff`, `code`, `principal`, `eschool_url`, `eschool_param`) VALUES
('1', 'KRISHNA INTERNATIONAL SCHOOL', '5th KM Stone, G T Road, Aligarh (UP)', '9837050000', 'kisaligarh@gmail.com', 'www.kisaligarh.com', '2130936', '09509', 'MRS. UTTRA KAPOOR', 'kis.accevate.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_sec_master`
--

CREATE TABLE IF NOT EXISTS `kisalg_sec_master` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sec` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `kisalg_sec_master`
--

INSERT INTO `kisalg_sec_master` (`id`, `sec`) VALUES
(11, 'A'),
(12, 'B'),
(13, 'C'),
(14, 'D');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_session`
--

CREATE TABLE IF NOT EXISTS `kisalg_session` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `session` varchar(100) NOT NULL,
  `curr` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `kisalg_session`
--

INSERT INTO `kisalg_session` (`id`, `session`, `curr`) VALUES
(6, '2016-2017', '1');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_smsapi`
--

CREATE TABLE IF NOT EXISTS `kisalg_smsapi` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `set_sms` enum('0','1') NOT NULL,
  `api_url` varchar(1000) NOT NULL,
  `api_key` varchar(100) NOT NULL,
  `sender_id` varchar(100) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `all_sms` varchar(100) NOT NULL,
  `mobile_no2` varchar(100) NOT NULL,
  `daily_summary` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `kisalg_smsapi`
--

INSERT INTO `kisalg_smsapi` (`id`, `set_sms`, `api_url`, `api_key`, `sender_id`, `mobile_no`, `all_sms`, `mobile_no2`, `daily_summary`) VALUES
(1, '1', 'http://message.accevate.com/api/v3/?', 'A1bbc3dc145678cad89a904492c562b70', 'SCHOOL', '8475976976', 'NO', '', 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_stop_master`
--

CREATE TABLE IF NOT EXISTS `kisalg_stop_master` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stop` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `session` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `kisalg_stop_master`
--

INSERT INTO `kisalg_stop_master` (`id`, `stop`, `amount`, `session`) VALUES
(1, 'Bhartari', '1050', '2016-2017'),
(2, 'Gabhana', '1300', '2016-2017'),
(3, 'Dorau Mod', '1350', '2016-2017'),
(4, 'Chandaus', '1550', '2016-2017'),
(5, 'Nagla Padam', '1450', '2016-2017'),
(6, 'Andala', '1350', '2016-2017'),
(7, 'Khair', '1450', '2016-2017'),
(8, 'Kaasimpur', '1450', '2016-2017'),
(9, 'KIS to Sotmil', '1050', '2016-2017'),
(10, 'Aligarh City', '1300', '2016-2017'),
(11, 'Navodaya School', '1700', '2016-2017'),
(12, 'bhankri', '1300', '2016-2017'),
(13, 'ogipur', '1550', '2016-2017'),
(14, 'Guria Bhag', '1300', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_stream`
--

CREATE TABLE IF NOT EXISTS `kisalg_stream` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stream` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `kisalg_stream`
--

INSERT INTO `kisalg_stream` (`id`, `stream`) VALUES
(1, 'GENERAL'),
(2, 'SCIENCE'),
(3, 'COMMERCE'),
(6, 'COMPUTER');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_student`
--

CREATE TABLE IF NOT EXISTS `kisalg_student` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `enq_no` int(5) NOT NULL,
  `adm_no` int(10) DEFAULT NULL,
  `stu_name` varchar(100) NOT NULL,
  `stu_name_hindi` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `fat_name` varchar(100) NOT NULL,
  `fat_occ` varchar(100) NOT NULL,
  `fat_income` varchar(100) NOT NULL,
  `mot_name` varchar(110) NOT NULL,
  `mot_occ` varchar(100) NOT NULL,
  `mot_income` varchar(100) NOT NULL,
  `phy_chal` varchar(50) NOT NULL,
  `lang` varchar(50) NOT NULL,
  `cast_cert_no` varchar(50) NOT NULL,
  `cast_cert_issue` varchar(50) NOT NULL,
  `aadhar` varchar(50) NOT NULL,
  `ward_no` varchar(50) NOT NULL,
  `pan` varchar(50) NOT NULL,
  `fat_qual` varchar(50) NOT NULL,
  `mot_qual` varchar(50) NOT NULL,
  `guard_name` varchar(200) NOT NULL,
  `guard_relation` varchar(200) NOT NULL,
  `guard_no` varchar(200) NOT NULL,
  `house` varchar(100) NOT NULL,
  `stream` varchar(100) NOT NULL,
  `adm_class` varchar(10) NOT NULL,
  `class` varchar(100) NOT NULL,
  `sec` varchar(100) NOT NULL,
  `gender` enum('F','M') NOT NULL,
  `religion` varchar(100) NOT NULL,
  `nationality` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `address_co` varchar(255) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `alt_sms` varchar(100) NOT NULL,
  `mobile_co` varchar(100) NOT NULL,
  `mobile2_co` varchar(100) NOT NULL,
  `roll_no` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `do_adm` date NOT NULL,
  `new_old` varchar(100) NOT NULL,
  `bg` varchar(10) NOT NULL,
  `mobile2` varchar(20) NOT NULL,
  `fat_email` varchar(50) NOT NULL,
  `fat_aadhar` varchar(50) NOT NULL,
  `fat_comp` varchar(50) NOT NULL,
  `fat_office_addrs` varchar(100) NOT NULL,
  `mobile3` varchar(20) NOT NULL,
  `mot_email` varchar(50) NOT NULL,
  `mot_aadhar` varchar(50) NOT NULL,
  `mot_comp` varchar(50) NOT NULL,
  `mot_office_addrs` varchar(100) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `school_class` varchar(100) NOT NULL,
  `school_session` varchar(100) NOT NULL,
  `school_curri` varchar(100) NOT NULL,
  `school_sub` varchar(100) NOT NULL,
  `cert1` varchar(10) NOT NULL,
  `cert2` varchar(10) NOT NULL,
  `cert3` varchar(10) NOT NULL,
  `cert4` varchar(10) NOT NULL,
  `cert5` varchar(10) NOT NULL,
  `cert6` varchar(10) NOT NULL,
  `cert7` varchar(10) NOT NULL,
  `cert8` varchar(10) NOT NULL,
  `cert9` varchar(10) NOT NULL,
  `cert10` varchar(10) NOT NULL,
  `cert1_remark` varchar(100) NOT NULL,
  `cert2_remark` varchar(100) NOT NULL,
  `cert3_remark` varchar(100) NOT NULL,
  `cert4_remark` varchar(100) NOT NULL,
  `cert5_remark` varchar(100) NOT NULL,
  `cert6_remark` varchar(100) NOT NULL,
  `cert7_remark` varchar(100) NOT NULL,
  `cert8_remark` varchar(100) NOT NULL,
  `cert9_remark` varchar(100) NOT NULL,
  `cert10_remark` varchar(100) NOT NULL,
  `photo_stu` varchar(200) NOT NULL,
  `photo_fat` varchar(200) NOT NULL,
  `photo_mot` varchar(200) NOT NULL,
  `photo_guard` varchar(200) NOT NULL,
  `allow_discount` enum('NO','YES') NOT NULL DEFAULT 'NO',
  `custom_fee` enum('NO','YES') NOT NULL DEFAULT 'NO',
  `is_shown` enum('NO','YES') NOT NULL DEFAULT 'YES',
  `tc_issue` enum('NO','YES') NOT NULL DEFAULT 'NO',
  `form_no` varchar(100) NOT NULL,
  `disc_id` varchar(50) NOT NULL,
  `session` varchar(20) NOT NULL,
  `only_child` enum('NO','YES') NOT NULL DEFAULT 'NO',
  `dl_parent` varchar(255) NOT NULL,
  UNIQUE KEY `adm_no` (`adm_no`),
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `kisalg_student`
--

INSERT INTO `kisalg_student` (`id`, `enq_no`, `adm_no`, `stu_name`, `stu_name_hindi`, `username`, `password`, `fat_name`, `fat_occ`, `fat_income`, `mot_name`, `mot_occ`, `mot_income`, `phy_chal`, `lang`, `cast_cert_no`, `cast_cert_issue`, `aadhar`, `ward_no`, `pan`, `fat_qual`, `mot_qual`, `guard_name`, `guard_relation`, `guard_no`, `house`, `stream`, `adm_class`, `class`, `sec`, `gender`, `religion`, `nationality`, `category`, `address`, `address_co`, `mobile`, `alt_sms`, `mobile_co`, `mobile2_co`, `roll_no`, `dob`, `do_adm`, `new_old`, `bg`, `mobile2`, `fat_email`, `fat_aadhar`, `fat_comp`, `fat_office_addrs`, `mobile3`, `mot_email`, `mot_aadhar`, `mot_comp`, `mot_office_addrs`, `school_name`, `school_class`, `school_session`, `school_curri`, `school_sub`, `cert1`, `cert2`, `cert3`, `cert4`, `cert5`, `cert6`, `cert7`, `cert8`, `cert9`, `cert10`, `cert1_remark`, `cert2_remark`, `cert3_remark`, `cert4_remark`, `cert5_remark`, `cert6_remark`, `cert7_remark`, `cert8_remark`, `cert9_remark`, `cert10_remark`, `photo_stu`, `photo_fat`, `photo_mot`, `photo_guard`, `allow_discount`, `custom_fee`, `is_shown`, `tc_issue`, `form_no`, `disc_id`, `session`, `only_child`, `dl_parent`) VALUES
(1, 0, 1, 'DAKSH', '', 'daksh6184', '537292', 'DHARMESH', '', '', 'MRS. GUNJAN', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'A', 'F', '', '', '', 'PALWAL SHIV COLONY', '', '8901552491', '', '', '', '', '2012-01-28', '0000-00-00', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '20161228123221-860.jpg', '20161228122549-914.jpg', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(2, 0, 2, 'AKSHIT TANWAR', '', 'akshit8379', '456460', 'DIGAMBER', '', '', 'MRS. NIDHI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'UKG', 'A', 'M', '', '', '', 'PALWAL NEW EXTENSION COLONY', '', '9992512507', '', '', '', '', '2011-12-12', '2016-04-02', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(3, 0, 3, 'NIRUPAM', '', 'nirupam8744', '402477', 'MANOJ KUMAR', '', '', 'MRS. SONIA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'UKG', 'A', 'F', '', '', '', 'PALWAL SHIV COLONY', '', '9896337427', '', '', '', '', '2011-08-04', '2016-04-01', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(4, 0, 4, 'GAURI', '', 'gauri1677', '305422', 'PERVESH', '', '', 'MRS. BABLI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'B', 'M', '', '', '', 'PALWAL RAJIV NAGAR', '', '8607988790', '', '', '', '', '2012-07-17', '2016-07-14', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', 'aaaa'),
(5, 0, 5, 'JATIN RAJ', '', 'jatin2780', '519401', 'AMIT KUMAR', '', '', 'MRS. GAJNA DEVI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'UKG', 'A', 'M', '', '', '', 'KHEDLA', '', '9811148342', '', '', '', '', '2011-09-07', '2016-04-01', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(6, 0, 6, 'HIMANSHI', '', 'himanshi7067', '874908', 'SANJAY KUMAR', '', '', 'MRS. KUSUM LATA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'UKG', 'A', 'F', '', '', '', 'PALWAL PANCHWATI COLONY', '', '8607016394', '', '', '', '', '2011-10-14', '2016-04-02', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(7, 0, 7, 'EKTA', '', 'ekta2672', '431214', 'NARENDER KUMAR', '', '', 'MRS. SAVITA RANI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'UKG', 'A', 'M', '', '', '', 'DHATIR', '', '9991481950', '', '', '', '', '2012-01-05', '2016-04-08', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(8, 0, 8, 'CHHAVI', '', 'chhavi9550', '625316', 'HARVIR SINGH', '', '', 'MRS. VANDANA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'UKG', 'A', 'M', '', '', '', 'KONDAL', '', '9968644613', '', '', '', '', '2011-04-10', '2016-05-11', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(9, 0, 9, 'TUSHAR', '', 'tushar9014', '320163', 'RAJ VIR', '', '', 'MRS. BEENA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'A', '', '', '', '', 'PALWAL BASS MOHALLA', '', '7404156659', '', '', '', '', '2011-12-15', '2016-04-01', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(10, 0, 10, 'TANIA', '', 'tania2146', '668397', 'AZAD SINGH', '', '', 'MRS. RENU', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'B', '', '', '', '', 'ALAHPUR', '', '9013899458', '', '', '', '', '2011-03-22', '2016-04-07', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(11, 0, 11, 'MANJU BALYAN', '', 'manju7941', '138813', 'OM PAL', '', '', 'MRS. ASHA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'A', '', '', '', '', 'KHEDLA', '', '9812326225', '', '', '', '', '2012-12-10', '2016-04-06', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(12, 0, 12, 'PRACHI', '', 'prachi3012', '358070', 'MR. DEVENDER', '', '', 'MRS. PINKI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'A', 'F', '', '', '', 'HAAJIPUR', '', '9812975767', '', '', '', '', '2012-07-23', '2016-04-13', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'student.jpg', 'father.jpg', '', '20161228122846-380.jpg', 'NO', 'YES', 'YES', '', '', '', '2016-2017', 'NO', ''),
(13, 0, 13, 'ANANT GOSWAMI', '', 'anant9468', '928218', 'PREM CHAND', '', '', 'MRS. RACHNA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'A', '', '', '', '', 'DEEGHOT', '', '9813640166', '', '', '', '', '2012-09-05', '2016-04-23', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(14, 0, 14, 'LUXMI', '', 'luxmi8591', '943596', 'AJAY KUMAR', '', '', 'MRS. POONAM', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'B', '', '', '', '', 'JENDA PUR', '', '9813952444', '', '', '', '', '2012-02-27', '2016-07-11', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(15, 0, 15, 'LAKSHAY', '', 'lakshay2134', '281276', 'RAJ KUMAR', 'SERVICE', '', 'MRS. REKHA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'A', '', '', '', '', 'PALWAL HUDA SEC-2', '', '8569908121', '', '', '', '', '2012-03-18', '2016-04-30', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(16, 0, 16, 'OM KAR', '', 'om6260', '272224', 'SURESH BHARDWAJ', '', '', 'MRS. SUMAN LATA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'B', '', '', '', '', 'KUSLIPUR', '', '9812009593', '', '', '', '', '2010-01-01', '2016-04-06', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(17, 0, 17, 'LAVANYA', '', 'lavanya6892', '175428', 'TARUN KUMAR', '', '', 'MRS. SUNITA SHARMA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'B', '', '', '', '', 'PALWAL SHYAM NAGAR EECCO', '', '9467211880', '', '', '', '', '2010-01-01', '2016-05-14', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(18, 0, 18, 'BHUMI DIXIT', '', 'bhumi2124', '439053', 'MAHESH KUMAR', '', '', 'MRS. YASHODHRA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'A', '', '', 'INDIAN', '', 'PALWAL DHARAM NAGAR', '', '9996311164', '', '', '', '', '2011-07-15', '2016-04-29', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', 'drshrh'),
(19, 0, 19, 'AAYUSHI', '', 'aayushi6368', '156791', 'MR. SATPAL', '', '', 'MRS. USHA RANI', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'B', '', '', 'INDIAN', '', 'VPO- JAINDAPUR PALWAL', '', '9811354578', '', '', '', '', '2011-12-11', '2016-04-01', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', ''),
(20, 0, 20, 'VIHAN TANWAR', '', 'vihan3757', '476344', 'MR. TEKCHAND', '', '', 'MRS. BABITA', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LKG', 'C', '', '', 'INDIAN', '', 'VPO- PRITHLA PALWAL', '', '8818065161', '', '', '', '', '2012-05-22', '2016-05-07', 'OLD', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'YES', 'YES', '', '', '', '2016-2017', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_stu_custom_data`
--

CREATE TABLE IF NOT EXISTS `kisalg_stu_custom_data` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `default` enum('0','1') NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `field` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `length` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=71 ;

--
-- Dumping data for table `kisalg_stu_custom_data`
--

INSERT INTO `kisalg_stu_custom_data` (`id`, `default`, `name`, `field`, `type`, `length`) VALUES
(1, '1', 'Admission No.', 'adm_no', 'INT', ''),
(2, '1', 'Student Type', 'type', 'VARCHAR', ''),
(3, '1', 'Fee Category', 'fee_cat', 'VARCHAR', ''),
(4, '1', 'Student Name', 'stu_name', 'VARCHAR', ''),
(5, '1', 'Student Name (in Hindi)', 'stu_name_hindi', 'VARCHAR', ''),
(6, '1', 'Username', 'username', 'VARCHAR', ''),
(7, '1', 'Password', 'password', 'VARCHAR', ''),
(8, '1', 'Father Name', 'fat_name', 'VARCHAR', ''),
(9, '1', 'Father Occupation', 'fat_occ', 'VARCHAR', ''),
(10, '1', 'Father Income', 'fat_income', 'VARCHAR', ''),
(11, '1', 'Mother Name', 'mot_name', 'VARCHAR', ''),
(12, '1', 'Mothe Occupation', 'mot_occ', 'VARCHAR', ''),
(13, '1', 'Mother Income', 'mot_income', 'VARCHAR', ''),
(14, '1', 'Physically Challenged', 'phy_chal', 'VARCHAR', ''),
(15, '1', 'Mother Tongue', 'lang', 'VARCHAR', ''),
(16, '1', 'Father Qualification', 'fat_qual', 'VARCHAR', ''),
(17, '1', 'Mother Qualification', 'mot_qual', 'VARCHAR', ''),
(18, '1', 'House', 'house', 'VARCHAR', ''),
(19, '1', 'Stream', 'stream', 'VARCHAR', ''),
(20, '1', 'Adm. Class', 'adm_class', 'VARCHAR', ''),
(21, '1', 'Current Class', 'class', 'VARCHAR', ''),
(22, '1', 'Current Section', 'sec', 'VARCHAR', ''),
(23, '1', 'Blood Group', 'bg', 'ENUM', 'A+,A-,B+,B-,AB+,AB-,O+,O-'),
(24, '1', 'Gender', 'gender', 'ENUM', 'F, M'),
(25, '1', 'Religion', 'religion', 'VARCHAR', ''),
(26, '1', 'Nationality', 'nationality', 'VARCHAR', ''),
(27, '1', 'Category', 'category', 'VARCHAR', ''),
(28, '1', 'Permanent Address', 'address', 'VARCHAR', ''),
(29, '1', 'Correspondance Address', 'address_co', 'VARCHAR', ''),
(30, '1', 'SMS No.', 'mobile', 'VARCHAR', ''),
(31, '1', 'Alt. SMS No.', 'alt_sms', 'VARCHAR', ''),
(32, '1', 'Correspondance Contact No.', 'mobile_co', 'VARCHAR', ''),
(33, '1', 'Correspondance Alt Contact No. ', 'mobile2_co', 'VARCHAR', ''),
(34, '1', 'Roll No', 'roll_no', 'VARCHAR', ''),
(35, '1', 'SSSM ID', 'sssn', 'VARCHAR', ''),
(36, '1', 'Date of Birth', 'dob', 'DATE', ''),
(37, '1', 'Date of Admission', 'do_adm', 'DATE', ''),
(38, '1', 'Adm. Type', 'new_old', 'VARCHAR', ''),
(39, '1', 'Last School Attended', 'school_name', 'VARCHAR', ''),
(40, '1', 'Last School Class', 'school_class', 'VARCHAR', ''),
(41, '1', 'Last School Session', 'school_session', 'VARCHAR', ''),
(42, '1', 'Last School Curriculum', 'school_curri', 'VARCHAR', ''),
(43, '1', 'Last School Subjects Opted', 'school_sub', 'VARCHAR', ''),
(44, '1', 'Visibility', 'is_shown', 'ENUM', 'NO,YES'),
(45, '1', 'TC Issued', 'tc_issue', 'ENUM', 'NO,YES'),
(46, '1', 'Using Transport', 'is_transport', 'ENUM', 'NO,YES'),
(47, '1', 'Form No.', 'form_no', 'VARCHAR', ''),
(48, '1', 'Only Child', 'only_child', 'ENUM', 'NO,YES'),
(49, '1', 'Mother Aadhar No.', 'mot_aadhar', 'VARCHAR', ''),
(50, '1', 'Mother Contact No.', 'mobile3', 'VARCHAR', ''),
(51, '1', 'Mother Email ID', 'mot_email', 'VARCHAR', ''),
(52, '1', 'Mother Company Name', 'mot_comp', 'VARCHAR', ''),
(53, '1', 'Mother Office Address', 'mot_office_addrs', 'VARCHAR', ''),
(54, '1', 'Father Aadhar No.', 'fat_aadhar', 'VARCHAR', ''),
(55, '1', 'Father Contact No.', 'mobile2', 'VARCHAR', ''),
(56, '1', 'Father Email ID', 'fat_email', 'VARCHAR', ''),
(57, '1', 'Father Company Name', 'fat_comp', 'VARCHAR', ''),
(58, '1', 'Father Office Address', 'fat_office_addrs', 'VARCHAR', ''),
(59, '1', 'Student Aadhar No.', 'stu_aadhar', 'VARCHAR', ''),
(60, '1', 'NSO/Left Date', 'nso_date', 'DATE', ''),
(61, '1', 'Contact Name', 'con_name', 'VARCHAR', ''),
(62, '1', 'Contact Qualification', 'con_qual', 'VARCHAR', ''),
(63, '1', 'Contact Aadhar', 'con_aadhar', 'VARCHAR', ''),
(64, '1', 'Contact Mobile No.', 'mobile4', 'VARCHAR', ''),
(65, '1', 'Contact Email', 'con_email', 'VARCHAR', ''),
(66, '1', 'Contact Income', 'con_income', 'VARCHAR', ''),
(67, '1', 'Contact Company Name', 'con_comp', 'VARCHAR', ''),
(68, '1', 'Contact Occupation', 'con_occ', 'VARCHAR', ''),
(69, '1', 'Contact Office Address', 'con_office_addrs', 'VARCHAR', ''),
(70, '0', 'Driving License No.', 'dl_parent', 'VARCHAR', '255');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_stu_custom_fee`
--

CREATE TABLE IF NOT EXISTS `kisalg_stu_custom_fee` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stu_id` int(10) NOT NULL,
  `adm_no` varchar(10) DEFAULT NULL,
  `head1_apr` int(10) NOT NULL,
  `head2_apr` int(10) NOT NULL,
  `head3_apr` int(10) NOT NULL,
  `head3_oct` int(10) NOT NULL,
  `head4_apr` int(10) NOT NULL,
  `head4_may` int(10) NOT NULL,
  `head4_jun` int(10) NOT NULL,
  `head4_jul` int(10) NOT NULL,
  `head4_aug` int(10) NOT NULL,
  `head4_sep` int(10) NOT NULL,
  `head4_oct` int(10) NOT NULL,
  `head4_nov` int(10) NOT NULL,
  `head4_dec` int(10) NOT NULL,
  `head4_jan` int(10) NOT NULL,
  `head4_feb` int(10) NOT NULL,
  `head4_mar` int(10) NOT NULL,
  `head5_apr` int(10) NOT NULL,
  `head5_may` int(10) NOT NULL,
  `head5_jun` int(10) NOT NULL,
  `head5_jul` int(10) NOT NULL,
  `head5_aug` int(10) NOT NULL,
  `head5_sep` int(10) NOT NULL,
  `head5_oct` int(10) NOT NULL,
  `head5_nov` int(10) NOT NULL,
  `head5_dec` int(10) NOT NULL,
  `head5_jan` int(10) NOT NULL,
  `head5_feb` int(10) NOT NULL,
  `head5_mar` int(10) NOT NULL,
  `head1_method` varchar(50) NOT NULL,
  `head2_method` varchar(50) NOT NULL,
  `head3_method` varchar(50) NOT NULL,
  `head4_method` varchar(50) NOT NULL,
  `head5_method` varchar(50) NOT NULL,
  `session` varchar(20) NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `fee_id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_stu_sess_data`
--

CREATE TABLE IF NOT EXISTS `kisalg_stu_sess_data` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stu_id` int(10) NOT NULL,
  `adm_no` int(10) DEFAULT NULL,
  `type` varchar(25) NOT NULL,
  `fee_cat` varchar(25) NOT NULL,
  `class` varchar(30) NOT NULL,
  `sec` varchar(20) NOT NULL,
  `new_old` enum('NEW','OLD') NOT NULL DEFAULT 'NEW',
  `custom_fee` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `disc_id` varchar(50) NOT NULL,
  `is_transport` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `stop_id` int(10) NOT NULL,
  `bus_id` int(10) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `session` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `kisalg_stu_sess_data`
--

INSERT INTO `kisalg_stu_sess_data` (`id`, `stu_id`, `adm_no`, `type`, `fee_cat`, `class`, `sec`, `new_old`, `custom_fee`, `disc_id`, `is_transport`, `stop_id`, `bus_id`, `start_date`, `end_date`, `session`) VALUES
(1, 1, 1, 'GENERAL', 'GENERAL', 'LKG', 'A', 'OLD', 'NO', '', 'YES', 2, 1, '0000-00-00', '0000-00-00', '2016-2017'),
(2, 2, 2, 'GENERAL', 'GENERAL', 'UKG', 'A', 'OLD', 'NO', '', 'YES', 2, 1, '2017-01-09', '2017-01-31', '2016-2017'),
(3, 3, 3, 'GENERAL', 'GENERAL', 'UKG', 'A', 'OLD', 'NO', '', 'YES', 2, 1, '2016-06-22', '0000-00-00', '2016-2017'),
(4, 4, 4, 'GENERAL', 'GENERAL', 'LKG', 'B', 'OLD', 'NO', '', 'NO', 0, 0, '2016-12-23', '0000-00-00', '2016-2017'),
(5, 5, 5, 'GENERAL', 'GENERAL', 'UKG', 'A', 'OLD', 'NO', '', 'YES', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(6, 6, 6, 'GENERAL', 'GENERAL', 'UKG', 'A', 'OLD', 'NO', '', 'NO', 0, 6, '0000-00-00', '0000-00-00', '2016-2017'),
(7, 7, 7, 'GENERAL', 'GENERAL', 'UKG', 'A', 'OLD', 'NO', '', 'NO', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(8, 8, 8, 'GENERAL', 'GENERAL', 'UKG', 'A', 'OLD', 'NO', '', 'YES', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(9, 9, 9, 'GENERAL', 'GENERAL', 'LKG', 'A', 'OLD', 'NO', '', 'NO', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(10, 10, 10, 'GENERAL', 'GENERAL', 'LKG', 'B', 'OLD', 'NO', '', 'YES', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(11, 11, 11, 'GENERAL', 'GENERAL', 'LKG', 'A', 'OLD', 'NO', '', 'NO', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(12, 12, 12, 'GENERAL', 'GENERAL', 'LKG', 'A', 'OLD', 'NO', '', 'NO', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(13, 13, 13, 'GENERAL', 'GENERAL', 'LKG', 'A', 'OLD', 'NO', '', 'YES', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(14, 14, 14, 'GENERAL', 'GENERAL', 'LKG', 'B', 'OLD', 'NO', '', 'NO', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(15, 15, 15, 'GENERAL', 'GENERAL', 'LKG', 'A', 'OLD', 'NO', '', 'YES', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(16, 16, 16, 'GENERAL', 'GENERAL', 'LKG', 'B', 'OLD', 'NO', '', 'NO', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(17, 17, 17, 'GENERAL', 'GENERAL', 'LKG', 'B', 'OLD', 'NO', '', 'NO', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(18, 18, 18, 'GENERAL', 'GENERAL', 'LKG', 'A', 'OLD', 'NO', '', 'NO', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(19, 19, 19, 'GENERAL', 'GENERAL', 'LKG', 'B', 'OLD', 'NO', '', 'NO', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(20, 20, 20, 'GENERAL', 'GENERAL', 'LKG', 'B', 'OLD', 'NO', '', 'YES', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(35, 43, NULL, 'GENERAL', 'GENERAL', 'NUR', 'A', 'NEW', 'NO', '', 'NO', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(37, 45, 22, 'GENERAL', 'GENERAL', 'UKG', 'A', 'NEW', 'NO', '', 'NO', 0, 0, '0000-00-00', '0000-00-00', '2016-2017'),
(38, 46, NULL, 'GENERAL', 'GENERAL', 'UKG', 'B', 'NEW', 'NO', '', 'NO', 0, 0, '0000-00-00', '0000-00-00', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_stu_tpt_fee`
--

CREATE TABLE IF NOT EXISTS `kisalg_stu_tpt_fee` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `stu_id` int(10) NOT NULL,
  `adm_no` varchar(10) NOT NULL,
  `tp_apr` int(10) NOT NULL,
  `tp_may` int(10) NOT NULL,
  `tp_jul` int(10) NOT NULL,
  `tp_aug` int(10) NOT NULL,
  `tp_sep` int(10) NOT NULL,
  `tp_oct` int(10) NOT NULL,
  `tp_nov` int(10) NOT NULL,
  `tp_dec` int(10) NOT NULL,
  `tp_jan` int(10) NOT NULL,
  `tp_feb` int(10) NOT NULL,
  `tp_mar` int(10) NOT NULL,
  `session` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `kisalg_stu_tpt_fee`
--

INSERT INTO `kisalg_stu_tpt_fee` (`id`, `stu_id`, `adm_no`, `tp_apr`, `tp_may`, `tp_jul`, `tp_aug`, `tp_sep`, `tp_oct`, `tp_nov`, `tp_dec`, `tp_jan`, `tp_feb`, `tp_mar`, `session`) VALUES
(1, 1, '1', 500, 500, 500, 500, 0, 0, 0, 0, 0, 0, 0, '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_tpt_months`
--

CREATE TABLE IF NOT EXISTS `kisalg_tpt_months` (
  `id` int(10) NOT NULL,
  `tp_apr` enum('0','1') NOT NULL DEFAULT '1',
  `tp_may` enum('0','1') NOT NULL DEFAULT '1',
  `tp_jun` enum('0','1') NOT NULL DEFAULT '0',
  `tp_jul` enum('0','1') NOT NULL DEFAULT '1',
  `tp_aug` enum('0','1') NOT NULL DEFAULT '1',
  `tp_sep` enum('0','1') NOT NULL DEFAULT '1',
  `tp_oct` enum('0','1') NOT NULL DEFAULT '1',
  `tp_nov` enum('0','1') NOT NULL DEFAULT '1',
  `tp_dec` enum('0','1') NOT NULL DEFAULT '1',
  `tp_jan` enum('0','1') NOT NULL DEFAULT '1',
  `tp_feb` enum('0','1') NOT NULL DEFAULT '1',
  `tp_mar` enum('0','1') NOT NULL DEFAULT '1',
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kisalg_tpt_months`
--

INSERT INTO `kisalg_tpt_months` (`id`, `tp_apr`, `tp_may`, `tp_jun`, `tp_jul`, `tp_aug`, `tp_sep`, `tp_oct`, `tp_nov`, `tp_dec`, `tp_jan`, `tp_feb`, `tp_mar`) VALUES
(1, '1', '1', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_transfer_certificate`
--

CREATE TABLE IF NOT EXISTS `kisalg_transfer_certificate` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `s_no` int(11) NOT NULL,
  `book_no` varchar(100) DEFAULT NULL,
  `stu_id` int(10) DEFAULT NULL,
  `adm_no` varchar(100) DEFAULT NULL,
  `reg_no_stu` varchar(100) DEFAULT NULL,
  `tc_no` int(11) NOT NULL,
  `ncc` varchar(100) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `no_meeting` varchar(100) DEFAULT NULL,
  `attendance` varchar(100) DEFAULT NULL,
  `general_conduct` varchar(100) DEFAULT NULL,
  `student_failed` varchar(100) NOT NULL,
  `school_exam_last_taken` varchar(100) NOT NULL,
  `sub_offer` varchar(100) NOT NULL,
  `qualified_promotion` varchar(100) NOT NULL,
  `paid_all_dues` varchar(100) NOT NULL,
  `concession` varchar(100) NOT NULL,
  `name_struck_off` varchar(100) NOT NULL,
  `last_class` varchar(100) NOT NULL,
  `game_played` varchar(100) NOT NULL,
  `do_apply` date NOT NULL,
  `remark` varchar(100) DEFAULT NULL,
  `date_issue` date DEFAULT NULL,
  `session` varchar(100) DEFAULT NULL,
  `cancel` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `issuedby` varchar(50) NOT NULL,
  `approvedby` varchar(50) NOT NULL,
  `principalremark` varchar(50) NOT NULL,
  `requestby` varchar(50) NOT NULL,
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `kisalg_transfer_certificate`
--

INSERT INTO `kisalg_transfer_certificate` (`id`, `s_no`, `book_no`, `stu_id`, `adm_no`, `reg_no_stu`, `tc_no`, `ncc`, `reason`, `no_meeting`, `attendance`, `general_conduct`, `student_failed`, `school_exam_last_taken`, `sub_offer`, `qualified_promotion`, `paid_all_dues`, `concession`, `name_struck_off`, `last_class`, `game_played`, `do_apply`, `remark`, `date_issue`, `session`, `cancel`, `issuedby`, `approvedby`, `principalremark`, `requestby`) VALUES
(23, 1, NULL, 19, '19', '2345', 0, 'dfd', 'drhe', 'drhe', 'dhrehr', 'YES', 'NO', 'Xth', 'English', 'Ok', 'YES', 'No', 'dfde', 'LKG', 'drfdn', '2017-01-14', 'Ok', '2017-01-05', '2016-2017', 'YES', 'ROOT', '', '', ''),
(24, 2, NULL, 18, '18', '2345', 0, 'YES', 'dont like it', '56', '56', 'genral form', 'X', 'YES', 'English', 'YES', 'YES', 'NO', 'No', 'LKG', 'basket ball', '2017-01-14', 'Yes ok ', '2017-01-05', '2016-2017', 'YES', 'ROOT', '', '', ''),
(25, 3, NULL, 17, '17', '', 0, 'Yes', 'passed Out', '234', '234', 'general', 'No', 'higher School', 'English,Math,Hindi', 'No', 'Yes', 'No', 'No', 'Xth', 'Yes', '2017-01-28', 'Hello', '2017-01-06', '2016-2017', 'YES', 'ROOT', '', '', ''),
(27, 4, NULL, 16, '16', '', 0, 'dshsehr', 'xhsh', 'dshsehre', 'shserh', 'segdwshe', 'shsh', 'sh', 'shs', 'sdh', 'sdhsd', 'sdhs', 'shsh', 'sh', 'sdhsh', '2017-01-06', 'wergwg', '2017-01-27', '2016-2017', 'YES', 'ROOT', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_type`
--

CREATE TABLE IF NOT EXISTS `kisalg_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `session` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `kisalg_type`
--

INSERT INTO `kisalg_type` (`id`, `type`, `session`) VALUES
(4, 'GENERAL', '2016-2017');

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_vehicle_master`
--

CREATE TABLE IF NOT EXISTS `kisalg_vehicle_master` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `veh_no` varchar(100) NOT NULL,
  `bus_no` varchar(100) NOT NULL,
  `driver_name` varchar(100) NOT NULL,
  `mobile_no` varchar(100) NOT NULL,
  `stop` varchar(255) NOT NULL,
  `veh_capacity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `kisalg_vehicle_master`
--

INSERT INTO `kisalg_vehicle_master` (`id`, `veh_no`, `bus_no`, `driver_name`, `mobile_no`, `stop`, `veh_capacity`) VALUES
(1, 'UP81AF6512', 'R1', 'MAHESH SHARMA', '7500244101', '2,4', 50),
(2, 'UP81AF2246', 'R2', 'OMVEER', '7500244102', '', 100),
(3, 'UP81AF3460', 'R3', 'ARUN', '7500244103', '', 50),
(4, 'UP81AF6511', 'R4', 'NAVEEN', '7500244104', '2,3', 40),
(5, 'UP81AF2249', 'R5', 'RAJESH THAKUR', '7500244105', '1,5', 50),
(6, 'UP81AH6958', 'R6', 'MADAN KUMAR', '7500244106', '', 56),
(7, 'UP81AH6959', 'R7', 'SONU D.J.', '7500244107', '', 50),
(9, 'UP81AF2632', 'R8', 'K.K. SHARMA', '7500244108', '', 50),
(10, 'UP81AF2631', 'R9', 'LOVEKUSH', '7500244109', '', 50),
(11, 'UP81AF2633', 'R10', 'DEEPU SHARMA', '7500244110', '', 40),
(12, 'UP81AF2634', 'M6', 'VIVEK SHARMA', '7500244123', '', 70),
(13, 'UP81AF2794', 'M2', 'VANSHI SHARMA', '7500244122', '', 70),
(14, 'UP81AF2529', 'K1', 'SUNIL', '7500244111', '', 70),
(15, 'UP81AF2260', 'K2', 'GAJENDRA PAL', '7500244112', '', 45),
(16, 'UP81AF2530', 'K3', 'BHUPENDRA SINGH', '7500244113', '2,6', 45),
(17, 'UP81AF2532', 'K4', 'RAJVIR SINGH', '7500244114', '', 56),
(18, 'UP81AF2575', 'K5', 'KISHAN PAL', '7500244115', '', 34),
(19, 'UP81AF2528', 'K6', 'UDAL SINGH', '7500244116', '', 45),
(20, 'UP81AF2339', 'K7', 'RAJU KHA', '7500244117', '', 67),
(21, 'UP81AF2261', 'K8', 'NARENDRA CHAUDHARY', '7500244118', '', 56),
(22, 'UP81AA9705', 'K9', 'LOKESH SHARMA', '7500244119', '', 56),
(23, 'UP81AF2340', 'K10', 'MANGAL JOSHI', '7500244120', '', 34),
(24, 'UP81AF2573', 'K14', 'GOLDI', '7500244123', '', 45),
(25, 'UP81AF2527', 'K15', 'RAJENDRA SHARMA', '7500244125', '', 67),
(26, 'UP81AF2341', 'K16', 'RAVINDRA SHARMA', '7500244126', '', 56),
(27, 'UP81AF2574', 'K17', 'SHARIF', '7500244127', '', 56),
(28, 'UP81AF2531', 'K18', 'SANJAY', '7500244128', '', 50),
(29, 'UP81AF2338', 'K19', 'PRAMOD SHARMA', '7500244129', '', 50),
(30, 'UP81AF0842', 'K20', 'ARUN SINGH', '7500244130', '', 65),
(31, 'UP81AF0841', 'K21', 'SHIV KUMAR', '7500244131', '', 60),
(32, 'UP81AF0237', 'K22', 'KHAJAN SINGH', '7500244132', '', 0),
(33, 'UP81AF0322', 'K23', 'VISHNU KUMAR', '7500244133', '', 0),
(34, 'UP81AF3202', 'K24', 'RAM KISHOR', '7500244134', '', 0),
(35, 'UP81AA9585', 'K26', 'SONU', '7500244136', '', 0),
(36, 'UP81AF6383', 'K27', 'RAJESH II', '7500244137', '', 0),
(37, 'UP81AF6384', 'K28', 'BALDEV SINGH', '7500244138', '', 0),
(38, 'UP81AF9535', 'K29', 'MADAN LAL', '7500244139', '', 0),
(39, 'UP81AF9536', 'K30', 'GURUDEEP', '7500244140', '', 0),
(40, 'UP81AF9537', 'K25', 'RAMESH PAL', '7500244125', '', 0),
(41, 'UP81BT2049', 'M3', 'MONU SHARMA', '7500242383', '', 0),
(42, 'UP81BT2050', 'M4', 'SUBHASH SHARMA', '7500242384', '', 0),
(57, 'UP81AF3203', 'M 5', 'SHANU', '7500242385', '', 0),
(62, 'UP81AF3202', 'K 11', 'AVTAR SINGH', '7500244121', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `kisalg_visits`
--

CREATE TABLE IF NOT EXISTS `kisalg_visits` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `regarding` text NOT NULL,
  `towhom` varchar(100) NOT NULL,
  `comment` text NOT NULL,
  `status` int(2) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `user` varchar(50) NOT NULL,
  `session` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `kisalg_visits`
--

INSERT INTO `kisalg_visits` (`id`, `date`, `name`, `mobile`, `address`, `regarding`, `towhom`, `comment`, `status`, `pic`, `user`, `session`) VALUES
(4, '2015-11-19 00:00:00', '1111', '111', '11', '111', 'Principal', '', 0, '', 'ROOT', '2015-2016'),
(5, '2015-11-19 00:00:00', '1111', '111', '11', '111', 'Principal', '', 0, '', 'ROOT', '2015-2016'),
(6, '2015-11-19 00:00:00', 'surya', '1111', 'accevate', 'software', 'Director', '', 0, '', 'ROOT', '2015-2016'),
(7, '2016-12-27 13:42:08', 'vijay', '8851204136', 'ewegqeg', 'sgeqeqe', 'Director', 'Yes. drhehehejr', 1, '', 'ROOT', '2016-2017'),
(8, '2016-12-28 10:52:16', 'Surya', '7290005481', 'Accevate', 'Software', 'Director', 'Yes. FSEGWEGWEWRWHE', 1, '', 'ROOT', '2016-2017'),
(9, '2016-12-28 11:58:43', 'VIJAY', '8512041363', 'SEWEHWHWHW', 'GWERHWHRE', 'Director', '', 0, '20161228072716-224.jpg', 'ROOT', '2016-2017');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
