<?php
$page='student';
require('core.php');
if($_SESSION['ACC_STUDENT']=='0') {
	header("Location: main.php");
}

if(isset($_REQUEST)){
	
	$from_date = datestamp($_REQUEST["from_date"]);
	$to_date = datestamp($_REQUEST["to_date"]);

	function createDateRangeArray($strDateFrom,$strDateTo)
	{
		$aryRange=array();
		$iDateFrom=mktime(1,0,0,substr($strDateFrom,5,2),     substr($strDateFrom,8,2),substr($strDateFrom,0,4));
		$iDateTo=mktime(1,0,0,substr($strDateTo,5,2),     substr($strDateTo,8,2),substr($strDateTo,0,4));
		if ($iDateTo>=$iDateFrom)
		{
			array_push($aryRange,date('Y-m-d',$iDateFrom)); // first entry
			while ($iDateFrom<$iDateTo)
			{
				$iDateFrom+=86400; // add 24 hours
				array_push($aryRange,date('Y-m-d',$iDateFrom));
			}
		}
		return $aryRange;
	}
	$date = createDateRangeArray($from_date,$to_date);
	
}
include('header.php');


?>
<div class="container">
	<?php print_menu($student_menu_items); ?>
	<div class="row">
		<h3>New Admissions (by date)</h3>
		<form id="form1" name="form1" method="get" action="student-new-list-date">
			<label>From Date: </label> 
			<input name="from_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["from_date"]; ?>"  style="width: 100px;" readonly class="datepicker" />  
			<label>To Date : </label> 
			<input name="to_date" class="datepicker" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["to_date"]; ?>"  style="width: 100px;" readonly /> 
			<label>Record Type : </label> 
			<select name="r_type">
				<option <?php if($_REQUEST['r_type'] == 'count'){ echo 'selected'; }?> value='count'>Only Count</option>
				<option <?php if($_REQUEST['r_type'] == 'detail'){ echo 'selected'; }?> value='detail'>With Details</option>
			</select>
			<input type="submit" name="button" id="button1" value="Filter" />
			<input type="button" onclick="tableToExcel('testTable', 'Student')" value="Export to Excel" style="float:right;padding: 2px;" />
			<input type="text" id="searchTerm" class="search_box" onkeyup="doSearch()" style="float:right;padding: 2px;" placeholder="Search Here....." />
		</form><hr>
		<table id="testTable" class="table table-striped" style="font-size:11px;">
			<thead>
				<tr>
					<?php if($_REQUEST['r_type']=='detail') { ?>
						<th align="center"><strong>SR</strong></th>
						<th align="center"><strong>Adm No.</strong></th>
						<th align="center"><strong>Student Name</strong></th>
						<th align="center"><strong>Father's Name</strong></th>
						<th align="center"><strong>Mother's Name</strong></th>
						<th align="center"><strong>Address</strong></th>
						<th align="center"><strong>Mobile</strong></th>
						<th align="center"><strong>DOB</strong></th>
						<th align="center"><strong>G</strong></th>
						<th align="center"><strong>Class</strong></th>
						<th align="center"><strong>Sec</strong></th>
					<?php }  
					else if($_REQUEST['r_type']=='count') { ?>
						<th>Class</th>
						<th>Admissions</th>
					<?php } ?>
				</tr>
			</thead>
			<tbody>
				<?php
				if($_REQUEST['r_type']=='detail') { 
					$n=1;
					foreach($date as $go) {
						$db->join("stu_sess_data st", "st.stu_id=s.adm_no", "LEFT");
						$db->where ("s.is_shown", 'YES');
						$db->where ("s.tc_issue", 'NO');
						$db->where ("s.do_adm", $go);
						$db->where ("s.session", $_SESSION['SESSION']);
						$students = $db->get('student s');
						if(count($students)> 0){ ?>
							<tr>
								<td colspan="11" style="font-size:14px; font-weight:bold;">Dated : <?php echo date('d F, Y', strtotime($go)); ?></td>
							</tr>
							<?php 
							foreach ($students as $s){?>
								<tr>
									<td align="center"><?php echo $n++; ?></td>
									<td align="center"><?php echo $s['adm_no']; ?></td>
									<td align="center"><?php echo $s['stu_name']; ?></td>
									<td align="center"><?php echo $s['fat_name']; ?></td>
									<td align="center"><?php echo $s['mot_name']; ?></td>
									<td align="center"><?php echo $s['address']; ?></td>
									<td align="center"><?php echo $s['mobile']; ?></td>
									<td align="center"><?php $dob = date('d-m-Y', strtotime($s['dob'])); if($dob <> '01-01-1970') { echo $dob; } ?></td>
									<td align="center"><?php  echo $s['gender']; ?></td>
									<td align="center"><?php echo $s['class']; ?></td>
									<td align="center"><?php echo $s['sec']; ?></td>
								</tr>
							<?php }
						}
					}
				}
				else if($_REQUEST['r_type']=='count'){
					$cols = Array ("class");
					$class = $db->get ("class_master", null, $cols);
					$n = 0;
					
				
					
					foreach($class as $c_class) {
						foreach($date as $go) {
							$cols = Array ("id","is_shown","tc_issue","do_adm","class","session","stu_name");
							$db->where ("is_shown", 'YES');
							$db->where ("tc_issue", 'NO');
							$db->where ("do_adm", $go);
							$db->where ("class", $c_class['class']);
							$db->where ("session", $_SESSION['SESSION']);
							$students = $db->get('student', null, $cols);
							
							//echo '<br>';
							if(!empty($students)){ $n[] = 1;   }
						}
						//echo '<br>'; print_r($n);
						if(array_sum($n)>0) {
							echo "<tr><td>".$c_class['class']."</td><td>".array_sum($n)."</td></tr>";
						} //exit;
						unset($n);
					}
				} ?>
			</tbody>
		</table>
	</div>
</div>
<?php
include('footer.php');
?>       