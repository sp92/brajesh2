<?php
$page='student';
require('core.php');
if($_SESSION['ACC_STUDENT']=='0') {
	header("Location: main.php");
}

include('header.php');

?>
<div class="container">
	<?php print_menu($student_menu_items); ?>
	<div class='row'>
		<h3>Issue Admit Cards</h3>
		<div id="message" style="width: 270px;float: right;font-size: 11px;"></div>
		<center>
			<table class="table table-striped">
				<tr>
					<td align=right><label>Select Class :</label></td>
					<td>
						<select name="class" class="form-control" id="class">
							<option value="">--</option>
							<?php
							$user = $db->get ("class_master");
							if ($db->count > 0) {
								foreach ($user as $u) { 
							?>			
							<option <?php if($_REQUEST['class'] == $u['class']) { echo 'selected'; }?> value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
							<?php } } ?>	
						</select>  
					</td>
				</tr>
				<tr>
					<td align=right><label>Select Section :</label></td>
					<td>
						<select name="section" id="section" class="form-control">
							<option value="">--</option>
							<?php
							$user = $db->get ("sec_master");
							if ($db->count > 0) {
								foreach ($user as $u) { 
							?>			
							<option <?php if($_REQUEST['section'] == $u['sec']) { echo 'selected'; }?> value='<?php echo $u['sec']; ?>'><?php echo $u['sec']; ?></option>
							<?php } } ?>
						</select>
					</td>
				</tr>
				<tr>
					<td align=right><label>Enter Exam Detail :</label></td>
					<td><input type="text" name="exam_type" id="exam_type" placeholder="Ex. Class Examination Dec/Jan 2004-05" class="form-control" /></td>
				</tr>
				<tr>
					<td colspan=2><center><button class="btn-success" onclick="printadmitcard();">Print Admit Card</button></center></td>
				</tr>
			</table>
		</center>
		<script>
			function printadmitcard() {
				var c_class = $("#class").val();
				var c_sec = $("#section").val();
				var c_examtype = $("#exam_type").val();
				window.open("student-admit-card-print.php?class="+c_class+"&sec="+c_sec+"&exam_type="+c_examtype, "Window2", "status=no,height=" + window.screen.width + ",width=" + window.screen.width + ",resizable=yes,toolbar=no,addressbar=no,menubar=no,scrollbars=no,location=no,directories=no");
			}
		</script>
	</div>
</div>
<?php
include('footer.php');
?>       