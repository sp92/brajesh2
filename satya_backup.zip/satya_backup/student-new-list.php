<?php
$page='student';
require('core.php');
if($_SESSION['ACC_STUDENT']=='0') {
	header("Location: main.php");
}

include('header.php');
?>
<div class="container">
	<?php print_menu($student_menu_items); ?>
	<div class="row">
		<h3>New Admissions</h3>
		<form id="list-student-new" name="list-student-new" method="GET" action="student-new-list">
			<table class="table ">
				<tr>
					<td>
						<label>Class</label>
						<select name="class">
							<option value="">--</option>
							<?php
							$user = $db->get ("class_master");
							if ($db->count > 0) {
								foreach ($user as $u) { 
							?>			
							<option <?php if($_REQUEST['class'] == $u['class']) { echo 'selected'; }?> value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
							<?php } } ?>	
						</select>
					</td>
					<td>
						<label>Section</label>
						<select name="section">
							<option value="">--</option>
							<?php
							$user = $db->get ("sec_master");
							if ($db->count > 0) {
								foreach ($user as $u) { 
							?>			
							<option <?php if($_REQUEST['section'] == $u['sec']) { echo 'selected'; }?> value='<?php echo $u['sec']; ?>'><?php echo $u['sec']; ?></option>
							<?php } } ?>
						</select>
					</td>
				<td>
					<label>Order By</label>
					<select name="order">
						<option value="">--</option>
						<option value="adm_no" <?php if($_REQUEST["order"]=='adm_no') { echo "selected"; } ?>>Admission No.</option>
						<option value="stu_name" <?php if($_REQUEST["order"]=='stu_name') { echo "selected"; } ?>>Student Name</option>
					</select>
				</td>
				<td>
					<label>Type</label>
					<select name="type">
						<option value="">--</option>
						<?php
							$type = $db->get ("type");
							if ($db->count > 0) {
								foreach ($type as $t) { 
							?>			
							<option <?php if($_REQUEST['type'] == $t['type']) { echo 'selected'; }?> value='<?php echo $t['type']; ?>'><?php echo $t['type']; ?></option>
							<?php } } ?>
					</select>
					<input type="submit" name="button" id="button1" value="Submit" />
					<a href="student-new-list.php">reset</a>
				</td>
				<td>
				<?php if(acl_check('export_table', $_SESSION['SESS_ID']) != false) {  ?>
					<input type="button" onclick="tableToExcel('searchable', 'Student')" value="Export to Excel" style="float:right;padding: 2px;" />
				<?php } ?>
					<input type="text" id="searchTerm" class="search_box" onkeyup="doSearch()" style="float:right;padding: 2px;" placeholder="Search Here....." />
				</td>
			</tr>
		</table>
	</form>
	<table id="searchable" class="table table-striped" style="font-size:11px;">
		<thead>
			<tr>
				<th align="center"><strong>SR</strong></th>
				<th align="center"><strong>Type</strong></th>
				<th align="center"><strong>Adm No.</strong></th>
				<th align="center"><strong>Adm Date</strong></th>
				<th align="center"><strong>Student Name</strong></th>
				<th align="center"><strong>Father's Name</strong></th>
				<th align="center"><strong>Mother's Name</strong></th>
				<th align="center"><strong>Address</strong></th>
				<th align="center"><strong>Mobile</strong></th>
				<th align="center"><strong>DOB</strong></th>
				<th align="center"><strong>Gender</strong></th>
				<th align="center"><strong>Class</strong></th>
				<th align="center"><strong>Sec</strong></th>
			</tr>
		</thead>
		<tbody>
			<?php
			$db->join("stu_sess_data st", "st.stu_id=s.adm_no", "LEFT");
			if ($_REQUEST["class"]<>'') {
				$db->where ("st.class", $_REQUEST["class"]);
			}
			if ($_REQUEST["section"]<>'') {
				$db->where ("st.sec", $_REQUEST['section']);
			}
			if ($_REQUEST["order"]<>'') {
				$db->orderBy('s.'.$_REQUEST["order"],"asc");
			}
			if ($_REQUEST["type"]<>'') {
				$db->where ("s.type", $_REQUEST["type"]);
			}
			$db->where ("s.is_shown", 'YES');
			$db->where ("s.tc_issue", 'NO');
			$db->where ("s.session", $_SESSION['SESSION']);
			$students = $db->get('student s');
			$n=1;
			foreach($students as $s){
			?>
				<tr>
					<td align="center"><?php echo $n++; ?></td>
					<td align="center"><?php echo $s['type']; ?></td>
					<td align="center"><?php echo $s['adm_no']; ?></td>
					<td align="center"><?php echo getdmYFormat($s['do_adm']);?></td>
					<td align="center"><?php echo $s['stu_name']; ?></td>
					<td align="center"><?php echo $s['fat_name']; ?></td>
					<td align="center"><?php echo $s['mot_name']; ?></td>
					<td align="center"><?php echo $s['address']; ?></td>
					<td align="center"><?php echo $s['mobile']; ?></td>
					<td align="center"><?php echo getdmYFormat($s['do_adm']);?></td>
					<td align="center"><?php  echo $s['gender']; ?></td>
					<td align="center"><?php echo $s['class']; ?></td>
					<td align="center"><?php echo $s['sec']; ?></td>
				</tr>
			<?php } ?>
		</tbody>
	</table>
	
</div>
</div>
<!-- /container -->
<?php
include('footer.php');
?>