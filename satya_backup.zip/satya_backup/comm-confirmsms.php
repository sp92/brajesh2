<?php
$page='comm';
require('core.php');
if($_SESSION['ACC_COMM']=='0') 
{
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">
<div class="row">
<div class="col-md-2 hidden-xs">
<?php print_menu($comm_menu_items); ?>
</div>
<div class="col-md-10">

<h5 class="pull-right"><b><span id="balance" class="text-danger"></span></b> Credits</h5>

<h3>Message Confirmation</h3>
<div class="row">
<div class="col-md-12">
<textarea class="form-control message-checkbox box-content" name="message" id="ac-message" placeholder="Type your text message here (up to max 4000 characters)" maxlength="4000" required="required" data-counter="true" placeholder="Enter your message" rows="4" ></textarea>
<p class="sms-cnt">
	<span class="ac-sms-count">0</span> Character(s),
	<span  class="ac-sms-credits">0</span> SMS
<button type="button" class="btn btn-primary btn-xs pull-right" data-toggle="modal" data-target=".bs-example-modal-lg">Sms Count</button>
</p>
<hr>




	
</div>
</div>
</div>
</div>
</div> <!-- /container -->

<?php
include('lib/forsms.php');
include('footer.php');
?>