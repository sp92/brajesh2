<?php
$page='transport';
require('core.php');

if($_SESSION['ACC_STUDENT']=='0') {
	header("Location: main.php");
}
include('header.php');

?>
<div class="container">
<div class="row">
       			<h3>Student Report (Using Transport)</h3>
<form id="form1" name="form1" method="get" action="transport-report-all">

<label>Class :</label>
<select name="class">
<option value="">--</option>

<option value="Nursery">Nursery</option>
<?php $stop=$db->get('class_master');
foreach($stop as $data){
?>
<option <?php echo ($data['class']==$_REQUEST['class']) ? 'selected' : '';?> value="<?php echo $data['class']?>"><?php echo $data['class']?></option>
<?php } ?>
</select>

<label>Section : </label>
<select name="section">
<option value="">--</option>
<?php $stop=$db->get('sec_master');
foreach($stop as $data){
?>
<option <?php echo ($data['sec']==$_REQUEST['section']) ? 'selected' : '';?> value="<?php echo $data['sec']?>"><?php echo $data['sec']?></option>
<?php } ?>
</select>
&nbsp;&nbsp;|&nbsp;&nbsp; 
<label>Stu. Type</label>
<select name="type">
<option value="ALL">ALL</option>
<?php
				$type = $db->get ("type");
				if ($db->count > 0) {
					foreach ($type as $t) { ?>			
						<option <?php if($_REQUEST['fee_type'] == $t['type']) { echo 'selected'; }?> value='<?php echo $t['type']; ?>'><?php echo $t['type']; ?></option>
					<?php } 
				} ?>
				</select>

<label>Order By :</label>
<select name="order">
<option <?php echo ($_REQUEST['order']=="adm_no") ? 'selected' : '';?> value="adm_no">Admission No.</option>
<option <?php echo ($_REQUEST['order']=="stu_name") ? 'selected' : '';?> value="stu_name">Student Name</option>
</select>


<input type="checkbox" name="all" value="all"> Show All Students


<input type="submit" name="button" id="button1" value="Submit">


<input type="button" class="btn-success" onclick="return windowpop('transport-self.php', +screen.width, +screen.height)" style="padding: 2px;padding-left: 5px;padding-right: 5px;float: right;" value="Self Transport">

  <input type="button" onclick="tableToExcel('testTable', 'Student')" value="Export to Excel" style="float:right;padding: 2px;">
<input type="text" id="searchTerm" class="search_box" onkeyup="doSearch()" style="float:right;padding: 2px;" placeholder="Search Here.....">


</form>
   <button onclick="print_pdf();" style="float:right;padding: 2px;">PDF Report</button>
				<script type="text/javascript">
var tableToExcel = (function() {
  var uri = 'data:application/vnd.ms-excel;base64,'
    , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
    , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
    , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
  return function(table, name) {
    if (!table.nodeType) table = document.getElementById(table)
    var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
    window.location.href = uri + base64(format(template, ctx))
  }
})()
</script>
<script>
pramukhIME.addLanguage(PramukhIndic,"hindi"); 
pramukhIME.enable('stu_name_hindi');
</script>
<table id="testTable" class="table" style="font-size: 11px; padding: 0px;">
<thead class="tableFloatingHeaderOriginal">
<tr>
<th align="center"><strong>SR</strong></th>
<th align="center"><strong>Bus No.</strong></th>
<th align="center"><strong>Adm No.</strong></th>
<th align="center"><strong>Student Name</strong></th>
<th align="center"><strong>Status</strong></th>

<th align="center"><strong>Father Name</strong></th>
<th align="center"><strong>Class</strong></th>
<th align="center"><strong>section</strong></th>
<th align="center"><strong>Address</strong></th>
<th align="center"><strong>Stoppage</strong></th>
<th align="center"><strong>Route</strong></th>
</tr>
</thead>
<tbody>
<?php 

$db->join("vehicle_master v", "v.id=s.bus_id", "LEFT");
$db->join("student st", "st.id=s.stu_id", "LEFT");
$db->join("stop_master stm", "stm.id=s.stop_id", "LEFT");
$db->where('s.is_transport','YES');
if(!isset($_REQUEST['all'])){
if(isset($_REQUEST['class']) && $_REQUEST['class']!=""){
$db->where('s.class',$_REQUEST['class']);
}
if(isset($_REQUEST['section']) && $_REQUEST['section']!=""){
$db->where('s.sec',$_REQUEST['section']);
}
if(isset($_REQUEST['type']) && $_REQUEST['type']!="ALL"){
$db->where('s.type',$_REQUEST['type']);
}

if(isset($_REQUEST['order'])){
$db->orderBy('st.'.$_REQUEST['order'],'asc');
}
}
$report=$db->get('stu_sess_data s',null,'v.bus_no,s.adm_no,st.stu_name,st.fat_name,st.address,s.class,s.sec,s.is_transport,stm.stop');

$x=0;
if($report){
foreach($report as $rep){$x++;
?>
    <tr align="center">
	   <td><?php echo $x;?></td>
	   <td><?php echo $rep['bus_no'];?></td>
	   <td><?php echo $rep['adm_no'];?></td>
	   <td><?php echo $rep['stu_name'];?></td>
	   <td><?php echo $rep['is_transport'];?></td>
	   <td><?php echo $rep['fat_name'];?></td>
	   <td><?php echo $rep['class'];?></td>
	   <td><?php echo $rep['sec'];?></td>
	   <td><?php echo $rep['address'];?></td>
	   <td><?php echo $rep['stop'];?></td>
	   <td></td>
	   
	</tr>
<?php }}else{
	echo "<td colspan='10' align=center><strong> No Data Found !!!</td>";
}?>
</tbody>
</table>

<script>
function print_pdf(){
	document.sampleform.submit();
}
</script>
</div>
</div>
<?php
include('footer.php');
?>    