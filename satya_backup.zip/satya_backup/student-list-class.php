<?php
$page='student';
require('core.php');
if($_SESSION['ACC_STUDENT']=='0') {
	header("Location: main.php");
}
include('header.php');

?>
<div class="container">
	<?php print_menu($student_menu_items); ?>
	<div class="row">
	<h3>New Admissions (Classwise)</h3>
		<div id="message" style="width: 270px;float: right;font-size: 11px;margin-top:-40px;"></div>
		<form id="form1" name="form1" method="get" action="student-list-class">
			<?php if(isset($_REQUEST['menu']) && $_REQUEST['menu']=='OFF') {
				echo "<input type='hidden' name='menu' value='OFF' />";
			}?>
			<label>Class :</label>
			<select name="class">
				<option value="">--</option>
				<?php
				$user = $db->get ("class_master");
				if ($db->count > 0) {
					foreach ($user as $u) { 
				?>			
				<option <?php if($_REQUEST['class'] == $u['class']) { echo 'selected'; }?> value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
				<?php } } ?>	
			</select>
			<label>Section : </label>
			<select name="section">
				<option value="">--</option>
				<?php
				$user = $db->get ("sec_master");
				if ($db->count > 0) {
					foreach ($user as $u) { 
				?>			
				<option <?php if($_REQUEST['section'] == $u['sec']) { echo 'selected'; }?> value='<?php echo $u['sec']; ?>'><?php echo $u['sec']; ?></option>
				<?php } } ?>
			</select>
			Student Type : 
			<select name="fee_type" >
				<option value="">--</option>
				<?php
				$type = $db->get ("type");
				if ($db->count > 0) {
					foreach ($type as $t) { ?>			
						<option <?php if($_REQUEST['fee_type'] == $t['type']) { echo 'selected'; }?> value='<?php echo $t['type']; ?>'><?php echo $t['type']; ?></option>
					<?php } 
				} ?>
			</select>
			<label>Order By :</label>
			<select name="order">
				<option value="">--</option>
				<option value="adm_no" <?php if($_REQUEST["order"]=='adm_no') { echo "selected"; } ?>>Admission No.</option>
				<option value="stu_name" <?php if($_REQUEST["order"]=='stu_name') { echo "selected"; } ?>>Student Name</option>
			</select>
			<input type="submit" name="button" id="button1" value="Submit" />
			<a href="student-list-class.php">reset</a>
			<input type="button" onclick="tableToExcel('searchable', 'Student')" value="Export to Excel" style="float:right;padding: 2px;" />
			<input type="text" id="searchTerm" class="search_box" onkeyup="doSearch()" style="float:right;padding: 2px;" placeholder="Search Here....." />
		</form>
		<span style="color:red;font-weight:bold;">Note : Click on Student Name or Admission No. to view student profile.</span><br/><br/>
		<?php ob_start(); ?>
		<table id="searchable" class="table" style="font-size:11px;">
			<thead>
				<tr>
					<th align="center"><strong>SR</strong></th>
					<th align="center"><strong>Adm No.</strong></th>
					<th align="center"><strong>Student Name</strong></th>
					<th align="center"><strong>Type</strong></th>
					<th align="center"><strong>Father's Name</strong></th>
					<th align="center"><strong>Mother's Name</strong></th>
					<th align="center"><strong>Address</strong></th>
					<th align="center"><strong>Mobile</strong></th>
					<th align="center" style="width:80px;"><strong>DOB</strong></th>
					<th align="center"><strong>G</strong></th>
					<th align="center"><strong>Class</strong></th>
					<th align="center"><strong>Sec</strong></th>
				</tr>
			</thead>
			<tbody>
				<?php
				$db->join("stu_sess_data st", "st.stu_id=s.adm_no", "LEFT");
				if ($_REQUEST["class"]<>'') {
					$db->where ("st.class", $_REQUEST["class"]);
				}
				if ($_REQUEST["section"]<>'') {
					$db->where ("st.sec", $_REQUEST['section']);
				}
				if ($_REQUEST["fee_type"]<>'') {
					$db->where ("st.type", $_REQUEST["fee_type"]);	
				}
				if ($_REQUEST["order"]<>'') {
					$db->orderBy('s.'.$_REQUEST["order"],"asc");	
				}
				$db->where ("s.is_shown", 'YES');
				$db->where ("s.tc_issue", 'NO');
				$db->where ("s.session", $_SESSION['SESSION']);
				$students = $db->get('student s');
				$n=1;
				foreach($students as $s){
					if($s['new_old']=='NEW'){
						$trstyle = 'background-color:lightyellow;';
					$tdstyle = '';}
					else {
						$tdstyle = '';
						$trstyle = 'bgcolor="#FFFFFF"';
					} ?>
					<tr style="<?php echo $trstyle; ?>">
						<td align="center" <?php echo $tdstyle; ?>><?php echo $n++; ?></td>
						<td align="center" <?php echo $tdstyle; ?>><?php echo $s['adm_no']; ?></td>
						<td align="center" <?php echo $tdstyle; ?>><?php echo $s['stu_name']; ?></td>
						<td align="center" <?php echo $tdstyle; ?>><?php echo $s['type']; ?></td>
						<td align="center" <?php echo $tdstyle; ?>><?php echo $s['fat_name']; ?></td>
						<td align="center" <?php echo $tdstyle; ?>><?php echo $s['mot_name']; ?></td>
						<td align="center" <?php echo $tdstyle; ?>><?php echo $s['address']; ?></td>
						<td align="center" <?php echo $tdstyle; ?>><?php echo $s['mobile']; ?></td>
						<td align="center" <?php echo $tdstyle; ?>><?php $dob = date('d-m-Y', strtotime($s['dob'])); if($dob <> '01-01-1970') { echo $dob; } ?></td>
						<td align="center" <?php echo $tdstyle; ?>><?php  echo $s['gender']; ?></td>
						<td align="center" <?php echo $tdstyle; ?>><?php echo $s['class']; ?></td>
						<td align="center" <?php echo $tdstyle; ?>><?php echo $s['sec']; ?></td>
					</tr>
				<?php  } ?>
			</tbody>
		</table>	
	</div>
</div>
<?php
include('footer.php');
?>       