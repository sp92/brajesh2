<?php
include('lib/config.php');
if(@$_REQUEST['hdnCmd']=="EDIT")
{
	$comment2=clean($_REQUEST['comment']);
	$choice = clean($_REQUEST['choice']);
	$status='1';
	$comment = $choice.". ".$comment2;
	$id=clean($_REQUEST['id']);
	$data=array(
	'comment'=>$comment,
	'status'=>$status
	);
	$db->where('id',$id);
	$db->update('visits',$data);
	
	
	echo "<script>document.location.href='respond?success';</script>";
}
$id=clean($_REQUEST['visit']);
?>
<html>
<head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1;">
        <title>:: ACCEVATE TECHNOLOGIES - ONLINE SCHOOL MANAGEMENT v1.2::</title>
        <meta name="description" content="">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" href="css/bootstrap.css">
        <style>
            body {
                padding: 50px;
            }
			.footer {
			position: fixed;
			bottom: 0;
			width: 100%;
			/* Set the fixed height of the footer here */
			height: 20px;
			background-color: #FFCACA;
			border-top: 3px solid;
			}
        </style>
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<body style="padding-top: 0;">
<div class="container">
<div class="row">
<div class='col-sm-12'>
<?php if(isset($_REQUEST['success'])) { ?>
<br>
<br>
<div class="alert alert-success" role="alert">Your Comment has been saved and sent to Frontdesk. You may close this window.</div>

<?php } ?>

<?php if(isset($_REQUEST['visit'])) { ?>
<h3>Respond to Visit</h3>
<?php
	$n=1;
	$db->where('id',$id);
	$db->where('status','0');
	$db_form=$db->get('visits');
	
	foreach($db_form as $rows){
?>	
<strong>Name : </strong><?php echo $rows['name']; ?><br>
<strong>Address : </strong><?php echo $rows['address']; ?><br>
<strong>Regarding : </strong><?php echo $rows['regarding']; ?><br>
<strong>Picture : </strong><br>
<img src="pictures/visits/<?php echo $rows['pic']; ?>" width="100" height="100"/>

<hr>

<center>
<form class="form" role="form" action="respond" method="post" style="width:300px;padding:25px;">
<input type="hidden" name="hdnCmd" value="EDIT">
<input type="hidden" name="id" value="<?php echo $id; ?>">

  <label><input type='radio' name="choice" value="No" checked />&nbsp;No</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<label><input type='radio' name="choice" value="Yes" />&nbsp;Yes</label>
				<br>
				<br>
    <div class="form-group">
    <label for="exampleInputEmail2">Comment: </label><br>
    <textarea name='comment' rows='5'></textarea>
  </div>
  <button type="submit" class="btn btn-default">Comment</button>
</form><br/><br/>
<?php
}
}
?>
</center>
</div>
</div>
</div>