<?php
$page='master';
include('core.php');
if($_SESSION['ACC_MASTER']=='0') 
{
	header("Location: main.php");
}
//Code to Add & Delete Route
if(@$_REQUEST['hdnCmd']=="ADD")
	{
		$route=clean($_REQUEST['route']);
		$data = Array (
			'route' => $route
		);
		$db->insert ('route_master', $data);
		header("Location: ./master-route");
	}
if(@$_REQUEST['action']=="del")
	{
		$db->where('id', round($_REQUEST['id']));
		$db->delete('route_master');
		header("Location: ./master-route");
	}
include('header.php');
?>
<div class="container">

<div class="row">
<div class="col-md-2 hidden-xs">
	<?php print_menu($master_menu_items); ?>
	</div>
	<div class="col-md-10">
	<h3>Route / Stop Master</h3>
	<div class="col-md-12">

	
	
	<br/>
	<br/>
<table class="table table-striped table-hover" >
<thead>
<tr>
<th >SR</td>
<th>Routes</td>
<th >Stop</td>
<th>Update</td>
</tr>
</thead>
<tbody>
				
			<?php
					$n=1;
					$user = $db->get ("route_master");
					if ($db->count > 0) {
						$ind=0;
						foreach ($user as $u) { 
					?>			
<tr>
<td><?php echo $n; $n++; ?></td>
<td><?php echo $u['route']; ?></td>
<td> <select data-placeholder="Choose Stops" class="form-control chosen-select"  multiple >
            <?php 
			$stop_id = explode(",", $u['stop']);
			$stop = $db->get ("stop_master");
			foreach ($stop as $uu) { 
			?>
            <option value="<?php echo $uu['id'];?>" <?php if(in_array($uu['id'], $stop_id)) { echo "selected"; } ?> ><?php echo $uu['stop'];?></option>
            <?php } ?>
      </select></td>
<td width="200">

<button onClick="updateRoute(<?php echo $u['id'].",".$ind;?>)">update</button>
<a href="master-route?action=del&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a></td>
</tr>
		  <?php
		$ind++;	}
			}
		?>	
<tr>				
<td></td>
<td colspan=2><form action="master-route" method="post"><input type="text" name="route" required />
<input type="hidden" name="hdnCmd" value="ADD"><input  class="btn btn-default btn-sm" type="submit" name="submit" value="Add Route" /></form>
</td>
</tr>	
<tr>			
<td colspan=3 style='color:red;'>Note: Classes should be in increasing order.</td>
</tr>			
</table>			
	</div>
	

	
	</div>
	
	
	
	
    </div>
</div> <!-- /container -->
<script>
function updateRoute(id,pas){
	routeid=$(".chosen-select").eq(pas).val();
	if(routeid==null){
		alert("Please Atleast One Stop!!");
	}else{
    $.ajax({
			type: 'POST',
			url: 'function/masterfunctions?mode=update',
			data:"stop="+routeid+"&id="+id,
			success: function (data) {
				    alert("Data Updated Successfully");
					
			}
		});
	}
	
	
}
</script>
<?php
include('footer.php');
?>