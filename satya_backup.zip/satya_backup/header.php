<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="assets/img/favicon.ico">
	<base href="/fee/erp/" />
	<title>:: ONLINE SCHOOL MANAGEMENT v2.1 :: ACCEVATE TECHONOLOGIES ::</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
	<!--[if !IE]><!-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<!--<![endif]-->
	<!--[if lte IE 8]>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<![endif]-->

	<!--[if gt IE 8]>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
	<![endif]-->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="assets/css/bootstrap-datepicker3.min.css">
	<link rel="stylesheet" href="assets/css/ladda-themeless.min.css">
	<link rel="stylesheet" href="assets/css/chosen.min.css">
	<link rel="stylesheet" href="assets/css/bootstrap-multiselect.css">
	<link href="assets/css/custom.css" rel="stylesheet">
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body class="">

	<div id="overlay" class="loading"></div>
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="./main"><img src="assets/img/logo.png" style="width: 80px;"></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <?php if($_SESSION['ACC_MASTER']=='1') 	{	?>
			<li class="dropdown <?php if($page=='master') echo "active"; ?>" >
              <a href="#"  class="dropdown-toggle " data-toggle="dropdown">Master <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="./master-school" class="xload">School Master</a> <?php $master_menu_items[] = '<a href="./master-school" class="btn btn btn-success btn-block">School Master</a>';  ?></li>
                <li><a href="./master-session" class="xload">Session Master</a> <?php $master_menu_items[] = '<a href="./master-session" class="btn btn btn-success btn-block">Session Master</a>';  ?></li>
				<li class="divider"></li>
                <li><a href="./master-class">Class Master</a> <?php $master_menu_items[] = '<a href="./master-class" class="btn btn btn-success btn-block">Class Master</a>';  ?></li>
                <li><a href="./master-stream">Stream Master</a> <?php $master_menu_items[] = '<a href="./master-stream" class="btn btn btn-success btn-block">Stream Master</a>';  ?></li>
                <li><a href="./master-house">House Master</a> <?php $master_menu_items[] = '<a href="./master-house" class="btn btn btn-success btn-block">House Master</a>';  ?></li>
				<li class="divider"></li>
                <li><a href="./master-route">Route / Stop Master</a> <?php $master_menu_items[] = '<a href="./master-route" class="btn btn btn-success btn-block">Route / Stop Master</a>';  ?></li>
                <li><a href="./master-vehicle">Vehicle Master</a> <?php $master_menu_items[] = '<a href="./master-vehicle" class="btn btn btn-success btn-block">Vehicle Master</a>';  ?></li>
				
                <li class="divider"></li>
				<li><a href="./master-document">Documents Master</a> <?php $master_menu_items[] = '<a href="./master-document" class="btn btn btn-success btn-block">Documents Master</a>';  ?></li>
			  </ul>
            </li>
			<?php } ?>
			
			<?php if($_SESSION['ACC_FRONTDESK']=='1') 	{	?>
			<li class="dropdown <?php if($page=='frontdesk') echo "active"; ?>" >
              <a href="#"  class="dropdown-toggle " data-toggle="dropdown">Frontdesk <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="./frontdesk-setup">Frontdesk Setup</a> <?php $frontdesk_menu_items[] = '<a href="./frontdesk-setup" class="btn btn btn-success btn-block">Frontdesk Setup</a>';  ?></li>
				<li class="divider"></li>
				<li class="dropdown-header">Feedbacks</li>
				<li><a href="./frontdesk-feedback-add">Add Feedback / Suggestions</a> <?php $frontdesk_menu_items[] = '<a href="./frontdesk-feedback-add" class="btn btn btn-success btn-block">Add Feedback</a>';  ?></li>
				<li><a href="./frontdesk-feedback-list">View Feedbacks / Suggestions</a> <?php $frontdesk_menu_items[] = '<a href="./frontdesk-feedback-list" class="btn btn btn-success btn-block">View Feedbacks</a>';  ?></li>
				<li class="divider"></li>
				<li class="dropdown-header">Visitors</li>
				<li><a href="./frontdesk-visitors-add">Record Visits</a> <?php $frontdesk_menu_items[] = '<a href="./frontdesk-visitors-add" class="btn btn btn-success btn-block">Record Visits</a>';  ?></li>
			<li><a href="./frontdesk-visitors-list">List Visitors</a> <?php $frontdesk_menu_items[] = '<a href="./frontdesk-visitors-list" class="btn btn btn-success btn-block">List Visitors</a>';  ?></li>
				<li class="divider"></li>
				<li class="dropdown-header">Half Day Leaves</li>
				<li><a href="./frontdesk-halfday-add">Add Halfdays</a> <?php $frontdesk_menu_items[] = '<a href="./frontdesk-halfday-add" class="btn btn btn-success btn-block">Add Halfdays</a>';  ?></li>
				<li><a href="./frontdesk-halfday-list">List Halfdays</a><?php $frontdesk_menu_items[] = '<a href="./frontdesk-halfday-list" class="btn btn btn-success btn-block">List Halfdays</a>';  ?></li>
				
				<li class="divider"></li>
				<li class="dropdown-header">Admission Enquiry</li>
				<li><a href="./frontdesk-inqui-add">Add Enquiry</a><?php $frontdesk_menu_items[] = '<a href="./frontdesk-inqui-add" class="btn btn btn-success btn-block">Add Inquiry</a>';  ?></li>
				<!--<li><a href="./frontdesk-admquery-list">List Queries</a><?php $frontdesk_menu_items[] = '<a href="./frontdesk-admquery-list" class="btn btn btn-success btn-block">List Queries</a>';  ?></li>-->
				<li class="divider"></li>
				<li class="dropdown-header">Counselling</li>
			   <li><a href="./frontdesk-add">Proceed Enquiry</a> <?php $frontdesk_menu_items[] = '<a href="./frontdesk-add" class="btn btn btn-success btn-block">Proceed Enquiry</a>';  ?></li>
			   <li><a href="./frontdesk-schedule-interview">Scheduled Interview</a> <?php $frontdesk_menu_items[] = '<a href="./frontdesk-schedule-interview" class="btn btn btn-success btn-block">Scheduled Interview</a>';  ?></li>
			   <li><a href="./frontdesk-admission-approvel">Admission Approval</a> <?php $frontdesk_menu_items[] = '<a href="./frontdesk-admission-approvel" class="btn btn btn-success btn-block">Admission Approval</a>';  ?></li>
				
              </ul>
            </li>
			<?php } ?>
			
			
			
			
			<?php if($_SESSION['ACC_STUDENT']=='1') 	{	?>
			<li class="dropdown <?php if($page=='student') echo "active"; ?>" >
              <a href="#"  class="dropdown-toggle " data-toggle="dropdown">Student <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="./student-new">New Student</a> <?php $student_menu_items[] = '<a href="./student-new" class="btn btn-xs btn-primary">New Student</a>';  ?></li>
				<li class="divider"></li>
				<li><a href="./student-new-list">List New Student</a> <?php $student_menu_items[] = '<a href="./student-new-list" class="btn btn-xs btn-primary">List New Student</a>';  ?></li>
				<li><a href="./student-new-list-date">New Student (by date)</a> <?php $student_menu_items[] = '<a href="./student-new-list-date" class="btn btn-xs btn-primary">New Student (by date)</a>';  ?></li>
				<li><a href="./student-list-class">List Student (classwise)</a> <?php $student_menu_items[] = '<a href="./student-list-class" class="btn btn-xs btn-primary">List Student (classwise)</a>';  ?></li>
				<li><a href="./student-search">Search Student</a> <?php $student_menu_items[] = '<a href="./student-search" class="btn btn-xs btn-primary">Search Student </a>';  ?></li>
				<li><a href="./student-report-all">Customized Report</a> <?php $student_menu_items[] = '<a href="./student-report-all" class="btn btn-xs btn-primary">Customized Report</a>';  ?></li>
				<!--<li><a href="./student-list-nso">Student List (NSO)</a> <?php $student_menu_items[] = '<a href="./student-list-nso" class="btn btn-xs btn-primary">Student List (NSO)</a>';  ?></li>-->
				<li><a href="./student-list-tc">Student List (TC Issued)</a> <?php $student_menu_items[] = '<a href="./student-list-tc" class="btn btn-xs btn-primary">Student List (TC Issued)</a>';  ?></li>
				<li><a href="./student-admit-card">Student Admit Card</a> <?php $student_menu_items[] = '<a href="./student-admit-card" class="btn btn-xs btn-primary">Student Admit Card</a>';  ?></li>
				<li><a href="./student-dynamic-entry">Dynamic Head Entry </a> <?php $student_menu_items[] = '<a href="./student-dynamic-entry" class="btn btn-xs btn-primary">Dynamic Head Entry</a>';  ?></li>
				
              </ul>
            </li>
			<?php } ?>
			
			<?php if($_SESSION['ACC_FEE']=='1') 	{	?>
			<li class="dropdown <?php if($page=='fee') echo "active"; ?>" >
              <a href="#"  class="dropdown-toggle " data-toggle="dropdown">Fee Section <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li class="dropdown-submenu">
                <a style="cursor:pointer;">Fee Setup</a>
                <ul class="dropdown-menu">
                  <li><a href="./fee-define-type">Define Types</a> <?php $fee_menu_items[] = '<a href="./fee-define-type" class="btn btn-xs btn-primary head-menu">Define Fee Type</a>';  ?></li>
                  <li><a href="./fee-define-category">Define Categories</a> <?php $fee_menu_items[] = '<a href="./fee-define-category" class="btn btn-xs btn-primary head-menu">Define Category</a>';  ?></li>
                  <li><a href="./fee-define-heads">Define Fee Heads</a> <?php $fee_menu_items[] = '<a href="./fee-define-heads" class="btn btn-xs btn-primary head-menu">Define Fee Heads</a>';  ?></li>
                  <li><a href="./fee-define-amount">Define Fee Amount</a> <?php $fee_menu_items[] = '<a href="./fee-define-amount" class="btn btn-xs btn-primary head-menu">Define Fee Amount</a>';  ?></li>
				  <li><a href="./fee-discount">Define Fee Discount</a> <?php $fee_menu_items[] = '<a href="./fee-discount" class="btn btn-xs btn-primary head-menu">Define Fee discount</a>';  ?></li>
                  <li><a href="./fee-view-amount">View / Change Fee Amount</a> <?php $fee_menu_items[] = '<a href="./fee-view-amount" class="btn btn-xs btn-primary head-menu">View / Change Fee Amount</a>';  ?></li>
				  <li class="divider"></li>
                  <li><a href="#">Define Addl. Heads</a></li>
                </ul>
              </li>
			  <li class="divider"></li>
			  <li><a href="./discount-approvel" class="bg-danger">Discount Approval</a> <?php $fee_menu_items[] = '<a href="./discount-approvel" class="btn btn-xs btn-primary head-menu">Discount Approval</a>';  ?></li>
              <li><a href="./fee-pay-search" class="bg-danger">Pay Fee</a> <?php $fee_menu_items[] = '<a href="./student-new" class="btn btn-xs btn-primary head-menu">New Student</a>';  ?></li>
			  <li class="divider"></li>
				<li class="dropdown-header">Fee Rports</li>
				<li><a href="./fee-view-trasaction">Fee Transactions</a> <?php $fee_menu_items[] = '<a href="./fee-view-trasaction" class="btn btn-xs btn-primary head-menu">Fee Transactions</a>';  ?></li>
				<!--<li><a href="./fee-lastyear-dues">Last Year Dues</a> <?php $fee_menu_items[] = '<a href="./fee-lastyear-dues" class="btn btn-xs btn-primary head-menu">Last Year Dues</a>';  ?></li>-->
				<li><a href="./fee-annual-calc">Annual Fee Calculation</a> <?php $fee_menu_items[] = '<a href="./fee-annual-calc" class="btn btn-xs btn-primary head-menu">Annual Fee Calculation</a>';  ?></li>
				<li><a href="./fee-bank-payslip">Bank Payslip</a> <?php $fee_menu_items[] = '<a href="./fee-bank-payslip" class="btn btn-xs btn-primary head-menu">Bank Payslip</a>';  ?></li>
				<li><a href="./fee-cheque-listing">	Cheque Listing</a> <?php $fee_menu_items[] = '<a href="./fee-cheque-listing" class="btn btn-xs btn-primary head-menu">Cheque Listing</a>';  ?></li>
				
				
				<li><a href="./fee-cllection">Fee Collection</a> <?php $fee_menu_items[] = '<a href="./fee-cllection" class="btn btn-xs btn-primary head-menu">Fee Collection</a>';  ?></li>
				
				<li><a href="./fee-cat-list">Categorised List</a> <?php $fee_menu_items[] = '<a href="./fee-cat-list" class="btn btn-xs btn-primary head-menu">Categorised List</a>';  ?></li>
				<li class="dropdown-submenu">
					<a style="cursor:pointer;">Other Reports</a>
					<ul class="dropdown-menu">
					<li><a href="./fee-classwise-collection">Classwise Collection</a> <?php $fee_menu_items[] = '<a href="./fee-classwise-collection" class="btn btn-xs btn-primary head-menu">Classwise Collection</a>';  ?></li>
					<li><a href="./fee-cheque-coll">Cheque Collection</a> <?php $fee_menu_items[] = '<a href="./fee-cheque-coll" class="btn btn-xs btn-primary head-menu">Cheque Collection</a>';  ?></li>
						  <li><a href="./fee-monthwise-summary">Monthwise Fee Summary </a> <?php $fee_menu_items[] = '<a href="./fee-monthwise-summary" class="btn btn-xs btn-primary head-menu">Monthwise Fee Summary</a>';  ?></li>
					</ul>
              </li>
			  <li><a href="./transport-report-all">Student List(Using Transport)</a> <?php $fee_menu_items[] = '<a href="./transport-report-all" class="btn btn-xs btn-primary head-menu">Student List(Using Transport)</a>';  ?></li>
			  <li><a href="./transport-report-bus">BusWise List</a> <?php $fee_menu_items[] = '<a href="./transport-report-bus" class="btn btn-xs btn-primary head-menu">BusWise List</a>';  ?></li>
			  <li><a href="./transport-report-route">Route / Stoppage Wise List</a> <?php $fee_menu_items[] = '<a href="./transport-report-route" class="btn btn-xs btn-primary head-menu">Route / Stoppage Wise List</a>';  ?></li>
              </ul>
            </li>
			<?php } ?>
			
			<?php if($_SESSION['ACC_GROUP']=='root') 	{	?>
			<li class="dropdown <?php if($page=='system') echo "active"; ?>" >
              <a href="#"  class="dropdown-toggle " data-toggle="dropdown"> System <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="./system-student-import">Import Student Data</a> <?php $settings_menu_items[] = '<a href="./system-student-import" class="btn btn-xs btn-primary">Import Student</a>';  ?></li>
                <li><a href="./system-master-edit">Student Master Edit</a> <?php $settings_menu_items[] = '<a href="./system-master-edit" class="btn btn-xs btn-primary">Master Edit</a>';  ?></li>
                <li><a href="./system-fee-recalculate">Fee Data Import / Recalculate</a> <?php $settings_menu_items[] = '<a href="./system-fee-recalculate" class="btn btn-xs btn-primary">Fee Import / Recalc.</a>';  ?></li>
                <li><a href="./system-dynamic-info-heads">Dynamic Data Heads</a> <?php $settings_menu_items[] = '<a href="./system-dynamic-info-heads" class="btn btn-xs btn-primary">Dynamic Heads</a>';  ?></li>
				<li><a href="./system-dynamic-extra-heads">Dynamic Extra Heads</a> <?php $settings_menu_items[] = '<a href="./system-dynamic-extra-heads" class="btn btn-xs btn-primary">Dynamic Extra Heads</a>';  ?></li>
				<li class="divider"></li>
				
				<li class="dropdown-header">Access Management</li>
                <li><a href="./system-manage-user">Manage Users</a> <?php $settings_menu_items[] = '<a href="./system-manage-user" class="btn btn-xs btn-primary">Manager Users</a>';  ?></li>
                <li><a href="./system-acl">Manage Permissions</a> <?php $settings_menu_items[] = '<a href="./system-acl" class="btn btn-xs btn-primary">Permissions</a>';  ?></li>
              </ul>
            </li>
			<?php } ?>
			
			<?php if($_SESSION['ACC_ATTENDANCE']=='1') 	{	?>
			<li class="dropdown <?php if($page=='attendance') echo "active"; ?>" >
              <a href="#"  class="dropdown-toggle " data-toggle="dropdown">Attedance <b class="caret"></b></a>
              <ul class="dropdown-menu">
				<li class="dropdown-header">Setup</li>
                <li><a href="./attendance-codes">Attedance Setup</a> <?php $atten_menu_items[] = '<a href="./attendance-codes" class="btn btn btn-success btn-block">Attedance Setup</a>';  ?></li>
                <li class="divider"></li>
				<li class="dropdown-header">Student Attedance</li>
                <li><a href="./attendance-mark">Mark Attedance</a> <?php $atten_menu_items[] = '<a href="./attendance-mark" class="btn btn btn-danger btn-block">Mark Student Atten.</a>';  ?></li>
                <li><a href="./attendance-absent-log">Attendance Log</a> <?php $atten_menu_items[] = '<a href="./attendance-absent-log" class="btn btn btn-danger btn-block">Student Attedance Log</a>';  ?></li>
                <li class="divider"></li>
			  </ul>
            </li>
			<?php } ?>
			
			<?php if($_SESSION['ACC_CERTIFICATE']=='1') 	{	?>
			<li class="dropdown <?php if($page=='cert') echo "active"; ?>" >
              <a href="#"  class="dropdown-toggle " data-toggle="dropdown"> Certificate <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="./certificate-transfer">Transfer Certificate</a> <?php $certificate_menu_items[] = '<a href="./certificate-transfer" class="btn btn-xs btn-primary">Transfer Certificate</a>';  ?></li>
				 <li><a href="./certificate-transfer-list">Transfer Certificate List</a> <?php $certificate_menu_items[] = '<a href="./certificate-transfer-list" class="btn btn-xs btn-primary">Transfer Certificate List</a>';  ?></li>
				 <li><a href="./certificate-charactor">Charactor Certificate</a> <?php $certificate_menu_items[] = '<a href="./certificate-charactor" class="btn btn-xs btn-primary">Charactor Certificate</a>';  ?></li>
                
              </ul>
            </li>
			<?php } ?>
			
			
			<li><a href="#">Academics</a></li>
			
			<?php if($_SESSION['ACC_COMM']=='1') 	{	?>
			<li class="dropdown <?php if($page=='comm') echo "active"; ?>" >
              <a href="#"  class="dropdown-toggle " data-toggle="dropdown">Communication <b class="caret"></b></a>
              <ul class="dropdown-menu">
				<li class="dropdown-header">Setup</li>
                <li><a href="./comm-template">Manage Template</a> <?php $comm_menu_items[] = '<a href="./comm-template" class="btn btn btn-danger btn-block">Templates</a>';  ?></li>
                <li><a href="./comm-confirmsms">SMS Confirmation</a> <?php $comm_menu_items[] = '<a href="./comm-confirmsms" class="btn btn btn-success btn-block">SMS Confirmation</a>';  ?></li>
                <li><a href="./comm-sendcommon">Send Common Message</a> <?php $comm_menu_items[] = '<a href="./comm-sendcommon" class="btn btn btn-success btn-block">Common Message</a>';  ?></li>
                <li class="divider"></li>
			  </ul>
            </li>
			<?php } ?>
			
			<li><a href="#">CCE</a></li>
			<li><a href="#">Library</a></li>
			<li><a href="./logout">Log Out</a></li>
			
          </ul>
        </div><!--/.nav-collapse -->
    </nav>