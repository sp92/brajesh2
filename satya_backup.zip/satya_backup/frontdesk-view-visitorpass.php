<?php
$page='frontdesk';
require('core.php');
error_reporting(0);
if($_SESSION['ACC_FRONTDESK']=='0') 
{
	header("Location: main.php");
}
//include('header.php');
?>
	<br/>
	<!-- Start Content -->
	<div class="row">
	<div class="col-md-9">
<?php
if($_REQUEST['type']=='visit') {
	
$id=$_REQUEST['id'];
$db->where('id',$id);
$row=$db->get('visits');

if($db->count > 0) {

ob_start();
?>

<div class=Section1>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:1px solid;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0in 5.4pt 0in 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:13.05pt'>
  <td width=786 colspan=20 align=center valign=bottom style='width:534.15pt;border:solid windowtext 2.25pt;
  border-bottom:none;background:#D9D9D9;mso-background-themecolor:background1;
  mso-background-themeshade:217;padding:0in 5.4pt 0in 5.4pt;height:13.05pt'>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:17.0pt;mso-bidi-font-size:14.0pt'><?php echo SCHOOLNAME; ?></span><span style='font-size:14.0pt'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;height:20.25pt'>
  <td width=786 colspan=20 align=center valign=top style='width:534.15pt;border-top:none;
  border-left:solid windowtext 2.25pt;border-bottom:none;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:20.25pt'>

  </td>
 </tr>
 <tr style='mso-yfti-irow:1;height:20.25pt'>
  <td width=786 colspan=18 align=center valign=top style='width:534.15pt;border-top:none;
  border-left:solid windowtext 2.25pt;border-bottom:none;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:20.25pt'>
  <p class=MsoNormal align=center style='margin-top:12.0pt;margin-right:0in;
  margin-left:0in;text-align:center'><b style='mso-bidi-font-weight:
  normal'><u><span style='font-size:14.0pt;mso-bidi-font-size:16.0pt;
  font-family:JuniusSmallCaps'>Visitor Pass</span></u></b><span
  style='font-size:14.0pt'><o:p></o:p></span></p>
  </td>
  <td colspan=2>
  <?php echo "<img src='pictures/visits/".$row[0]['pic']."' style='width:130px;border:1px solid #000;'>"; ?>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2;height:.3in'>
  <td width=140 valign=bottom  style='width:95.3pt;border:none;border-left:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Name :<o:p></o:p></span></p>
  </td>
  <td width=296 colspan=9 valign=bottom style='width:201.1pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['name']; ?><o:p></o:p></span></p>
  </td>
  <td width=91 colspan=3 valign=bottom align=right style='width:61.8pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Date :<o:p></o:p></span></p>
  </td>
  <td width=90 colspan=2 valign=bottom style='width:61.1pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:9.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo date('d/m/Y'); ?><o:p></o:p></span></p>
  </td>
  <td width=86 colspan=4 valign=bottom  style='width:58.5pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Time :<o:p></o:p></span></p>
  </td>
  <td width=83 valign=bottom style='width:56.35pt;border-top:none;border-left:
  none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo date('H:i A'); ?><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3;height:.3in'>
  <td width=140 valign=bottom  style='width:95.3pt;border:none;border-left:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Address / Org. :<o:p></o:p></span></p>
  </td>
  <td width=296 colspan=9 valign=bottom style='width:201.1pt;border:none;
  border-bottom:1px solid;mso-border-top-alt:1px solid;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['address']; ?><o:p></o:p></span></p>
  </td>
  <td width=188 colspan=7 valign=bottom align=right  style='width:127.4pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Contact No.:<o:p></o:p></span></p>
  </td>
  <td width=162 colspan=3 valign=bottom style='width:110.35pt;border-top:none;
  border-left:none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php 
  echo  $row[0]['mobile'];
  ?><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:4;height:19.3pt'>
  <td width=179 colspan=3  valign=bottom style='width:121.8pt;border:none;
  border-left:solid windowtext 2.25pt;padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Purpose of visit:<o:p></o:p></span></p>
  </td>
  <td width=607 colspan=17 valign=bottom style='width:412.35pt;border-top:none;
  border-left:none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['regarding']; ?><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:5;height:19.3pt'>
  <td width=240 colspan=6  valign=bottom style='width:162.8pt;border:none;
  border-left:solid windowtext 2.25pt;padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Whom to visit:<o:p></o:p></span></p>
  </td>
  <td width=198 colspan=5 valign=bottom style='width:134.2pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['towhom']; ?><o:p></o:p></span></p>
  </td>
  <td width=186 colspan=5  valign=bottom align=right style='width:126.45pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Closure Time :<o:p></o:p></span></p>
  </td>
  <td width=163 colspan=4 valign=bottom style='width:110.7pt;border-top:none;
  border-left:none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><o:p></o:p></span></p>
  </td>
 </tr>
 
 <tr style='mso-yfti-irow:10;height:16.2pt'>
  <td width=786 colspan=20 valign=top style='width:534.15pt;border-top:none;
  border-left:solid windowtext 2.25pt;border-bottom:none;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:16.2pt'>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:14.0pt'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:11;mso-yfti-lastrow:yes;height:22.7pt'>
  <td width=379 colspan=8 valign=bottom style='width:257.4pt;border-top:none;
  border-left:solid windowtext 2.25pt;border-bottom:solid windowtext 2.25pt;
  border-right:none;padding:0in 5.4pt 0in 5.4pt;height:22.7pt'>
  <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
  style='font-size:13.0pt;mso-bidi-font-size:13.0pt'></span></b><b><span
  style='font-size:14.0pt'>Signature of Visitor<o:p></o:p></span></p>
  </td>
  <td width=407 colspan=12  align=right valign=bottom style='width:276.75pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 2.25pt;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:22.7pt'>
  <p class=MsoNormal  style='text-align:right'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:13.0pt;mso-bidi-font-size:13.0pt;font-family:
  "Monotype Corsiva"'>Signature of Visited</span></b><span style='font-size:
  14.0pt'><o:p></o:p></span></p>
  </td>
 </tr>
 <![if !supportMisalignedColumns]>
 <tr height=0>
  <td width=134 style='border:none'></td>
  <td width=13 style='border:none'></td>
  <td width=23 style='border:none'></td>
  <td width=35 style='border:none'></td>
  <td width=3 style='border:none'></td>
  <td width=18 style='border:none'></td>
  <td width=54 style='border:none'></td>
  <td width=77 style='border:none'></td>
  <td width=7 style='border:none'></td>
  <td width=47 style='border:none'></td>
  <td width=1 style='border:none'></td>
  <td width=56 style='border:none'></td>
  <td width=30 style='border:none'></td>
  <td width=73 style='border:none'></td>
  <td width=12 style='border:none'></td>
  <td width=6 style='border:none'></td>
  <td width=1 style='border:none'></td>
  <td width=42 style='border:none'></td>
  <td width=33 style='border:none'></td>
  <td width=80 style='border:none'></td>
 </tr>
 <![endif]>
</table>


<p class=MsoNormal>&nbsp;</p>

</div>

<?php } 
}

if($_REQUEST['type']=='query') {
	$enq_no=$_REQUEST['id'];
$db->where('id',$enq_no);
$row=$db->get('inquiry');
if($db->count >0){
ob_start();
?>

<div class=Section1>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:1px solid;mso-border-alt:solid black .5pt;
 mso-border-themecolor:text1;mso-yfti-tbllook:1184;mso-padding-alt:0in 5.4pt 0in 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:13.05pt'>
  <td width=786 colspan=20 align=center valign=bottom style='width:534.15pt;border:solid windowtext 2.25pt;
  border-bottom:none;background:#D9D9D9;mso-background-themecolor:background1;
  mso-background-themeshade:217;padding:0in 5.4pt 0in 5.4pt;height:13.05pt'>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:17.0pt;mso-bidi-font-size:14.0pt'><?php echo $school_name; ?></span><span style='font-size:14.0pt'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;height:20.25pt'>
  <td width=786 colspan=20 align=center valign=top style='width:534.15pt;border-top:none;
  border-left:solid windowtext 2.25pt;border-bottom:none;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:20.25pt'>
  <p class=MsoNormal align=center style='margin-top:12.0pt;margin-right:0in;
  margin-left:0in;text-align:center'><b style='mso-bidi-font-weight:
  normal'><u><span style='font-size:14.0pt;mso-bidi-font-size:16.0pt;
  font-family:JuniusSmallCaps'>&nbsp;</span></u></b><span
  style='font-size:14.0pt'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1;height:20.25pt'>
  <td width=786 colspan=18 align=center valign=top style='width:534.15pt;border-top:none;
  border-left:solid windowtext 2.25pt;border-bottom:none;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:20.25pt'>
  <p class=MsoNormal align=center style='margin-top:12.0pt;margin-right:0in;
  margin-left:0in;text-align:center'><b style='mso-bidi-font-weight:
  normal'><u><span style='font-size:18.0pt;mso-bidi-font-size:16.0pt;
  font-family:JuniusSmallCaps'>Visitor Pass</span></u></b><span
  style='font-size:14.0pt'><o:p></o:p></span></p>
  </td>
  <td colspan=2>
  <?php echo "<img src='pictures/enquiry/".$row[0]['pic']."' style='width:130px;border:1px solid #000;'>"; ?>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2;height:.3in'>
  <td width=140 valign=bottom  style='width:95.3pt;border:none;border-left:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Name :<o:p></o:p></span></p>
  </td>
  <td width=296 colspan=9 valign=bottom style='width:201.1pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['fat_name']; ?><o:p></o:p></span></p>
  </td>
  <td width=91 colspan=3 valign=bottom align=right style='width:61.8pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Date :<o:p></o:p></span></p>
  </td>
  <td width=90 colspan=2 valign=bottom style='width:61.1pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:9.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo date('d/m/Y', strtotime($row[0]['pass_date'])); ?><o:p></o:p></span></p>
  </td>
  <td width=86 colspan=4 valign=bottom  style='width:58.5pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Time :<o:p></o:p></span></p>
  </td>
  <td width=83 valign=bottom style='width:56.35pt;border-top:none;border-left:
  none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo date('H:i A', strtotime($row[0]['pass_date'])); ?><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3;height:.3in'>
  <td width=140 valign=bottom  style='width:95.3pt;border:none;border-left:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Address / Org. :<o:p></o:p></span></p>
  </td>
  <td width=296 colspan=9 valign=bottom style='width:201.1pt;border:none;
  border-bottom:1px solid;mso-border-top-alt:1px solid;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['address']; ?><o:p></o:p></span></p>
  </td>
  <td width=188 colspan=7 valign=bottom align=right  style='width:127.4pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Contact No.:<o:p></o:p></span></p>
  </td>
  <td width=162 colspan=3 valign=bottom style='width:110.35pt;border-top:none;
  border-left:none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:.3in'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php 
  echo  $row[0]['mobile'];
  ?><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:4;height:19.3pt'>
  <td width=179 colspan=3  valign=bottom style='width:121.8pt;border:none;
  border-left:solid windowtext 2.25pt;padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Purpose of visit:<o:p></o:p></span></p>
  </td>
  <td width=607 colspan=17 valign=bottom style='width:412.35pt;border-top:none;
  border-left:none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Admission of their ward  <?php echo $row[0]['name']; ?><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:5;height:19.3pt'>
  <td width=240 colspan=6  valign=bottom style='width:162.8pt;border:none;
  border-left:solid windowtext 2.25pt;padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Whom to visit:<o:p></o:p></span></p>
  </td>
  <td width=198 colspan=5 valign=bottom style='width:134.2pt;border:none;
  border-bottom:1px solid;padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><?php echo $row[0]['towhom']; ?><o:p></o:p></span></p>
  </td>
  <td width=186 colspan=5  valign=bottom align=right style='width:126.45pt;border:none;
  padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal  style='text-align:right'><span
  style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'>Closure Time :<o:p></o:p></span></p>
  </td>
  <td width=163 colspan=4 valign=bottom style='width:110.7pt;border-top:none;
  border-left:none;border-bottom:1px solid;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:19.3pt'>
  <p class=MsoNormal><span style='font-size:11.0pt;font-family:"Arial Narrow","sans-serif"'><o:p></o:p></span></p>
  </td>
 </tr>
 
 <tr style='mso-yfti-irow:10;height:16.2pt'>
  <td width=786 colspan=20 valign=top style='width:534.15pt;border-top:none;
  border-left:solid windowtext 2.25pt;border-bottom:none;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:16.2pt'>
  <p class=MsoNormal align=center style='text-align:center'><span
  style='font-size:14.0pt'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:11;mso-yfti-lastrow:yes;height:22.7pt'>
  <td width=379 colspan=8 valign=bottom style='width:257.4pt;border-top:none;
  border-left:solid windowtext 2.25pt;border-bottom:solid windowtext 2.25pt;
  border-right:none;padding:0in 5.4pt 0in 5.4pt;height:22.7pt'>
  <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
  style='font-size:13.0pt;mso-bidi-font-size:13.0pt'></span></b><b><span
  style='font-size:14.0pt'>Signature of Visitor<o:p></o:p></span></p>
  </td>
  <td width=407 colspan=12  align=right valign=bottom style='width:276.75pt;border-top:none;
  border-left:none;border-bottom:solid windowtext 2.25pt;border-right:solid windowtext 2.25pt;
  padding:0in 5.4pt 0in 5.4pt;height:22.7pt'>
  <p class=MsoNormal  style='text-align:right'><b style='mso-bidi-font-weight:
  normal'><span style='font-size:13.0pt;mso-bidi-font-size:13.0pt;font-family:
  "Monotype Corsiva"'>Signature of Visited</span></b><span style='font-size:
  14.0pt'><o:p></o:p></span></p>
  </td>
 </tr>
 <![if !supportMisalignedColumns]>
 <tr height=0>
  <td width=134 style='border:none'></td>
  <td width=13 style='border:none'></td>
  <td width=23 style='border:none'></td>
  <td width=35 style='border:none'></td>
  <td width=3 style='border:none'></td>
  <td width=18 style='border:none'></td>
  <td width=54 style='border:none'></td>
  <td width=77 style='border:none'></td>
  <td width=7 style='border:none'></td>
  <td width=47 style='border:none'></td>
  <td width=1 style='border:none'></td>
  <td width=56 style='border:none'></td>
  <td width=30 style='border:none'></td>
  <td width=73 style='border:none'></td>
  <td width=12 style='border:none'></td>
  <td width=6 style='border:none'></td>
  <td width=1 style='border:none'></td>
  <td width=42 style='border:none'></td>
  <td width=33 style='border:none'></td>
  <td width=80 style='border:none'></td>
 </tr>
 <![endif]>
</table>


<p class=MsoNormal>&nbsp;</p>

</div>

<?php } } ?>

<?php /* file_put_contents('visitpass.htm', ob_get_contents());
echo "<script>window.location.href='vp_pdf.php';</script>";
ob_end_flush();  */
?>