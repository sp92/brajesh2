<?php
$page = 'master';
require('core.php');
if ($_SESSION['ACC_MASTER'] == '0') {
    header("Location: ./main");
}
require_once('header.php');
?>
<div class="container">

    <div class="row">
        <div class='col-md-2'>
            <?php print_menu($master_menu_items); ?>
        </div>
        <div class='col-md-10'>
            <h3>School Information</h3>
            <?php
            $db->where("id", 1);
            $user = $db->get("school_info", 1);
            if ($db->count > 0) {
                foreach ($user as $u) {
                    $school_name = $u['school_name'];
                    $address = $u['address'];
                    $phone = $u['phone'];
                    $email = $u['email'];
                    $website = $u['website'];
                    $cbse_aff = $u['cbse_aff'];
                    $code = $u['code'];
                    $principal = $u['principal'];
                    $eschool_url = $u['eschool_url'];
                    $eschool_param = $u['eschool_param'];
                }
            }
            ?>	
            <form id="master-form">
                <div class='row'>
                    <div class='col-md-6 col-sm-6 col-xs-12'>
                        <input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
                        <input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php'); ?>">

                        <label for="street">School Name : </label> 
                        <input type="text" name="school_name" class="form-control" value="<?php echo $school_name; ?>" />
                        <br>
                        <label for="city">Address : </label>
                        <input type="text" name="address" class="form-control" value="<?php echo $address; ?>" />
                        <br>
                        <label for="country">Phone No. : </label> 
                        <input name="phone" type="text" class="form-control" value="<?php echo $phone; ?>" />
                        <br>
                        <label for="country">Principal Name : </label> 
                        <input type="text" name="principal"  class="form-control" value="<?php echo $principal; ?>" />
                        <br>
                        <label for="country">E-School URL [starts with http:// without trailing hash (/)]: </label> 
                        <input type="text" name="eschool_url" class="form-control" value="<?php echo $eschool_url; ?>" />
                        <br>
                        <label for="country">Fee Collection Method : </label> 
                        <input type="text" class="form-control col-md-2" value="<?php echo fee_coll_type; ?>" disabled />
                        <br>
                    </div>
                    <div  class='col-md-6  col-sm-6 col-xs-12'>
                        <label for="state">Email : </label>
                        <input name="email" type="text" class="form-control" placeholder="Email Address" value="<?php echo $email; ?>"  />
                        <br>
                        <label for="zip">Website : </label>
                        <input name="website" type="text" class="form-control" value="<?php echo $website; ?>"  />
                        <br>
                        <label for="tel">Affiliation No. : </label>
                        <input type="text" name="cbse_aff" class="form-control" value="<?php echo $cbse_aff; ?>" />
                        <br>
                        <label for="tel">School Code : </label>
                        <input type="text" name="code" class="form-control" value="<?php echo $code; ?>" />
                        <br>
                        <label for="country">E-School URL Parameters (param1=val1&amp;param2=val2): </label> 
                        <input type="password" name="eschool_param" class="form-control" value="<?php echo $eschool_param; ?>" />
                    </div>
                </div>

                <div align="center">
                    <br>
                    <?php if (acl_check('master_update_school_info', $_SESSION['SESS_ID']) != false) { ?>
                        <button class="btn btn-primary ladda-button kill-evo" type='submit' data-style="zoom-out"><span class="ladda-label">Update Information</span></button>
                    <?php } ?>
                </div>
            </form>

        </div>



    </div>
</div> 
<script>
    $('#master-form').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: 'POST',
            url: './function/masterfunctions',
            data: $(this).serialize(),
            success: function (data) {
                if (data == '0') {
                    $.notify({message: 'Failed to update information.'}, {type: 'danger'});
                } else {
                    $.notify({message: '<strong>Successfully</strong> updated the information.'}, {type: 'success'});
                }
            }
        });
    });
</script>
<?php
require_once('footer.php');
?>