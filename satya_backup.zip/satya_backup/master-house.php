<?php
$page='master';
require('core.php');
if($_SESSION['ACC_MASTER']=='0') 
{
	header("Location: main.php");
}
error_reporting(0);
if(@$_REQUEST['hdnCmd']=="ADD")
	{
	$house=clean($_REQUEST['house']);
	
	$data = Array (
		'house' => $house
	);
	if($house!=''){
	$db->insert ('house', $data);
	}else{
	header("Location: ./master-house");
	}
	}
if(@$_REQUEST['action']=="del")
	{
	$db->where('id', round($_REQUEST['id']));
	$db->delete('house');
	header("Location: ./master-house");
	}
include('header.php');
?>
<div class="container">

<div class="row">
<div class="col-md-2 hidden-xs">
	<?php print_menu($master_menu_items); ?>
	</div>
	<div class="col-md-10">
	<h3>House Master</h3>
<center>
<table class="table table-striped table-hover table-bordered" style="width:350px;">
<thead>
<tr>
<th style="width:20px;">SR</th>
<th style="width:150px;">House</th>
<th style="width:1px;">Update</th>
</tr>
</thead>
<tbody>
				
			<?php
				$n=1;
					$user = $db->get ("house");
					if ($db->count > 0) {
						foreach ($user as $u) { 
							
					?>			
<tr>
<td><?php echo $n; $n++; ?></td>
<td><?php echo $u['house']; ?></td>
<td><a href="master-house?action=del&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a></td>
</tr>
		  <?php
				}
					}
		?>	
<tr>				
<td></td>
<td colspan=2><form action="./master-house" method="post"><input type="text" name="house"/>
<input type="hidden" name="hdnCmd" value="ADD"><input type="submit" name="submit" class="btn-primary" value="Add House" /></form>
</td>
</tr>				
</table>
</center>
	</div>

    </div>
    </div> <!-- /container -->
<?php
include('footer.php');
?>