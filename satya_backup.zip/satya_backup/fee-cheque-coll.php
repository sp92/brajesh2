<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') 
{
	header("Location: main.php");
}

include('header.php');
$session = $_SESSION['SESSION'];
?>

<div class="container">
	<?php print_menu($fee_menu_items); ?><br>
	<div class="row">
		<h3>Cheque Collection</h3>
		<form name="myForm" onsubmit="return(validate());" method="get" action="fee-cheque-coll">
			<label>From Date: </label> 
			<input name="from_date" class="datepicker" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["from_date"]; ?>" style="width: 100px;" readonly />  
			<label>To Date : </label> 
			<input name="to_date" data-date-format="dd/mm/yyyy" class="datepicker" value="<?php echo $_REQUEST["to_date"]; ?>" style="width: 100px;" readonly /> 
			<label>Location : </label>
			<select name="location">
				<?php
				$sql = $db->get("location");
				foreach($sql as $row) {
					echo "<option value='".$row["location"]."'".($row["location"]==$_REQUEST["location"] ? " selected" : "").">".$row["location"]."</option>";
				} ?>
			</select>
			<input type="submit" name="submit" value="SUBMIT" />
			<input type="button" onclick="tableToExcel('searchable', 'Student')" value="Export To Excel" style='float:right;' />
			<input type="text" id="searchable" class="search_box" onkeyup="doSearch()" style="float:right;padding: 2px;" placeholder="Search Here....." />
		</form><hr>
		<table id="searchable" class="table table-hover" style="font-size:11px;">
			<thead>
				<tr>
					<th align="center"><strong>Date</strong></th>
					<th align="center"><strong>Rec.No.</strong></th>
					<th align="center"><strong>Deposit Location</strong></th>
					<th align="center" style="width: 66px;"><strong>Adm No.</strong></th>
					<th align="center"><strong>Student Name</strong></th>
					<th align="center"><strong>Cheque No.</strong></th>
					<th align="center"><strong>Bank Name</strong></th>
					<th align="center"><strong>Cheque Date</strong></th>
					<th align="center"><strong>Chq Amount</strong></th>
					<th align="center"><strong>Total Amount</strong></th>
				</tr>
			</thead>
			<tbody>
				<?php
				$from_date = datestamp($_REQUEST["from_date"]);
				$to_date = datestamp($_REQUEST["to_date"]);
				$location = $_REQUEST["location"];
				if($location){
					$loc = "AND location='".$location."'";
				}
				else{
					$loc = '';
				}
				$n=1;
				$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
				if(!empty($head_defineSession)){
					foreach($head_defineSession as $key=>$value){
						if (strpos($value['Field'], 'head') !== false) {
							$query =  $query.'sum('.$value['Field'].') as h'.($headCount+1).', ';
							$headCount++;
						}
					}
				}
				$sql = $db->rawQuery("SELECT id,rec_no,rec_date,adm_no,month,particular, sum(transport) as transport2, ".$query." sum(amount) as amount2,cancelled,location,mode,user,chq_no,chq_date,chq_bnk,cash_amt,chq_amt,chq_clr,remark,transport,discount,late_fine,session FROM ".PREFIX."fee_paid WHERE rec_date between '" . $from_date . "' and '".$to_date."' ".$loc." and mode<>'CASH' group by rec_no  ORDER by id asc");
				foreach($sql as $row){
					if($row['chq_clr']=='NO') { ?>
						<tr style="background:yellow;font-weight:bold;">
							<td align="center"><?php echo date('d/m/Y', strtotime($row['rec_date'])); ?></td>
							<td align="center">
								<?php 
								$rec_loc = $db->rawQuery("SELECT * FROM ".PREFIX."location where location='".$row['location']."'");
								foreach($rec_loc as $rec_loc2) { 
									echo $rec_loc2['code']."-".$row['rec_no']; 
								} ?>
							</td>
							<td align="center"><?php echo $row['location']; ?></td>
							<td align="center"><?php echo $row['adm_no']; ?></td>
							<td align="center">
								<?php 
								$stu_name = $db->rawQuery("SELECT stu_name from ".PREFIX."student where adm_no=".$row["adm_no"]."");
								echo $stu_name[0]['stu_name'] ; ?>
							</td>
							<td align="center"><?php echo $row['chq_no']; ?> </td>
							<td align="center"><?php echo $row['chq_bnk']; ?> </td>
							<td align="center"><?php echo $row['chq_date']; ?> </td>
							<td align="center"><?php $t_1_unclr[] = $row['chq_amt']; echo $row['chq_amt']; ?> </td>
							<td align="center">
								<?php 
								$t_2_unclr[] = $row['amount2']+$row['late_fine']-$row['discount']; 
								echo $row['amount2']+$row['late_fine']-$row['discount']; ?>
							</td>
						</tr>
					<?php } 
					else { ?>
						<tr>
							<td align="center"><?php echo date('d/m/Y', strtotime($row['rec_date'])); ?></td>
							<td align="center">
								<?php 
								$rec_loc = $db->rawQuery("SELECT * FROM ".PREFIX."location where location='".$row['location']."'");
								foreach($rec_loc as $rec_loc2) { 
									echo $rec_loc2['code']."-".$row['rec_no']; 
								} ?>
							</td>
							<td align="center"><?php echo $row['location']; ?></td>
							<td align="center"><?php echo $row['adm_no']; ?></td>
							<td align="center">
								<?php 
								$stu_name = $db->rawQuery("SELECT stu_name from ".PREFIX."student where adm_no=".$row["adm_no"]."");
								echo $stu_name[0]['stu_name'] ; ?>
							</td>
							<td align="center"><?php echo $row['chq_no']; ?> </td>
							<td align="center"><?php echo $row['chq_bnk']; ?> </td>
							<td align="center"><?php echo $row['chq_date']; ?> </td>
							<td align="center"><?php $t_1_clr[] = $row['chq_amt']; echo $row['chq_amt']; ?> </td>
							<td align="center">
								<?php 
								$t_2_clr[] = $row['amount2']+$row['late_fine']-$row['discount']; 
								echo $row['amount2']+$row['late_fine']-$row['discount']; ?>
							</td>
						</tr>
					<?php }
				} ?>
				<tr>
					<td colspan="3" align=right><b>Cleared Cheques : </b></td>
					<td colspan="3"><b>Rs. <?php echo array_sum($t_1_clr); ?></b></td>
					<td colspan="3" align=right><b>Uncleared Cheques : </b></td>
					<td colspan="3"><b>Rs. <?php echo array_sum($t_1_unclr); ?></b></td>
				</tr>
			</tbody>
		</table>
    </div>
</div>
<?php
include('footer.php');
?>