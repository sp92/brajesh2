<?phpinclude('lib/config.php');$homepage=$_REQUEST['data'];$type=$_REQUEST['type'];$session=$_REQUEST['session'];$category=$_REQUEST['category'];$date=date('d F, Y');//$homepage = file_get_contents("transac.htm");include("mpdf/mpdf.php");if($_REQUEST['orientation']=='L') {$mpdf=new mPDF('','A4-L', 0, '', 5, 5, 16, 16, 9, 9, 'L');}if($_REQUEST['orientation']=='P') {$mpdf=new mPDF('','A4', 0, '', 5, 5, 16, 16, 9, 9, '');}$mpdf->mirrorMargins = 0; // Use different Odd/Even headers and footers and mirror margins$mpdf->defaultheaderfontsize = 10; /* in pts */$mpdf->defaultheaderfontstyle = B; /* blank, B, I, or BI */$mpdf->defaultheaderline = 1; /* 1 to include line below header/above footer */$mpdf->defaultfooterfontsize = 12; /* in pts */$mpdf->defaultfooterfontstyle = B; /* blank, B, I, or BI */$mpdf->defaultfooterline = 1; /* 1 to include line below header/above footer */$mpdf->SetHeader($type.'|'.$school_name.'|'.$category);$mpdf->SetFooter($session.'|- {PAGENO} -|'.$date); /* defines footer for Odd and Even Pages - placed at Outer margin */$mpdf->SetFooter(array( 'L' => array( 'content' => 'Text to go on the left', 'font-family' => 'sans-serif', 'font-style' => 'B', /* blank, B, I, or BI */ 'font-size' => '10', /* in pts */ ),'C' => array( 'content' => '- {PAGENO} -','font-family' => 'serif', 'font-style' => 'BI', 'font-size' => '18', /* gives default */ ),'R' => array( 'content' => 'Printed @ {DATE j-m-Y H:m}', 'font-family' => 'monospace', 'font-style' => '', 'font-size' => '10', ), 'line' => 1, /* 1 to include line below header/above footer */
), 'E' /* defines footer for Even Pages */
);
//$stylesheet = file_get_contents('css/bootstrap.css');
//$mpdf->WriteHTML($stylesheet,1);
$stylesheet2 = file_get_contents('css/print-style2.css');
$mpdf->WriteHTML($stylesheet2,1);$html = mb_convert_encoding($homepage, 'UTF-8', 'UTF-8');
$mpdf->WriteHTML($html);
$mpdf->Output();
exit;
?>