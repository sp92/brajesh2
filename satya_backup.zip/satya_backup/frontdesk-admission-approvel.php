<?php
$page='frontdesk';
require('core.php');
if($_SESSION['ACC_FRONTDESK']=='0') {
	header("Location: main.php");
}

include('header.php');
?>
<div class="container">
  
    <div class="row">
	 <div class="col-md-2 hidden-xs">
<?php print_menu($frontdesk_menu_items); ?>
</div>
		<div class="col-md-10">
		<h3>Admission Approvals</h3>
		<form id="add-query" method="post">
		
			<table class="table table-striped" style="padding: 0px;">
				<tbody><tr>
				<td align="right">Enquiry No. : </td>
				<td><input type="text" name="enq_no" id="enq_no" onkeyup="lookItUp2();" required="" autocomplete="off" class="form-control" style="width:70%">
				<a href="javascript:void(0);" onclick="get_enquiry_no()">Get Interviews</a>
				<script>
				function get_enquiry_no() {
					payfee = $.popupWindow('frontdesk-enquiry?adm_status=Interview',{height:500,width:800});
					
				}
				</script>
				</td>
			<td align="right"> Picture Captured: </td>
				<td align="center" style="height:112px;"><span id="pic"><img src="pictures/query/ " style="height:150px;"></span></td>
			</tr>
			
			
					
			<tr>
				<td align="right">Name of the Child: </td>
				<td>
				<input type="text" name="stu_name" id="stu_name" class="form-control" readonly="" required="">
				</td>
			
			<td align="right">Date of birth: </td>
				<td valign="middle">
				<input type="text" name="dob" id="dob" class="form-control" style="width: 100px;" onchange="getage();" readonly="" required="">
				
Age :				
				</td>
			
			
			</tr>
			
	

	
			<tr>
				<td align="right">Father's Name: </td>
				<td>
				<input type="text" name="fat_name" id="fat_name" class="form-control" readonly="" required="">
				</td>
					<td align="right">Father's Contact No.: </td>
				<td>
				<input type="number" name="mobile" id="mobile" class="form-control" readonly="" required="">
				</td>
			</tr>
			
			
			<tr>
				<td align="right">Occupation: </td>
				<td>
				<input type="text" name="fat_occ" id="fat_occ" class="form-control" readonly="">
				</td>
				<td align="right"></td>
				<td>
				
				</td>
			</tr>
			
			
			<tr>
				<td align="right">Location : </td>
				<td><input type="text" name="location" id="location" class="form-control" required="" readonly="">
				</td>
					<td align="right"></td>
					<td></td>
			</tr>
			
			<tr>
				<td align="right">Current Class : </td>
				<td><input type="text" name="current_class" id="current_class" class="form-control" readonly="" required="">
				</td>
				<td align="right">Current School Name : </td>
				<td>
				<input type="text" name="last_school" id="last_school" class="form-control" readonly="" required="">
				</td>
			</tr>
			
			
			<tr>
				<td align="right">Class to be admitted: </td>
				<td><input type="text" name="class" id="class" class="form-control" required="" readonly="">
				</td>
					<td align="right">Division : </td>
				<td><input type="text" name="division" id="division" class="form-control" required="" readonly="">
				</td>
			</tr>
			
		
			
			<tr>
				<td colspan="2" align="center">Discount Approved: &nbsp;&nbsp;&nbsp;&nbsp;
				<label><input type="radio" name="disc_approved" value="YES" checked="" required=""> Yes</label>
					&nbsp;&nbsp;&nbsp;&nbsp;
					<label><input type="radio" name="disc_approved" value="NO" required=""> No</label>
				</td>
				<td colspan="2" align="center">Admission Approved: 
				&nbsp;&nbsp;&nbsp;&nbsp;
					<label><input type="radio" name="adm_status" value="Approved" checked="" required=""> Approved</label>
					&nbsp;&nbsp;&nbsp;&nbsp;
					<label><input type="radio" name="adm_status" value="Unapproved" required=""> Unapproved</label>
				</td>
				
			</tr>
			
			<tr>
				<td align="right">Admission Status: </td>
				<td><input type="text" class="form-control" value="Interview" required="" readonly="">
				</td>
			
			<td align="right">Remark: </td>
				<td>
				<textarea name="approvalremark" class="form-control"></textarea>
				</td>
			</tr>
			
			
			
			<tr>
				<td colspan="2" align="right"><input class="btn btn-success" id="submit" type="submit" name="submit"></td>
				<td colspan="2" align="left"><input type="reset" class="btn btn-primary" value="Reset"></td>
			</tr>
			</tbody></table>
			</form>
		</div>	
		


	</div>	
	<hr>

 <script>



	</div>

<?php
include('footer.php');
?>
<script>
    $('#add-query').submit(function(event) {
	if(confirm('Confirm?' )) {
		event.preventDefault();
                $.ajax({
                        type: 'POST',
                        url: 'function/frontdeskfunctions?page=frontdesk-addmission-approval',
                        data: $(this).serialize(),
						success: function (data) {
							alert(data);
							$.notify({message: '<strong>Successfully</strong> updated the information.' },{type: 'success'});
						}
                });
	} else {
		event.preventDefault();
		return false;
	}
});
function HandlePopupResult(result) {
	data=result.split("^");
	$("#enq_no").val(data[0]);
	$("#stu_name").val(data[1]);
	$("#fat_name").val(data[2]);
	$("#mot_name").val(data[3]);
	$("#class").val(data[4]);
	$("#last_school").val(data[5]);
	$("#mobile").val(data[6]);
	$("#dob").val(data[7]);
	$("#fat_occ").val(data[8]);
	$("#location").val(data[9]);
	$("#current_class").val(data[10]);
	document.getElementById('pic').innerHTML = "<img src='pictures/enquiry/"+data[11]+"' style='width: 122px;'>";
	
	}
</script>