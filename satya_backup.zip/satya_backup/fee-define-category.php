<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') 
{
	header("Location: main.php");
}
error_reporting(0);
if(@$_REQUEST['hdnCmd']=="ADD")
{
	$type=clean($_REQUEST['type']);
	
	if(isset($type) && $type != ''){
		$data = Array (
			'fee_cat' => strtoupper($type),
			'session'=> $_SESSION['SESSION']
		);
		$db->insert ('fee_cat', $data);
		header("Location: ./fee-define-category");
	}
}
if(@$_REQUEST['action']=="del")
{
	$db->where('id', round($_REQUEST['id']));
	$db->delete('fee_cat');
	header("Location: ./fee-define-category");
}
include('header.php');
?>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row">
		<h3>Fee Category</h3>
		<center>
			<table class="table table-striped table-hover table-bordered" style="width:350px;">
				<thead>
					<tr>
						<th style="width:20px;">SR</th>
						<th style="width:150px;">Fee Category</th>
						<th style="width:1px;">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$n=1;
					$fee_type = $db->get ("fee_cat");
					if ($db->count > 0) {
						foreach ($fee_type as $u) {  ?>			
							<tr>
								<td><?php echo $n; $n++; ?></td>
								<td><?php echo $u['fee_cat']; ?></td>
								<td>
									<a href="fee-define-category?action=del&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
								</td>
							</tr>
							<?php
						}
					} ?>	
					<tr>				
						<td></td>
						<td colspan=2>
							<form action="./fee-define-category" method="post">
								<input type="text" name="type" />
								<input type="hidden" name="hdnCmd" value="ADD"><input type="submit" name="submit" class="btn-primary" value="Add Category" />
							</form>
						</td>
					</tr>	
				</tbody>
			</table>
		</center>
    </div>
</div> <!-- /container -->
<?php
include('footer.php');
?>