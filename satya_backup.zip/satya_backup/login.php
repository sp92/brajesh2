<?php 
$start = microtime(true);
include('lib/config.php'); 
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>:: ONLINE SCHOOL MANAGEMENT v2.1 :: ACCEVATE TECHONOLOGIES ::</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
		<link rel="stylesheet" href="assets/css/ladda-themeless.min.css">
		<!--[if !IE]><!-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
		<!--<![endif]-->
	
		<!--[if lte IE 8]>
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<![endif]-->
	
		<!--[if gt IE 8]>
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
		<![endif]-->
		<link rel="stylesheet" href="assets/css/custom.css">
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
    <div class="container">
      <form class="form-signin col-md-4 col-md-offset-4 col-xs-12 col-sm-6 col-sm-offset-3" role="form" id="loginForm">
        <center><img src="assets/img/rec_logo.jpg" style="width: 150px;"></center><br/>
        <input type="text" name="login" class="form-control has-error" id="user" placeholder="Username"  autocomplete="off" required autofocus  /><br/>
        <input type="password" name="password" class="form-control" id="pass" placeholder="Password" required ><br/>
        <select class="form-control" name="session">
		<?php
			$cols = Array ("session");
			$db->orderBy("session","desc");
			$session = $db->get ("session", null, $cols);
			foreach ($session as $sess) { 
			?>
		<option value="<?php echo $sess['session']; ?>"><?php echo $sess['session']; ?></option>
		<?php
			}
		?>	
		</select>
		<br>
		<div class="row">
		<div class="col-md-6 col-sm-6 col-xs-6">
		Enter Code : <img src="lib/captcha">
		</div>
		<div class="col-md-6 col-sm-6 col-xs-6">
			<input type="text" name="vercode" id="vercode"  autocomplete="off" class="form-control" required />
		</div>
		</div>
		<br>
	    <button class="btn btn-block btn-primary ladda-button kill-evo" type='submit' data-style="zoom-out"><span class="ladda-label">Sign In</span></button>
		<hr>
	 <span id="msg" style='font-weight:bold;color:red;'></span>
	 <span id="msg2" style='font-weight:bold;color:green;'></span>
      </form>
	  
    </div> <!-- /container -->  
	
	<footer class="footer">
      <div class="container">
		<div class="row">
			<div class="col-md-6">
				<p class="text-muted">&copy; Accevate Technologies <?php echo date('Y'); ?>
			</div>
			<div class="col-md-6">
				<p class="text-muted pull-right">Load Time : <?php echo round(microtime(true) - $start,3); ?> Sec
			</div>
		</div>
      </div>
    </footer>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="assets/js/spin.min.js"></script>
<script src="assets/js/ladda.min.js"></script>
<script src="assets/js/custom.js"></script>
</body>
</html>