<?php $page='certificate';
require('core.php');
error_reporting(0);
if($_SESSION['ACC_FEE']=='0') { header("Location: main"); }

if(isset($_REQUEST['hdnCmd']) && $_REQUEST['hdnCmd']=="ISSUE"){
	unset($_REQUEST['stu_name']);
	unset($_REQUEST['fat_name']);
	unset($_REQUEST['mot_name']);
	unset($_REQUEST['nationality']);
	unset($_REQUEST['category']);
	unset($_REQUEST['dob']);
	unset($_REQUEST['do_adm']);
	unset($_REQUEST['adm_class']);
	unset($_REQUEST['submit']);
	unset($_REQUEST['hdnCmd']);
	    $db->orderBy('id','DESC');
	$s_no=$db->get('transfer_certificate',1,'s_no');
	if($s_no){
		$_REQUEST['s_no']=$s_no[0]['s_no']+1;
	}else{
		$_REQUEST['s_no']=1;
	}
	
	$_REQUEST['do_apply']=datestamp($_REQUEST['do_apply']);
	$_REQUEST['date_issue']=datestamp($_REQUEST['date_issue']);
	$_REQUEST['session']=$_SESSION['SESSION'];
	$_REQUEST['issuedby']=$_SESSION['SESS_NAME'];
	$_REQUEST['cancel']='YES';
	$_REQUEST['stu_id']=$_REQUEST['id'];
	$_REQUEST['adm_no']=$_REQUEST['id'];
	unset($_REQUEST['id']);
	
	
	$db->insert('transfer_certificate',$_REQUEST);
	
	$data=array(
	   'tc_issue'=>'YES'
	);
	$db->where('adm_no',$_REQUEST['id']);
	$db->update('student',$data);
	
	header("Location: ./certificate-transfer");
	
}







include('header.php');
?>

<div class="container">        <br>

    <div class="row">
       	
		<div class="col-md-12">
			<h3 class="glyphicons adress_book"><i></i> Enter Admission No.:</h3>
		</div>
		
		<div class="col-md-3">
			<form method="get" action="certificate-transfer" id="form1" role="form">
				<input type="text" name="adm_no" class="form-control" style="background-color: beige;">
		</form></div>	

		<div class="col-md-3">
				<button type="submit" class="btn btn-success" onclick="$('#form1').submit();">Submit</button>
			
		</div>	
	</div>	
	<hr>		

	
	
    <div id="txtHint1"></div>
<?php 
if(isset($_REQUEST['adm_no'])){
	$db->where('adm_no',$_REQUEST['adm_no']);
	$check=$db->get('transfer_certificate');
	if($db->count!=1){
		
	$db->join("stu_sess_data s", "s.adm_no=ss.adm_no", "LEFT");
	$db->where('ss.adm_no',$_REQUEST['adm_no']);
	$user=$db->get('student ss',null,'ss.*,s.type,s.fee_cat');
	
	if($db->count>0){
?>	
    <form method="post" action="certificate-transfer">
<input type="hidden" name="hdnCmd" value="ISSUE">
<input type="hidden" name="id" value="<?php echo $_REQUEST['adm_no'];?>">


<table class="table" style="font-size:12px;">
    
    <tr>
	<td colspan=4>
	
	Registration No. of the Candidate (in case Class IX to XII): <input type="text" name="reg_no_stu" value="" style="width: 200px;" />
	</td>
	</tr>
	
	
  </table>


  <br/>
  
  <table class="table" style="font-size:12px;">
    <tr>
		<td>1.</td>
		<td>Name of the Student:</td>
		<td><input type="text" name="stu_name" value="<?php echo $user[0]['stu_name'];?>" style="width: 100%;" /></td>
    </tr>
    
    <tr>
      <td>2.</td>
      <td>Mother's Name:</td>
      <td><input type="text" name="mot_name" value="<?php echo $user[0]['mot_name'];?>" style="width: 100%;" /></td>
    </tr>
    
	<tr>
      <td>3.</td>
      <td>Father's / Guardian's Name:</td>
      <td><input type="text" name="fat_name" value="<?php echo $user[0]['fat_name'];?>" style="width: 100%;" /></td>
    </tr>
	
	<tr>
      <td>4.</td>
      <td>Nationality:</td>
      <td><input type="text" name="nationality" value="<?php echo $user[0]['nationality'];?>" style="width: 100%;" /></td>
    </tr>
	
	<tr>
      <td>5.</td>
      <td style="width:550px;">Whether the pupil belongs to SC/ST/OBC category:</td>
      <td><input type="text" name="category" value="<?php echo $user[0]['fee_cat'];?>" style="width: 100%;"  /></td>
    </tr>
	
	
	<tr>
      <td>6.</td>
      <td style="width:550px;">Date of Birth according to the Admission Register (In figure)</td>
      <td><input type="text" name="dob" data-date-format="dd/mm/yyyy"  class="input_date" value="<?php echo getdmYFormat($user[0]['dob']);?>" style="width: 100%;" readonly  />
            </td>
    </tr>
	
	
    <tr>
      <td>7.</td>
      <td>Date of first admission in the school with class:</td>
      <td>
	  <input type="text" name="do_adm" data-date-format="dd/mm/yyyy"  class="input_date" value="<?php echo getdmYFormat($user[0]['do_adm']);?>" readonly />
            <input type="text" name="adm_class" value="<?php echo $user[0]['class'];?>" />
	  </td>
    </tr>
	
    <tr>
      <td>8.</td>
      <td>Whether the student is failed?:</td>
      <td><input type="text" name="student_failed" value="" style="width: 100%;"  /></td>
    </tr>
    
    <tr>
      <td>9.</td>
      <td>Subjects offered:</td>
      <td><input type="text" name="sub_offer" value="" style="width: 100%;"  /></td>
    </tr>
    
    <tr>
      <td>10.</td>
      <td>Class in which the pupil last studies (in words):</td>
      <td><input type="text" name="last_class" style="width: 100%;" value="" /></td>
    </tr>
    
    <tr>
      <td>11.</td>
      <td>School/Board Examination last taken with result:</td>
      <td><input type="text" name="school_exam_last_taken"  value="" style="width: 100%;"  /></td>
    </tr>
    
	
    <tr>
      <td>12.</td>
      <td>Whether qualified for promotion to the next higher class:</td>
      <td><input type="text" name="qualified_promotion" value="" style="width: 100%;"  /></td>
    </tr>
    
    <tr>
      <td>13.</td>
      <td>Whether the pupil has paid all dues to the school:</td>
      <td><input type="text" name="paid_all_dues" value="" style="width: 100%;"  /></td>
    </tr>
    
	
    <tr>
      <td>14.</td>
      <td>Whether the pupil was in receipt of any fee concession, if so the nature of such concession:</td>
      <td><input type="text" name="concession" value="" style="width: 100%;"  /></td>
    </tr>
    
	
    <tr>
      <td>15.</td>
      <td>Whether the pupil is NCC Cadet/BoyScout/Girl Guide (give details):</td>
      <td><input type="text" name="ncc" value="" style="width: 100%;"  /></td>
    </tr>
    
    <tr>
      <td>16.</td>
      <td>Date on which pupils name was struck off the rolls of the school:</td>
      <td><input type="text" name="name_struck_off" value="" style="width: 100%;"  /></td>
    </tr>
    
    <tr>
      <td>17.</td>
      <td>Games played or extra curricular activities in which the pupil usually took part (mention achievement level):</td>
      <td><input type="text" name="game_played" value="" style="width: 100%;"  /></td>
    </tr>
    
	
    <tr>
      <td>18.</td>
      <td>Reason for leaving the school:</td>
      <td><input type="text" name="reason" value="" style="width: 100%;"  /></td>
    </tr>
    
    <tr>
      <td>19.</td>
      <td>Total No. of Working Days:</td>
      <td><input type="text" name="no_meeting" value="" style="width: 100%;"  /></td>
    </tr>
    
    <tr>
      <td>20.</td>
      <td>Total days student attended the school:</td>
      <td><input type="text" name="attendance" value="" style="width: 100%;"  /></td>
    </tr>
    
    <tr>
      <td>21.</td>
      <td>General conduct:</td>
      <td><input type="text" name="general_conduct" value="" style="width: 100%;"  /></td>
    </tr>
    
	
    <tr>
      <td>22.</td>
      <td>Any other remarks:</td>
      <td><input type="text" name="remark" value="" style="width: 100%;"  /></td>
    </tr>
    
	
    <tr>
      <td>23.</td>
      <td>Date of Application of certificate:</td>
      <td><input type="text" name="do_apply" data-date-format="dd/mm/yyyy"  class="input_date datepicker2" value="" style="width: 100%;"  /></td>
    </tr>
    
	
    <tr>
      <td>24.</td>
      <td>Date of issue of certificate:</td>
      <td><input type="text" name="date_issue" data-date-format="dd/mm/yyyy"  class="input_date datepicker2" value="" style="width: 100%;"  /></td>
    </tr>
  
 
	
	<tr>
	<td colspan="3">
	<center>
	<input type="submit" name="submit" value="Issue Transfer Certificate" /> &nbsp;&nbsp;&nbsp;&nbsp;
	<a href="#" onclick="return windowpop('view-tc.php?id=', 545, 433)">View / Print</a>
	</center>
	</td>
	</tr>
	
  </table>
</form> 
<?php }
	}else{
	$db->join("stu_sess_data s", "s.adm_no=ss.adm_no", "LEFT");
	$db->where('ss.adm_no',$_REQUEST['adm_no']);
	$user=$db->get('student ss',null,'ss.*,s.class as cl,s.sec as se');
		?>
		
		<table class="table table-bordered">
<thead>
<tr>
<th><strong>SR</strong></th>
<th><strong>Status</strong></th>
<th><strong>Admission No.</strong></th>
<th><strong>Student Name</strong></th>
<th><strong>Parent's Name</strong></th>
<th><strong>Class</strong></th>
<th><strong>Section</strong></th>
<th style="width: 65px;"><strong>Option</strong></th>
</tr></thead><tbody><tr>
<td align="center" bgcolor="#FFFFFF">1</td>
<td align="center" bgcolor="#FFFFFF"><span class="label label-danger">TC ISSUED</span></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $_REQUEST['adm_no']?></td>
<td align="center"><a href="fee?adm_no=2425" class="stu_name_hover_details" alt="2425"><?php echo $user[0]['stu_name'];?></a></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $user[0]['fat_name'];?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $user[0]['cl'];?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $user[0]['se'];?></td>
<td><a onclick="get_tc(<?php echo $_REQUEST['adm_no'];?>)" style="cursor:pointer;">[View / Print]</a></td>
</tr></tbody></table>
		<?php
	}

} ?>
      </div>
	  <script>
function get_tc(id) {

payfee = $.popupWindow('certificate-view-tc?adm_no='+id,{height:600,width:900});

}
</script>
<?php
include('footer.php');
?>