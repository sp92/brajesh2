<?php
$page='master';
require('core.php');
if($_SESSION['ACC_MASTER']=='0') 
{
	header("Location: main.php");
}
if(@$_REQUEST['hdnCmd']=="ADD")
	{
	$stream=clean($_REQUEST['stream']);
	
	$data = Array (
		'stream' => $stream
	);
	if($stream!=''){
	$db->insert ('stream', $data);
	}else{
	header("Location: ./master-stream");
	}
	}
if(@$_REQUEST['action']=="del")
	{
	$db->where('id', round($_REQUEST['id']));
	$db->delete('stream');
	header("Location: ./master-stream");
	}
include('header.php');
?>
<div class="container">

<div class="row">
<div class="col-md-2">
<?php print_menu($master_menu_items); ?>
</div>
<div class="col-md-10">
<h3>Stream Master</h3>
<center>
<table class="table table-striped table-hover table-bordered" style="width:350px;">
<thead>
<tr>
<th style="width:20px;">SR</th>
<th style="width:150px;">Stream</th>
<th style="width:1px;">Update</th>
</tr>
</thead>
<tbody>
				
			<?php
				$n=1;
					$user = $db->get ("stream");
					if ($db->count > 0) {
						foreach ($user as $u) { 
							
					?>			
<tr>
<td><?php echo $n; $n++; ?></td>
<td><?php echo $u['stream']; ?></td>
<td><a href="master-stream?action=del&id=<?php echo $u['id']; ?>" onClick="return confirm('Are you want to sure Delete Information');" class="btn btn-default btn-xs " role="button"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a></td>
</tr>
		  <?php
				}
					}
		?>	
<tr>				
<td></td>
<td colspan=2><form action="./master-stream" method="post"><input type="text" name="stream" required/>
<input type="hidden" name="hdnCmd" value="ADD"><input type="submit" name="submit" class="btn-primary" value="Add Stream" /></form>
</td>
</tr>				
</table>
</center>
</div>

    </div>
    </div> <!-- /container -->
<?php
include('footer.php');
?>