<?php $page='certificate';
require('core.php');
error_reporting(E_ALL);
if($_SESSION['ACC_FEE']=='0') { header("Location: main"); }

if(isset($_REQUEST['hdnCmd']) && $_REQUEST['hdnCmd']=="EDIT"){
	
    $data=array(
	  'class'=>$_REQUEST['class'],
	  'session'=>$_REQUEST['session'],
	  'nature'=>$_REQUEST['nature'],
	  'date_issue'=>datestamp($_REQUEST['date_issue']),
	);
	$db->where('id',$_REQUEST['update_id']);
	$db->update('charactor_certificate',$data);
	header("Location: ./certificate-charactor");
	
}
include('header.php');
?>
<div class="container">  
<div class="row">
<h3>Issue Character Certificate</h3>
<form method="post" action="certificate-charactor-edit">

<input type="hidden" name="hdnCmd" value="EDIT">
<input type="hidden" name="update_id" value="<?php echo $_REQUEST['id'];?>">

<table class="table">
<?php 
    $db->join("student ss", "ss.adm_no=cc.stu_id", "LEFT");
	$db->where('cc.id',$_REQUEST['id']);
	$user=$db->get('charactor_certificate cc',null,'cc.*,ss.stu_name,ss.fat_name,ss.gender');
	
?>
    

    <tbody><tr>


	  <td>

          Admission No.: <input type="text" name="adm_no" value="<?php echo $user[0]['stu_id']?>" style="width: 50%;" readonly="">

      </td>

    </tr>

    

  </tbody></table>

  <br>

  <table class="table">

    <tbody><tr>

		<td>1.</td>

		<td>Name of the Pupil:</td>

		<td><input type="text" name="stu_name" value="<?php echo $user[0]['stu_name']?>" readonly style="width: 100%;"></td>

    </tr>

    

    <tr>

      <td>2.</td>

      <td>Father's Name:</td>

      <td><input type="text" name="fat_name" readonly value="<?php echo $user[0]['fat_name']?>" style="width: 100%;"></td>

    </tr>

    

    <tr>

      <td>3.</td>

      <td>Class:</td>

      <td>

	  <select name="class">

<option value="">--</option>
<?php $class_sess=$db->get('class_master');
	    foreach($class_sess as $class){
	 ?>
	      <option <?php echo ($class['class']==$user[0]['class']) ? 'selected' : '';?> value="<?php echo $class['class'];?>"><?php echo $class['class'];?></option>
		<?php } ?>
</select>

	  

	  </td>

    </tr>

    

    <tr>

      <td>4.</td>

      <td>For Session:</td>

      <td><select name="session">
     <?php $session=$db->get('session');
	    foreach($session as $sess){
	 ?>
	      <option value="<?php echo $sess['session'];?>"><?php echo $sess['session'];?></option>
		<?php } ?>
	 </select>

	  

	  </td>

    </tr>

    

	<tr>

      <td>5.</td>

      <td>Nature of Candidate:</td>

      <td><input type="text" name="nature" value="Good" style="width: 100%;"></td>

    </tr>

	

    <tr>

      <td>6.</td>

      <td>Date of Issue:</td>

      <td><input type="text" name="date_issue" value="<?php echo date('d-m-Y')?>" class="datepicker2" style="width: 100%;" readonly=""></td>

    </tr>

	

	<tr>

	<td colspan="3">

	<center>

		<input class="btn" onclick="this.disabled=true;this.value='Submitting, Please Wait...';this.form.submit();" type="submit" value="UPDATE"> &nbsp;&nbsp;&nbsp;&nbsp;

	</center>

	</td>

	</tr>

</tbody></table>

<span class="label" style="color:red; font-size:11px;">* Note: Class is here for reference only. To change this information, please close this window and then change the information in the student profile.</span>

  

  

  

</form> 

</div>
</div>
<?php
include('footer.php');
?>