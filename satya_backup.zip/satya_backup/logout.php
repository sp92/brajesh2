<?php
include('lib/config.php'); 
 session_name("accevate_erp");
 session_start();

include('lib/auth.php'); 

if($_SESSION['ACC_GROUP']<>'admin' AND $_SESSION['ACC_GROUP']<>'root') {
	$data = Array (
		'is_log' => 'FALSE'
	);
	$db->where ('id', $id);
	$db->update ('admin', $data);
}

 unset($_SESSION['SESS_ID']);
 unset($_SESSION['SESS_NAME']);
 unset($_SESSION['ACC_MASTER']);
 unset($_SESSION['ACC_STUDENT']);
 unset($_SESSION['ACC_FEE']);
 unset($_SESSION['ACC_ADMISSION']);
 unset($_SESSION['ACC_TRANSPORT']);
 unset($_SESSION['ACC_CERTIFICATE']);
 unset($_SESSION['ACC_SETTING']);
 unset($_SESSION['ACC_GROUP']);
 unset($_SESSION['LOCATION']);
 unset($_SESSION['SESSION']);
 unset($_SESSION['REC_DATE']);
 session_destroy();
header("location: login");
?>