<?php 
include('core.php');

$fields = $_REQUEST['fields'];
$fields_arr = explode(',', $fields);

$class_stu = $db->get('stu_custom_data'); 
$field_info=array();
foreach($class_stu as $fecth) {
	$key = $fecth['field'];
	$field_info[$key] = $fecth['name']."^".$fecth['type'];
}
foreach($fields_arr as $field) {
	$header[] = $field_info[$field];
	$header_print[] = $field_info[$field];
}

foreach($header_print as $h) {
	$aaa = explode("^", $h);
	$h_print[] = $aaa[0];
}



if($_REQUEST['new_old']<>'') { $myArr[]="'t1.new_old', '".$_REQUEST['new_old']."'"; } 

if(isset($_REQUEST['class']) && $_REQUEST['class']<>'') { $class_arr = $_REQUEST['class']; } 
else {  $cols=array("class"); $class_stu = $db->get('class_master',null,$cols); foreach($class_stu as $class2)	 { $class_arr[] = $class2['class']; }} 


if(isset($_REQUEST['sec']) && $_REQUEST['sec']<>'') { $sec_arr = $_REQUEST['sec']; } 
else { $cols=array("section"); $section_q = $db->get('sec_master',null,$cols); foreach($section_q as $section2)	 { $sec_arr[] = $section2['section']; }}



if($_REQUEST['gender']<>'') { $where_clause[] = " gender = '".$_REQUEST['gender']."' "; } 
$show_age = false;
if(isset($_REQUEST['ageon']) AND $_REQUEST['ageon']<>'') { $d2 = datestamp($_REQUEST['ageon']); $show_age = true; }


                            
							
							$db->join("stu_sess_data sd", "t1.id=sd.stu_id", "LEFT");
							if($_REQUEST['new_old']!="") { $db->where ('t1.new_old', $_REQUEST['new_old']); } 
							if($_REQUEST['stu_type']=='regular') {$db->where ('t1.is_shown', 'YES');  }
							if($_REQUEST['gender']!="") { $db->where ('t1.gender', $_REQUEST['gender']); } 
							if($_REQUEST['stu_type']=='nso') {  
                              $db->where ('t1.is_shown', 'NO');
							  $db->where ('t1.tc_issue', 'YES');
							 }
							 
							 if($_REQUEST['stu_type']=='tc') { $db->where ('t1.tc_issue', 'YES'); }
							
							if($_REQUEST['fee_cat']!="") {
								$db->where('t1.fee_cat', $_REQUEST['fee_cat'], 'IN');
							}
							if($_REQUEST['category']!=""){
								$db->where('t1.category', $_REQUEST['category'], 'IN');
							}
							if($_REQUEST['religion']!=""){
								$db->where('t1.religion', $_REQUEST['religion'], 'IN');
							}
							if(isset($_REQUEST['adm_from']) AND $_REQUEST['adm_from']<>'' and isset($_REQUEST['adm_to']) AND $_REQUEST['adm_to']<>'') { 
							$to="'".datestamp($_REQUEST['adm_from'])."'";
							$from="'".datestamp($_REQUEST['adm_to'])."'";
							$db->where('do_adm', Array ($to, $from), 'BETWEEN');

							}
                             if($_REQUEST['class']!=""){$db->where('sd.class', $class_arr, 'IN');}
							 if($_REQUEST['sec']!=""){$db->where('sd.sec',$sec_arr, 'IN'); }
							$db->where('t1.session',$_SESSION['SESSION']); 
							$db->orderBy('t1.'.$_REQUEST['order'], 'asc'); 
							$user = $db->get("student t1", null, $fields_arr); 
							
							
							
if($_REQUEST['rpt_type']=='export') {
	@header("Last-Modified: " . @gmdate("D, d M Y H:i:s",$_GET['timestamp']) . " GMT");
	@header("Content-type: text/x-csv");
	 //If the file is NOT requested via AJAX, force-download
	if(!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
	   header("Content-Disposition: attachment; filename=search_results.csv");
	}
	echo "not working";
}
 
if($_REQUEST['rpt_type']=='display') {
echo "<button onclick='print_pdf();' class='btn-primary' style='float:right;padding: 2px;margin-top:-30px;'>PDF Report</button>";
echo "<input type='button' class='btn-danger' onclick=\"tableToExcel('testTable', 'Student')\" value='Excel' style='float:right;margin-top:-30px;margin-right:80px;' />";
ob_start();
echo "<table id='testTable' class='table table-striped' style='font-size:11px;'><thead><tr>";
foreach ($h_print as $head_name) {
	echo "<th>".$head_name."</th>";
}
if($show_age==true) {
	echo "<th>Age on ".$_REQUEST['ageon']."</th>";
}
echo "</tr></thead><tbody>";

$count = count($h_print);
if($show_age==true) { $count++; }
$n=0;
$gt=0;
foreach($user as $data){
echo "<tr>";
				foreach($fields_arr as $field) {
					if($field == 'dob' or $field == 'do_adm') {
						echo "<td align=center>";
						$dddddd = date('d/M/Y', strtotime($data[$field])); if($dddddd <> '01/Jan/1970') {  echo $dddddd; }
						echo "</td>";
					} else if($field == 'nso_date') {
						echo "<td align=center>";
						$dddddd = date('d/M/Y', strtotime($data[$field])); if($dddddd <> '01/Jan/1970') {  echo $dddddd; }
						echo "</td>";
					} else {
						echo "<td align=center>".$data[$field]."</td>";
					}
				}
				if($show_age==true) {
					echo "<td align=center>".get_age($data['dob'], $d2)."</td>";
				}
				echo "</tr>";
				$n=0;
				
}
if(isset($_REQUEST['group_sec']) and $_REQUEST['group_sec']=='on') {
				echo "<tr><td colspan='".$count."' align=center><b>Total students : ".count($user)."</td></tr>";
				echo "<tr><td colspan='".$count."'>`</td></tr>";
			}
echo "</tbody><tfoot><tr><th colspan='".$count."'>Total students : ".count($user)."</td></tr></tfoot></table>";



$xml2 = ob_get_contents();
$xml = str_replace('"','',$xml2);
$output = str_replace(array("\r\n", "\r"), "\n", $xml);
$lines = explode("\n", $output);
$new_lines = array();

foreach ($lines as $i => $line) {
    if(!empty($line))
        $new_lines[] = trim($line);
}
?>
<form name="sampleform" method="POST" action="get_pdf" onsubmit="return createTarget(this.target)" target="formtarget">
<input type="hidden" name="data" value="<center><?php echo implode($new_lines); ?></center>" />
<input type="hidden" name="orientation" value="<?php echo $_REQUEST['layout']; ?>" />
<input type="hidden" name="type" value="<?php echo $_REQUEST['rpt_name']; ?>" />
<input type="hidden" name="session" value="<?php echo $_SESSION['SESSION']; ?>" />
</form>
<?php
}
exit();
?>