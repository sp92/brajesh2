<?php
$page='transport';
require('core.php');
if($_SESSION['ACC_STUDENT']=='0') {
	header("Location: main.php");
}
include('header.php');

?>
<div class="container">
<div class="row">
<h3>Route / Stoppage Wise List</h3>
<script type="text/javascript">
var tableToExcel = (function() {
  var uri = 'data:application/vnd.ms-excel;base64,'
    , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
    , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
    , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
  return function(table, name) {
    if (!table.nodeType) table = document.getElementById(table)
    var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
    window.location.href = uri + base64(format(template, ctx))
  }
})()
</script>
<script>
pramukhIME.addLanguage(PramukhIndic,"hindi"); 
pramukhIME.enable();
</script>
<div>
<form id="form1" name="form1" method="get" action="transport-report-route">

<label>Stoppage : </label>
<select name="stop" id="stop">
<option value="">--Select Stop--</option>
<?php $stop=$db->get('stop_master');
foreach($stop as $data){
?>
<option <?php echo ($data['id']==$_REQUEST['stop']) ? 'selected' : '';?> value="<?php echo $data['id']?>"><?php echo $data['stop']?></option>
<?php } ?>
</select>
<label>Order By</label>
<select name="order">
<option <?php echo ($_REQUEST['order']=="adm_no") ? 'selected' : '';?> value="adm_no">Admission No.</option>
<option <?php echo ($_REQUEST['order']=="stu_name") ? 'selected' : '';?> value="stu_name">Student Name</option>
</select>
<input type="submit" name="button" id="button" onclick="document.form1.submit();" value="Submit">
<input type="button" onclick="tableToExcel('testTable', 'Student')" value="Export to Excel" style="float:right;margin-right: 28px;">
<input type="text" id="searchTerm" class="search_box" onkeyup="doSearch()" style="float:right;padding: 2px;" placeholder="Search Here.....">
</form>



</div>


Please select Route From The Drop down menu.

<table id="testTable" class="table" style="padding: 0px;">
<thead class="tableFloatingHeaderOriginal">
<tr>
<th align="center"><strong>SR</strong></th>
<th align="center"><strong>Bus No.</strong></th>
<th align="center"><strong>Adm No.</strong></th>
<th align="center"><strong>Student Name</strong></th>
<th align="center"><strong>Status</strong></th>

<th align="center"><strong>Father Name</strong></th>
<th align="center"><strong>Class</strong></th>
<th align="center"><strong>section</strong></th>
<th align="center"><strong>Address</strong></th>
<th align="center"><strong>Stoppage</strong></th>
<th align="center"><strong>Route</strong></th>
</tr>
</thead>
<tbody>
<tbody>
<?php 

$db->join("vehicle_master v", "v.id=s.bus_id", "LEFT");
$db->join("student st", "st.id=s.stu_id", "LEFT");
$db->join("stop_master stm", "stm.id=s.stop_id", "LEFT");
$db->where('stm.id',$_REQUEST['stop']);
$db->orderBy('st.'.$_REQUEST['order'],'asc');
$report=$db->get('stu_sess_data s',null,'v.bus_no,s.adm_no,st.stu_name,st.fat_name,st.address,s.class,s.sec,s.is_transport,stm.stop');
$x=0;
if($report){
foreach($report as $rep){$x++;
?>
    <tr align="center">
	   <td><?php echo $x;?></td>
	   <td><?php echo $rep['bus_no'];?></td>
	   <td><?php echo $rep['adm_no'];?></td>
	   <td><?php echo $rep['stu_name'];?></td>
	   <td><?php echo $rep['is_transport'];?></td>
	   <td><?php echo $rep['fat_name'];?></td>
	   <td><?php echo $rep['class'];?></td>
	   <td><?php echo $rep['sec'];?></td>
	   <td><?php echo $rep['address'];?></td>
	   <td><?php echo $rep['stop'];?></td>
	   <td></td>
	   
	</tr>
<?php }}else{
	echo "<td colspan='10' align=center><strong> No Data Found !!!</td>";
}?>
</tbody>
</table>
     </div>
	 </div>
<?php
include('footer.php');
?>     