<?php
$page='fee';
require('core.php');
error_reporting(0);
if($_SESSION['ACC_FEE']=='0') { header("Location: main.php"); }
if(isset($_REQUEST['submit-button'])){
     if($_REQUEST['fee_option']!=2){
		 $status=$_REQUEST['fee_option'];
	 }
	 $start=datestamp($_REQUEST['from_date']);
	 $end=datestamp($_REQUEST['to_date']);
}

include('header.php');
?>
<div class="container">
	<?php print_menu($fee_menu_items); ?>
	<div class="row">
		<h3>Cash Discount Approval</h3>
		<div class="col-md-12">
		<form method="GET" >
		<table style="font-size: 14px;width:100%;">
				<tbody><tr>
					<td style="border-bottom: none!important;"> From : 
						<input name="from_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST['from_date'];?>" class="datepicker" style="width: 100px;" readonly="" autocomplete="off">  
					</td>
					<td style="border-bottom: none!important;">To : 
						<input name="to_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST['to_date'];?>" class="datepicker" style="width: 100px;" readonly="" autocomplete="off"> 
					</td>
					<td style="border-bottom: none!important;">Approval Status : 
						<select name="fee_option">
							<option value="2" <?php echo ($_REQUEST['fee_option']==2) ? 'selected' : '';?> >ALL </option>
							<option value="1" <?php echo ($_REQUEST['fee_option']==1) ? 'selected' : '';?>>Approved</option>
							<option value="0" <?php echo ($_REQUEST['fee_option']==0 &&$_REQUEST['fee_option']!="") ? 'selected' : '';?>>Pending</option>
							
						</select>
					</td>
					<?php echo $_REQUEST['fee_option'];?>
					<td style="border-bottom: none!important;">
						<input type="submit" name="submit-button" value="Filter Discount" autocomplete="off">
					</td>
				</tr>
			</tbody></table>
			</form>
			<br><hr>
	<div id="show-filter">		
	<table class = "table">
   
   
   <thead>
      <tr>
         <th>Name</th>
         <th>Father Name</th>
         <th>Discount amount</th>
		 <th>Remarks</th>
		 <th>Requested By</th>
		 <th>Requested Date</th>
		 <th>Approved Amount</th>
		  <th>Approved Remark</th>
		 <th>Approved by</th>
		 <th>Approved Date</th>
		 <th>Action</th>
      </tr>
   </thead>
   
   <tbody>
    <?php 
	   $db->join("student st", "st.id=dis.stu_id", "LEFT");
	   if(isset($_REQUEST['submit-button'])){
	      if($_REQUEST['fee_option']!=2){
			$db->where('dis.approved',$_REQUEST['fee_option']);
		      }
	   $db->where('dis.p_date', Array ($start, $end), 'BETWEEN');
	   }
	   $stu_info = $db->get ("cash_discount_master dis", null, "st.stu_name, st.fat_name,dis.*");
	   $ind=0;
	   foreach($stu_info as $info){
		   
		   ?>
	   
      <tr >
         <td><?php echo $info['stu_name'];?></td>
         <td><?php echo $info['fat_name'];?></td>
         <td>Rs. <?php echo $info['p_amount'];?></td>
		 <td><?php echo $info['remark'];?></td>
         <td><?php echo $info['p_by'];?></td>
         <td><?php 
		 echo  getdmYFormat($info['p_date']);
		   ?></td>
		 <td> <?php if(acl_check('approve_cash_discounts', $_SESSION['SESS_ID']) != false) {  ?>
		 <input type="text" name="approved_amount" class="approved-amount" value="<?php echo $info['approved_amount'];?>">
		 <?php }else{
			  echo $info['approved_amount'];
		 }?></td>
		  <td><?php if(acl_check('approve_cash_discounts', $_SESSION['SESS_ID']) != false) {  ?>
		  <textarea name="approved_remark" rows="1" cols="16" class="approved-remark"><?php echo $info['approved_remark'];?></textarea></td>
		  <?php }else{
			  echo $info['approved_remark'];
		  }?>
         <td><input type="hidden" name="approved_by" class="approved-by" value="<?php echo $_SESSION['SESS_NAME']; ?>"><?php echo ($info['approved']) ? $_SESSION['SESS_NAME'] : ''; ?></td>
         <td><?php 
		     
          echo  getdmYFormat($info['approved_date']);
		   ?></td>
		 <td>
		 <?php if(acl_check('approve_cash_discounts', $_SESSION['SESS_ID']) != false) {  ?>
                      <?php if($info['approved']){ echo 'Approved';}else{?><button onclick="approved_discount(<?php echo $ind.",".$info['id'];?>)">Approve</button><?php }?>
					  <?php }else{if($info['approved']){ echo 'Approved';}else{ echo 'Pending';}} ?>
		 
		 </td>
      </tr>
	   <?php $ind++;} ?>
      
      
   </tbody>
   
</table></div>
		</div>
		
		
    </div>
    </div>
	
<script>
function approved_discount(ind,id){
	approved_amount=$(".approved-amount").eq(ind).val();
	approved_remark=$(".approved-remark").eq(ind).val();
	approved_by=$(".approved-by").eq(ind).val();
	 $.ajax({
					type: 'POST',
					url: './function/feeamountfunctions?query=ApprovedDiscountForm',
					data: "approved_amount="+approved_amount+"&approved_remark="+approved_remark+"&approved_by="+approved_by+"&update_id="+id,
					success: function (data) {
						alert("Request has been Approved By Admin");
					}
				});
	
}

</script>
 
<?php
include('footer.php');
?>