<?php
$page='system';
require('core.php');
if($_SESSION['ACC_GROUP']<>'root') 
{
	header("Location: main.php");
}

if ($_FILES['csv']['size'] > 0) { 

    $file = $_FILES['csv']['tmp_name']; 
	$users = $db->rawQuery('SHOW COLUMNS FROM '.$prefix.'student');
	foreach ($users as $user) {
		$fieldnames[] = $user['Field'];
	}
	if(isset($_REQUEST['empty']) && $_REQUEST['empty']=='TRUE') {
		$db->rawQuery('TRUNCATE TABLE '.$prefix.'student');
	}
	
	$handle = fopen($file, "r");
	$i=0;
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        if($i>0) {
			$n=0;
			foreach($fieldnames as $f) {
				$data2[$f] = clean($data[$n]);
				$n++;
			}
			$db->insert ('student', $data2);
		}
        $i++;
    }
    fclose($handle);
	header('Location: system-student-import?success=1'); die; 
} 
include('header.php');
?>
<div class="container">
<?php print_menu($settings_menu_items); ?>
<div class="row">
<h3>Import Students Data</h3>
<br>
<h4>Current Student Count (Including NSO, TCs, etc) : <b><span class="text-danger"><?php $cnt = $db->getValue ("student", "count(adm_no)"); echo $cnt; ?></span></b></h4>

<p class="text-muted">Double check the student data before importing into the database. You can also create the backup of the data <a href="#">here</a>.</p>
<hr>

<h4><a href="export/export-csv-student-format">Download CSV Format For Import</a></h4>
<p class="text-muted"></p>
<hr>


<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
  <div class="form-group">
    <h4 for="exampleInputFile">Select CSV File :</h4>
    <input name="csv" type="file" id="csv" accept=".csv" required /> 
    <p class="help-block">Only upload the downloaded format from above. <span class="text-danger">CSV FILE FORMAT IS ALLOWED</span>.<br>
	Allowed Format for dates : <span class="text-danger">yyyy-mm-dd</span><br>
	<!--While importing student data, make sure to <span class="text-danger">DELETE the header (fieldnames) column</span>.-->
	</p>
  </div>
  <div class="checkbox">
    <label>
      <input type="checkbox" name="empty" value="TRUE"> Empty Student Table
    </label>
  </div>
  <button type="submit" class="btn btn-primary ladda-button kill" data-style="zoom-out">Upload CSV</button>
</form>
<?php if(isset($_REQUEST['success'])) { ?>
<hr>
<h4 class="text-success">Import was successful.</h4>
<?php } ?>


</div>
</div> <!-- /container -->
<?php
include('footer.php');
?>