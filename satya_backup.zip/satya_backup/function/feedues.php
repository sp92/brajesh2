<?php 

function getLateFine($month_arr) {
	$late_fine = 50;
	foreach($month_arr as $month) {
		$charge[]=50;
	}
	return array_sum($charge);
}
function getDiscountApproval($id){
	global $db;
	$db->where('stu_id',$id);
	$db->where('approved','1');
	$db->where('used','0');
	$approved_amt=$db->get('cash_discount_master',null,'id,approved_amount,approved_remark');
	return $approved_amt;
}
function getCurrentDue($id,$curr_month){
	global $db;
	global $m_array;
	global $mf_array;

	$offsetKey = array_search ($curr_month, $m_array);
	
	$n=array_keys($m_array); //<---- Grab all the keys of your actual array and put in another array
	$count=array_search($offsetKey,$n); //<--- Returns the position of the offset from this array using search
	$new_arr=array_slice($m_array,0,$count+1,true);//<--- Slice it with the 0 index as start and position+1 as the length parameter.
	$new_arr2=array_slice($mf_array,0,$count+1,true);//<--- Slice it with the 0 index as start and position+1 as the length parameter.
	unset($m_array);
	unset($mf_array);
	$m_array = $new_arr;
	$mf_array = $new_arr2;
	
	$db->join("stu_sess_data sc", "s.id = sc.stu_id", "LEFT");
$db->where ('s.id', $id);
$db->where ('sc.session', $_SESSION["SESSION"]);
$data_stu = $db->getOne("student s");

if($data_stu['is_transport'] == 'YES') {
	$db->join("stop_master r", "s.stop_id=r.id", "LEFT");
	$db->where ('s.session', $_SESSION['SESSION']);
	$db->where ("s.stu_id",$id);
	$stop_add=$db->get('stu_sess_data s',null,'r.stop,r.amount,month(s.start_date) month');
	
	$data['stop_name']=$stop_add[0]['stop'];
	$data['stop_amount']=$stop_add[0]['amount'];
	$data['start_month']=$stop_add[0]['month'];
	
}

if($data_stu['custom_fee'] == 'YES') {
	$db->where ('session', $_SESSION['SESSION']);
	$db->where ('stu_id', $id);
	$fee_stu = $db->getOne ("stu_custom_fee");
} else {
	$db->where ('session', $_SESSION['SESSION']);
	$db->where ('class', $data_stu['class']);
	$db->where ('new_old', $data_stu['new_old']);
	$db->where ('fee_cat', $data_stu['fee_cat']);
	$db->where ('type', $data_stu['type']);
	$fee_stu = $db->getOne ("fee_amount");	
}

$headCount = 0;
$query = '';
$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
if(!empty($head_defineSession)){
	foreach($head_defineSession as $key=>$value){
		//echo $value['Field'];
		if (strpos($value['Field'], 'head') !== false) {
			$query =  $query.'sum('.$value['Field'].') as h'.($headCount+1).', ';
			$headCount++;
		}
	}
}	
	
foreach($m_array as $m) { 
	for($i=1; $i<=$headCount; $i++) {
		$month = "head".$i."_".$m;
		$t_fee[] = $fee_stu[$month];
	}
	$total_fee[] = array_sum($t_fee);
	unset($t_fee);
}

foreach($m_array as $m) { 
	$month = "tp_".$m;
	$t_fee = $tpt_stu[$month];
	$total_tp[] = $t_fee;
	unset($t_fee);
}	

$query = $query." sum(transport) as tp";
foreach($mf_array as $m) {
	$tota = 0;
	$db->where ('session', $_SESSION['SESSION']);
	$db->where ('stu_id', $id);
	$db->where ('cancelled', '0');
	$db->where ('month', $m);
	$fee_paid = $db->getOne ("fee_paid", $query);
	for($i=0;$i<=$headCount;$i++){
		$tota = $tota+$fee_paid['h'.($i+1)];
	}
	$tota = $tota+$fee_paid['tp'];
	$ms = strtolower(substr($m,0,3));
	$paid_fee[] = $tota;
	for($i=1; $i<=$headCount; $i++) {
		$month = "head".$i."_".$ms;
		$t_fee[] = $fee_stu[$month];
	}
	$p = array_sum($t_fee);

	$month = "tp_".strtolower(substr($m,0,3));
	$balance[] = $p - $tota + $tpt_stu[$month];
	$check = $p - $tota + $tpt_stu[$month];
	if($check > 0) {
		$for_late_fine[] = $m;
	}
	unset($t_fee);
}
$data['cashDiscount']=cashDiscount($id);
$data['disc_amount']=getDiscountApproval($id);
$transport_fee=transportFees($id,$curr_month);
$data['transport_fees']=$transport_fee['tpt'];
$curr_due = array_sum($balance)+$transport_fee['sum'];
$data['curr_total'] = $curr_due;   //
$data['late_total'] = getLateFine($for_late_fine);   //
$fine=getHeadingOfFine($id);
foreach($fine as $key => $val){
	 foreach($val as $key2 => $val2) {
		 $label_amt[] = $val2; 
	 }
}
$extra_total = array_sum($label_amt);
$data['full_total']=$curr_due+getLateFine($for_late_fine)+$extra_total+$transport_fee['tpt'];
return $data;	
}



function getHeadingOfFine($id){
	global $db;
    $db->where('stu_id',$id);
	$db->where ('session', $_SESSION['SESSION']);
	$db->groupBy ("ehead_id");
	$head=$db->get('extra_charges',null,'ehead_id,sum(amount) as amount');
	
	$head_amount=array();
	$indici_chrge=array();
	$ehead_id=array();
    
	foreach($head as $val){
		$head_name = $val['ehead_id'];
		$extra_total[$head_name]=$val['amount'];
	}
	
	foreach($extra_total as $key => $val) {
		$db->where('stu_id',$id);
		$db->where ('session', $_SESSION['SESSION']);
		$extra_paid = $db->getOne ("fee_paid", "sum(".$key.") as sum");
		$ehead = $key;
		$db->where('ehead_id',$ehead);
		$heading=$db->getone('extra_heads','head_name');
		$head_label = $heading['head_name'];
		$data[$ehead][$head_label] = $val - $extra_paid['sum'];
	}
	return $data;
}
function transportFees($id,$current_month) {
	global $db;
	global $m_array;
	
	
	$db->join("stu_sess_data sd", "s.id=sd.stu_id", "LEFT");
	$db->where ("s.is_shown", 'YES');
	$db->where ("s.tc_issue", 'YES', '<>');
	$db->where ('sd.session', $_SESSION["SESSION"]);
	$db->where ('s.id', $id);
	$data_stu = $db->getOne("student s");
	if($data_stu['is_transport'] == 'YES') {
		
		
		$stop_id = $data_stu['stop_id'];
		
		$db->where ('session', $_SESSION['SESSION']);
		$db->where ('stu_id', $id);
		$tpt_stu = $db->getOne ("stu_tpt_fee");
		if ($db->count == 0) {
			$end_key = array_search($current_month, $m_array);
			$start_month = strtolower(date('M', strtotime($data_stu['start_date'])));
		    $start_key = array_search($start_month, $m_array);
			$db->where ('session', $_SESSION['SESSION']);
			$db->where ("id", $stop_id);
			$stop_amount = $db->getOne ("stop_master", "amount");
			$tpt_fee = $stop_amount['amount'];
		  
		  $db->where ("id", 1);
			$tpt_months = $db->getOne ("tpt_months");
			if(isset($start_key)==TRUE AND isset($end_key)==FALSE ) {
				foreach($m_array as $key => $val) {
					$m2 = "tp_".$val;
					if($tpt_months[$m2]==1 AND $key >= $start_key) {
						$tpt_stu[$m2] = $tpt_fee;
					}
				}
			} elseif (isset($start_key)==TRUE AND isset($end_key)==TRUE ) {
				foreach($m_array as $key => $val) {
					$m2 = "tp_".$val;
					if($tpt_months[$m2]==1 AND $key >= $start_key AND $key <= $end_key) {
						$tpt_stu[$m2] = $tpt_fee;
					}
				}
			} else {
				$tpt_stu = array();
			}
		}
	}
	$db->where('stu_id',$id);
	$paid_transport=$db->get('fee_paid',null,'sum(transport) as sum');
	$data['sum']=$paid_transport[0]['sum'];
	$data['tpt']=array_sum(array_values($tpt_stu))-$paid_transport[0]['sum'];
	
	return $data;
	
}
function cashDiscount($id){
	global $db;
	   $db->join("student st", "st.id=dis.stu_id", "LEFT");
	   $db->where('dis.stu_id',$id);
	   $stu_info = $db->get ("cash_discount_master dis", null, "st.stu_name, st.fat_name,dis.*");
	   return $stu_info; 
}
?>