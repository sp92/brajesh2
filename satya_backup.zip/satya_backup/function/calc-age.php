<?php 
include('../core.php');
$date = clean(datestamp($_REQUEST ['dob']));
if($date<>'1970-01-01') {
$date1 = new DateTime($date);
$date2 = new DateTime();
$interval = $date1->diff($date2);
echo $interval->y . " yrs, " . $interval->m." mnt, ".$interval->d." day"; 
}
?>