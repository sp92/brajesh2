<?php 
include('../core.php');
$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'fee_amount');
if(!empty($head_defineSession)){
	foreach($head_defineSession as $key=>$value){
		if (strpos($value['Field'], 'head') !== false) {
			$headNameArry[] = $value['Field'];
		}
	}
}
if($_REQUEST['query']=="AddDiscountForm") {
	$data=array(
	'stu_id'=>$_REQUEST['stu_id'],
	'adm_no'=>$_REQUEST['stu_id'],
	'remark'=>$_REQUEST['remark_here'],
	'p_amount'=>$_REQUEST['p_amount'],
	'p_by'    =>$_REQUEST['p_by'],
	'p_date'  =>date('Y-m-d'),
	'approved'=>"0",
	'used'=>"0",
	'session' =>$_SESSION['SESSION']
	);
	$db->insert ('cash_discount_master', $data);exit;
}
if($_REQUEST['query']=="ApprovedDiscountForm") {
	$data=array(
	'approved_amount'=>$_REQUEST['approved_amount'],
	'approved_remark'=>$_REQUEST['approved_remark'],
	'approved_by'=>$_REQUEST['approved_by'],
	'approved_date'  =>date('Y-m-d'),
	'approved'=>"1"
	);
	$db->where('id',$_REQUEST['update_id']);
	$db->update ('cash_discount_master', $data);
	exit;
}
/************************************** FETCHING FEE AMOUNT *********************************/
if(isset($_REQUEST['getamount'])) {
$type = clean($_REQUEST['var1']);
$fee_cat = clean($_REQUEST['var2']);
$new_old = clean($_REQUEST['var3']);
$db->where('session', $_SESSION['SESSION']);
$head = $db->get ("head_define");

if ($db->count > 0) {
	$head_count = 0;
	foreach ($head as $u) {
		foreach($u as $v=>$f){
			if(strpos($v, 'head') !== false){
				$head_count++;
			}
		}
		for ($i = 1; $i <= $head_count; $i++) { 
			$var = 'head'.$i;
			$heads[] = $u[$var];
		}
	}
}
$done_class = array();
$db->where('session', $_SESSION['SESSION']);
$db->where('type', $type);
$db->where('fee_cat', $fee_cat);
$db->where('new_old', $new_old);
$cols = Array ("class");
$user = $db->get ("fee_amount", null, $cols);
if ($db->count > 0) {
	foreach ($user as $u) { 
		$done_class[] = $u['class'];
	} 
}
$heads = array_filter($heads);
$heads_count = count($heads);

$user = $db->get ("class_master");
	if ($db->count > 0) {
	foreach ($user as $u) { 
			$all_class[] = $u['class'];
		} 
	} 
	$left_class = array_diff($all_class, $done_class);
echo "<strong>Classes :</strong> ";
	foreach ($left_class as $l) {
		echo "<div class='checkbox' style='display: inline-block'>
			<label><input type='checkbox' name='class[]' value='".$l."'>".$l."</label>
		</div>&nbsp;&nbsp;&nbsp;&nbsp;";
	}
echo "<br><br>";
echo "<table class='table table-striped table-bordered'>
<thead>
<tr>
<th>Fee Head</th>
<th>All</th>";
foreach($mf_array as $m) {
	echo "<th>".$m."</th>";
}
echo "</tr></thead><tbody>";
$i=1;
foreach ($heads as $h) {
	echo "<tr><th>".$h."<hr class='mar-10'>
	<select name='head".$i."_method' style='font-weight:normal;'>
		<option value='MONTHLY' >MONTHLY</option>
		<option value='BI-MONTHLY' >BI-MONTHLY</option>
		<option value='H-YEARLY' >H-YEARLY</option>
		<option value='QUARTERLY' >QUARTERLY</option>
		<option value='ANNUAL' >ANNUAL</option>
		<option value='ONE TIME' >ONE TIME</option>
	</select>
	</th><th><input type='checkbox' id='".$id."'></th>";
	
	foreach($m_array as $m) {
		$head_name = "head".$i."_".$m;
		if(in_array($head_name,$headNameArry)){
			echo "<td><input type='text' class='form-control numonly' name='".$head_name."' value='0' /></td>";
		}else{
			echo "<td></td>";
		}		
	}
	echo "</tr>";
	$i++;
}
echo "</tbody></table>";
exit();
}

// FEE STRUCTURE SUBMIT FUNCTION
if(isset($_REQUEST['form']) AND $_REQUEST['form']=='fee-define-amount' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {
	foreach($_REQUEST['class'] as $c) {
		$class[] = $c;
	}
	unset($_REQUEST['secure_salt']);
	unset($_REQUEST['form']);
	unset($_REQUEST['class']);
	unset($_REQUEST['submitamount']);
	foreach($_REQUEST as $key => $val) {
		$data[$key] = clean($val);
	}
	unset($data['accevate_erp']);
	$data['session'] = $_SESSION['SESSION'];
	
	foreach($class as $c) {
		$data['class'] = $c;
		$last_id = $db->insert ('fee_amount', $data);
	}
	echo $db->getLastError();
}
	
// FEE STRUCTURE VIEW / UPDATE
if(isset($_REQUEST['viewamount'])) {
$type = clean($_REQUEST['var1']);
$fee_cat = clean($_REQUEST['var2']);
$new_old = clean($_REQUEST['var3']);
$class = clean($_REQUEST['var4']);

$db->where('session', $_SESSION['SESSION']);
$head = $db->get ("head_define");
if ($db->count > 0) {
	foreach ($head as $u) { 
		for ($i = 1; $i <= count($headNameArry); $i++) { 
			$var = 'head'.$i;
			$heads[] = $u[$var];
		}
	}
}

$heads = array_filter($heads);
$heads_count = count($heads);


	
echo "<table class='table table-striped table-bordered'>
<thead>
<tr>
<th>Fee Head</th>";
foreach($mf_array as $m) {
	echo "<th>".$m."</th>";
}
echo "</tr></thead><tbody>";
$i=1;
$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'fee_amount');
if(!empty($head_defineSession)){
	foreach($head_defineSession as $key=>$value){
		if (strpos($value['Field'], 'head') !== false) {
			$headNameArry[] = $value['Field'];
		}
	}
}

foreach ($heads as $h) {
	
		$head_name = "head".$i."_method";
		
		$db->where('session', $_SESSION['SESSION']);
		$db->where('type', $type);
		$db->where('fee_cat', $fee_cat);
		$db->where('new_old', $new_old);
		$db->where('class', $class);
		$head_method = $db->getOne ("fee_amount", $head_name);
		if($head_method[$head_name] == 'MONTHLY' ){ $month = 'selected'; }
		if($head_method[$head_name] == 'BI-MONTHLY' ){ $bimonth = 'selected'; }
		if($head_method[$head_name] == 'H-YEARLY' ){ $hyearly = 'selected'; }
		if($head_method[$head_name] == 'QUARTERLY' ){ $quar = 'selected'; }
		if($head_method[$head_name] == 'ANNUAL' ){ $annual = 'selected'; }
		if($head_method[$head_name] == 'ONE TIME' ){ $onetime = 'selected'; }
		
	$html =  "<tr><th>".$h."<hr class='mar-10'>";
	$html.= "<select name='head".$i."_method' style='font-weight:normal;'>
	
		<option ".$month." value='MONTHLY' >MONTHLY</option>
		<option ".$$bimonth." value='BI-MONTHLY' >BI-MONTHLY</option>
		<option ".$hyearly." value='H-YEARLY' >H-YEARLY</option>
		<option ".$quar." value='QUARTERLY' >QUARTERLY</option>
		<option ".$annual." value='ANNUAL' >ANNUAL</option>
		<option ".$onetime." value='ONE TIME' >ONE TIME</option>
	</select></th>";
	$onetime = $month = $bimonth = $hyearly = $quar = $annual = '';
	echo $html;
	foreach($m_array as $m) {  
		 $head_name1 = "head".$i."_".$m;
		
		$db->where('session', $_SESSION['SESSION']);
		$db->where('type', $type);
		$db->where('fee_cat', $fee_cat);
		$db->where('new_old', $new_old);
		$db->where('class', $class);
		if(in_array($head_name1,$headNameArry)){ 
			$head_amt = $db->getOne ("fee_amount", $head_name1);
			echo "<td><input type='text' class='form-control numonly' name='".$head_name1."' value='".$head_amt[$head_name1]."' /></td>"; 
		} else {
			echo "<td></td>";
		}
	}
	echo "</tr>";
	$i++;
}
echo "</tbody></table>";
exit();
}

if(isset($_REQUEST['form']) AND $_REQUEST['form']=='fee-view-amount' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {

	
	unset($_REQUEST['secure_salt']);
	unset($_REQUEST['form']);
	unset($_REQUEST['submitamount']);
	
	$type = clean($_REQUEST['type']);
	$fee_cat = clean($_REQUEST['fee_cat']);
	$new_old = clean($_REQUEST['new_old']);
	$class = clean($_REQUEST['class']);
	unset($_REQUEST['fee_cat']);
	unset($_REQUEST['type']);
	unset($_REQUEST['new_old']);
	unset($_REQUEST['class']);
	
	foreach($_REQUEST as $key => $val) {
		$data[$key] = clean($val);
	}
	
	unset($data['accevate_erp']);
	
	$db->where('session', $_SESSION['SESSION']);
	$db->where('type', $type);
	$db->where('fee_cat', $fee_cat);
	$db->where('new_old', $new_old);
	$db->where('class', $class);
	$last_id = $db->update ('fee_amount', $data);
	echo $db->getLastError();
	
}


if(isset($_REQUEST['form']) AND $_REQUEST['form']=='fee-status' AND $_REQUEST['query'] == 'AddDiscount' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {

	$fee_amountSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'fee_amount');
	if(!empty($fee_amountSession)){
		foreach($fee_amountSession as $key=>$value){
			if (strpos($value['Field'], 'head') !== false) {
				$feeNameArry[] = $value['Field'];
			}
		}
	}

	// Old way to get record
	//$db->where("adm_no", $_REQUEST["adm_no"]);
	//$db->where("session", $_SESSION["SESSION"]);
	//$stu = $db->getOne("seswise_class");
	
	$db->join("seswise_class sc", "s.adm_no = sc.adm_no", "LEFT");
	$db->where ('s.adm_no', $_REQUEST["adm_no"]);
	$db->where ('sc.session', $_SESSION["SESSION"]);
	$stu = $db->getOne("student s");
	
	$str = $_REQUEST["allotdisc"][0];
	
	if(!empty($stu['disc_id'])){
		$str = $stu["disc_id"].','.$str;
	}

	$data = array("disc_id"=>$str);
	$db->where("adm_no", $_REQUEST["adm_no"]);
	$db->where("session", $_SESSION["SESSION"]);
	$db->update("seswise_class",$data);

	$db->where("id", $_REQUEST["allotdisc"][0]);
	$arr = $db->getOne('discount');

	foreach($arr as $a=>$f){
		if(strpos($a,"head") !== false){
			if(!empty($a) || $a != 0){
				$newArr[$a] = $f;
			}
		}
	}

	foreach($newArr as $m=>$va){
		if($va != 0){
			foreach($m_array as $mo){
				$mothArr[$m.'_'.$mo] = $va;
			}
		}
	}
	foreach($mothArr as $mot=>$vlue){
		if(in_array($mot,$feeNameArry)){
			
			$db->where("adm_no", $_REQUEST["adm_no"]);
			$db->where("session",$_SESSION["SESSION"]);
			$stuCustom = $db->get("stu_custom_fee");
			
			if(empty($stuCustom)){
				$cols = Array ($mot);
				$db->where('session', $_SESSION['SESSION']);
				$db->where('type', $stu["type"]);
				$db->where('fee_cat', $stu["fee_cat"]);
				$db->where('new_old', $stu["new_old"]);
				$db->where('class', $stu["class"]);
				$stdnts = $db->get("fee_amount",null,$cols);
			}
			else{
				$stdnts = $stuCustom;
			}
			$discunt = $stdnts[0][$mot] * $vlue / 100 ;
			$custonFeeArr[$mot] = $stdnts[0][$mot] - $discunt;
		}
	}
	
	if(empty($stuCustom)){
		$db->where('session', $_SESSION['SESSION']);
		$db->where('type', $stu["type"]);
		$db->where('fee_cat', $stu["fee_cat"]);
		$db->where('new_old', $stu["new_old"]);
		$db->where('class', $stu["class"]);
		$stdntes = $db->get("fee_amount");
		$stdntes = $stdntes[0];
	}
	else{
		$stdntes = $stuCustom[0];
	}
	unset($stdntes["id"]);
	unset($stdntes["class"]);
	unset($stdntes["new_old"]);
	unset($stdntes["type"]);
	unset($stdntes["fee_cat"]);
	$insertArr = $stdntes;
	foreach($stdntes as $ke=>$se){
		foreach($custonFeeArr as $c=>$vl){	
			if(strpos($ke,$c) !== false){
				$insertArr[$c] = $vl;
			}
		}
	}
	if(empty($stuCustom)){
		$insertArr['adm_no'] = $_REQUEST["adm_no"];
		$insertArr['session'] = $_SESSION["SESSION"];
		$db->insert("stu_custom_fee",$insertArr);
		$db->where("adm_no",$_REQUEST["adm_no"]);
		$db->where("session",$_SESSION["SESSION"]);
		$da = array("custom_fee" => 'YES');
		$db->update("seswise_class",$da);
	}
	else{
		$db->where("adm_no",$_REQUEST["adm_no"]);
		$db->where("session",$_SESSION["SESSION"]);
		$db->update("stu_custom_fee",$insertArr);
	}	
	$db->where("id",$_REQUEST["allotdisc"][0]);
	$discName = $db->getOne("discount");
	$msg = 'Discount <b>'.$discName["disc_name"].'</b> applied.';
	logAction($_REQUEST['adm_no'], $msg);
//print_r($insertArr);
exit;
}

if(isset($_REQUEST['form']) AND $_REQUEST['form']=='fee-discount' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {

	unset($_REQUEST['secure_salt']);
	unset($_REQUEST['form']);
	unset($_REQUEST['submitamount']);
	foreach($_REQUEST as $key => $val) {
		$data[$key] = clean($val);
	}
	$data["session"] = $_SESSION["SESSION"];
	
	echo $Id = $db->insert("discount",$data);
}

if(isset($_REQUEST['form']) AND $_REQUEST['form']=='fee-status' AND $_REQUEST['query'] == 'recal-fee' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {
	// Getting head counts
	$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
	if(!empty($head_defineSession)){
		foreach($head_defineSession as $key=>$value){
			if (strpos($value['Field'], 'head') !== false) {
				$headNameArry1[] = $value['Field'];
			}
		}
	}
	// Getting required fields to fetch other important information
	$headNameArry1[] = 'transport';
	
	// Old way to get record
	$cols = Array("custom_fee","is_transport","class","new_old","type","fee_cat");
	$db->where("adm_no",$_REQUEST["adm_no"]);
	$curr_fee = $db->get("student",null,$cols);
	
	//$cols = Array("sc.custom_fee","sc.is_transport","sc.class","sc.new_old","s.type","s.fee_cat");
	//$db->join("seswise_class sc", "s.adm_no = sc.adm_no", "LEFT");
	//$db->where ('s.adm_no', $_REQUEST["adm_no"]);
	//$db->where ('sc.session', $_SESSION["SESSION"]);
	//$curr_fee = $db->get("student s",null,$cols);
	
	// Fetching fee amount
	if($curr_fee[0]['is_transport'] == 'YES') {
		$db->where ('session', $_SESSION['SESSION']);
		$db->where ('adm_no', $_REQUEST["adm_no"]);
		$tpt_stu = $db->getOne ("stu_tpt_fee");
	}
	
	//var_dump($tpt_stu);
	
	if($curr_fee[0]['custom_fee'] == "YES"){
		$db->where("adm_no",$_REQUEST["adm_no"]);
		$db->where("session",$_SESSION["SESSION"]);
		$stuFeeArray = $db->getOne("stu_custom_fee");
	}
	else{
		$db->where("class",$curr_fee[0]['class']);
		$db->where("new_old",$curr_fee[0]['new_old']);
		$db->where("type",$curr_fee[0]['type']);
		$db->where("fee_cat",$curr_fee[0]['fee_cat']);
		$db->where("session",$_SESSION["SESSION"]);
		$stuFeeArray = $db->getOne("fee_amount");
	}
	$cls = array("rec_no","month","rec_date","amount","late_fine","discount");
	$db->where("adm_no",$_REQUEST["adm_no"]);
	$db->where("session",$_SESSION["SESSION"]);
	$feePaidArray = $db->get("fee_paid",null,$cls);  // Array containing raw deposited fee amount
	
	//Deleting raw deposited fee of that adm_no
	$db->where('adm_no',$_REQUEST["adm_no"]);
	$db->where("session",$_SESSION["SESSION"]);
	$db->delete("fee_paid");
	
	// Beginning the process of recalculation
	if(!empty($feePaidArray)){
		$i = 0; 
		foreach($feePaidArray as $fee){
			$feeamnt = $fee['amount'];
			foreach($mf_array as $mf){
				$data['rec_no'] = $fee['rec_no'];
				$data['rec_date'] = $fee['rec_date'];
				$data['month'] = $mf;
				$m = strtolower(substr($mf,0,3));
				$data['amount'] = 0;
				$data['session'] = $_SESSION["SESSION"];
				$data['adm_no'] = $_REQUEST["adm_no"];
				$data['type'] = 'FEE';
				
				foreach($headNameArry1 as $hd){
					if($hd <> 'transport') {
						if (array_key_exists($hd.'_'.$m, $stuFeeArray)) { 
							$db->where("month",$mf);
							$db->where("adm_no",$_REQUEST["adm_no"]);
							$db->where("session",$_SESSION["SESSION"]);
							$mtArr = $db->getOne("fee_paid", "sum(".$hd.") as sum");
							$t = $stuFeeArray[$hd.'_'.$m] - $mtArr["sum"];
							if($feeamnt >= $t) {
								$data[$hd] = $t;
								$data['amount'] += $data[$hd];
								$feeamnt = $feeamnt - $t;
							} else {
								$data[$hd] = $feeamnt;
								$data['amount'] += $data[$hd];
								$feeamnt = 0;
							}
						}
						else{
							$data[$hd] = 0;
						}
					} else {
						$hd = 'tp';
						
						if (array_key_exists($hd.'_'.$m, $tpt_stu)) {
							$db->where("month",$mf);
							$db->where("adm_no",$_REQUEST["adm_no"]);
							$db->where("session",$_SESSION["SESSION"]);
							$mtArr = $db->getOne("fee_paid", "sum(transport) as sum");
							$t = $tpt_stu[$hd.'_'.$m] - $mtArr["sum"];
							if($feeamnt >= $t) {
								$data['transport'] = $t;
								$data['amount'] += $data['transport'];
								$feeamnt = $feeamnt - $t;
							} else {
								$data['transport'] = $feeamnt;
								$data['amount'] += $data['transport'];
								$feeamnt = 0;
							}
						}
						else{
							$data['transport'] = 0;
						}
					}
				}
				print_r($data);
				$db->insert('fee_paid',$data); // inserting recalculated fee
				
				$db->where('amount',0);
				$db->where('adm_no',$data['adm_no']);
				$db->where("session",$_SESSION["SESSION"]);
				$db->delete("fee_paid");  // deleting 0 amount rows
			}
			$i++;
		}	exit;
	}
}
?>