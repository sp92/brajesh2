<?php 
function api_data() {
	global $db;
	$db->where ("id", 1);
	$api_data = $db->get ("smsapi",1);
	return($api_data);
}
function CallAPISMS($data)
{
	$api_data = api_data();
	if($api_data[0]['set_sms']==1) {
		$url = $api_data[0]['api_url'];
		$api_key = $api_data[0]['api_key'];
		$ch = curl_init( $url );
		curl_setopt( $ch, CURLOPT_POST, 1);
		curl_setopt( $ch, CURLOPT_POSTFIELDS, 'api_key='.$api_key.'&'.$data);
		curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt( $ch, CURLOPT_HEADER, 0);
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
		$response = curl_exec( $ch );
		return($response);
	}
}
/************************************** GET CREDITS *********************************/
function get_sms_bal() {
	$api_call = 'method=account.credits';
	$response = CallAPISMS($api_call);
	return($response);
}



?>