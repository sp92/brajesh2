<?php 
include('../core.php');

//if($_REQUEST['query'] == 'recal-fee' && $_SESSION['SESS_NAME']=='ROOT') {
error_reporting(0);
$cols = Array ("adm_no");
$users = $db->get ("fee_paid", null, $cols);
if ($db->count > 0) {
    foreach ($users as $user) { 
        $adm_no_arr[] = $user['adm_no'];
    }
}

$adm_no_ar = array_unique($adm_no_arr);

//$adm_no_ar = array('20151928','20151824');


foreach($adm_no_ar as $adm_no) {
	

	/*
	// Getting head counts
	$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
	if(!empty($head_defineSession)){
		foreach($head_defineSession as $key=>$value){
			if (strpos($value['Field'], 'head') !== false) {
				$headNameArry1[] = $value['Field'];
			}
		}
	}
	// Getting required fields to fetch other important information
	$headNameArry1[] = 'transport';
	
	// Old way to get record
	$cols = Array("custom_fee","is_transport","class","new_old","type","fee_cat");
	$db->where("adm_no",$adm_no);
	$curr_fee = $db->get("student",null,$cols);

	//$cols = Array("sc.custom_fee","sc.is_transport","sc.class","sc.new_old","s.type","s.fee_cat");
	//$db->join("seswise_class sc", "s.adm_no = sc.adm_no", "LEFT");
	//$db->where ('s.adm_no', $adm_no);
	//$db->where ('sc.session', $_SESSION["SESSION"]);
	//$curr_fee = $db->get("student s",null,$cols);
	
	// Fetching fee amount
	if($curr_fee[0]['is_transport'] == 'YES') {
		$db->where ('session', $_SESSION['SESSION']);
		$db->where ('adm_no', $adm_no);
		$tpt_stu = $db->getOne ("stu_tpt_fee");
	}
	
	//var_dump($tpt_stu);
	
	if($curr_fee[0]['custom_fee'] == "YES"){
		$db->where("adm_no",$adm_no);
		$db->where("session",$_SESSION["SESSION"]);
		$stuFeeArray = $db->getOne("stu_custom_fee");
	}
	else{
		$db->where("class",$curr_fee[0]['class']);
		$db->where("new_old",$curr_fee[0]['new_old']);
		$db->where("type",$curr_fee[0]['type']);
		$db->where("fee_cat",$curr_fee[0]['fee_cat']);
		$db->where("session",$_SESSION["SESSION"]);
		$stuFeeArray = $db->getOne("fee_amount");
	}
	$cls = array("rec_no","month","rec_date","amount","late_fine","discount");
	$db->where("adm_no",$adm_no);
	$db->where("session",$_SESSION["SESSION"]);
	$feePaidArray = $db->get("fee_paid",null,$cls);  // Array containing raw deposited fee amount
	
	//Deleting raw deposited fee of that adm_no
	$db->where('adm_no',$adm_no);
	$db->where("session",$_SESSION["SESSION"]);
	$db->delete("fee_paid");
	
	// Beginning the process of recalculation
	if(!empty($feePaidArray)){
		$i = 0; 
		foreach($feePaidArray as $fee){
			$feeamnt = $fee['amount'];
			foreach($mf_array as $mf){
				$data['rec_no'] = $fee['rec_no'];
				$data['rec_date'] = $fee['rec_date'];
				$data['month'] = $mf;
				$m = strtolower(substr($mf,0,3));
				$data['amount'] = 0;
				$data['session'] = $_SESSION["SESSION"];
				$data['adm_no'] = $adm_no;
				$data['type'] = 'FEE';
				
				foreach($headNameArry1 as $hd){
					if($hd <> 'transport') {
						if (array_key_exists($hd.'_'.$m, $stuFeeArray)) { 
							$db->where("month",$mf);
							$db->where("adm_no",$adm_no);
							$db->where("session",$_SESSION["SESSION"]);
							$mtArr = $db->getOne("fee_paid", "sum(".$hd.") as sum");
							$t = $stuFeeArray[$hd.'_'.$m] - $mtArr["sum"];
							if($feeamnt >= $t) {
								$data[$hd] = $t;
								$data['amount'] += $data[$hd];
								$feeamnt = $feeamnt - $t;
							} else {
								$data[$hd] = $feeamnt;
								$data['amount'] += $data[$hd];
								$feeamnt = 0;
							}
						}
						else{
							$data[$hd] = 0;
						}
					} else {
						$hd = 'tp';
						
						if (array_key_exists($hd.'_'.$m, $tpt_stu)) {
							$db->where("month",$mf);
							$db->where("adm_no",$adm_no);
							$db->where("session",$_SESSION["SESSION"]);
							$mtArr = $db->getOne("fee_paid", "sum(transport) as sum");
							$t = $tpt_stu[$hd.'_'.$m] - $mtArr["sum"];
							if($feeamnt >= $t) {
								$data['transport'] = $t;
								$data['amount'] += $data['transport'];
								$feeamnt = $feeamnt - $t;
							} else {
								$data['transport'] = $feeamnt;
								$data['amount'] += $data['transport'];
								$feeamnt = 0;
							}
						}
						else{
							$data['transport'] = 0;
						}
					}
				}
				//print_r($data);
				$db->insert('fee_paid',$data); // inserting recalculated fee
				
				$db->where('amount',0);
				$db->where('adm_no',$data['adm_no']);
				$db->where("session",$_SESSION["SESSION"]);
				$db->delete("fee_paid");  // deleting 0 amount rows
			}
			$i++;
		}	
	}*/
	
	
	
	$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'head_define');
	if(!empty($head_defineSession)){
		foreach($head_defineSession as $key=>$value){
			if (strpos($value['Field'], 'head') !== false) {
				$headNameArry1[] = $value['Field'];
			}
		}
	}
	// Getting required fields to fetch other important information
	$headNameArry1[] = 'transport';
	
	// Old way to get record
	$cols = Array("custom_fee","is_transport","class","new_old","type","fee_cat");
	$db->where("adm_no",$adm_no);
	$curr_fee = $db->get("student",null,$cols);
	
	//$cols = Array("sc.custom_fee","sc.is_transport","sc.class","sc.new_old","s.type","s.fee_cat");
	//$db->join("seswise_class sc", "s.adm_no = sc.adm_no", "LEFT");
	//$db->where ('s.adm_no', $_REQUEST["adm_no"]);
	//$db->where ('sc.session', $_SESSION["SESSION"]);
	//$curr_fee = $db->get("student s",null,$cols);
	
	// Fetching fee amount
	if($curr_fee[0]['is_transport'] == 'YES') {
		$db->where ('session', $_SESSION['SESSION']);
		$db->where ('adm_no', $adm_no);
		$tpt_stu = $db->getOne ("stu_tpt_fee");
	}
	
	//var_dump($tpt_stu);
	
	if($curr_fee[0]['custom_fee'] == "YES"){
		$db->where("adm_no",$adm_no);
		$db->where("session",$_SESSION["SESSION"]);
		$stuFeeArray = $db->getOne("stu_custom_fee");
	}
	else{
		$db->where("class",$curr_fee[0]['class']);
		$db->where("new_old",$curr_fee[0]['new_old']);
		$db->where("type",$curr_fee[0]['type']);
		$db->where("fee_cat",$curr_fee[0]['fee_cat']);
		$db->where("session",$_SESSION["SESSION"]);
		$stuFeeArray = $db->getOne("fee_amount");
	}
	$cls = array("rec_no","month","rec_date","amount","late_fine","discount");
	$db->where("adm_no",$adm_no);
	$db->where("session",$_SESSION["SESSION"]);
	$feePaidArray = $db->get("fee_paid",null,$cls);  // Array containing raw deposited fee amount
	
	//Deleting raw deposited fee of that adm_no
	$db->where('adm_no',$adm_no);
	$db->where("session",$_SESSION["SESSION"]);
	$db->delete("fee_paid");
	
	// Beginning the process of recalculation
	if(!empty($feePaidArray)){
		$i = 0; 
		foreach($feePaidArray as $fee){
			$feeamnt = $fee['amount'];
			foreach($mf_array as $mf){
				
				if($feeamnt>0) {
					$data['rec_no'] = $fee['rec_no'];
					$data['rec_date'] = $fee['rec_date'];
					$data['month'] = $mf;
					$m = strtolower(substr($mf,0,3));
					$data['amount'] = 0;
					$data['session'] = $_SESSION["SESSION"];
					$data['adm_no'] = $adm_no;
					$data['type'] = 'FEE';
					
					foreach($headNameArry1 as $hd){
						if($hd <> 'transport') {
							if (array_key_exists($hd.'_'.$m, $stuFeeArray)) { 
								$db->where("month",$mf);
								$db->where("adm_no",$adm_no);
								$db->where("session",$_SESSION["SESSION"]);
								$mtArr = $db->getOne("fee_paid", "sum(".$hd.") as sum");
								$t = $stuFeeArray[$hd.'_'.$m] - $mtArr["sum"];
								if($feeamnt >= $t) {
									$data[$hd] = $t;
									$data['amount'] += $data[$hd];
									$feeamnt = $feeamnt - $t;
								} else {
									$data[$hd] = $feeamnt;
									$data['amount'] += $data[$hd];
									$feeamnt = 0;
								}
							}
							else{
								$data[$hd] = 0;
							}
						} else {
							$hd = 'tp';
							
							if (array_key_exists($hd.'_'.$m, $tpt_stu)) {
								$db->where("month",$mf);
								$db->where("adm_no",$adm_no);
								$db->where("session",$_SESSION["SESSION"]);
								$mtArr = $db->getOne("fee_paid", "sum(transport) as sum");
								$t = $tpt_stu[$hd.'_'.$m] - $mtArr["sum"];
								if($feeamnt >= $t) {
									$data['transport'] = $t;
									$data['amount'] += $data['transport'];
									$feeamnt = $feeamnt - $t;
								} else {
									$data['transport'] = $feeamnt;
									$data['amount'] += $data['transport'];
									$feeamnt = 0;
								}
							}
							else{
								$data['transport'] = 0;
							}
						}
					}
					//print_r($data);
					$db->insert('fee_paid',$data); // inserting recalculated fee
					
					$db->where('amount',0);
					$db->where('adm_no',$data['adm_no']);
					$db->where("session",$_SESSION["SESSION"]);
					$db->delete("fee_paid");  // deleting 0 amount rows
				
				}
				
			}
			$i++;
		}	
	}
	unset($feePaidArray);
	unset($headNameArry1);
	unset($data);
	unset($tpt_stu);
}
echo "Processed Adm No. ".$i;
//}
?>