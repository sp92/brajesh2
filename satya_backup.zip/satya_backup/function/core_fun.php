<?php 
include('../core.php');
//$fields_search=$_REQUEST['fields'];
$fields_search=array("adm_no","stu_name","username","password","fat_name");
  
/*    for table colum use the query  student table*/
$columns = $db->rawQueryValue('SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA ="erp" AND TABLE_NAME =  "kisalg_student"');
//print_r($users);
$filter_array=array();

foreach($fields_search as $search) {
    
    
    if(in_array($search, $columns))
    {

      $val=array_search($search,$columns);
        
        $filter_array[]=$columns["$val"];
        
    }

}
print_r($filter_array);

/* create array for remove the ambiguity */

$array_amb=array("adm_no","class","sec","sssn","new_old");
//print_r($array_amb);

foreach($array_amb as $search_amb) {
	
	
	if(in_array($search_amb, $filter_array))
	{

		 $val=array_search($search_amb,$filter_array);
		
		 $filter_array["$val"]="s.".$search_amb." as "."stu_".$search_amb;
		
	}

}

/****************************************/

	$db->join("stu_sess_data sd", "s.id=sd.stu_id", "LEFT");
    $db->where("s.is_shown", 'YES');
    $db->where("s.tc_issue", 'YES', '<>');
    $db->where('sd.session', $_SESSION["SESSION"]);
    $db->where('s.stu_name', '%' . clean($_GET['term']) . '%', 'LIKE');
    $data1 = $db->get("student s", null, $filter_array);
// print_r($data1);
 echo "<div class='col-md-12'><table>";

 foreach($data1 as $row) {
  echo('<tr>');
  foreach($row as $cell) {
    echo('<td style="padding:5px 5px 5px 5px;">' . $cell . '</td>');
  }
  echo('</tr>');
}

 echo "</table></div>";


exit();
?>