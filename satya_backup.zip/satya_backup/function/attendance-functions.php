<?php 
include('../core.php');
error_reporting(E_ALL);
/************************************** ATTENDANCE HEADS SETUP *********************************/
if(isset($_REQUEST['opt2']) and isset($_REQUEST['val2']) and isset($_REQUEST['id2'])) {
$data = Array (
	$_REQUEST['opt'] => $_REQUEST['val']
);
$db->where ('id', $_REQUEST['id']);
$db->update ('atten_code', $data);
exit();
}
/************************************** ATTENDANCE CODES SETUP *********************************/
if(isset($_REQUEST['opt']) and isset($_REQUEST['val']) and isset($_REQUEST['id'])) {
$data = Array (
	$_REQUEST['opt'] => $_REQUEST['val']
);
$db->where ('id', $_REQUEST['id']);
$db->update ('atten_code', $data);
exit();
}
/******************************* MARKING HOLIDAY FOR SINGLE CLASS *******************************/
if(isset($_REQUEST['for_holiday'])) {
	
$date = datestamp($_REQUEST['date']);
$class_arr2 = explode(",", $_REQUEST['class']); // comma separated class list
foreach($class_arr2 as $class) {
	$class_arr[] = $class;
}
$remark = clean($_REQUEST['holiday_remark']);
$atten_head = clean($_REQUEST['head']);
unset($_REQUEST['for_holiday']);
unset($_REQUEST['date']);
unset($_REQUEST['class']);
foreach($class_arr as $class) {
	$db->where ('class', $class);
	$db->where ('date', $date);
	$w_days = $db->getOne('attendance_w_days');
	if ($db->count == 0) {
		$data = Array (
			"date" => $date,
			"class" => $class,
			"head" => $atten_head,
			"remark" => $remark,
			"session" => $_SESSION['SESSION']
		);
		$db->insert ('attendance_w_days', $data);
		echo "1";
	} else {
		echo "2";
	}
}
exit;
}
/************************************** GETTING DONE / UNDONE CLASSES *********************************/
if(isset($_REQUEST['get-classes'])) {
	$date = datestamp($_REQUEST['date']);
	$classes = array();
	$db->where ('date', $date);
	$w_days = $db->get('attendance_w_days');
	foreach($w_days as $w) {
		$classes[] = $w['class'];
	}
	
	$class = $db->get ("class_master");
	$section = $db->get ("sec_master");
	foreach ($class as $key => $val) { 
		foreach($section as $key2 => $val2) {
			$db->join("stu_sess_data sd", "s.id=sd.stu_id", "LEFT");
			$db->where ("s.is_shown", 'YES');
			$db->where ("s.tc_issue", 'YES', '<>');
			$db->where ('sd.session', $_SESSION["SESSION"]);
			$db->where ('sd.class', $val['class']);
			$db->where ('sd.sec', $val2['sec']);
			$user = $db->get("student s",null,"s.id");
			if ($db->count > 0) {
				$data = $db->count;
				//$class_arr[] = $val['class']." - ".$val2['sec']." (".$data.")";
				$class_arr[] = $val['class']." - ".$val2['sec'];
			}
		}
	}
	$done = array();
	$undone = array();
	foreach($class_arr as $d) {
		if(in_array($d, $classes, TRUE)) {
			$done[$d] = 1;
		} else {
			$done[$d] = 0;
		}
	}
	echo json_encode($done);
}
/******************************** GET STUDENT ATTENDANCE *********************************/
if(isset($_REQUEST['mark']) and isset($_REQUEST['var1'])) {
if($_REQUEST['var1']<>'' AND $_REQUEST['var2']<>'' ) {
$var1 = explode(" - ", $_REQUEST['var1']);
$date = datestamp($_REQUEST['var2']);

$class = $var1[0];
$sec = $var1[1];
$n=1;
	$db->join("stu_sess_data sd", "s.id=sd.stu_id", "LEFT");
	$db->where ("s.is_shown", 'YES');
	$db->where ("s.tc_issue", 'YES', '<>');
	$db->where ('sd.session', $_SESSION["SESSION"]);
	$db->where ('sd.class', $class);
	$db->where ('sd.sec', $sec);
	$db->orderBy('s.stu_name',"asc");	
	$students = $db->get("student s",null,"s.id, s.stu_name, s.fat_name, sd.class, sd.sec");
	
	$db->where ("student", '1');
	$codes = $db->get ("atten_code",null,'code,color,heading');
	?>
	<?php foreach($codes as $key2 => $val2) { ?>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="background-color:<?php echo $val2['color']; ?>;border:1px solid;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> <?php echo $val2['heading']; ?>
	<?php } ?>
	<br/>
	<br/>
	<form id="mark-attendance">
	<input type="hidden" name="class" value="<?php echo $_REQUEST['var1']; ?>" />
	<input type="hidden" name="date" value="<?php echo $date; ?>" />
	<table class="table table-hover">
	<thead>
		<tr>
			<th width=50>Sr.</th>
			<th width=200>Student Name</th>
			<th width=200>Father Name</th>
			<th width=200>Class</th>
			<th>Attendance</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($students as $key => $val) { ?>
		<tr>
			<td align=center><?php echo $n; $n++; ?></td>
			<td><?php echo $val['stu_name']; ?></td>
			<td><?php echo $val['fat_name']; ?></td>
			<td><?php echo $val['class']." - ".$val['sec']; ?></td>
			<td align=center><?php 
			foreach($codes as $key2 => $val2) {
				if($val2['code']=='P') { $checked = 'checked'; } else { $checked = ''; }
				echo "<label><input type='radio' name='atten_code-".$val['id']."' value='".$val2['code']."' ".$checked." > ".$val2['code']."</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ";
			} ?></td>
		</tr>
		<?php } ?>
	</tbody>
	</table>
	<button class="btn btn-primary ladda-button kill-evo" type='submit' data-style="zoom-out"><span class="ladda-label">Save Attendance</span></button>
	</form>
	<script>
	$('input:radio').change(function(){
		var selection = $(this).val();
		<?php foreach($codes as $key2 => $val2) { ?>
		if(selection == '<?php echo $val2['code']; ?>')
		$(this).closest('tr').css('background-color', '<?php echo $val2['color']; ?>');
		<?php } ?>
	});
	</script>
	<script>
	$('#mark-attendance').submit(function(event) {
	event.preventDefault();
		$.ajax({
			type: 'POST',
			url: './function/attendance-functions?save-attendance',
			data: $(this).serialize(),
			success: function (data) {
				get_classes();
				if(data=='0') {
					$.notify({message: 'Failed to update information.' },{type: 'danger'});
				} else if(data=='2') {
					$.notify({message: 'Attendance already marked. Use Update Attendance option instead.' },{type: 'danger'});
				} else {
					$.notify({message: '<strong>Attendance</strong> saved.' },{type: 'success'});
				}
			}
		});
	});
</script>
<?php 
}
exit();
}

/************************************** SAVE ATTENDANCE *********************************/
if(isset($_REQUEST['save-attendance'])) {
$date = $_REQUEST['date'];
$class = $_REQUEST['class'];
unset($_REQUEST['save-attendance']);
unset($_REQUEST['date']);
unset($_REQUEST['class']);

$db->where ('date', $date);
$db->where ('class', $class);
$w_days = $db->getOne('attendance_w_days');
foreach($_REQUEST as $key => $val) {
	$key2 = explode("-", $key);
	$stu_id = $key2[1];
	if($val<>'P') {
		$data = Array (
			"stu_id" => $stu_id,
            "atten_code" => $val,
            "date" => $date,
            "session" => $_SESSION['SESSION']
		);
		$data2[] = $data;
		unset($data);
	}
}
if ($db->count == 0) {
	$data = Array (
		"date" => $date,
		"class" => $class,
		"head" => "W",
		"session" => $_SESSION['SESSION']
	);
	$db->insert ('attendance_w_days', $data);
	foreach($data2 as $data) {
		$db->insert ('attendance_stu', $data);
	}
	echo "1";
} else {
	echo "2";
}

exit();
}
/************************************** GET ATTENDANCE *********************************/
if(isset($_REQUEST['get-log'])) {
	$n =1;
$date = datestamp($_REQUEST['date']);
$code = $_REQUEST['code'];
unset($_REQUEST['get-log']);
$class_arr2 = explode(",", $_REQUEST['class']); // comma separated class list
foreach($class_arr2 as $class) {
	$class_arr[] = $class;
}
$db->where ("student", '1');
$codes = $db->get ("atten_code",null,'code,heading');
foreach($codes as $code_d) {
	$c1 = $code_d['code'];
	$h1 = $code_d['heading'];
	$code_label[$c1] = $h1;
}
	?>
	<table class="table table-hover">
	<thead>
		<tr>
			<th width=50>Sr.</th>
			<th width=200>Student Name</th>
			<th width=200>Father Name</th>
			<th width=200>Class</th>
			<th>Attendance</th>
		</tr>
	</thead>
	<tbody>
		<?php 
		foreach($class_arr as $class) {
			$class2 = explode(" - ", $class);
			$db->join("stu_sess_data sd", "s.id=sd.stu_id", "LEFT");
			$db->where ("s.is_shown", 'YES');
			$db->where ("s.tc_issue", 'YES', '<>');
			$db->where ('sd.session', $_SESSION["SESSION"]);
			$db->where ('sd.class', $class2[0]);
			$db->where ('sd.sec', $class2[1]);
			$db->orderBy('s.stu_name',"asc");	
			$students = $db->get("student s",null,"s.id, s.stu_name, s.fat_name, sd.class, sd.sec");
		
				
		foreach($students as $key => $val) { 
				$db->where ('date', $date);
				$db->where ('stu_id', $val['id']);
				if($code <> "") {
					$db->where ('atten_code', $code);
					$codeon = true;
				} else {
					$codeon = false;
				}
				$attendance = $db->getOne('attendance_stu',null, "atten_code");
				if ($db->count > 0) {
					$atten = $attendance['atten_code']; 
				} else {
					$atten = "P"; // need to add extended methods over here
				}
			if($codeon == true) {
				if($code == $atten) { ?>
					<tr>
						<td align=center><?php echo $n; $n++; ?></td>
						<td><?php echo $val['stu_name']; ?></td>
						<td><?php echo $val['fat_name']; ?></td>
						<td><?php echo $val['class']." - ".$val['sec']; ?></td>
						<td align=center><?php echo $code_label[$atten]; ?></td>
					</tr>
				<?php }
			} else { ?>
				<tr>
					<td align=center><?php echo $n; $n++; ?></td>
					<td><?php echo $val['stu_name']; ?></td>
					<td><?php echo $val['fat_name']; ?></td>
					<td><?php echo $val['class']." - ".$val['sec']; ?></td>
					<td align=center><?php echo $code_label[$atten]; ?></td>
				</tr>
			<?php } ?>
		
		<?php } } ?>
	</tbody>
	
	<?php
	


exit();
}


?>