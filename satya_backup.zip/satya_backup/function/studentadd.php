<?php 
include('../core.php');
error_reporting(0);
if(isset($_REQUEST['form']) AND $_REQUEST['form']=='student-new' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {
	
	$data1["class"] = clean($_REQUEST["class"]);
	$data1["sec"] = clean($_REQUEST["sec"]);
	$data1['session'] = $_SESSION['SESSION'];
	if($_REQUEST["is_transport"] == "YES")
	$data1['is_transport'] = clean($_REQUEST['is_transport']);
	$data1['new_old'] = clean($_REQUEST['new_old']);
	$adm_no = $db->getOne ("student", "max(adm_no) as adm");
	if($_REQUEST['std_type'] == 'confirm' ){
		$new_adm_no = $adm_no['adm']+1;
	}
	else if($_REQUEST['std_type'] == 'provisional'){
		$new_adm_no = NULL;
	}
	$bus_fee = $_REQUEST['bus_fee'];
	$route = $_REQUEST['route'];
	$stop = explode(":::", $_REQUEST['stop']);
	$stop2 = $stop[0];
	
	$do_adm = $_REQUEST['do_adm'];
	$dob = $_REQUEST['dob'];
	$cast_cert_issue = $_REQUEST['cast_cert_issue'];
	unset($_REQUEST['secure_salt']);
	unset($_REQUEST['form']);
	unset($_REQUEST['dob']);
	unset($_REQUEST['do_adm']);
	unset($_REQUEST['cast_cert_issue']);
	unset($_REQUEST['s_adm_no']);
	unset($_REQUEST['rec_no']);
	unset($_REQUEST['bus_fee']);
	unset($_REQUEST['adm_no']);
	unset($_REQUEST['route']);
	unset($_REQUEST['stop']);
	unset($_REQUEST['new_old']);

	$data['do_adm'] = datestamp($do_adm);
	$data['dob'] = datestamp($dob);
	$data['cast_cert_issue'] = datestamp($cast_cert_issue);
	$data['adm_no'] = $new_adm_no;
	$data['adm_class'] = $_REQUEST['class'];
	$data1['adm_no'] = $data['adm_no'];
	$data['session'] = $_SESSION['SESSION'];
	$is_transport = $_REQUEST['is_transport'];
	unset($_REQUEST["is_transport"]);
	unset($_REQUEST["class"]);
	unset($_REQUEST["sec"]);
	
	foreach($_REQUEST as $key => $val) {
		$data[$key] = clean($val);
	}
	unset($data['accevate_erp']);
	unset($data['std_type']);
	
	$data['session'] = $_SESSION['SESSION'];
   
	$last_id = $db->insert('student', $data);
	
	$data1['stu_id'] = $data['adm_no'];
	$data1['type'] = $_REQUEST['type'];
	$data1['fee_cat'] =$_REQUEST['type'];
	 
	$db->insert('stu_sess_data', $data1);
	
	unset($data);
	/*enquiry Update*/
	  $data12=array(
	   "adm_status"=>"Admitted",
	   "do_adm"=>date('Y-m-d')
   );
   	
	$db->where('id',$_REQUEST['enq_no']);
	$last_id = $db->update ('inquiry', $data12);
	/*-------------update--------------------------*/
	
	
	if($is_transport == 'YES') {
		
		$data = Array (
			"adm_no" => $new_adm_no,
			"route" => $route,
			"stop" => $stop2,
		);
		
		$user = $db->getOne ("tpt_months");
		foreach($m_array as $tp) {
			$tp = "tp_".$tp;
			if($user[$tp] == 1) {
				$data[$tp] = $bus_fee;
			}
		}
		$data['session'] = $_SESSION['SESSION'];
		$db->insert('stu_tpt_fee', $data);
	}
	
	if(strlen($_REQUEST['mobile']) == 10) {
	$eschool_url = $db->getOne ("school_info", "eschool_url as cnt");
	
	$message = "Dear Parents,%0A%0AThank you for admitting your ward ".$_REQUEST['stu_name']." in ".SCHOOLNAME.".%0ASchool's E-Portal Login details are: ".$eschool_url['cnt']."%0A%0ALogin: ".getusername($_REQUEST['stu_name'])."%0A%0APassword: Your Mobile Number%0A%0AWe are happy to have you as a part of our School Family.%0A%0AThank You.";
	send_sms($_REQUEST['mobile'],$message);
	}
	
	echo "<a class='btn btn-success' href='fee?adm_no=".$new_adm_no."'>Pay Fee</a>&nbsp;&nbsp;&nbsp;<a class='btn btn-default' href='student-new'>Add Another Student</a>";
exit;
}
/***********************************transport info*****************************************************************/
if(isset($_REQUEST['updateTransportInfo'])) {
	$db->where ('stop', '%'.clean($_REQUEST['id']).'%', 'LIKE');
	$stop=$db->get('vehicle_master');
	foreach($stop as $stop_id){
		echo "<option value='".$stop_id['id']."'>".$stop_id['bus_no']."</option>";
	}
	exit;
}
/*********************************************bus Capacity***************************************************/
if(isset($_REQUEST['getTransportCapacity'])) {
	$db->where ('id',$_REQUEST['capacity']);
	$capacity=$db->get('vehicle_master');
    /*-------^capacity^---------*/
	$html="";
	if($_REQUEST['option']==1){
		$html="<option value='".$capacity[0]['id']."'>".$capacity[0]['bus_no']."</option>";
	}
	$db->where ('bus_id',$_REQUEST['capacity']);
	$using=$db->get('stu_sess_data',null,'count(bus_id) as num');
	$avail=$capacity[0]['veh_capacity']-$using[0]['num'];
	echo $capacity[0]['veh_capacity']."-".$avail."-".$html;
	exit;
}

/*********************************************update Transport***************************************************/
if(isset($_REQUEST['updateTransportData'])) {
	$data=array(
	 'is_transport'=>$_REQUEST['is_transport'],
	 'stop_id'=>$_REQUEST['stop'],
	 'bus_id'=>$_REQUEST['bus_no'],
	 'start_date'=>datestamp($_REQUEST['strt_date_tp']),
	 'end_date'=>datestamp($_REQUEST['end_date_tp'])
	);
	$db->where('stu_id',$_REQUEST['adm_no']);
	$db->update('stu_sess_data',$data);
	echo "DOne";exit;
}
/*********************************************update Transport***************************************************/
if(isset($_REQUEST['updatebasicinfo'])) {
	//$do_adm = $_REQUEST['do_adm'];
	$dob = $_REQUEST['dob'];
	$cast_cert_issue = $_REQUEST['cast_cert_issue'];
	unset($_REQUEST['secure_salt']);
	unset($_REQUEST['form']);
	unset($_REQUEST['dob']);
	unset($_REQUEST['do_adm']);
	unset($_REQUEST['cast_cert_issue']);
	unset($_REQUEST['s_adm_no']);
	unset($_REQUEST['rec_no']);

	//$data['do_adm'] = datestamp($do_adm);
	$data['dob'] = datestamp($dob);
	$data['cast_cert_issue'] = datestamp($cast_cert_issue);
	$data['adm_class'] = $_REQUEST['class'];

	$data1["class"] = $_REQUEST["class"];
	$data1["sec"] = $_REQUEST["sec"];
	$data1["new_old"] = $_REQUEST["new_old"];
	unset($_REQUEST["class"]);
	unset($_REQUEST["sec"]);
	unset($_REQUEST["new_old"]);
	
	$data['session'] = $_SESSION['SESSION'];
	
	foreach($_REQUEST as $key => $val) {
		$data[$key] = clean($val);
	}
	unset($data['accevate_erp']);	
	
	$db->where('adm_no', $_REQUEST['adm_no']);
	$db->where('session', $_SESSION['SESSION']);
	$last_id = $db->update ('seswise_class', $data1);

	$db->where('session', $_SESSION['SESSION']);
	$db->where('adm_no', $_REQUEST['adm_no']);
	$last_id = $db->update ('student', $data);

	unset($data);
	
	if(strlen($_REQUEST['mobile']) == 10) {
	$eschool_url = $db->getOne ("school_info", "eschool_url as cnt");
	
	//$message = "Dear Parents,%0A%0AThank you for admitting your ward ".$_REQUEST['stu_name']." in ".SCHOOLNAME.".%0ASchool's E-Portal Login details are: ".$eschool_url['cnt']."%0A%0ALogin: ".getusername($_REQUEST['stu_name'])."%0A%0APassword: Your Mobile Number%0A%0AWe are happy to have you as a part of our School Family.%0A%0AThank You.";
	//send_sms($_REQUEST['mobile'],$message);
	}
exit;
}

if(isset($_REQUEST['updatefeeinfo'])) {
	unset($_REQUEST['updatefeeinfo']);
	foreach($_REQUEST as $key => $val) {
		$data[$key] = clean($val);
	}
	$db->where("adm_no", $_REQUEST['adm_no']);
	$db->where("session", $_SESSION['SESSION']);
	$customFee = $db->get('stu_custom_fee');
	$data["session"] = $_SESSION["SESSION"];
	if(empty($customFee)){
		$id = $db->insert("stu_custom_fee", $data);
		$custom = array("custom_fee" => "YES");
		$db->where('adm_no', $_REQUEST['adm_no']);
		$db->where('session', $_SESSION['SESSION']);
		$last_id = $db->update ('seswise_class', $custom);
	}
	else{
		$db->where('adm_no', $_REQUEST['adm_no']);
		$last_id = $db->update ('stu_custom_fee', $data);
	}
	echo $db->getLastError();		
exit;
}

?>