<?php 
error_reporting(0);
$name = date('YmdHis')."-".rand(100,999);
if(isset($_REQUEST['visit'])) {
$newname="../pictures/visits/".$name.".jpg";
}
if(isset($_REQUEST['halfday'])) {
$newname="../pictures/halfday/".$name.".jpg";
}
if(isset($_REQUEST['enquiry'])) {
$newname="../pictures/enquiry/".$name.".jpg";
}
if(isset($_REQUEST['father'])) {
$newname="../pictures/father/".$name.".jpg";
}
if(isset($_REQUEST['guardian'])) {
$newname="../pictures/guardian/".$name.".jpg";
}
if(isset($_REQUEST['mother'])) {
$newname="../pictures/mother/".$name.".jpg";
}
if(isset($_REQUEST['student'])) {
$newname="../pictures/student/".$name.".jpg";
}
$file = file_put_contents( $newname, file_get_contents('php://input') );
if (!$file) {
	print "ERROR: Failed to write data to $filename, check permissions\n";
	exit();
}
echo $name.".jpg";
?>