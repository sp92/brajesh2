<?php 
include('../core.php');
error_reporting(0);
if($_SESSION['ACC_FEE']=='0') { exit; }
/************************************** FETCHING FEE AMOUNT *********************************/
				$search_name=clean($_REQUEST['search_name']);
				if(isset($search_name) && $search_name!=""){ 
							$db->where("stu_name", Array("LIKE" => $search_name."%" )); 
							$data_stu = $db->get('student'); 

							echo "<table  border='1'>";
							echo "<th>S.No.</th><th>Name</th><th>father's Name</th><th>Section</th><th>Class</th>";
							$i=0;
							foreach($data_stu as $value){$i++;
							echo  "<tr>";

							echo "<td>".$i."</td><td><a href='fee-status/".$value['adm_no']."'>".$value['stu_name']."</a></td><td>".$value['fat_name']."</td><td>".$value['sec']."</td><td>".$value['class']."</td>";
							echo  "</tr>";
							}
							echo "</table>";
							exit;
				}
/************************************** ADDING bounce *********************************/
if(isset($_REQUEST['feedbounce'])) {
	
	$str_id=explode(",",$_REQUEST['stu_id']);
	$stu_amount=explode(",",$_REQUEST['stu_amount']);
	$stu_rec=explode(",",$_REQUEST['stu_rec']);
	  for($x=0;$x<count($str_id);$x++){
		  $bounce_rec=array(
	  'rec_no'=>$stu_rec[$x],
	  'stu_id'=>$str_id[$x],
	  'adm_no'=>$str_id[$x],
	  'chq_no'=>$_REQUEST['chq_no'],
	  'amount'=>$stu_amount[$x],
	  'bounce_date'=>date('Y-m-d'),
	  'bounce_by'=>$_SESSION['SESS_NAME'],
	  'bounce_reason'=>$_REQUEST['comment'],
	  'session'=>$_SESSION['SESSION']
	    );
		$db->insert ('chq_bounce_master', $bounce_rec); 
		unset($bounce_rec);
	  }
	
	 $data=array(
	'cancelled'=>'1'
	);
	$db->where('chq_no',$_REQUEST['chq_no']);
	$db->update('fee_paid',$data);   
	/*-------------------------------------------------------------------*/
	
	$bounce=array(
	  'stu_id'=>$str_id[0],
	  'adm_no'=>$str_id[0],
	  'ehead_id'=>'ehead2',
	  'amount'=>$_REQUEST['bounce_amount'],
	  'session'=>$_SESSION['SESSION'],
	  'remark'=>$_REQUEST['comment']
	);
	$db->insert ('extra_charges', $bounce); 
	exit;
}
/*--------------------------above extra charges----------------------------------------------*/				
				
/************************************** FETCHING FEE AMOUNT *********************************/
$adm_no=clean($_REQUEST['adm_no']);
if($adm_no=='') { echo "<script>window.close();</script>"; }
$month1=clean($_REQUEST['drop1']);
$month2=clean($_REQUEST['drop2']);
$head_defineSession =  $db->rawQuery('SHOW COLUMNS FROM '.PREFIX.'fee_amount');
if(!empty($head_defineSession)){
	foreach($head_defineSession as $key=>$value){
		if (strpos($value['Field'], 'head') !== false) {
			$headNameArry[] = $value['Field'];
		}
	}
}
if($month1<$month2 or $month1==$month2)
{
	for($i=$month1; $i<$month2+1; $i++)
	{
		$m_sel[]=$i;
	}
}
foreach($m_sel as $range)
{
	if (array_key_exists($range, $m_array)) {
		$m_range[]=$m_array[$range];
	}
}

// Old way to get record
//$db->where ('adm_no', $adm_no);
//$data_stu = $db->getOne ("student");

$db->join("stu_sess_data sc", "s.adm_no = sc.adm_no", "LEFT");
$db->where ('s.adm_no', $adm_no);
$db->where ('sc.session', $_SESSION["SESSION"]);
$data_stu = $db->getOne("student s");

if($data_stu['is_transport'] == 'YES') {
	$db->where ('session', $_SESSION['SESSION']);
	$db->where ('adm_no', $adm_no);
	$tpt_stu = $db->getOne ("stu_tpt_fee");
}
if($data_stu['custom_fee'] == 'YES') {
	$db->where ('session', $_SESSION['SESSION']);
	$db->where ('adm_no', $adm_no);
	$fee_stu = $db->getOne ("stu_custom_fee");
} else {
	$db->where ('session', $_SESSION['SESSION']);
	$db->where ('class', $data_stu['class']);
	$db->where ('new_old', $data_stu['new_old']);
	$db->where ('fee_cat', $data_stu['fee_cat']);
	$db->where ('type', $data_stu['type']);
	$fee_stu = $db->getOne ("fee_amount");	
}
$db->where('session', $_SESSION['SESSION']);
$head = $db->get ("head_define",1);
if ($db->count > 0) {
	foreach ($head as $u) { 
		for ($i = 1; $i <= count($headNameArry); $i++) { 
			$var = 'head'.$i;
			$heads[] = $u[$var];
		}
	}
}
$heads2 = array_filter($heads);
$heads_count = count($heads2);

foreach($m_range as $m) {
	for ($i=1; $i <= $heads_count; $i++) {
		$head_name = "head".$i."_".$m;
		$head = "head".$i."_".$m;
		$total_fee[$head] = $fee_stu[$head_name];
	}
}
if($data_stu['is_transport'] == 'YES') {
	foreach($m_range as $m) {
		$head_name = "tp_".$m;
		$fee = $tpt_stu[$head_name];
		$tpt_fee[$m] = intval($fee);
		unset($fee);
	}
}
foreach($m_range as $m) {
for ($i=1; $i <= $heads_count; $i++) {
	$head_name = "head".$i."_".$m;
	$db->where ('session', $_SESSION['SESSION']);
	$db->where ('adm_no', $adm_no);
	$db->where ('cancelled', '0');
	$db->where ("month", '%'.$m.'%', 'LIKE');
	
	$h_m = "sum(head".$i.") as h".$i;
	$h_m2 = "h".$i;
	$fee_paid = $db->getOne ("fee_paid", $h_m);
	$paid_fee[$head_name] = $fee_paid[$h_m2];
}
}
foreach($m_range as $m) {
	$db->where ('session', $_SESSION['SESSION']);
	$db->where ('adm_no', $adm_no);
	$db->where ('cancelled', '0');
	$db->where ("month", '%'.$m.'%', 'LIKE');
	$fee_paid = $db->getOne ("fee_paid", "sum(transport) as tp");
	$paid_fee_tp[$m] = $fee_paid["tp"];
}

//var_dump($total_fee);
//echo "<br>";
//echo "<br>";
//var_dump($tpt_fee);
//echo "<br>";
//echo "<br>";
//var_dump($paid_fee);
//echo "<br>";
//var_dump($paid_fee_tp);
$mode = $_REQUEST['mode'];
?>
<center>
<div id="divmsg"></div>

<form name="myForm" id="fee">
<input type="hidden" name="adm_no" value="<?php echo $adm_no; ?>" />
<input type="hidden" name="class" value="<?php echo $data_stu['class']; ?>" />
<input type="hidden" name="sec" value="<?php echo $data_stu['sec']; ?>" />
<?php foreach($m_range as $m) { ?>
	<input type='hidden' name='<?php echo $m; ?>'  />
<?php } ?>

<table class="table table-bordered table-condensed" style="width: 65%;font-size: 12px;<?php if($mode=='manual') { ?> display:none; <?php } ?>" >
<tr style='background-color: azure;'>
<?php 
$n=1;
foreach($heads2 as $h_name) {
if ($n % 4 == 0) {
  print "<tr style='background-color: azure;'>";
}
?>

<td><?php echo $h_name; ?><br/>
<input type='text' name='head<?php echo $n; ?>_total' id="head<?php echo $n; ?>_total" tabindex=-1 class="form-control" value='<?php
foreach($m_range as $m) {
	$h_m = "head".$n."_".$m;
	$t_fee[] = $total_fee[$h_m] - $paid_fee[$h_m];
	$tot_amount[] = $total_fee[$h_m] - $paid_fee[$h_m];
}
echo array_sum($t_fee);
unset($t_fee);
?>' readonly /></td>
 <?php 
$main=getCurrentDue($adm_no,$m_array[$month2]);
?> 
<?php
if ($n % 3 == 0) { print "</tr>"; }
$n++;  
}
?>
</tr>
<?php if($data_stu['is_transport'] == 'YES') { ?>
<tr style='background-color: azure;'>
<td>TRANSPORT FEE<br/>
<input type='text' name='transport' id="transport_total" tabindex=-1 class="form-control" value='<?php
if($main['transport_fees']){echo $main['transport_fees'];}else{echo "0";}
?>' readonly /></td>
</tr>
<?php } ?>
</table>


<table class="table" <?php if($mode=='auto') { ?> style="display:none;" <?php } ?> >
<tr>
<td></td>
<?php 
$n=1;
foreach($heads2 as $h_name) {
  print "<th style='background-color: azure;'>".$h_name."</th>";
}
if($data_stu['is_transport'] == 'YES') {   print "<th style='background-color: azure;'>TRANSPORT FEE</th>"; } ?>
</tr>

<?php foreach($m_range as $m) { ?>
<tr>
<td><?php echo strtoupper($m); ?></td>
<?php for ($i=1; $i <= $heads_count; $i++) { 
$h_m = "head".$i."_".$m;
$fee_left = $total_fee[$h_m] - $paid_fee[$h_m];
?>
<td>
<input type='text' name='<?php echo $h_m; ?>' class="form-control <?php echo "head".$i; ?>"  value='<?php echo $fee_left; ?>'  />
<script>
$('input[name=<?php echo $h_m; ?>]').jStepper({minValue:0, maxValue:<?php echo $fee_left; ?>});
var <?php echo $h_m; ?>_h = <?php echo $fee_left; ?>;
</script>
</td>
<?php } ?>
<td>
<input type='text' name='tp_<?php echo $m; ?>' class="form-control transport" value='<?php echo $tpt_fee[$m] - $paid_fee_tp[$m]; ?>'  />
<script>
$('input[name=<?php echo $m; ?>]').jStepper({minValue:0, maxValue:<?php echo $tpt_fee[$m] - $paid_fee_tp[$m]; ?>});
var tp_<?php echo $m; ?>_h = <?php echo $tpt_fee[$m] - $paid_fee_tp[$m]; ?>;
</script>
</td>
</tr>
<?php } ?>

</table>
<table class="table table-bordered table-condensed" id="extra" style="width: 65%;font-size: 12px;">
<tr>
<?php 
	$head=getHeadingOfFine($adm_no);
	 foreach($head as $key => $val){
		 foreach($val as $key2 => $val2) {
			 $label = $key2;
			 $label_amt = $val2; 
		 } 
		 $extra_total[] = $label_amt;
		 ?>
     <td><strong><?php echo $label;?>: </strong>
     <input type="text" name="<?php echo $key;?>" class="form-control extra" value="<?php echo $label_amt;?>" <?php if($mode=='auto') { ?> readonly <?php } ?> />
	 <script>
$('input[name=<?php echo $key;?>]').jStepper({minValue:0, maxValue:<?php echo $label_amt;?>});
var <?php echo $key;?>_h = <?php echo $label_amt;?>;
</script>
	 
	 </td>	
 <?php $x++;} ?>
</tr>
</table>
<table class="table table-bordered table-condensed" style="width: 65%;font-size: 12px;">

			<tbody>
				<tr style="background-color: beige;">
					<td><strong>Late Fine: </strong> <input type="text" name="late_fine" id="late_fine" class="form-control" value="<?php echo $main['late_total'];?>" required />
					<script>$('#late_fine').jStepper({minValue:0});</script></td>				
					<td><strong>Discount: </strong> 
					<select name="discount" id="discount" class="form-control" style="width:204px">
					    <option value="0">0</option>
						<?php foreach($main['disc_amount'] as $val){
							?>
							<option value="<?php echo $val['id']."*".$val['approved_amount'];?>">Rs. <?php echo $val['approved_amount'];?> <?php echo substr($val['approved_remark'],0,20)?></option>
						<?php }?>
					</select>
					</td>				
					<td><strong>Deposit: </strong><input type="text"  class="form-control" name="total" id="total" value="<?php echo (array_sum($tot_amount)+$main['fine'])+array_sum($extra_total)+$main['transport_fees']; ?>" <?php if($mode=='manual') { ?> readonly <?php } ?> />
					<script>$('#total').jStepper({minValue:0,maxValue:<?php echo (array_sum($tot_amount)+$main['fine'])+array_sum($extra_total)+$main['transport_fees']; ?>});</script></td>
					<td><b>Total Amount:</b><br><b>Rs.</b><span id='total_payable' style="font-size: 20px;color: red;"><?php echo $main['full_total']; ?></span>
					<input type="hidden" name="left" id="left" value="0" />
					</td>
				</tr>
				<tr style="background-color: beige;">
					
					<td colspan=4>
					<b>Mode of Payment : </b>
					&;&nbsp;&nbsp;&nbsp;
					
					<label class="radio-inline" >
				<input type="radio" class="radio" name="mode" value="CASH" checked />
				CASH
			</label>
			<label class="radio-inline" >
				<input type="radio" class="radio" name="mode" value="CHEQUE"  />
				CHEQUE
			</label>
			</td>
			</tr>
			
			<tr style="background-color: beige;">
					<td colspan=4>
			Cheque No:<input type="text" name="chq_no" id="chq_no" placeholder="Cheque No." style=" width: 100px;" disabled />
			
			MICR Code:<input type="text" name="micr_code" id="micr_code" placeholder="MICR CODE" style=" width: 100px;" disabled />
			
			Bank Name:<input type="text" name="chq_bnk" id="chq_bnk" placeholder="Bank Name" style=" width: 100px;" disabled />
			
			Branch Name:<input type="text" name="chq_branch" id="chq_branch" placeholder="Branch Name" style=" width: 100px;" disabled />
			<br><br>
			Date:&nbsp; &nbsp;<input type="text" name="chq_date" id="chq_date" placeholder="Cheque Date" style=" width: 100px;" disabled class="datepicker"/>
			
			Amount:&nbsp; &nbsp;<input type="text" name="chq_amt" id="chq_amt" placeholder="Cheque Amount" style=" width: 100px;" disabled readonly />
			
			</td>
					
				</tr>
				<tr style="background-color: beige;">
					<td colspan="4" ><strong>Remark: </strong><input type="text"  class="form-control" name="remark"  /></td>				
				</tr>
				<tr style="background-color: beige;">
					
					<td colspan=4>
					<center>
					<input type="submit" class="btn btn-danger" id="pay" value="Deposit Fee" />
					</form>
					
					<button class="btn btn-success" onclick="$.popupWindow('receipt-preview', { width:800, height:600, createNew: true })" value="Preview Receipt" >Preview Receipt</button>
					
					
					</center>
</td>


				</tr>
			</tbody>
		</table>




  </center>

  <script>
  
  $('#fee input').keyup(function(event) {
	<?php if($mode=='auto') { ?>
	var total = $('#total').val();
	
	var discount2 = document.getElementById('discount').value;
	   split= discount2.split("*");
	   discount = split[1];
	var late_fine = document.getElementById('late_fine').value;
	
	var total_payable ;
	total_payable = parseInt(total)+parseInt(late_fine)-parseInt(discount);
	document.getElementById('total_payable').innerHTML=total_payable;
	
	var fee_orig = <?php echo array_sum($tot_amount); ?>;
	
	<?php for ($i=1; $i <= $heads_count; $i++) { ?>
		var <?php echo "head".$i; ?>_total = 0;
	<?php } ?>
	
	<?php foreach($head as $key => $val){ ?>
		var <?php echo $key; ?> = 0;
	<?php $x++; } ?>
	
	var transport_total = 0;
	
	<?php  
	foreach($head as $key => $val){
		 foreach($val as $key2 => $val2) {
			 $label_amt = $val2; 
		 }  ?>
	if(<?php echo $key; ?>_h <= total) { var total = total - <?php echo $key; ?>_h;	$('[name=<?php echo $key; ?>').val(<?php echo $key; ?>_h);  }
	else { 	$('[name=<?php echo $key; ?>]').val(total);  var total = 0;	}
	<?php } ?>
	
	
	<?php 
	foreach($m_range as $m) { 
	for ($i=1; $i <= $heads_count; $i++) { 
		$h_m = "head".$i."_".$m;
	?>
	
	if(<?php echo $h_m; ?>_h <= total) { var total = total - <?php echo $h_m; ?>_h; $('[name=<?php echo $h_m; ?>]').val(<?php echo $h_m; ?>_h); <?php echo "head".$i; ?>_total+= Number(<?php echo $h_m; ?>_h);	}
		else { $('[name=<?php echo $h_m; ?>]').val(total); <?php echo "head".$i; ?>_total+= Number(total); var total = 0; }
	<?php } ?>
	
	if(tp_<?php echo $m; ?>_h <= total) { var total = total - tp_<?php echo $m; ?>_h;	$('[name=tp_<?php echo $m; ?>]').val(tp_<?php echo $m; ?>_h); transport_total+= Number(tp_<?php echo $m; ?>_h); }
	else { 	$('[name=tp_<?php echo $m; ?>]').val(total); transport_total+= Number(total); var total = 0;	}
	<?php } ?>
	
	
	
	
	<?php for ($i=1; $i <= $heads_count; $i++) { ?>
	if($('#<?php echo "head".$i; ?>_total').length) { document.getElementById('<?php echo "head".$i; ?>_total').value = <?php echo "head".$i; ?>_total; }
	<?php } ?>
	
	if($('#transport_total').length) { document.getElementById('transport_total').value = transport_total; }	
	
	<?php } ?>
	<?php if($mode=='manual') { ?>
	
	<?php for ($i=1; $i <= $heads_count; $i++) { ?>
	var <?php echo "head".$i; ?>_total = 0;
	$('.<?php echo "head".$i; ?>').each(function() {
		<?php echo "head".$i; ?>_total+= Number($(this).val());
	});
	if($('#<?php echo "head".$i; ?>_total').length) { document.getElementById('<?php echo "head".$i; ?>_total').value = <?php echo "head".$i; ?>_total; }
	<?php } ?>
	
	
	
	var extra_total = 0;
	$('.extra').each(function() {
		extra_total+= Number($(this).val());
	});
	//if($('#transport_total').length) { document.getElementById('transport_total').value = transport_total;  }
	
	var transport_total = 0;
	$('.transport').each(function() {
		transport_total+= Number($(this).val());
	});
	if($('#transport_total').length) { document.getElementById('transport_total').value = transport_total;  }
	
	var discount = document.getElementById('discount').value;
	var late_fine = document.getElementById('late_fine').value;
	
	var total_payable ;
total_payable = parseInt(late_fine)<?php for ($i=1; $i <= $heads_count; $i++) { ?>+parseInt(<?php echo "head".$i; ?>_total)<?php } ?>+parseInt(transport_total)-parseInt(discount)+parseInt(extra_total);
document.getElementById('total').value=total_payable;
	document.getElementById('total_payable').innerHTML=total_payable;
	
	<?php } ?>
	$("#chq_amt").val(total_payable);
});
  
  
  $('.radio').click(function(){
    if ($(this).is(':checked'))
    {
      var value = $(this).val();
		if(value=='CASH') {
			$("#chq_no").attr('disabled','disabled');
			$("#chq_bnk").attr('disabled','disabled');
			$("#micr_code").attr('disabled','disabled');
			$("#chq_branch").attr('disabled','disabled');
			$("#chq_date").attr('disabled','disabled');
			$("#chq_amt").attr('disabled','disabled');
			$("#chq_amt").val("");
		}
		if(value=='CHEQUE') {
			$("#chq_no").attr('disabled',false);
			$("#chq_bnk").attr('disabled',false);
			$("#micr_code").attr('disabled',false);
			$("#chq_branch").attr('disabled',false);
			$("#chq_date").attr('disabled',false);
			$("#chq_amt").attr('disabled',false);
			var chq_amt = $("#total").val();
			$("#chq_amt").val(chq_amt);
		}
    }
});
$( "#micr_code" ).keyup(function() {
  var micrcode = $(this).val();
	$.ajax({
			type: 'POST',
			url: 'function/getbankmicr',
			data: {micrcode: micrcode},
			dataType: 'json',
			success: function (data) {
				if(data.fail == 'fail'){
					$("#chq_bnk").attr('disabled',false);
					$("#chq_branch").attr('disabled',false);
					$("#chq_bnk").val('');
					$("#chq_branch").val('');
				}
				else{
					
					$("#chq_bnk").val(data.bank_name);
					$("#chq_branch").val(data.branch_name);
					$("#chq_bnk").attr('disabled','disabled');						
					$("#chq_branch").attr('disabled','disabled');
				}
			}
	});
});
$('#fee').submit(function(event) {
	if(confirm('Confirm Fee Deposit?' )) {
		$("#pay").attr('disabled','disabled');
		$("#getmonth").hide();
		$("#fee").hide();
		$("#successmsg").html('<h5><center><b><span style="font-weight:bold;color:red;">Depositing fee and preparing receipt. Please wait......</span></b></center></h5>');
		event.preventDefault();
                $.ajax({
                        type: 'POST',
                        url: 'fee-deposit',
                        data: $(this).serialize(),
						success: function (data) {
							$('#divmsg').html(data);
						}
                });
	} else {
		event.preventDefault();
		return false;
	}
});
  </script>