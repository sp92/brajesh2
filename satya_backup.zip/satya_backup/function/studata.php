<?php 
include('../core.php');




exit();
?>