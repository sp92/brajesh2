<?php 
include('../core.php');


if(isset($_REQUEST['load'])) {
	$out = array(
		'radiant_9th' => $db->get ("student")
	);
	echo json_encode($out);
}

?>