<?php 
include('../core.php');
error_reporting(E_ALL);
/*----------------------------------proceeding form of frontdesk--------------------------------------------------*/
if(isset($_REQUEST['enq_no']) && $_REQUEST['page']=="frontdesk-add") {
    unset($_REQUEST['page']);
	$data_id=clean($_REQUEST['enq_no']);
	$date = datestamp($_REQUEST['date']);
	$dob = datestamp($_REQUEST['dob']);
	unset($_REQUEST['enq_no']);
	unset($_REQUEST['date']);
	unset($_REQUEST['dob']);
	
	foreach($_REQUEST as $key => $val) {
		$data[$key] = clean($val);
	}
	$data['date'] = $date;
	$data['dob'] = $dob;
	
	$db->where('id',$data_id);
	$last_id = $db->update ('inquiry', $data);
	exit;
}
/*------------------------------student----info----------------------------------*/
if(isset($_REQUEST['stu_info'])) {
    $stu_id=explode("-",$_REQUEST['stu_data']);
	$db->where('id',$stu_id[0]);
	$info=$db->get('student',null,'photo_stu,photo_fat,photo_mot,photo_guard');
	 ?>
	 <div  class="col-md-3">
	 <h3>Student Image</h3><br>
	 <img src="pictures/photo_stu/<?php echo ($info[0]['photo_stu']) ? $info[0]['photo_stu'] : 'images.jpg'?>" width="200" height="200" title="Student image">
	  </div>
	  <div  class="col-md-3">
	<h3>Father Image</h3><br>
	  <img src="pictures/photo_fat/<?php echo ($info[0]['photo_fat']) ? $info[0]['photo_fat'] : 'images.jpg'?>" width="200" height="200" title="Father Image">
	  </div>
	  <div  class="col-md-3">
	  <h3>Mother Image</h3><br>
	  <img src="pictures/photo_mot/<?php echo ($info[0]['photo_mot']) ? $info[0]['photo_mot'] : 'images.jpg'?>" width="200" height="200" title="Mother image">
	  </div>
	  <div  class="col-md-3">
	  <h3>Guardian Image</h3><br>
	  <img src="pictures/photo_guard/<?php echo ($info[0]['photo_guard']) ? $info[0]['photo_guard'] : 'images.jpg'?>" width="200" height="200" title="Guardian image">
	  </div>
	 <?php
	exit;
}
/*---------------------------------------interview Scheduled-----------------------------------------------------------------*/
if(isset($_REQUEST['enq_no']) && $_REQUEST['page']=="frontdesk-schedule-interview") {
	$date=datestamp($_REQUEST['interview_date']);
	$date_full=$date." ".$_REQUEST['hour'].":".$_REQUEST['minute'].":00";
	$data=array(
	   "adm_status"=>"Interview",
	   "interview_date"=>$date_full,
	   "principal"=>clean($_REQUEST['principal']),
	   "scheduler_remark"=>clean($_REQUEST['scheduler_remark'])
	);

    $db->where('id',clean($_REQUEST['enq_no']));
	$last_id = $db->update ('inquiry', $data);
	exit;     
}

/*----------------------------------approvalinfrontdesk--------------------------------------------------*/
if(isset($_REQUEST['enq_no']) && $_REQUEST['page']=="frontdesk-addmission-approval") {
   $data=array(
	   "adm_status"=>clean($_REQUEST['adm_status']),
	   "disc_approved"=>clean($_REQUEST['disc_approved']),
	   "approve_date"=>date('Y-m-d'),
	   "approvedby"=>$_SESSION['SESS_NAME'],
	   "approvalremark"=>clean($_REQUEST['approvalremark'])
   );
   	
	$db->where('id',$_REQUEST['enq_no']);
	$last_id = $db->update ('inquiry', $data);
	exit;       
}


/************************************** FETCHING STUDENT LIST FOR AUTOCOMPLETE *********************************/
if(isset($_REQUEST['stu_details'])) {
$return_arr = array();

// Old way to get record
//$db->where ("is_shown", '1');
//$db->where ("tc_issue", '1', '<>');
//$db->where ("stu_name", '%'.clean($_GET['term']).'%', 'LIKE');
//$user = $db->get ("student");

$db->join("stu_sess_data sd", "s.id=sd.stu_id", "LEFT");
$db->where ("s.is_shown", 'YES');
$db->where ("s.tc_issue", 'YES', '<>');
$db->where ('sd.session', $_SESSION["SESSION"]);
$db->where ('s.stu_name', '%'.clean($_GET['term']).'%', 'LIKE');
$user = $db->get("student s", null, "s.adm_no, s.stu_name, s.fat_name, sd.class, sd.sec");
 	foreach ($user as $u) { 
		$row_array['value'] = $u['adm_no']." - ".$u['stu_name']." - ".$u['fat_name']." - ".$u['class']." - ".$u['sec'];
        $row_array['stu_name'] = $u['adm_no']." - ".$u['stu_name']." - ".$u['fat_name']." - ".$u['class']." - ".$u['sec'];
		array_push($return_arr,$row_array);
	}
echo json_encode($return_arr);

exit();
}

/************************************** SETTING SMS FOR FRONTDESK *********************************/
if(isset($_REQUEST['opt']) and isset($_REQUEST['val']) and isset($_REQUEST['id'])) {
$data = Array (
	$_REQUEST['opt'] => $_REQUEST['val']
);
$db->where ('id', $_REQUEST['id']);
$db->update ('fd_master', $data);
exit();
}

/************************************** ADDING FEEDBACK *********************************/
if(isset($_REQUEST['form']) AND $_REQUEST['form']=='frontdesk-feedback-add' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {
$m_type = clean($_REQUEST ['m_type']); 
$name = clean($_REQUEST ['name']); 
$mobile = clean($_REQUEST ['mobile']); 
$message = clean($_REQUEST ['message']); 
$stu_name = clean($_REQUEST ['stu_name']); 
	
	$data = clean_data($_REQUEST);
	$last_id = $db->insert ('feedback', $data);

if($stu_name<>'') {
	$later=  "%0AFor (".$stu_name.") "; 
}
$message2 = "Thank you for your ".$m_type.". Your reference no. is : ".$last_id."%0AWe will inform you with SMS for any updates.%0AThank You%0A-".SCHOOLNAME_SHORT."-";
send_sms($mobile,$message2);

$mobile = array();
$message2 = "Received ".$m_type." %0Afrom ".$name.$later."%0AMessage: ".$message;
$db->where ("complain", '1');
$user = $db->get ("fd_master");
foreach ($user as $u) { 
	$mobile[] =$u['mobile'];
}
$mobile2 = implode(',', $mobile);
send_sms($mobile2,$message2);
exit;
}

if(isset($_REQUEST['feedcomment'])) {
	
	$mobile=clean($_REQUEST['mobile']);
	$comment=clean($_REQUEST['comment']);
	$m_type=clean($_REQUEST['m_type']);
	$message=clean($_REQUEST['message']);
	$status='1';
	$id=clean($_REQUEST['id']);
	$data=array(
	'comment'=>$comment,
	'status' =>$status,
	'user'   =>$_SESSION['SESS_NAME']
	);
    
	$db->where('id',$id);
	$db->update('feedback',$data); 
	
	
if(strlen($mobile)==10) {

$db->where('id','1');
$sms_var=$db->get('smsapi');

$url = $sms_var[0]['api_url'];
$api_key = $sms_var[0]['api_key'];
$sender_id = $sms_var[0]['sender_id'];


$message2 = "Following action has been taken against your ".$m_type." ".$message." (REF No. ".$id.")%0A".$comment."%0AThank You%0A-BBIS-";
$myvars = 'workingkey='.$api_key.'&sender='.$sender_id.'&to='.$mobile.'&message='.$message2.'';
//echo $myvars;
$ch = curl_init( $url );
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, $myvars);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec( $ch );
}
exit;
}

/************************************** ADDING VISITORS *********************************/
if(isset($_REQUEST['form']) AND $_REQUEST['form']=='frontdesk-visitors-add' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {
$towhom = explode(':::', clean($_REQUEST ['towhom'])); 
	unset($_REQUEST['secure_salt']);
	unset($_REQUEST['form']);
	foreach($_REQUEST as $key => $val) {
		$data[$key] = clean($val);
	}
	unset($data['towhom']);
	unset($data['accevate_erp']);
	$data['towhom'] = $towhom[0];
	$data['user'] = $_SESSION['SESS_NAME'];
	$data['date'] = date('Y-m-d H:i:s');
	$data['session'] = $_SESSION['SESSION'];
	
	$last_id = $db->insert ('visits', $data);
	
	$name = clean($_REQUEST ['name']); 
	$address = clean($_REQUEST ['address']); 
	$regarding = clean($_REQUEST ['regarding']); 
	
	$message2 = "Dear Sir/Mam, ".$name." came from ".$address." to meet you regarding ".$regarding.". Please respond by clicking this link :- http://".$_SERVER['HTTP_HOST']."/respond?visit=".$last_id;
	send_sms($towhom[1],$message2);
}


/************************************** ADDING STUDENT HALFDAY *********************************/

if(isset($_REQUEST['form']) AND $_REQUEST['form']=='frontdesk-halfday-add-student' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {

$stu_name = explode('-', clean($_REQUEST ['stu_name'])); 
$adm_no = $stu_name[0];
$name = $stu_name[1];
$fat_name = $stu_name[2];
$class = $stu_name[3];
$sec = $stu_name[4];
$pic_name = $_REQUEST['pic'];

	unset($_REQUEST['secure_salt']);
	unset($_REQUEST['form']);
	foreach($_REQUEST as $key => $val) {
		$data[$key] = clean($val);
	}
	unset($data['related']);
	unset($data['stu_name']);
	unset($data['stu_name']);
	unset($data['accevate_erp']);
	$data['adm_no'] = $adm_no;
	$data['name'] = $name;
	$data['fat_name'] = $fat_name;
	$data['class'] = $class;
	$data['sec'] = $sec;
	$data['user'] = $_SESSION['SESS_NAME'];
	$data['date'] = date('Y-m-d H:i:s');
	$data['session'] = $_SESSION['SESSION'];
	
	
	if($_REQUEST['infrm']=='on' and isset($_REQUEST['infrm_img'])) {
		$to_folder = $_REQUEST['infrm_img'];
		$from_folder = '../pictures/halfday/'.$pic_name;
		$to_folder = '../pictures/'.$to_folder.'/'.$pic_name;
		
		copy($from_folder, $to_folder);
	}
	
	unset($data['infrm']);
	unset($data['infrm_img']);
	
	$last_id = $db->insert ('halfday', $data);
	$lata=array(
	$_REQUEST['infrm_img']=>$pic_name
	);
	$db->where('id',$adm_no);
	 $db->update ('student',$lata);
	
$taker = clean($_REQUEST ['takenby']); 
$relation = clean($_REQUEST ['takenrelation']); 
$message = clean($_REQUEST ['reason']); 

$message2 = "Dear Parents, Your ward ".$name." has been taken back to home by ".$taker." (".$relation.") on Half Day Leave.%0AReason provided : ".$message."%0AKindly acknowledge.%0A-".SCHOOLNAME_SHORT."-";

$cols = Array ("mobile");
$db->where ("adm_no", $adm_no);
$users = $db->get ("student", null, $cols);
if ($db->count > 0) {
    foreach ($users as $u) { 
        $mobile2 = $u['mobile'];
    }
}
send_sms($mobile2,$message2);

$mobile = array();
$message2 = "Dear Sir/Mam, ".$name." (".$class."-".$sec.") has taken half day leave%0AReason: ".$message;
$db->where ("halfday_stu", '1');
$user = $db->get ("fd_master");
foreach ($user as $u) { 
	$mobile[] =$u['mobile'];
}
$mobile2 = implode(',', $mobile);
send_sms($mobile2,$message2);
echo "<input type='button' class='btn btn-primary'  value='Print' onclick='print_gatepass(".$last_id.");'>";
exit;
}

/************************************** ADDING TEACHER HALFDAY *********************************/
if(isset($_REQUEST['form']) AND $_REQUEST['form']=='frontdesk-halfday-add-teacher' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {
$name = clean($_REQUEST ['name']); 
$message = clean($_REQUEST ['reason']); 
$data = clean_data($_REQUEST);
$last_id = $db->insert ('halfday', $data);

$mobile = array();
$message2 = "Dear Sir/Mam, ".$name." has taken Half Day Leave today.%0AReason provided : ".$message;
$db->where ("halfday_tr", '1');
$user = $db->get ("fd_master");
foreach ($user as $u) { 
	$mobile[] =$u['mobile'];
}
$mobile2 = implode(',', $mobile);
send_sms($mobile2,$message2);
exit;
}

/************************************** ADMISSION INQUIRY *********************************/
if(isset($_REQUEST['form']) AND $_REQUEST['form']=='frontdesk-inqui-add' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {

unset($_REQUEST['secure_salt']);
unset($_REQUEST['form']);
unset($_REQUEST['rec_date']);
$stu_name = strtoupper(clean($_REQUEST['stu_name']));
$mobile = strtoupper(clean($_REQUEST['mobile']));
$session = $_SESSION['SESSION'];
foreach($_REQUEST as $key => $val) {
	$data[$key] = strtoupper(clean($val));
}
$data['date'] = date('Y-m-d');
unset($data['accevate_erp']);

$db->insert ('inquiry', $data);
$message2 = "Thank you for your contacting ".SCHOOLNAME." for the admission of your ward ".$stu_name.". Have a Good Day ahead.";
send_sms($mobile,$message2);
exit;

}

?>