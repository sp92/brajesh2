<?php 
include('../core.php');
error_reporting(E_ALL);
include('comm-functions.php');
/************************************** GET CREDITS *********************************/
if(isset($_REQUEST['option']) and $_REQUEST['option'] == 'checkbal') {
$bal_status = get_sms_bal();
$api_info = api_data();

$bal = json_decode($bal_status, true);
echo $bal['data']['credits'];

exit();
}



?>