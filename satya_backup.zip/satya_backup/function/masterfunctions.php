<?php 
include('../core.php');

if(isset($_REQUEST['form']) AND $_REQUEST['form']=='master-school' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {
	unset($_REQUEST['secure_salt']);
	unset($_REQUEST['form']);
	
	foreach($_REQUEST as $key => $val) {
		$data[$key] = clean($val);
	}
	unset($data['accevate_erp']);
	$db->where ('id', 1);
	if ($db->update ('school_info', $data))
		echo '1';
	else
		echo '0';
}

if(isset($_REQUEST['form']) AND $_REQUEST['form']=='master-document' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {
	unset($_REQUEST['secure_salt']);
	unset($_REQUEST['form']);
	
	foreach($_REQUEST as $key => $val) {
		$data[$key] = strtoupper(clean($val));
	}
	unset($data['accevate_erp']);
	$db->where ('id', 1);
	if ($db->update ('certificate', $data))
		echo '1';
	else
		echo '0';
}
if($_REQUEST['mode']=="update") {
	$data = Array (
    'stop' => $_REQUEST['stop'],
    );
	$db->where ('id', $_REQUEST['id']);
	$db->update ('route_master', $data);
	exit;
}
if($_REQUEST['mode']=="update_vehicle") {
	$data = Array (
    'stop' => $_REQUEST['stop'],
    );
	$db->where ('id', $_REQUEST['id']);
	$db->update ('vehicle_master', $data);
	exit;
}
?>