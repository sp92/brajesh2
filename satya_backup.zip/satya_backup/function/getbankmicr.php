<?php 
include('../core.php');
error_reporting(0);

$micr = $_REQUEST["micrcode"];
$db->where('micrcode',$micr);
$micrArr=$db->get('bank_detail');
//$micrArr = mysql_fetch_assoc(mysql_query("SELECT * from ".PREFIX."bank_detail where micrcode = '".$micr."'"));
if(!$micrArr){
	echo json_encode(array("fail"=>'fail'));
}
else{
	echo json_encode($micrArr[0]);
}
	
exit;
?>