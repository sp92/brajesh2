<?php
	session_name("accevate_erp");
	session_start(); 
	require_once('../lib/config.php');
	error_reporting(0);

	$login = clean($_REQUEST['login']);
	$password = clean($_REQUEST['password']);
	$session = clean($_REQUEST['session']);
	if($login == '') {
		$errmsg_arr[] = 'Login ID missing';
		$errflag = true;
		echo "<script>alert('Login ID is missing.');</script>";
	}
	if($password == '') {
		$errmsg_arr[] = 'Password missing';
		$errflag = true;
		echo "<script>alert('Password is missing.');</script>";
	}
	if (clean($_REQUEST['vercode']) != $_SESSION["vercode"] OR $_SESSION["vercode"]=='') { 
		session_write_close();
		//header("location: ./login");
		echo "failed1";
		exit();
	}
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		//header("location: ./login");
		setcookie('login', $login, time()+60*60*6, '/');
		setcookie('session', $session, time()+60*60*6, '/');
		echo "success";
		exit();
	}
	global $db;
	$db->where ("username", $login);
	$db->where ("password", $password);
	$user = $db->get ("admin",1);
	if ($db->count > 0) {
			foreach ($user as $u) { 
				$id = $u['id'];
				$name = $u['name'];
				$master = $u['master'];
				$admin = $u['admin'];
				$student = $u['student'];
				$fee = $u['fee'];
				$frontdesk = $u['frontdesk'];
				$counselling = $u['counselling'];
				$admission = $u['admission'];
				$attendance = $u['attendance'];
				$transport = $u['transport'];
				$certificate = $u['certificate'];
				$comm = $u['comm'];
				$setting = $u['setting'];
				$group = $u['group'];
				$location = $u['location'];
				$logged = $u['is_log'];
				$status = $u['status'];
				$salt = rand(1,1000000000);
			}
			if($logged=='N/A')
			{
				session_regenerate_id();
				$_SESSION['SESS_ID'] = $id;
				$_SESSION['SESS_NAME'] = $name;
				$_SESSION['ACC_MASTER'] = $master;
				$_SESSION['ACC_ADMIN'] = $admin;
				$_SESSION['ACC_STUDENT'] = $student;
				$_SESSION['ACC_FEE'] = $fee;
				$_SESSION['ACC_FRONTDESK'] = $frontdesk;
				$_SESSION['ACC_COUNSELLING'] = $counselling;
				$_SESSION['ACC_ADMISSION'] = $admission;
				$_SESSION['ACC_ATTENDANCE'] = $attendance;
				$_SESSION['ACC_TRANSPORT'] = $transport;
				$_SESSION['ACC_CERTIFICATE'] = $certificate;
				$_SESSION['ACC_COMM'] = $comm;
				$_SESSION['ACC_SETTING'] = $setting;
				$_SESSION['ACC_GROUP'] = $group;
				$_SESSION['LOCATION'] = $location;
				$_SESSION['SECURE_SALT'] = $salt;
				$_SESSION['SESSION'] = $session;
				session_write_close();
				setcookie('login', $login, time()+60*60*6, '/');
				setcookie('session', $session, time()+60*60*6, '/');
				/*mysql_query("INSERT INTO ".PREFIX."loghistory (user,ip,date) Values ('".$login."','".get_client_ip()."','".date("Y-m-d H:i:s")."')");*/
				echo "success";
				exit();
			}
			elseif($logged=='FALSE' && $status=='1')
			{
				session_regenerate_id();
				$_SESSION['SESS_ID'] = $id;
				$_SESSION['SESS_NAME'] = $name;
				$_SESSION['ACC_MASTER'] = $master;
				$_SESSION['ACC_ADMIN'] = $admin;
				$_SESSION['ACC_STUDENT'] = $student;
				$_SESSION['ACC_FEE'] = $fee;
				$_SESSION['ACC_FRONTDESK'] = $frontdesk;
				$_SESSION['ACC_COUNSELLING'] = $counselling;
				$_SESSION['ACC_ADMISSION'] = $admission;
				$_SESSION['ACC_TRANSPORT'] = $transport;
				$_SESSION['ACC_ATTENDANCE'] = $attendance;
				$_SESSION['ACC_CERTIFICATE'] = $certificate;
				$_SESSION['ACC_COMM'] = $comm;
				$_SESSION['ACC_SETTING'] = $setting;
				$_SESSION['ACC_GROUP'] = $group;
				$_SESSION['LOCATION'] = $location;
				$_SESSION['SECURE_SALT'] = $salt;
				$_SESSION['SESSION'] = $session;
				session_write_close();
				$data = Array (
					'is_log' => TRUE,
					'last_login' => date("Y-m-d H:i:s")
				);
				$db->where ('id', $id);
				$db->update ('admin', $data);
				
				$data = Array (
					'user' => $name,
					'ip' => get_ip(),
					'date' => date("Y-m-d H:i:s")
				);
				$db->insert ('loghistory', $data);
				//header("location: main");
				setcookie('login', $login, time()+60*60*6, '/');
				setcookie('session', $session, time()+60*60*6, '/');
				echo "success";
				exit();
			}
			elseif($logged=='TRUE' && $status=='1')
			{
				session_regenerate_id();
				$_SESSION['SESS_ID'] = $id;
				$_SESSION['SESS_NAME'] = $name;
				$_SESSION['ACC_MASTER'] = $master;
				$_SESSION['ACC_ADMIN'] = $admin;
				$_SESSION['ACC_STUDENT'] = $student;
				$_SESSION['ACC_FEE'] = $fee;
				$_SESSION['ACC_FRONTDESK'] = $frontdesk;
				$_SESSION['ACC_COUNSELLING'] = $counselling;
				$_SESSION['ACC_ADMISSION'] = $admission;
				$_SESSION['ACC_ATTENDANCE'] = $attendance;
				$_SESSION['ACC_TRANSPORT'] = $transport;
				$_SESSION['ACC_CERTIFICATE'] = $certificate;
				$_SESSION['ACC_COMM'] = $comm;
				$_SESSION['ACC_SETTING'] = $setting;
				$_SESSION['ACC_GROUP'] = $group;
				$_SESSION['LOCATION'] = $location;
				$_SESSION['SECURE_SALT'] = $salt;
				$_SESSION['SESSION'] = $session;
				session_write_close();
				/*mysql_query("INSERT INTO ".PREFIX."loghistory (user,ip,date) Values ('".$login."','".get_client_ip()."','".date("Y-m-d H:i:s")."')");*/
				//header("location: login2?user=".$login."&id=".$member['id']."&salt=".rand(1,1000000000)."");
				echo "login2";
				exit();
			}
			else {
				//header("location: ./login");
				echo "failed2";
				exit();
	} }
		else {
		//header("location: ./login");
		echo "failed3";
		exit();
	}
	
?>