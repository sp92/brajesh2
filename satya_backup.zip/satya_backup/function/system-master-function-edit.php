<?php 
function addDataWithExtraCharge($data){                                 /*----------------------Insert -------------------------------------*/
	global $db;
	
	$f_label=clean($data['f_label']);
	$amount=clean($data['amount']);
             $db->orderBy('id','desc');
	$stats = $db->getOne ("extra_heads", null,"ehead");
	if($stats==null){
		$num=1;
	}else{
		$str=explode("d",$stats['ehead_id']);
		$num=$str[1]+1;
	}
	
	$field="ehead".$num;
	$data_d = Array (
	    'ehead_id' => $field,
	    'head_name' => $f_label,
		'amount'   =>$amount
	);
	
	$db->insert ('extra_heads', $data_d);

		$query = "ALTER TABLE  `".PREFIX."fee_paid` ADD  `".$field."` INT(10) NOT NULL  AFTER  `amount`";
	
	$db->rawQuery($query);
	return true;
}
function getExtaChargesData(){                                              /*----------------------Get Or Select---------------------------------*/
	global $db;
	$stats = $db->get("extra_heads");
	return $stats;
	
}
function deleteExtraCharge($data){                                          /*----------------------Delete----------------------------------------*/
		global $db; 
		
			$db->where('id', round($_REQUEST['id']));
			$db->delete('extra_heads');

			$field=clean($_REQUEST['field']);
			$query = "ALTER TABLE  `".PREFIX."fee_paid` DROP  `".$field."`";
			$db->rawQuery($query); 
			return true;
}
function editExtraCharges($data){                                             /*----------------------Edit----------------------------------------*/
	global $db;
		    $db->where('id',$data['id']);
			$editdata=$db->get('extra_heads');
			return $editdata;
}
function updateExtraCharge($data){                                            /*----------------------Update----------------------------------------*/
	global $db;
	$dataa = Array (
	'head_name'=>$data['head_name'],
	'amount'   =>$data['amount']
	);
	$db->where ('id', $data['id']);
	$db->update ('extra_heads', $dataa);
	return true;
}
?>