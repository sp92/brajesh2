<?php 
include('../core.php');
error_reporting(0);
if($_SESSION['ACC_FEE']=='0') { exit; }
if(isset($_REQUEST['cancelTC'])){
	$data=array(
	   'cancel'=>'NO'
	);
	$db->where('stu_id',$_REQUEST['id']);
	$db->update('transfer_certificate',$data);
	
	
	$data=array(
	   'tc_issue'=>'NO'
	);
	$db->where('adm_no',$_REQUEST['id']);
	$db->update('student',$data);
	exit;
}
if(isset($_REQUEST['cancelCC'])){
	$data=array(
	   'cancelled'=>'0'
	);
	$db->where('id',$_REQUEST['id']);
	$db->update('charactor_certificate',$data);
	
	exit;
}

?>