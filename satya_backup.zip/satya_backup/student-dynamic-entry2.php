<?php
require('core.php');
if(isset($_REQUEST['dyn_upd'])) {
	$dyn_field = $_REQUEST['field'];
	$dyn_data = $_REQUEST['field_data'];
	
	

$data = Array (
    $dyn_field =>$dyn_data
	
	
	
          
);
$db->where ('adm_no', $_REQUEST['adm_no']);
$db->update ('student', $data);
}
?>
