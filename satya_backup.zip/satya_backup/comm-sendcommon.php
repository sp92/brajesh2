<?php
$page='comm';
require('core.php');
if($_SESSION['ACC_COMM']=='0') 
{
	header("Location: main.php");
}
include('header.php');
?>
<link rel="stylesheet" href="assets/css/bootstrap-multiselect.css">
<div class="container">
<div class="row">
<div class="col-md-2 hidden-xs">
<?php print_menu($comm_menu_items); ?>
</div>
<div class="col-md-10">

<h5 class="pull-right"><b><span id="balance" class="text-danger"></span></b> Credits</h5>

<h3>Send Common SMS</h3>
<div class="row">
<div class="col-md-12">
<textarea class="form-control message-checkbox box-content" name="message" id="ac-message" placeholder="Type your text message here (up to max 4000 characters)" maxlength="4000" required="required" data-counter="true" placeholder="Enter your message" rows="4" ></textarea>
<p class="sms-cnt">
	<span class="ac-sms-count">0</span> Character(s),
	<span  class="ac-sms-credits">0</span> SMS
<button type="button" class="btn btn-primary btn-xs pull-right" data-toggle="modal" data-target=".bs-example-modal-lg">Sms Count</button>
</p>
<hr>
<form id="getrecord">
<table class="table" style="font-size:12px;">
<tr>
<td><label>Class:</label> </td>
<td><select name="class[]" class="multiselect" class="form-control" multiple>
<?php
$cols=array("class");
$class_stu = $db->get('class_master',null,$cols); 
foreach($class_stu as $stu){
	echo "<option value='".$stu["class"]."'".($stu["class"]==$_REQUEST["class"] ? " selected" : "").">".$stu["class"]."</option>";
}
	
?>
</select>
</td>

<td><label>Section:</label> </td>
<td><select name="sec[]" class="multiselect" class="form-control" multiple>
<?php
$cols=array("sec");
$db->orderBy ("sec","asc");
$class_stu = $db->get('sec_master',null,$cols); 
foreach($class_stu as $stu){
	echo "<option value='".$stu["sec"]."'".($stu["sec"]==$_REQUEST["sec"] ? " selected" : "").">".$stu["sec"]."</option>";
}


?>
</select>
</td>
</tr>
<tr>
<td><label>Student Type:</label> </td>
<td>
<select name="type" style="width:100%">
<option value="">-- Any --</option>
<?php
$class_stu = $db->get('type'); 
foreach($class_stu as $stu){
	echo "<option value='".$stu["type"]."'>".$stu["type"]."</option>";
}
	
?>
</select>
</td>

<td><label>Adm. Type:</label> </td>
<td><select name="new_old" style="width:100%">
<option value="">-- Any --</option>
<option value="OLD">OLD Only</option>
<option value="NEW">NEW Only</option>
</select>
</td>
</tr>



<tr>
<td><label>Gender:</label> </td>
<td><select name="gender" style="width:100%">
<option value="">-- Any --</option>
<option value="M">BOY Only</option>
<option value="F">GIRL Only</option>
</select>
</td>

<td><label>Have Birthday Today :</label> </td>
<td>
<input type="checkbox" name="today_birthday"  value="<?php echo date('d/m/Y'); ?>">
</td>
</tr>
<tr>
<td colspan=4 align=center><input class="btn btn-success btn-xs" type="submit" id="submit" name="submit" value="Get Student Records" /></td>
</tr>
</table>
</form>


<div id="for_data"></div>
	
</div>
</div>
</div>
</div>
</div> <!-- /container -->
<script src="assets/js/bootstrap-multiselect.js"></script>
<script>
$('.multiselect').multiselect({includeSelectAllOption: true});
$('#getrecord').submit(function(event) {
	if(confirm('Confirm?' )) {
		$( "#submit" ).prop('disabled',true);
		$( "#submit" ).val('Processing. Please wait......');
		event.preventDefault();
                $.ajax({
                        type: 'POST',
                        //url: 'function/studata',
                       url: 'function/core_fun',
                        data: $(this).serialize(),
						success: function (data) {
							console.log(data);
							 $('#for_data').html(data);
							$( "#submit" ).prop('disabled',false);
							$( "#submit" ).val('Export Data'); 
						}
                });
	} else {
		event.preventDefault();
		return false;
	}
});
</script>
<?php
include('lib/forsms.php');
include('footer.php');
?>