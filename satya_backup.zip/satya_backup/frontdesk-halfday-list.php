<?php
$page='frontdesk';
require('core.php');
error_reporting(0);
if($_SESSION['ACC_FRONTDESK']=='0') 
{
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">

  <div class="row">
    <div class="col-md-2 hidden-xs">
<?php print_menu($frontdesk_menu_items); ?>
</div>
	<div class="col-md-10">
	<h3>List Halfdays</h3>
<form name="myForm" method="get" action="frontdesk-halfday-list">
<label>Select :</label>
<select name="type" required="">
<option value="">--Please Select--</option>
<option value="Student">Student</option>
<option value="Teacher">Teacher</option>
</select>
<label>From Date: </label> 
<input name="from_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["from_date"]; ?>" class="datepicker" style="width: 100px;" readonly />  
<label>To Date : </label> 
<input name="to_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["to_date"]; ?>" class="datepicker" style="width: 100px;" readonly /> 
<label><input type='checkbox' name='pic' value='1' <?php if($_REQUEST["pic"]=='1') { echo "checked"; } ?> > Show Pictures </label>
<input type="submit" name="submit" value="SUBMIT" />


</form>
<hr>

<?php
$from_date = datestamp($_REQUEST["from_date"]);
$to_date = datestamp($_REQUEST["to_date"]);
$type = clean($_REQUEST["type"]);

if($type == 'Student') {
?>


<table id="testTable" class="table table-hover" style="font-size:11px;">
<thead>
<tr>
<th align="center"><strong>Date</strong></th>
<?php if($_REQUEST["pic"]=='1') { ?>
<th align="center"><strong>Photo</strong></th>
<?php } ?>
<th align="center"><strong>Adm. No.</strong></th>
<th align="center"><strong>Student Name</strong></th>
<th align="center"><strong>Father's Name</strong></th>
<th align="center"><strong>Class</strong></th>
<th align="center"><strong>Message</strong></th>
<th align="center"><strong>Taken By</strong></th>
<th align="center"><strong>Relation</strong></th>
<th align="center"><strong>Contact No.</strong></th>
<th align="center"><strong>Gatepass</strong></th>
</tr>
</thead>
<tbody>

<?php 
$data=array($from_date,$to_date,$type);
 $sql_result=$db->rawQuery("SELECT * from ".PREFIX."halfday where (DATE(date) between ? and ?) AND type=? order by id ASC", $data);


$n=1;
foreach($sql_result as $row)
{

	?>
	
<tr>
<td align="center"><?php echo date('d/m/Y', strtotime($row['date'])) ; ?></td>
<?php if($_REQUEST["pic"]=='1') { ?>
<td align="center"><img src="pictures/halfday/<?php echo $row['pic']; ?>" class="img-thumbnail" width="200" /></td>
<?php } ?>
<td align="center"><?php echo $row['adm_no']; ?></td>
<td align="center"><?php echo $row['name']; ?></td>
<td align="center"><?php echo $row['fat_name']; ?> </td>
<td align="center"><?php echo $row['class']." - ".$row['sec']; ?> </td>
<td align="center"><?php echo $row['message']; ?> </td>
<td align="center"><?php echo $row['takenby']; ?> </td>
<td align="center"><?php echo $row['takenrelation']; ?> </td>
<td align="center"><?php echo $row['takenmobile']; ?> </td>
<td align="center"><a href="frontdesk-view-gatepass?id=<?php echo $row['id']; ?>" target="_blank" >[Print]</a> </td>
</tr>
<?php } ?>
</tbody>
</table>
<?php } if($type == 'Teacher') { ?>

<table id="testTable" class="table table-hover" style="font-size:11px;">
<thead>
<tr>
<th align="center"><strong>Date</strong></th>
<th align="center"><strong>Name</strong></th>
<th align="center"><strong>Message</strong></th>
</tr>
</thead>
<tbody>

<?php 
$data=array($from_date,$to_date,$type);
 $sql_result=$db->rawQuery("SELECT * from ".PREFIX."halfday where (DATE(date) between ? and ?) AND type=? order by id ASC", $data);

$n=1;
foreach($sql_result as $row)
{

	?>
	
<tr>
<td align="center"><?php echo date('d/m/Y', strtotime($row['date'])) ; ?></td>
<td align="center"><?php echo $row['name']; ?></td>
<td align="center"><?php echo $row['message']; ?> </td>
</tr>
<?php } ?>
</tbody>
</table>



<?php } ?>
	</div>


	</div>	


	
	
	
</div> <!-- /container -->





<?php
include('footer.php');
?>