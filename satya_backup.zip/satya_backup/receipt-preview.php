<?php

	include("core.php");
	include("lib/template.class.php");
	$profile = new Template("lib/user_profile.tpl");
	$profile->set("username", "monk3y");
	$profile->set("photoURL", "photo.jpg");
	$profile->set("name", "Monkey man");
	$profile->set("age", "23");
	$profile->set("location", "Portugal");
	
	$layout = new Template("lib/layout.tpl");
	$layout->set("title", "User profile");
	/*$layout->set("content", $profile->output());
	echo $layout->output();
	file_put_contents('rawhtml/yourpage.html', ob_get_contents());*/
	$myFile = "rawhtml/yourpage.html";
	$fh = fopen($myFile, 'w') or die("can't open file");
	$stringData = $layout->output();
	fwrite($fh, $stringData);
	fclose($fh);
	echo shell_exec("C:\wkhtmltopdf\bin\wkhtmltopdf.exe rawhtml/yourpage.html a.pdf");
	header("Location: a.pdf");
?>