<?php
$page = 'frontdesk';
require('core.php');
if ($_SESSION['ACC_FRONTDESK'] == '0') {
    header("Location: main.php");
}
$from_date = datestamp(isset($_REQUEST["from_date"]) ? $_REQUEST["from_date"] : date("d/m/Y", strtotime("-6 Days")));
$to_date = datestamp(isset($_REQUEST["to_date"]) ? $_REQUEST["to_date"] : date("Y/m/d"));
include('header.php');
$db->where("status", "DISPLAY_COL");
$col = $db->get("inquiry_custom_data");
//$col = $db->get("inquiry_custom_data", NULL, array("name", "description"));
?>
<link href="assets/css/jquery.dataTables.min.css" rel="stylesheet">
<div class="container">
    <div class="row">
        <div class="col-md-2">
            <?php print_menu($frontdesk_menu_items); ?>
        </div>	
        <div class="col-md-10"><br>
            <form class="inline-form"  method="get" action="frontdesk-admquery-list">
                From Date : <input name="from_date" data-date-format="dd/mm/yyyy" value="<?php echo date("d/m/Y", strtotime($from_date)); ?>" class="datepicker" style="width: 100px;" readonly /> 
                To Date : <input name="to_date" data-date-format="dd/mm/yyyy" value="<?php echo date("d/m/Y", strtotime($to_date)); ?>" class="datepicker" style="width: 100px;" readonly /> 
                <label><input type='checkbox' name='pic' value='1' <?php
                    if ($_REQUEST["pic"] == '1') {
                        echo "checked";
                    }
                    ?> > Show Pictures </label>
                &nbsp;&nbsp;&nbsp;
                <label> Current Enq. Status : </label><select name="status">
                    <option value="">All</option>
                    <option value="Enquiry" <?php
                    if ($_REQUEST['status'] == 'Enquiry') {
                        echo "selected";
                    }
                    ?> >Enquiry</option>
                    <option value="Prospectus" <?php
                    if ($_REQUEST['status'] == 'Prospectus') {
                        echo "selected";
                    }
                    ?> >Prospectus</option>
                    <option value="Interview" <?php
                    if ($_REQUEST['status'] == 'Interview') {
                        echo "selected";
                    }
                    ?> >Interview</option>
                    <option value="Approved" <?php
                    if ($_REQUEST['status'] == 'Approved') {
                        echo "selected";
                    }
                    ?> >Approved</option>
                    <option value="Unapproved" <?php
                    if ($_REQUEST['status'] == 'Unapproved') {
                        echo "selected";
                    }
                    ?> >Unapproved</option>
                    <option value="Admitted" <?php
                    if ($_REQUEST['status'] == 'Admitted') {
                        echo "selected";
                    }
                    ?> >Admitted</option>

                </select>
                <input type="submit" name="submit" value="SUBMIT" />
            </form>
            <br>
            <br>
            <table id="testTable" class="table table-bordered table-striped" >
                <thead>
                    <tr>
                        <th></th>
                        <th align="center"><strong>SR</strong></th>
                        <th align="center"><strong>Hitting Date</strong></th>
                        <?php if ($_REQUEST["pic"] == '1') { ?>
                            <th align="center"><strong>Photo</strong></th>
                        <?php } ?>
                        <th align="center"><strong>Name</strong></th>
                        <th align="center"><strong>Father Name</strong></th>
                        <th align="center" ><strong>Address</strong></th>
                        <th align="center"><strong>Contact</strong></th>
                        <th align="center"><strong>Class</strong></th>
                        <th align="center"><strong>Current Status</strong></th>
                        <th align="center"><strong>Pass</strong></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $date = array($from_date, $to_date);
                    $db->where('date', $date, 'between');
                    if (clean($_REQUEST["status"]) <> '') {
                        $db->where('adm_status', $_REQUEST["status"]);
                    }
                    $db->where('session', $_SESSION['SESSION']);
                    $data = $db->get('inquiry');
                    $n = 0;
                    foreach ($data as $val) {
                        $n++;
                        ?>
                        <tr>
                            <td><input type="radio" name="selectVisitor" value="<?php echo $val['id']; ?>"></td>
                            <td align="center"><?php echo $n; ?></td>
                            <td align="center"><?php echo getdmYFormat($val['date']) ?></td>
                            <?php if ($_REQUEST["pic"] == '1') { ?>
                                <td align="center"><img src="pictures/enquiry/<?php echo $val['pic']; ?>" class="img-thumbnail" width="200" /></td>
                            <?php } ?>
                            <td align="center"><?php echo $val['stu_name']; ?></td>
                            <td align="center"><?php echo $val['fat_name']; ?></td>
                            <td align="center">	<?php echo $val['address']; ?></td>
                            <td align="center"> <?php echo $val['mobile']; ?></td>
                            <td align="center"><?php echo $val['class']; ?> </td>
                            <td align="center"> <span class='label <?php
                                if ($val['adm_status'] == 'Enquiry') {
                                    echo "label-danger";
                                }
                                if ($val['adm_status'] == 'Prospectus') {
                                    echo "label-warning";
                                }
                                if ($val['adm_status'] == 'Interview') {
                                    echo "label-info";
                                }
                                if ($val['adm_status'] == 'Approved') {
                                    echo "label-default";
                                }
                                if ($val['adm_status'] == 'Unapproved') {
                                    echo "label-primary";
                                }
                                if ($val['adm_status'] == 'Admitted') {
                                    echo "label-success";
                                }
                                ?>'><?php echo $val['adm_status']; ?></span></td>
                            <td align="center"><a href="frontdesk-view-visitorpass?type=query&id=<?php echo $val['id']; ?>" target="_blank" >[Print]</a> </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <div class="panel panel-primary" id="detailedView">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-md-10">
                            <span id="detailsOf"></span>
                        </div>
                        <div class="col-md-2">
                            <button class="col-md-12 btn btn-danger">Edit</button>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="table-striped">
                        <table class="table">
                            <tbody>
                                <?php
                                if (!empty($data)) {
                                    foreach ($col as $v) {
                                        ?>
                                        <tr>
                                            <td class="col-md-3"><?php echo $v['description']; ?></td>
                                            <td class="col-md-6" id="<?php echo $v['name']; ?>">: </td>
                                            
                                            <td class="col-md-3">
                                                <?php
                                                switch ($v['type']) {
                                                    case "DATE":
                                                        echo '<input type="text" class="form-control class' . $v['name'] . ' datepicker" data-date-format="dd/mm/yyyy" readonly>';
                                                        break;
                                                    default :
                                                        switch ($v['name']) {
                                                            case "campus_visit":
                                                                echo '<div class="row"><div class="col-md-2"><input type="radio" class="form-control classcampus_visit" name="campus_visit" value="yes"></div><div class="col-md-4">Yes </div><div class="col-md-2"><input type="radio" class="form-control classcampus_visit" name="campus_visit" value="no"></div><div class="col-md-4">No</div></div>';
                                                                break;
                                                            default :
                                                                echo '<input type="text" class="form-control">';
                                                                break;
                                                        }
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>	
</div> <!-- /container -->
<script src="assets/js/jquery.dataTables.min.js"></script>
<script>
    $("#testTable").DataTable();
    var data = JSON.parse('<?php echo json_encode($data); ?>');
    var col = JSON.parse('<?php echo str_replace(array("'", '\"'), "", json_encode($col)); ?>');
    $('[name="selectVisitor"]').change(function () {
        if (this.checked) {
            var id = $(this).val();
            $.each(data, function (key, val) {
                if (val.id == id) {
                    $("#detailsOf").html(val.stu_name);
                    $.each(col, function (k, v) {
                        var colID = "#" + v.name;
                        var value = ": " + eval("val." + v.name);
                        $(colID).html(value);
                    });
                    $("#detailedView").show();
                }
            });
        }
    });
</script>
<?php
include('footer.php');
?>