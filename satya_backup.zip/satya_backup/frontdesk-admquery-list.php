<?php
$page='frontdesk';
require('core.php');
if($_SESSION['ACC_FRONTDESK']=='0') 
{
	header("Location: main.php");
}
include('header.php');
?>
<div class="container">

  <div class="row">



<div class="col-md-2">
<?php print_menu($frontdesk_menu_items); ?>

</div>	
		<div class="col-md-10"><br>
    
<form class="inline-form"  method="get" action="frontdesk-admquery-list">

From Date : <input name="from_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["from_date"]; ?>" class="datepicker" style="width: 100px;" readonly /> 
To Date : <input name="to_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["to_date"]; ?>" class="datepicker" style="width: 100px;" readonly /> 

<label><input type='checkbox' name='pic' value='1' <?php if($_REQUEST["pic"]=='1') { echo "checked"; } ?> > Show Pictures </label>
&nbsp;&nbsp;&nbsp;
<label> Current Enq. Status : </label><select name="status">
<option value="">All</option>
<option value="Enquiry" <?php if($_REQUEST['status']=='Enquiry') { echo "selected"; } ?> >Enquiry</option>
<option value="Prospectus" <?php if($_REQUEST['status']=='Prospectus') { echo "selected"; } ?> >Prospectus</option>
<option value="Interview" <?php if($_REQUEST['status']=='Interview') { echo "selected"; } ?> >Interview</option>
<option value="Approved" <?php if($_REQUEST['status']=='Approved') { echo "selected"; } ?> >Approved</option>
<option value="Unapproved" <?php if($_REQUEST['status']=='Unapproved') { echo "selected"; } ?> >Unapproved</option>
<option value="Admitted" <?php if($_REQUEST['status']=='Admitted') { echo "selected"; } ?> >Admitted</option>

</select>
<input type="submit" name="submit" value="SUBMIT" />
</form>
<br>
<br>
<table id="testTable" class="table table-bordered table-striped" >
<thead>
<tr>
<th align="center"><strong>SR</strong></th>
<th align="center"><strong>Hitting Date</strong></th>
<?php if($_REQUEST["pic"]=='1') { ?>
<th align="center"><strong>Photo</strong></th>
<?php } ?>
<th align="center"><strong>Name</strong></th>
<th align="center"><strong>Father Name</strong></th>
<th align="center" ><strong>Address</strong></th>
<th align="center"><strong>Contact</strong></th>
<th align="center"><strong>Class</strong></th>
<th align="center"><strong>Current Status</strong></th>
<th align="center"><strong>Pass</strong></th>
</tr>
</thead>
<tbody>
<?php 
if (clean($_REQUEST["from_date"])<>'' and clean($_REQUEST["to_date"])<>'') {
$from_date = datestamp($_REQUEST["from_date"]);
$to_date = datestamp($_REQUEST["to_date"]);
$date=array($from_date,$to_date);
$db->where('date',$date,'between');
} 

if (clean($_REQUEST["status"])<>'') {
 $db->where('adm_status',$_REQUEST["status"]);
 
}
$db->where('session',$_SESSION['SESSION']);
$data=$db->get('inquiry');
$n=0;
foreach($data as $val){$n++;
?>
<tr>
<td align="center"><?php echo $n;?></td>
<td align="center"><?php echo getdmYFormat($val['date'])?></td>
<?php if($_REQUEST["pic"]=='1') { ?>
<td align="center"><img src="pictures/enquiry/<?php echo $val['pic'];?>" class="img-thumbnail" width="200" /></td>
<?php } ?>
<td align="center"><?php echo $val['stu_name'];?></td>
<td align="center"><?php echo $val['fat_name'];?></td>
<td align="center">	<?php echo $val['address'];?></td>
<td align="center"> <?php echo $val['mobile'];?></td>
<td align="center"><?php echo $val['class'];?> </td>
<td align="center"> <span class='label <?php 
if($val['adm_status']=='Enquiry') { echo "label-danger"; } 
if($val['adm_status']=='Prospectus') { echo "label-warning"; } 
if($val['adm_status']=='Interview') { echo "label-info"; } 
if($val['adm_status']=='Approved') { echo "label-default"; } 
if($val['adm_status']=='Unapproved') { echo "label-primary"; } 
if($val['adm_status']=='Admitted') { echo "label-success"; } 
?>'><?php echo $val['adm_status'];?></span></td>
<td align="center"><a href="frontdesk-view-visitorpass?type=query&id=<?php echo $val['id'];?>" target="_blank" >[Print]</a> </td>
</tr>
<?php } ?>

</tbody>
</table>

  </div>


	</div>	

</div> <!-- /container -->


<?php
include('footer.php');
?>