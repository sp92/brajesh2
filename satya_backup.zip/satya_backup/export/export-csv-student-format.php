<?php 
require('../core.php');
header( 'Content-Type: text/csv' );
header( 'Content-Disposition: attachment;filename=student.csv');
$fieldnames = array();
$users = $db->rawQuery('SHOW COLUMNS FROM '.$prefix.'student');
foreach ($users as $user) {
    $fieldnames[] = $user['Field'];
}
$out = fopen('php://output', 'w');
fputcsv($out, $fieldnames);
fclose($out);
?>