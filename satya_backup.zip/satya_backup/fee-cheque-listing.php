<?php $page='fee';
require('core.php');
error_reporting(0);
if($_SESSION['ACC_FEE']=='0') { header("Location: main"); }
include('header.php');
?>
<div class="container">
<div class="row">
	<h3>Cheque Listing/Bouncing</h3>
	<form name="myForm" method="get" action="fee-cheque-listing">
		<?php if(isset($_REQUEST['menu']) && $_REQUEST['menu']=='OFF') {
			echo "<input type='hidden' name='menu' value='OFF' />";
		} ?>
		<table style="font-size: 14px;width:100%;">
			<tr>
				<td style="border-bottom: none!important;">
					From : <input name="from_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["from_date"]; ?>" class="datepicker" style="width: 100px;" readonly />  
				</td>
				<td style="border-bottom: none!important;">
					To : <input name="to_date" data-date-format="dd/mm/yyyy" value="<?php echo $_REQUEST["to_date"]; ?>" class="datepicker" style="width: 100px;" readonly /> 
				</td>
				<td style="border-bottom: none!important;">
					Location : <select name="location">
					           <?php 
							    $location=$db->get('location');
								foreach($location as $loc){
									
									?>
									 <option value="<?php echo $loc['location'];?>"><?php echo $loc['location'];?></option>
									<?php
								}
							   ?>
                              
							   </select>
				</td>
				
				<td style="border-bottom: none!important;">
					<input type="submit" name="submit" value="SUBMIT" />
					<input type="button" onclick="tableToExcel('testTable', 'Student')" value="Export"  />
					<input type="button" onclick="return windowpop('bob-pdf', 1000, 600)" value="Print PDF "  />
				</td>
			</tr>
		</table>	
	</form><hr/>

	

	
	<?php 
	
	?>
		
	<h4>Collection Date : <?php echo $_REQUEST['to_date']; ?></h4>
	<table id="testTable" class="table" style="font-size:12px;">
<thead>
<tr>
<th align="center" width="5%"><strong>Sr.</strong></th>
<th align="center" width="12%"><strong>Rec. Date</strong></th>
<th align="center" width="12%"><strong>Chq. No.</strong></th>

<th align="center" width="12%"><strong>Bank Name</strong></th>
<th align="center" width="12%"><strong>Branch</strong></th>
<th align="center" width="12%"><strong>Fee Particalur</strong></th>
<th align="center" width="12%"><strong>Cheque Amount</strong></th>
<th align="center" width="12%"><strong>Reason</strong></th>
<th align="center" width="12%"><strong>Bounce By/Date</strong></th>
</tr>
</thead>
<tbody>
 <?php 
 $db->where('ehead_id','ehead2');
 $bounce=$db->get('extra_heads',null,'amount');
if(isset($_REQUEST["from_date"]) and isset($_REQUEST["to_date"])) { 
 $from_date = datestamp($_REQUEST["from_date"]);
 $to_date = datestamp($_REQUEST["to_date"]);
 $date=array($from_date,$to_date);

 $db->join("bank_detail u", "p.micr_code=u.micrcode", "LEFT");
 $db->join("student s", "s.id=p.stu_id", "LEFT");
 $db->where('p.rec_date',$date,'between');
 $db->groupBy('p.chq_no');
 $data_f=$db->get('fee_paid p',null,'p.id,p.cancelled,u.branch_name,u.bank_name,p.chq_date,p.chq_no,sum(p.chq_amt) as chq_amt,GROUP_CONCAT(p.chq_amt) as br_amt,GROUP_CONCAT(p.rec_no) as br_rec,rec_date,GROUP_CONCAT(s.stu_name) as br_name,GROUP_CONCAT(s.id) as br_id');

 $n=0;
 $sum=0;
foreach($data_f as $bank){$n++;
$sum=$sum+$bank['chq_amt'];
?>
	<tr align="center">
	<td><?php echo $n;?></td>
	<td><?php echo getdmYFormat($bank['rec_date']);?></td>
	<td><?php echo $bank['chq_no'];?></td>
	
	<td><?php echo $bank['bank_name'];?></td>
	<td><?php echo $bank['branch_name'];?></td>
	<td>
	<table>
	<?php $arr_rec=array_unique(explode(",",$bank['br_rec']));
	      $arr_amt=array_unique(explode(",",$bank['br_amt']));
		  $arr_name=array_unique(explode(",",$bank['br_name']));
		   $v=0;
	foreach($arr_rec as $key=>$amo){
		echo "<tr>";
		echo "<td>".$amo.":</td><td><small>".$arr_name[$key]."</small>:</td><td>".$arr_amt[$v]."</td>";
		echo "</tr>";
	$v++;}?>
	</table>
	</td>
	<td><?php echo $bank['chq_amt'];?></td>
	<td>
	<?php if($bank['cancelled']!=1){?>
	<a href="javascript:void(0)" class="btn btn-default btn-xs" rel="popover" data-html='true' data-placement="left" data-toggle="popover" data-content="<form method='post' class='clearform' id='form<?php echo $bank['id']; ?>'>
<input type='hidden' name='chq_no' value='<?php echo $bank['chq_no'];?>' />
<input type='hidden' name='stu_id' value='<?php $arr_id=array_unique(explode(",",$bank['br_id']));$str_id=implode(",",$arr_id); echo $str_id; ?>' />
<input type='hidden' name='stu_amount' value='<?php echo implode(",",$arr_amt);?>' />
<input type='hidden' name='stu_rec' value='<?php echo implode(",",$arr_rec);?>' />
<input type='text' name='comment'  placeholder='Reason' required /><br><br>
<input type='text' name='bounce_amount' value='<?php echo $bounce[0]['amount']?>' /><br><br>
<input type='submit' class='update_form' value='Bounce'  />
</form>" data-placement="top" data-original-title="Add Reason">Bounce</a>
<?php }else{
	$db->where('chq_no',$bank['chq_no']);
	$reason=$db->get('chq_bounce_master',null,'bounce_reason');
	echo $reason[0]['bounce_reason'];
} ?>
	</td>
	<td>
	<?php $db->where('chq_no',$bank['chq_no']);
	$by=$db->get('chq_bounce_master',null,'bounce_by,bounce_date');
	echo $by[0]['bounce_by']."<br>";
	echo (getdmYFormat($by[0]['bounce_date'])!='01/01/1970') ? getdmYFormat($by[0]['bounce_date']) :'';?>
	</td>
	</tr>
<?php	} }
 
 ?>

</tbody>
</table>



		
	<?php
	
file_put_contents('bob.htm', ob_get_contents());
// end buffering and displaying page
ob_end_flush();
?>
	</div>
</div>
<?php
include('footer.php');
?>
<script>
$(function () {
  $('[data-toggle="popover"]').popover()
})
$(document).on('submit','.clearform',function(){
	var element = $(this);
    $.ajax({
           type: "POST",
           url: "function/feefunction?feedbounce",
           data: $(this).serialize(),
           success: function(data)
           {	element.replaceWith("Commented.");
				console.log(data);
		   }
         });
   return false;
});
</script>