<?php
error_reporting(0);

include('lib/config.php');

if($_SESSION['ACC_CERTIFICATE']=='NO') 
{
	header("Location: main.php");
}

$db->join("stu_sess_data sd", "sd.adm_no=ts.adm_no", "LEFT");
    $db->join("student s", "s.adm_no=ts.adm_no", "LEFT");
	$db->where('ts.adm_no',$_REQUEST['adm_no']);
	$db->where('ts.cancel','YES');
	$user=$db->get('transfer_certificate ts',null,'ts.*,sd.type,sd.fee_cat,s.*');
  
ob_start();
?>

<br>
<br>
<br>
<br>
<br>
<br>



  <center>
  <p align=center style='margin-bottom:0in;margin-bottom:.0001pt;text-align:center'>
    <b style='mso-bidi-font-weight:normal'>
      
       <u>TRANSFER CERTIFICATE</u>
      
    </b>
  </p></center>
  

<table border=0 cellspacing=0 cellpadding=0 style='margin-left:27px;font-size:13px;border-collapse:collapse;border:none;mso-yfti-tbllook:1184;mso-padding-alt: 0in 5.4pt 0in 5.4pt;mso-border-insideh:none;mso-border-insidev:none'>
    
    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
      <td width=250  style='width:166.5pt;padding:0in 5.4pt 0in 5.4pt'>
	  <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:normal'>
       
          <b style='mso-bidi-font-weight:normal;border-bottom:2px dotted #000;'>
       
          </b>
         
        </p>
       
      </td>
      <td width=400  style='width:100.55pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:normal'>
         
          <b style='mso-bidi-font-weight:normal;border-bottom:2px dotted #000;'>
           
          </b>
         
        </p>
      </td>
      <td width=178  style='width:133.55pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:normal'>
        Date of Issue: 
          <b style='mso-bidi-font-weight:normal;border-bottom:2px dotted #000;'>
            <?php $date_issue2 = date('d/m/Y', strtotime($user[0]['date_issue'])); if($date_issue2<>'01/01/1970') { echo $date_issue2; }  ?>
          </b>
          
        </p>
      </td>
      
    </tr>  
	
  </table> 
  
  <table border=0 cellspacing=0 cellpadding=0 style='margin-left:27px;font-size:13px;border-collapse:collapse;border:none;mso-yfti-tbllook:1184;mso-padding-alt: 0in 5.4pt 0in 5.4pt;mso-border-insideh:none;mso-border-insidev:none'>
    
    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
      <td width=250  style='width:166.5pt;padding:0in 5.4pt 0in 5.4pt'>
	  <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:normal'>
        S.R.No.: 
          <b style='mso-bidi-font-weight:normal;border-bottom:2px dotted #000;'>
      <?php echo $user[0]['s_no']; ?>
          </b>
         
        </p>
       
      </td>
      <td width=400  style='width:100.55pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:normal'>
         
          <b style='mso-bidi-font-weight:normal;border-bottom:2px dotted #000;'>
           
          </b>
         
        </p>
      </td>
      <td width=178  style='width:133.55pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:normal'>
        Scholar ID: 
          <b style='mso-bidi-font-weight:normal;border-bottom:2px dotted #000;'>
            NWS10<?php echo $user[0]['adm_no']; ?>
          </b>
          
        </p>
      </td>
      
    </tr>  
	
  </table> 
  
  <br/>

  <table border=0 cellspacing=0 cellpadding=0 style='margin-left:20px;border-collapse:collapse;border:none;mso-yfti-tbllook:1184;font-size:13px;mso-padding-alt: 0in 5.4pt 0in 5.4pt;mso-border-insideh:none;mso-border-insidev:none'>
    

	<tr style='mso-yfti-irow:1'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          1.
        </span>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
         Name of the Pupil 
        </span>
      <span>:</span>
	   <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo $user[0]['stu_name']; ?>
          </b>
        </span>
      </td>
      
    </tr>
	<tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:2'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          2.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
         Father’s/Guardian's Name
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            Mr. <?php echo $user[0]['fat_name']; ?>
          </b>
        </span>
      </td>
      
    </tr>
    <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:1'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          3.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
         Mother’s Name
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            Mrs.  <?php echo $user[0]['mot_name']; ?>
          </b>
        </span>
      </td>
      
    </tr>
    
	<tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:3'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          4.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
         Nationality
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
           <?php echo $user[0]['nationality']; ?> &nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	
	
    <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:4'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          5.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;font-size:13px;'>
         Category
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo $user[0]['fee_cat']; ?> &nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	
	
	
    <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:4'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          6.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;font-size:13px;'>
         Religion
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo $user[0]['religion']; ?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	
	<tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:7'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          7.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          Date of first admission in the school with class
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
          <?php echo getdmYFormat($user[0]['do_adm']);?>,&nbsp;<?php echo $user[0]['class']; ?>
          </b>
        </span>
      </td>
      
    </tr>
	
	
	 <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:5'>
      <td width=33 valign=top style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          8.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
         Date of Birth (in Christian Era) according to the Admission & Withdrawal Register (In figure)
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo getdmYFormat($user[0]['dob']);?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (In words) : 
			<span style="font-size:12px;text-transform:uppercase;"><?php
			
			?></span>
			&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
    
	
	
	
   
    
	 <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:8'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          9.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          Class in which the pupil last studies (in words)
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
           <?php echo $user[0]['last_class']; ?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	
	 <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:9'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          10.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          School/Board Examination last taken with result
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo $user[0]['school_exam_last_taken'];?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	
	 <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:9'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          11.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          Whether failed, if so once/twice in the same class
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo $user[0]['student_failed'];?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	
	<tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:7'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          12.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          Subjects studied
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo $user[0]['sub_offer'];?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	
   
   
    <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:10'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          13.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
         <span style='font-size:13px;'> Whether qualified for promotion to the next higher class?</span>
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <span style='font-size:12px;'><?php echo $user[0]['qualified_promotion'];?></span>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
    <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:11'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          14.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;font-size:13px;'>
         Month upto which the pupil has paid the school dues
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
          <?php echo $user[0]['paid_all_dues'];?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
    <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:12'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          15.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;font-size:13px;'>
          Any fee concession availed of, if so, the nature of such concession
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo $user[0]['concession'];?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	
	
	 <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:16'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          16.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
         Total no. of working days in the academic session
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
           <?php echo $user[0]['no_meeting'];?>
          </b>
        </span>
      </td>
      
    </tr>
    <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:17'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          17.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
         Total no. of working days pupil present in the school
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
           <?php echo $user[0]['attendance'];?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	
    <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:13'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          18.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;font-size:13px;'>
         Whether the pupil is NCC Cadet/Boy Scout/Girl Guide (give details)
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo $user[0]['ncc'];?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
    <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:14'>
      <td width=33 valign=top style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          19.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;font-size:13px;'>
         Games played or extra curricular activities in which the pupil usually took part<br>(mention achievement level therein)
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo $user[0]['game_played'];?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	<tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:18'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          20.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
         General conduct
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo $user[0]['general_conduct'];?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	
	<tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
	
    <tr style='mso-yfti-irow:20;mso-yfti-lastrow:yes'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          21.
        </p>
      </td>
      <td colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
         Date of application of TC
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo getdmYFormat($user[0]['do_apply']);?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	
	<tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
	
    <tr style='mso-yfti-irow:20;mso-yfti-lastrow:yes'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          22.
        </p>
      </td>
      <td colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
         Date of issue of TC
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
           <?php echo getdmYFormat($user[0]['date_issue']);?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
    <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:15'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          23.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
         Reason for leaving the school
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo $user[0]['reason'];?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
	
   
    
    <tr><td colspan=4><span style="font-size:7px;">&nbsp;</span></td></tr>
    <tr style='mso-yfti-irow:19'>
      <td width=33 valign=bottom style='width:24.75pt;padding:0in 5.4pt 0in 5.4pt'>
        <p style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
          24.
        </p>
      </td>
      <td  colspan=3 valign=middle style='width:100%;padding:0in 5.4pt 0in 5.4pt'>
        <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%'>
        Any other remarks
        </span>
      <span>:</span>
	    <span style='margin-bottom:0in;margin-bottom:.0001pt;line-height:115%;border-bottom: 1px dotted;'>
          <b style='mso-bidi-font-weight:normal'>
            <?php echo $user[0]['remark'];?>&nbsp;
          </b>
        </span>
      </td>
      
    </tr>
    
	
  </table>
  
<br/>


  <table border=0 cellspacing=0 cellpadding=0 style='border-collapse:collapse;border:none;;width:100%'>
    
    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
      <td width="250"   style='width=30%;padding:0in 5.4pt 0in 5.4pt'><center>
	  <br><br><br><br>
        <p align=center style='margin-bottom:0in;margin-bottom:.0001pt;text-align:center;line-height:normal'>
          <b style='mso-bidi-font-weight:normal'>
            Class Teacher
          </b>
        </p>
        <p align=center style='margin-bottom:0in;margin-bottom:.0001pt;margin-top:0;text-align:center;line-height:normal'>
          (Signature)
        </p>
     </center> </td>
      <td width="250"  style='width=30%;padding:0in 5.4pt 0in 5.4pt'><center>
<br><br><br><br>
        <p align=center style='margin-bottom:0in;margin-bottom:.0001pt;text-align:center;line-height:normal'>
          <b style='mso-bidi-font-weight:normal'>
           Checked By
          </b>
        </p>
        <p align=center style='margin-bottom:0in;margin-bottom:.0001pt;margin-top:0;text-align:center;line-height:normal'>
          (Name &amp; Designation)
        </p>
     </center> </td>
      <td width="250"  style='width=30%;padding:0in 5.4pt 0in 5.4pt'>
	  <center>
	  <br><br><br><br>
        <p align=center style='margin-bottom:0in;margin-bottom:.0001pt;text-align:center;line-height:normal'>
          <b style='mso-bidi-font-weight:normal'>
            Principal
          </b>
        </p>
        <p align=center style='margin-bottom:0in;margin-bottom:.0001pt;margin-top:0;text-align:center;line-height:normal;font-size:13px;'>
          (Sign. with official seal)
        </p></center>
      </td>
      
	 </tr>
  </table>
  
  <?php
/* file_put_contents('transfer_certificate.htm', ob_get_contents());
sleep(2);
echo "<script>window.location.href='tc_pdf.php';</script>";
ob_end_flush(); */
?>
