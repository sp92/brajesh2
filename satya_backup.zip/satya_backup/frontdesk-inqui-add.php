<?php
$page='frontdesk';
require('core.php');
include('header.php');
if($_SESSION['ACC_FRONTDESK']=='0') 
{
	header("Location: main.php");
}
?>

<div class="container">
	
	<div class="row">
	 <div class="col-md-2 hidden-xs">
<?php print_menu($frontdesk_menu_items); ?>
</div>
		<div class="col-md-6">
		<h3 >Admission Inquiry</h3>
			<form id="add-query" method="post">
				<input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
				<input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>">
				<input type="hidden" name='pic' id='pic'>
				<table class="table">
					<tr>
						<td align=right>Select counselor : </td>
						<td colspan=3 align=left>
							<select name="towhom" id="towhom"  class="required"  >
								<option value="">Select Counselor</option>
										<?php 
										$cols=array('title');
										$db->where('counseller','1');
										$counselor =$db->get ("fd_master", null, $cols);
										foreach($counselor as $title){
										?>
										<option value="<?php echo $title['title'];?>"><?php echo $title['title'];?></option>
										<?php }?>

							</select>
						</td>
					</tr>
					<tr>
						<td align=right>Class : </td>
						<td>
							<select name="class" id="class"  class="required" required >
								<option value="">Select Class</option>
								<?php
								$user = $db->get ("class_master");
								if ($db->count > 0) {
									foreach ($user as $u) { 
								?>			
								<option value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
								<?php } } ?>	
							</select>
						</td>
						<td align=right></td>
						<td></td>
					</tr>
					<tr>
						<td align=right>Student Name: <span class="glyphicon glyphicon-question-sign" id="guide2" ></span></td>
						<td><input type="text" name="stu_name" id="stu_name" style="width:100%;" required /></td>
						<td align=right>Date: </td>
						<td><input type="text" name="rec_date" value="<?php echo date('d/m/Y'); ?>" style="width: 100px;" readonly /></td>
					</tr>
					<tr>
						<td align=right>Father's Name:</td>
						<td><input type="text" name="fat_name" required id="fat_name" style="width:100%;" /></td>
						<td align=right></td>
						<td></td>
					</tr>
					<tr>
						<td align=right>Mother's Name : </td>
						<td ><input type="text" id="mot_name" name="mot_name" required style="width: 100%;" /></td>
						<td align=right>Current School : </td>
						<td ><input type="text" id="last_school" name="last_school" required /></td>
					</tr>
					<tr>
						<td align=right>Address : </td>
						<td ><input type="text" id="address" name="address" required style="width: 100%;" /></td>
						<td align=right>Mobile : </td>
						<td ><input type="text" id="mobile" name="mobile" required /></td>
					</tr>
					<tr>
						<td colspan=4 align=right></td>
				
					</tr>
					<tr>
						<td colspan=2 align=right><input class="btn btn-success" type="submit" id="submit" name="submit" />&nbsp;&nbsp;&nbsp;<input type="reset" class="btn btn-primary" value="Reset"></td>
						<td colspan=2 align=left><div id="divmsg"></div></td>
					</tr>
				</table>
			</form>
		</div>		

				<div  class="col-md-4" id="colmd4">
				<script type="text/javascript" src="assets/js/webcam.js"></script>
				<script language="JavaScript">
				document.write( webcam.get_html(320, 240) );
				</script>
				<br>
				<form>
				<input type="button" value="Take Snapshot" class="ladda-button kill-evo btn-primary" onclick="take_snapshot()">&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://get.adobe.com/flashplayer/" target="_blank">Download Flash Player</a>
				</form>

				<div id="upload_results" style="background-color:#eee;"></div>
				<hr>
				<span id="cap_image"></span>
				</div>		
	</div><hr>
	<style>
#webcam_movie { border: 3px solid; } 
</style>
	<script> 
		$('#add-query').submit(function(event) {
			if(confirm('Confirm?' )) {
				$( "#submit" ).prop('disabled',true);
				$( "#submit" ).val('Processing. Please wait......');
				event.preventDefault();
					$.ajax({
						type: 'POST',
						url: 'function/frontdeskfunctions',
						data: $(this).serialize(),
						success: function (data) {
							//console.log(data);
							$.notify({message: '<strong>Successfully</strong> insert the information.' },{type: 'success'});
							//$('#divmsg').html(data);
							$( "#submit" ).val('Processed. Please refresh.');
						}
					});
			} 
			else {
				event.preventDefault();
				return false;
			}
		});
	 </script>
	<script language="JavaScript">
        webcam.set_api_url( 'function/save_image_from_webcam?enquiry' );
		webcam.set_quality( 100 ); // JPEG quality (1 - 100)
		webcam.set_shutter_sound( false ); // play shutter click sound
		webcam.set_hook( 'onComplete', 'my_completion_handler' );

		function take_snapshot(){
			// take snapshot and upload to server
			document.getElementById('upload_results').innerHTML = '<img src="assets/img/update.gif">';
			webcam.snap();
		}

		function my_completion_handler(msg) {
			// extract URL out of PHP output
			if (msg.match(/jpg/gi)) {
				// show JPEG image in page
				document.getElementById('upload_results').innerHTML ='<h4>Picture Taken!</h4>';
				document.getElementById('pic').value = msg;
				document.getElementById('cap_image').innerHTML = "<img src='pictures/enquiry/"+msg+"' style='width: 122px;'>";
				// reset camera for another shot
				webcam.reset();
			}
			else {alert("PHP Error: " + msg);
		}
		}
	</script>
	<script>
		function HandlePopupResult(result) {
			$("#enq_no").val(result);
			lookItUp2();
		}	
	</script>	
</div>
<?php
include('footer.php');
?>       