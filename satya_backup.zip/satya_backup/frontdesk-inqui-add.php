<?php
$page = 'frontdesk';
require('core.php');
include('header.php');
if ($_SESSION['ACC_FRONTDESK'] == '0') {
    header("Location: main.php");
}
?>
<style>
    .selectimg:hover, .selectedimg{
        border: 2px solid #0044cc;
        cursor: pointer;
    }
    .selectimg img{
        width: 161px;
    }
</style>
<div class="container">

    <div class="row">
        <div class="col-md-2 hidden-xs">
            <?php print_menu($frontdesk_menu_items); ?>
        </div>
        <div class="col-md-6">
            <h3 >Admission Inquiry</h3>
            <form id="add-query" method="post">
                <input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
                <input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php'); ?>">
                <table class="table">
                    <tr>
                        <td align=right>Select counselor : </td>
                        <td colspan=3 align=left>
                            <select name="towhom" id="towhom"  class="required"  >
                                <option value="">Select Counselor</option>
                                <?php
                                $cols = array('title');
                                $db->where('counseller', '1');
                                $counselor = $db->get("fd_master", null, $cols);
                                foreach ($counselor as $title) {
                                    ?>
                                    <option value="<?php echo $title['title']; ?>"><?php echo $title['title']; ?></option>
                                <?php } ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td align=right></td>
                        <td></td>
                        <td align=right></td>
                        <td></td>
                    </tr>
                    <tbody style="border:none;">
                        <tr data-studid="1">
                            <td align=right>Student Name: </td>
                            <td><input type="text" name="stu_name[1]" class="studentrow" style="width:100%;" required="" /></td>
                            <td align=right>Class : </td>
                            <td>
                                <select name="class[1]" style="width:145px;height:24px;"  class="required" required="" >
                                    <option value="">Select Class</option>
                                    <?php
                                    $user = $db->get("class_master");
                                    if ($db->count > 0) {
                                        foreach ($user as $u) {
                                            ?>			
                                            <option value='<?php echo $u['class']; ?>'><?php echo $u['class']; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>	
                                </select>
                            </td>
                        </tr>
                    </tbody>
                    <tr>
                        <td align=right>Father's Name:</td>
                        <td><input type="text" name="fat_name" required id="fat_name" style="width:100%;" /></td>
                        <td align=right>Date: </td>
                        <td><input type="text" name="rec_date" value="<?php echo date('d/m/Y'); ?>" style="width: 145px;" readonly /></td>
                    </tr>
                    <tr>
                        <td align=right>Mother's Name : </td>
                        <td ><input type="text" id="mot_name" name="mot_name" required style="width: 100%;" /></td>
                        <td align=right>Current School : </td>
                        <td ><input type="text" id="last_school" name="last_school" required /></td>
                    </tr>
                    <tr>
                        <td align=right>Address : </td>
                        <td ><input type="text" id="address" name="address" required style="width: 100%;" /></td>
                        <td align=right>Mobile : </td>
                        <td ><input type="text" id="mobile" name="mobile" required /></td>
                    </tr>
                    <tr>
                        <td colspan=4 align=right></td>

                    </tr>
                    <tr>
                        <td colspan=2 align=right><input class="btn btn-success" type="submit" id="submit" name="submit" />&nbsp;&nbsp;&nbsp;<input type="reset" id="reset_add_enquiry" class="btn btn-primary" value="Reset"></td>
                        <td colspan=2 align=left><div id="divmsg"></div></td>
                    </tr>
                </table>
                <div class="row" id="studSnapshotFor"></div>
                <div class="row">
                    <div class="col-md-4 selectimg">
                        <span> Father</span>
                        <div>
                            <img src="assets/img/images.jpg">
                        </div>
                        <input type="hidden" name="fat_pic" value="">
                    </div>
                    <div class="col-md-4 selectimg">
                        <span> Mother</span>
                        <div>
                            <img src="assets/img/images.jpg">
                        </div>
                        <input type="hidden" name="mot_pic" value="">
                    </div>
                    <div class="col-md-4 selectimg">
                        <span> Guardian</span>
                        <div>
                            <img src="assets/img/images.jpg">
                        </div>
                        <input type="hidden" name="guard_pic" value="">
                    </div>
                </div>
            </form>


        </div>		

        <div  class="col-md-4" id="colmd4">
            <script type="text/javascript" src="assets/js/webcam.js"></script>
            <script language="JavaScript">
                document.write(webcam.get_html(320, 240));
            </script>
            <br>
            <form>
                <input type="button" value="Take Snapshot" class="ladda-button kill-evo btn-primary" onclick="take_snapshot()">&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://get.adobe.com/flashplayer/" target="_blank">Download Flash Player</a>
            </form>

            <div id="upload_results" style="background-color:#eee;"></div>
            <hr>
            <span id="cap_image"></span>

        </div>		
    </div><hr>
    <style>
        #webcam_movie { border: 3px solid; } 
    </style>
    <script>
        $('#reset_add_enquiry').click(function () {
            $("tbody").find("tr:first").nextAll("[data-studid]").remove();
            $("#studSnapshotFor").html("");
        });
        $('#add-query').submit(function (event) {
            if (confirm('Confirm?')) {
                $("#submit").prop('disabled', true);
                $("#submit").val('Processing. Please wait......');
                event.preventDefault();
                $.ajax({
                    type: 'POST',
                    url: 'function/frontdeskfunctions',
                    data: $(this).serialize(),
                    success: function (data) {
                        $.notify({message: '<strong>Successfully</strong> insert the information.'}, {type: 'success'});
                        $("#submit").val('Processed. Please refresh.');
                    }
                });
            } else {
                event.preventDefault();
                return false;
            }
        });
    </script>
    <script language="JavaScript">
        webcam.set_api_url('function/save_image_from_webcam?enquiry');
        webcam.set_quality(100);
        webcam.set_shutter_sound(false);
        webcam.set_hook('onComplete', 'my_completion_handler');

        function take_snapshot() {
            document.getElementById('upload_results').innerHTML = '<img src="assets/img/update.gif">';
            webcam.snap();
        }

        function my_completion_handler(msg) {
            if (msg.match(/jpg/gi)) {
                document.getElementById('upload_results').innerHTML = '<h4>Picture Taken!</h4>';
                if ($(".selectedimg").length) {
                    $(".selectedimg").find("input").val(msg);
                    $(".selectedimg").find("img").attr("src", "pictures/enquiry/" + msg);
                } else {
                    alert("Please select person to take snapshot.");
                }
                webcam.reset();
            } else {
                alert("PHP Error: " + msg);
            }
        }
    </script>
    <script>
        function HandlePopupResult(result) {
            $("#enq_no").val(result);
            lookItUp2();
        }
        $("body").delegate(".studentrow", "keyup", function (e) {
            if ($(this).val().trim() != "") {
                var blankRowExist = false;
                $(".studentrow").each(function () {
                    if ($(this).val().trim() == "") {
                        blankRowExist = true;
                    }
                });
                var snapshotForId = $(this).parents("tr").data("studid");
                if (!blankRowExist) {
                    var tr = $(this).parents("tr").clone();
                    if ($(tr).find("td:first a").length == 0) {
                        var removeLink = '<a title="Remove selected student." class="text-danger" onclick="removeStudent(this)" style="cursor:pointer">[x] </a>';
                        $(tr).find("td:first").prepend(removeLink);
                    }
                    var trId = parseInt(snapshotForId) + 1;
                    var stu_name = "stu_name[" + trId+"]";
                    var class_name = "class[" + trId+"]";
                    $(tr).find('input').attr("name", stu_name);
                    $(tr).attr("data-studid", trId);
                    $(tr).find('select').attr("name", class_name);
                    $(tr).find('.studentrow').val("");
                    $(this).parents("tbody").append(tr);
                    $(tr).find("input").prop("required", false);
                    $(tr).find("select").prop("required", false);
                    $(tr).prevAll("[data-studid]").find("input").prop("required", true);
                    $(tr).prevAll("[data-studid]").find("select").prop("required", true);
                    if ($("#snapshotFor_" + snapshotForId).length == 0) {
                        var col = $('<div class="col-md-4 selectimg"></div>');
                        var span = $("<span></span>");
                        var div = $('<div id="snapshotFor_' + snapshotForId + '"></div>');
                        var img = $('<img src="assets/img/images.jpg">');
                        var hidden = $('<input type="hidden" name="pic['+ snapshotForId+']" value="">');
                        $(div).append(img);
                        $(div).append(hidden);
                        $(span).html(" " + $(this).val());
                        $(col).append(span);
                        $(col).append(div);
                        $("#studSnapshotFor").append(col);
                    }
                }
                $("#snapshotFor_" + snapshotForId).prev("span").html(" " + $(this).val());
            } else {
                removeStudent(this);
            }
        });
        $("body").delegate(".selectimg", "click", function () {
            $(".selectedimg").removeClass("selectedimg");
            $(this).addClass("selectedimg");
        });
        function removeStudent(stud) {
            var tr = "#snapshotFor_" + $(stud).parents("tr").data("studid");
            var tbody = $(stud).parents("tbody");
            var cnt = 0;
            $(tbody).find("tr[data-studid]").each(function () {
                if ($(this).find("input").val().trim() == "") {
                    cnt++;
                }
            });
//            alert("cnt");
            if (cnt > 1) {
                $(stud).parents("tr").remove();
                $(tr).parents('.col-md-4').remove();
                if ($(tbody).find("tr:first").find("a").length) {
                    $(tbody).find("tr:first").find("a").remove();
                }
            }
        }
    </script>	
</div>
<?php
include('footer.php');
?>       