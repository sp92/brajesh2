<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="assets/img/favicon.ico">
	<base href="/fee/erp/" />
	<title>:: FEE DEPOSIT :: <?php echo $adm_no; ?> :: <?php echo $data_stu['stu_name']; ?> :: <?php echo $data_stu['class']." - ".$data_stu['sec']; ?> ::</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<link rel="stylesheet" href="assets/css/bootstrap-datepicker3.min.css">
	<link rel="stylesheet" href="assets/css/ladda-themeless.min.css">
    <link href="assets/css/custom.css" rel="stylesheet">
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>