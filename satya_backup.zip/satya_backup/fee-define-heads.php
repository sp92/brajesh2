<?php
$page='fee';
require('core.php');
if($_SESSION['ACC_FEE']=='0') 
{
	header("Location: main.php");
}

$cols = Array ("session","id");
$head_defineSession = $db->get ("head_define", null, $cols);
if(isset($_REQUEST['form']) AND $_REQUEST['form']=='fee-define-heads' AND $_REQUEST['secure_salt']==$_SESSION['SECURE_SALT']) {
	if(isset($_POST) && !empty($_POST)){
		
		$i = 1; $a = 0; $b = 1;
		
		$head_dfn = 'id';
		$fee_amunt = 'fee_cat';
		$fee_paid_column = 'particular';
		$fee_custom = 'adm_no';
		$discountafter = 'remark';
		
		foreach($_POST['field_name'] as $val){
			if($_POST['field_name'][$a] == '' && $_POST['check_month'][head.$b] != ''){
				print_r($_POST['check_month'][head.$b]); exit;
			}
			$a++; $b++;
			if($val != ''){
				
				$head_dfnArr[] = ' ADD head'.$i.' varchar(50) NOT NULL AFTER '.$head_dfn.' ';
				$fee_amuntArr[] = ' ADD head'.$i.'_method varchar(50) NOT NULL AFTER '.$fee_amunt.' ';
				$fee_paidArr[] = ' ADD head'.$i.' int(10) NOT NULL AFTER '.$fee_paid_column.' ';
				$fee_customArr[] = ' ADD head'.$i.'_method varchar(50) NOT NULL AFTER '.$fee_custom.' ';
				$discountArray[] = ' ADD head'.$i.' int(10) NOT NULL AFTER '. $discountafter.'' ;
				
				$head_dfn = "head".$i;
				$fee_amunt = "head".$i."_method";
				$fee_paid_column = "head".$i;
				$fee_custom = "head".$i."_method";
				$discountafter = "head".$i;
				
				$data[$head_dfn] = $val;
				$i++;
			}
		}

		$head_dfnArray = implode(',', $head_dfnArr);
		$fee_amuntArry = implode(',', $fee_amuntArr);
		$feePaidArray = implode(',', $fee_paidArr);
		$fee_customArry = implode(',', $fee_customArr);
		$discountArr = implode(',', $discountArray);

		$db->rawQuery('ALTER TABLE '.PREFIX.'head_define '.$head_dfnArray.';');
		$db->rawQuery('ALTER TABLE '.PREFIX.'fee_amount '.$fee_amuntArry.';');
		$db->rawQuery('ALTER TABLE '.PREFIX.'fee_paid '.$feePaidArray.';');
		$db->rawQuery('ALTER TABLE '.PREFIX.'stu_custom_fee '.$fee_customArry.';');
		$db->rawQuery('ALTER TABLE '.PREFIX.'discount '.$discountArr.';');
		
		$data['transport'] = $_POST['transport'];
		$data['session'] = $_SESSION['SESSION'];
 		if(empty($head_defineSession)){
			$id = $db->insert ('head_define', $data);
		}
		if(!empty($head_defineSession)){
			if($head_defineSession[0]['session'] != $_SESSION['SESSION']){
				$id = $db->insert ('head_define', $data);
			}
		}
		$feeamountafter = 'fee_cat';
		$fee_customafter = 'adm_no';
		
		foreach($_POST['check_month'] as $key=>$value){
			foreach($value as $a=>$v){
				$feeAmountArray[] = ' ADD '.$key.'_'.$v.' int(10) NOT NULL AFTER '. $feeamountafter.'' ;
				$feeamountafter = $key.'_'.$v;
				
				$feeCustomArray[] = ' ADD '.$key.'_'.$v.' int(10) NOT NULL AFTER '. $fee_customafter.'' ;
				$fee_customafter = $key.'_'.$v;
			}
		}
		$feeAmtArr = implode(',', $feeAmountArray);
		$feeCustomArr = implode(',', $feeCustomArray);
				
		$db->rawQuery('ALTER TABLE '.PREFIX.'fee_amount '.$feeAmtArr.';');
		$db->rawQuery('ALTER TABLE '.PREFIX.'stu_custom_fee '.$feeCustomArr.';');
		
		// Add column for transport checkox checked month in stu_tpt_fee table
		
		$stuCustomafter = 'stop';
		foreach($_POST['check_transport'] as $key){
			$stuCustomArray[] = ' ADD tp_'.$key.' int(10) NOT NULL AFTER '. $stuCustomafter.'' ;
			$stuCustomafter = 'tp_'.$key;
		}
		$stuCustomArr = implode(',', $stuCustomArray);
		$db->rawQuery('ALTER TABLE '.PREFIX.'stu_tpt_fee '.$stuCustomArr.';');
	}
}

include('header.php');

?>
<div class="container">
<?php print_menu($fee_menu_items); ?>
<div class="row">
<h3>Define Fee Heads</h3>

<form id="myform" action="" method="POST">
<input type="hidden" name="secure_salt" value="<?php echo $_SESSION['SECURE_SALT']; ?>">
<input type="hidden" name="form" value="<?php echo basename(__FILE__, '.php');  ?>">
	<table class="table">
		<thead>
			<tr>
				<th width="100" class="align-check">Fee Heads:</th>
				<?php
				if(fee_coll_type == 'MONTHLY'){
					foreach($mf_array as $monthleble){ ?>
						<th class="align-check"><?php echo substr($monthleble,0,3); ?></th>
					<?php }
				}
				?>
				<th><a href="javascript:void(0);" data-curr='1' id="add_button" class="add_button glyphicon glyphicon-plus-sign text-success gi-2x" title="Add field"></a></th>
			</tr>
		</thead>
		<tbody class="dynamic-field">
			
			<tr class="item-row">
				<td class="align-check">
					<input type="text" name="field_name[]" required="required" class='head' value="" placeholder='Fee Head Name'/>
				</td>
				<?php
				if(fee_coll_type == 'MONTHLY'){
					foreach($m_array as $monthleble){ ?>
						<td class="align-check"><input type="checkbox" name="check_month[head1][]" value="<?php echo $monthleble; ?>" /></td>
					<?php }
				}
				?>
				<td align="center" width=30>
					
				</td>
			</tr>
		</tbody>
		<tFOOT>
			<tr style="background-color:lightyellow;">
				<td class="align-check"><input type="text" name="transport" placeholder="Transport Head Name" /></td>
				<?php
				if(fee_coll_type == 'MONTHLY'){
					foreach($m_array as $monthleble){ ?>
						<td class="align-check"><input type="checkbox" name="check_transport[]" value="<?php echo $monthleble; ?>" /></td>
					<?php }
				}
				?><td></td>
			</tr>
			<tr>
				<th>
					<?php 
					$cols1 = Array ("session");
					$db->where ("session", $_SESSION['SESSION']);
					$head_define = $db->get ("head_define", null, $cols1);
					if(!empty($head_define)){
						if($head_define[0]['session'] == $_SESSION['SESSION']){?>
								<p style="color:red;">Note: </p><p>Heads information is already avaliable for this session.</p>
				</th>
				<th>	
					<a class="glyphicon glyphicon-edit gi-1x" href="javascript:void(0);"></a>
					<input type="button" name="reset" value="reset" onclick="reset_form()" />
					<?php 	} 
					} else { ?>
				</th>
				<th>
					<?php }?>
				</th>
				<th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th>
				<th>
					<?php
					if(!empty($head_define)){
							if($head_define[0]['session'] != $_SESSION['SESSION']){ ?>
								<button class="btn-primary ladda-button kill" type='submit' data-style="zoom-out"><span class="ladda-label">Create Heads</span></button>
						<?php  } 	
					}
					else if(empty($head_define)){ ?>
						<button class="btn-primary ladda-button kill" type='submit' data-style="zoom-out"><span class="ladda-label">Create Heads</span></button>
					<?php } ?>
				</th>
			</tr>
			
		</tFOOT>
	</table>
</form>
<script type="text/javascript">
	$(document).ready(function(){
		
		var i;
		var pausecontent = new Array();
		var words = <?php echo json_encode($m_array) ?>;// don't use quotes
		var LengthOfText = $('input[name="field_name[]"]').length;
		$.each(words, function(key, value) {
			pausecontent.push(value);
		});
		var n = $("#add_button").data("curr");
		var addButton = $('.add_button'); //Add button selector
		var wrapper = $('.dynamic-field'); //Input field wrapper
		$(addButton).click(function(){ //Once add button is clicked
		//alert(pausecontent.length);
		var dynamic_check = '';
		var LengthOfText = $('input[name="field_name[]"]').length;
		for(i = 0; i < pausecontent.length; i++) { 
			dynamic_check += '<td class="align-check"><input type="checkbox" name="check_month[head'+(LengthOfText+1)+'][]" value="'+pausecontent[i]+'" /></td>';
		}
		var fieldHTML = '<tr class="item-row"><td class="align-check"><input type="text" required="required" class="head" placeholder="Fee Head Name" name="field_name[]" value=""/></td>'+dynamic_check+'<td align=center width=30><a class="delbtn text-danger gi-2x glyphicon glyphicon-remove-sign"   title="Delete field"></a></td></tr>';
		$(wrapper).append(fieldHTML); // Add field html
		dynamic_check = '';
		});
	});

	$(document).on('click', "a.delbtn", function() {
		$(this).parents('.item-row').remove();   
	});	
		
	function reset_form(){
		$.ajax({
			method: 'POST',
			url: 'fee-ajax-reset.php?reset=reset',
			success: function(output){
				if(output == 1){
					$.notify({message: '<strong>Successfully</strong> reset the information.' },{type: 'success'});
					window.location.reload();
				}
				else{
					$.notify({message: 'Failed to reset information.' },{type: 'danger'});
				}
			}
		});
	}
</script>
</div>
</div> <!-- /container -->
<?php
include('footer.php');
?>